using AEAssist;
using AEAssist.CombatRoutine;
using AEAssist.CombatRoutine.Module;
using AEAssist.Extension;
using AEAssist.Helper;
using HealerACR.Common;
using HealerACR.Resolvers;
using HealerACR.Timeline;

namespace HealerACR.Rotations;

/// <summary>学者技能表。技能 ID 走 SpellIds 内置表（中文名）。</summary>
public class SCHSpellTable : JobSpellTable
{
    public override Jobs Job => Jobs.Scholar;
    public override string 职业名 => "学者";

    /// <summary>
    /// 基础输出链 —— ⚠️ **必须按等级从高到低排**。
    ///
    /// `取已解锁` 是"从前往后挑第一个已解锁的" ——
    /// **顺序就是优先级**，等级高的必须排在前面。
    ///
    /// ⚠️ 这里踩过坑（审计发现）：原来是
    ///    `极炎法(82) / 魔炎法(64) / 死炎法(72) / 气炎法(54) / 毁坏(38) / 毁灭(1)`
    ///    —— **魔炎法(64) 排在了 死炎法(72) 前面**，
    ///    于是 **72~81 级取到的是魔炎法**（死炎法是死代码），
    ///    整段等级都在打低一级的填充技。
    ///
    /// 等级（官方 Action 表）：极炎法 82 / 死炎法 72 / 魔炎法 64 /
    ///                        气炎法 54 / 毁坏 38 / 毁灭 1
    /// </summary>
    public override uint 基础输出 => SpellUtil.取已解锁(
        SpellIds.取("极炎法"), SpellIds.取("死炎法"), SpellIds.取("魔炎法"),
        SpellIds.取("气炎法"), SpellIds.取("毁坏"), SpellIds.取("毁灭"));

    /// <summary>药尾声补刀用的瞬发填充技 —— 学者：毁坏（17870）—— 本来就是瞬发，但即刻下能用高一级的极炎法。</summary>
    /// <summary>
    /// **药尾声填充技 = 基础输出**（已解锁的最高档读条技）。
    ///
    /// [!] 原来填的是 `毁坏` —— 但 `毁坏` **本来就瞬发**
    ///     ⇒ `Res_PotionTail` 的 `技本身瞬发 = true` ⇒ 走"直接用填充技"那条，
    ///     **永远不会用即刻咏唱**。
    ///     后果：药尾声只打 毁坏(220)，而不是 即刻 + 极炎法(295/320)，
    ///     **每个爆发药窗口少 75~100 威力**。
    ///
    /// [!] `Res_PotionTail` 的设计意图（它自己的注释）就是
    ///     "即刻咏唱 + 该职业最强的读条填充技"，学者那栏写的是
    ///     `即刻极炎法` —— 所以原来这个配置和 resolver 的期望不一致。
    ///
    /// [!] 80 级以下 `基础输出` 会退回 `毁坏`（本来就瞬发）⇒ 行为不变、无损失；
    ///     80 级以上自动变成 `极炎法` + 即刻。
    /// </summary>
    public override uint 药尾声填充技 => 基础输出;
    public override uint 群体输出 => SpellUtil.取已解锁(
        SpellIds.取("裂阵法"), SpellIds.取("破阵法"));
    // 注意：埋伏之毒**不在这里** —— 它需要"埋伏之毒预备"buff，是独立技能，
    // 由 SCH_BanefulImpaction 处理。当成普通 DoT 塞进链条会永远打不出来。

    // ══════════════════════════════════════════════════════════════════
    //  ★ 治疗候选集 ★  —— 数据来自游戏数据（见 `WhiteMageACR` 同处的说明）
    // ══════════════════════════════════════════════════════════════════
    private 治疗候选集? _治疗候选;

    /// <summary>

    /// **按等级查两档恢复力**（高等级档 / 低等级档）。

    ///

    /// [!] 游戏数据宏的形式是 `if(等级>=N, 高, 低)`。

    ///     来源：`dump_healpot.tsv`（游戏 ActionTransient 说明）。

    ///

    /// [!] 为什么要分档：不分档会把低等级段的恢复力**高估**

    ///     （医术 450/400 ⇒ 85 级以下高估 12.5%），

    ///     而医术 vs 鼓舞激励之策只差 150，就可能翻转选择。

    /// </summary>

    private static int 档位(uint 技能Id, int 高, int 低, int 提升等级)

    {

        try { return CharacterExt.我的等级() >= 提升等级 ? 高 : 低; }

        catch { return 低; }

    }

    
    public override 治疗候选集 治疗候选
    {
        get
        {
            if (_治疗候选 != null) return _治疗候选;

            var c = new 治疗候选集();

            // ── 单体 GCD ──
            // [!] 恢复力**分档**（450/400，85 级提升）——
            //     原来写死 450 ⇒ 85 级以下**高估 12.5%**，
            //     真值来源：`dump_healpot.tsv` 的 `恢复力=450/400`。
            c.加(new 治疗技能 { Id = SpellIds.取("医术"), 名 = "医术", 等级 = 4,
                恢复力 = 档位(SpellIds.取("医术"), 450, 400, 85), MP = 400, 咏唱 = 1.5f, 复唱 = 2.5f });

            // ── 单体 GCD 盾 ──
            c.加(new 治疗技能 { Id = SpellIds.取("鼓舞激励之策"), 名 = "鼓舞激励之策", 等级 = 30,
                恢复力 = 300, MP = 900, 咏唱 = 2.0f, 复唱 = 2.5f, 是盾 = true });

            // ── 群体 GCD 盾 ──
            // ══════════════════════════════════════════════════════════════
            //  [!] **修正：盾被算了两次**（数据核对发现）
            //
            //      原来写 `恢复力 = 520`（= 200 × 2.6，已把盾折进去）
            //      **同时又标 `是盾 = true`** ⇒ 打分里 `盾真实系数` 会**再加一次盾**。
            //
            //      真值（`dump_healpot.tsv` 原文）：
            //          恢复力：200
            //          追加效果：附加防护罩，**抵消相当于治疗量%的伤害**  持续 30 秒
            //      ⇒ 治疗 200 + 盾（100%）⇒ 恢复力写 **200**，盾交给 `是盾` 处理。
            // ══════════════════════════════════════════════════════════════
            c.加(new 治疗技能 { Id = SpellIds.取("士气高扬之策"), 名 = "士气高扬之策", 等级 = 35,
                恢复力 = 200, MP = 900, 咏唱 = 2.0f, 复唱 = 2.5f, 群体 = true, 是盾 = true });

            // [!] 盾 **180%**（数据核对）——
            //     原文：「该防护罩能够抵消相当于治疗量 **180%** 的伤害」
            //     `减伤状态表.护盾` 查不到这个倍率（它写在技能说明里），
            //     所以必须由候选自己给出，否则会退回 0.5 兜底，低估 3.6 倍。
            c.加(new 治疗技能 { Id = SpellIds.取("意气轩昂之策"), 名 = "意气轩昂之策", 等级 = 96,
                恢复力 = 200, MP = 900, 咏唱 = 2.0f, 复唱 = 2.5f, 群体 = true,
                是盾 = true, 盾百分比 = 180 });

            // ── 单体能力技 ──
            c.加(new 治疗技能 { Id = SpellIds.取("生命活性法"), 名 = "生命活性法", 等级 = 45,
                恢复力 = 600, MP = 0, 咏唱 = 0f, 冷却 = 1f, 资源消耗 = 1 });

            c.加(new 治疗技能 { Id = SpellIds.取("深谋远虑之策"), 名 = "深谋远虑之策", 等级 = 62,
                恢复力 = 800, MP = 0, 咏唱 = 0f, 冷却 = 45f });

            // ── 群体能力技 ──
            c.加(new 治疗技能 { Id = SpellIds.取("不屈不挠之策"), 名 = "不屈不挠之策", 等级 = 52,
                恢复力 = 400, MP = 0, 咏唱 = 0f, 冷却 = 30f, 群体 = true, 资源消耗 = 1 });

            // [!] **修正：凭空虚构了一个 HoT**（数据核对发现）
            //     真值（`dump_healpot.tsv` 原文）：
            //         「恢复自身及周围队员的体力　恢复力：320　发动条件：小仙女处于同行状态」
            //     ⇒ **纯直疗，没有 HoT**。
            //     原来多写了 `HoT恢复力 = 320, HoT持续 = 21f` ——
            //     `总恢复力` 会从 320 变成 320 + 320×(21/3)×0.6 = **1664**，
            //     把它算成了 5 倍的治疗量，会严重挤掉真正该用的技能。
            c.加(new 治疗技能 { Id = SpellIds.取("异想的祥光"), 名 = "异想的祥光", 等级 = 76,
                恢复力 = 320, MP = 0, 咏唱 = 0f, 冷却 = 60f, 群体 = true });

            // [!] **补上盾标记**（数据核对发现漏了）
            //     真值（`dump_healpot.tsv` 原文）：
            //         「恢复周围队员的体力　恢复力：250
            //           追加效果：附加防护罩，**抵消相当于治疗量 100% 的伤害**　持续 30 秒」
            //     ⇒ 250 治疗 + 等量盾 = 一份能力技干两份活，原来完全没算盾。
            c.加(new 治疗技能 { Id = SpellIds.取("慰藉"), 名 = "慰藉", 等级 = 80,
                恢复力 = 250, MP = 0, 咏唱 = 0f, 冷却 = 30f, 群体 = true, 充能 = 2,
                是盾 = true, 盾百分比 = 100 });

            // [!] **修正：它是纯 HoT，没有直疗**（数据核对发现）
            //     真值（`dump_healpot.tsv` 原文）：
            //         「持续恢复周围队员的体力　恢复力：80　持续时间：21秒」
            //     ⇒ 80 是**每跳**，不是"直疗 80 + HoT 80"。
            //     原来写 `恢复力 = 80`（直疗）+ `HoT恢复力 = 80` ⇒ 多算了一口直疗。
            c.加(new 治疗技能 { Id = SpellIds.取("仙光的低语"), 名 = "仙光的低语", 等级 = 20,
                恢复力 = 0, MP = 0, 咏唱 = 0f, 冷却 = 60f, 群体 = true,
                HoT恢复力 = 80, HoT持续 = 21f });

            _治疗候选 = c;
            return c;
        }
    }

    public override uint Dot技能 => SpellUtil.取已解锁(
        SpellIds.取("蛊毒法"), SpellIds.取("猛毒菌"), SpellIds.取("毒菌"));
    public override uint DotBuff => AuraIds.学者Dot;
    // 蛊毒法有三档 id（1895 / 2039 / 3089）
    public override uint[] 所有DotBuff => new[]
    {
        AuraIds.学者Dot, AuraIds.学者DotAlt, AuraIds.学者DotAlt2, AuraIds.学者Dot2, AuraIds.学者Dot1
    };

    public override uint 单体治疗GCD => SpellUtil.取已解锁(SpellIds.取("鼓舞激励之策"), SpellIds.取("医术"));
    public override uint 群体治疗GCD => SpellIds.取("士气高扬之策");

    // ⚠️ **绿帽不在这里** —— 它原先是 `取已解锁(深谋远虑之策, 生命活性法)`，
    //    被当成"紧急单奶"，而急救判据是血 < 30%。
    //    日志实证：坦克一直在 80%，于是**绿帽一次都没放过**
    //    （那一场 61 次单盾 / 0 次绿帽）。
    //    绿帽是 45 秒 CD 的**预铺**技能（挂上后目标掉到阈值自动触发治疗），
    //    所以归到 `预铺单奶能力技`。详见 JobSpellTable 那一栏的说明。
    public override uint 紧急单奶 => SpellIds.取("生命活性法");

    /// <summary>绿帽：45 秒 CD 的预铺 —— 给坦克挂上，掉血时自动触发治疗。</summary>
    public override uint 预铺单奶能力技 => SpellIds.取("深谋远虑之策");

    /// <summary>生命活性法：不读条、能移动中用的单体治疗。</summary>
    public override uint 瞬发单奶能力技 => SpellIds.取("生命活性法");

    /// <summary>
    /// 活性法阈值 **45%**（参考实现 IL 直读的 `活性法阈值 = 45`）。
    ///
    /// ⚠️ 比绿帽的 60% **低** —— 这个分层就是"能力技优先"的实现：
    ///      绿帽   60%  ← 45 秒 CD，预铺
    ///      活性法 45%  ← 应急瞬发
    ///      单盾   45%  ← GCD 读条（等量时能力技排前面，所以它先出）
    /// </summary>
    public override float 瞬发单奶血线 => 0.45f;

    public override uint 群体治疗能力技 => SpellIds.取("不屈不挠之策");
    public override uint 单体盾 => SpellIds.取("鼓舞激励之策");

    /// <summary>
    /// **群体盾：士气高扬之策**（审查发现原来没填 = 0）。
    ///
    /// [!] 后果：`Res_Mitigation` 的 AoE 盾分支读 `群体盾`，
    ///     为 0 时直接 `return -102` —— **减伤侧完全不知道学者有群盾**，
    ///     只会走治疗通路（治疗候选里有它，但那是"补血"语义，不是"预防"）。
    ///
    /// [!] 官表说明核实：士气高扬之策 = 恢复力 200 +
    ///     "附加能够抵御一定伤害的**防护罩**" —— 确实是盾。
    /// </summary>
    public override uint 群体盾 => SpellIds.取("士气高扬之策");
    public override uint 团队减伤 => SpellIds.取("野战治疗阵");

    public override uint 复活 => SpellIds.取("复生");
    public override uint 驱散 => SpellsDefine.Esuna;
    public override uint 醒梦 => SpellsDefine.LucidDreaming;

    // 需求 3：以太就是学者的"群奶能力技资源"，没以太就退回 GCD 群奶
    public override bool 治疗资源充足 => JobApiHelper.以太 >= HealSettings.Instance.以太保留数;

    // 需求 4：脱战把以太补上
    public override uint[] 脱战准备技能 => new[] { SpellIds.取("以太超流") };

    /// <summary>
    /// **召唤小仙女**（朝日召唤 17215，Lv4）。
    ///
    /// ⚠️ 这是学者治疗体系的地基，不是可选项：
    ///     · 「异想的祥光」—— 免费群体治疗
    ///     · 「异想的幻光」—— 免费群体减伤 + 治疗量提升
    ///     · 「以太契约」—— 给小仙女指定目标持续回血
    ///     · 「炽天召唤」—— 把小仙女升级成炽天使，解锁慰藉群盾
    ///     小仙女不在场时这些**全部放不出来**。
    ///
    /// ⚠️ 版本里**没有**单独的「夕月召唤」—— 查过官方技能表
    ///     （`dump_actions.tsv`），学者 Lv4 只有 17215「朝日召唤」这一个。
    ///     所以不做一个"选哪个仙女"的开关，那是多余的。
    /// </summary>
    public override uint 召唤宠物 => SpellIds.取("朝日召唤");

    // 移动填充：毁坏（Ruin II）是瞬发的，边走边打不掉输出
    public override uint 移动填充技 => SpellIds.取("毁坏");

    /// <summary>
    /// **站定填充技：毁灭** —— 站定时比「毁坏」多 10 威力。
    ///
    /// [!] 用户实测指出的问题（"远处应该打毁灭，而不是毁坏，少10威力"）：
    ///     50 级时 `基础输出` 解析成 **毁坏（140，瞬发）**，
    ///     而站定该用 **毁灭（150，读条 1.5s）**。
    ///
    ///     瞬发的代价就是威力低 —— 站定没有任何理由让这 10 点。
    ///
    /// [!] 为什么单独一个槽位而不是改 `基础输出` 的链条顺序：
    ///     那条链是"取进阶最高的"，毁坏(38) 确实比 毁灭(1) 进阶高 ——
    ///     顺序没错。**错的是"瞬发技在站定时也更优"这个隐含假设**。
    ///     所以补一个"站定专用"槽位，而不是动那条链。
    /// </summary>
    public override uint 站定填充技 => SpellIds.取("毁灭");

    /// <summary>
    /// **贴身时用破阵法代替毁坏** ——
    ///   破阵法 600 威力 / 瞬发 / 以自己为中心 5 米
    ///   毁坏   500 威力 / 瞬发
    /// ⇒ 站在近战位时破阵法**高 100 威力（+20%）**。
    ///
    /// ⚠️ 82 级后是 `裂阵法`（25866，威力 700）——
    ///    和 `群体输出` 一样走 `SpellUtil.当前形态()` 自动升级，
    ///    所以这里填**低级那个**即可。
    /// </summary>
    public override uint 近战填充技 => SpellIds.取("破阵法");

    /// <summary>
    /// **自身 AOE 技**（`CastType=2 Range=0`，以自己为中心）。
    ///
    /// ⚠️ 数据依据（`tools\CastProbe`）：
    ///       破阵法 16539  Lv46  咏唱**0.0**  射程0  范围5  威力 if(54)165 else 150
    ///       裂阵法 25866  Lv82  咏唱**0.0**  射程0  范围5  威力 180
    /// </summary>
    public override uint[] 自身AOE候选 => new[]
    {
        SpellIds.取("裂阵法"),    // 82 级
        SpellIds.取("破阵法"),    // 46 级
    };

    /// <summary>自身 AOE 的半径（学者是 5 米）</summary>
    public override (bool 是, float 半径) 自身AOE半径(uint 技能Id)
        => (技能Id == SpellIds.取("破阵法") || 技能Id == SpellIds.取("裂阵法"))
            ? (true, 5f) : (false, 0f);

    /// <summary>
    /// 贴身距离门槛 = **5 米**。
    ///
    /// ⚠️ 表里的默认值是 3，那个**偏小** —— 查官方技能表
    /// （`dump_actions.tsv`，逐字）：
    ///     16539 破阵法  学者 46  CastType=2  Range=0  **EffectRange=5**
    ///     25866 裂阵法  学者 82  CastType=2  Range=0  **EffectRange=5**
    ///     CastType=2 = **以自己为中心**的范围技
    /// ⇒ 半径就是 5 米。设成 3 的话，**3~5 米这一段会被判"够不着"**，
    ///   白白打了低一级的填充技（毁坏 500 威力 vs 破阵法 600）。
    ///
    /// 参考实现在同一处用的也是 5（IL 里的 `Ldc_r4 5`）。
    /// </summary>
    public override float 近战填充距离 => 5f;

    /// <summary>
    /// **威力档位** —— 用来判断"贴身时该用破阵法还是毁坏"。
    ///
    /// ══════════════════════════════════════════════════════════════
    ///  ★ 数据逐字来自**游戏数据宏**（不是攻略站的数字）★
    ///
    ///    用 `tools\HealPotency` 的 `raw` 模式解出（`ToMacroString()`）：
    ///
    ///      破阵法 16539:
    ///        <if([gnum68==28], <if([gnum72>=54], 165, 150)>, 150)>
    ///         └ 是学者 ┘        └ 等级≥54 ┘  高   低
    ///
    ///      毁坏 17870:
    ///        <if(学者, <if(等级>=82, 220,
    ///              <if(等级>=72, 200,
    ///              <if(等级>=64, 180,
    ///              <if(等级>=54, 160, 140)>)>)>)>, 140)>
    ///
    ///      裂阵法 25866:  180（**无档位**，恒定）
    ///      极炎法 25865:  <if(学者, <if(等级>=94, 320, 295)>, 295)>
    ///
    ///  ★ 为什么必须按等级比（而不是固定用一个）★
    ///
    ///    两者的相对高低**随等级翻转**：
    ///        46~53  破阵法 150 > 毁坏 140   ← 贴身该用**破阵法**
    ///        54~63  破阵法 165 > 毁坏 160   ← 还是破阵法
    ///        64~71  毁坏   180 > 破阵法 165 ← **翻转！**该用毁坏
    ///        72~81  毁坏   200 > 破阵法 165
    ///        82+    毁坏   220 > 裂阵法 180
    ///
    ///  ⚠️ 我曾经两次判错这件事：
    ///    ① 凭印象说"破阵法 600 > 毁坏 500"（那两个数没有出处）
    ///    ② 拿 The Balance 的 **100 级**数据（毁坏 220 / 裂阵法 180）
    ///       去判断 50 级 —— 而 50 级其实是 破阵法 150 / 毁坏 140，
    ///       **结论正好相反**。
    ///    威力**每个资料片都会重做**，且**每级档位不同** ——
    ///    必须按当前等级查。
    /// ══════════════════════════════════════════════════════════════
    /// </summary>
    /// <summary>
    /// **咏唱时间**（秒）—— 数据来自 `tools\CastProbe`（游戏 `Cast100ms` 字段）。
    ///
    /// ⚠️ 学者的读条填充技**全是 1.5 秒**，瞬发的全是 0 ——
    ///    而复唱都是 2.5 秒，所以两者都只占一个 GCD，
    ///    **咏唱时间在"选最优"的排序里约掉了**（比威力即可）。
    ///    见 `JobSpellTable.咏唱时间表` 的说明。
    /// </summary>
    public override IReadOnlyDictionary<uint, float> 咏唱时间表 { get; } = new Dictionary<uint, float>
    {
        [SpellIds.取("毁灭")]   = 1.5f,
        [SpellIds.取("毁坏")]   = 0f,      // 瞬发
        [SpellIds.取("破阵法")] = 0f,      // 瞬发
        [SpellIds.取("裂阵法")] = 0f,      // 瞬发
        [SpellIds.取("气炎法")] = 1.5f,
        [SpellIds.取("魔炎法")] = 1.5f,
        [SpellIds.取("死炎法")] = 1.5f,
        [SpellIds.取("极炎法")] = 1.5f,
    };

    protected override (int 等级, int 威力)[]? 威力表(uint 技能Id)
    {
        // 破阵法（46 级学）→ 54 级提升一档
        if (技能Id == SpellIds.取("破阵法"))
            return new[] { (54, 165), (0, 150) };

        // 裂阵法（82 级学）—— 无档位
        if (技能Id == SpellIds.取("裂阵法"))
            return new[] { (0, 180) };

        // ══════════════════════════════════════════════════════════════
        //  ★ 毁灭 —— **必须在这一档里**（用户实测发现缺失）★
        //
        //  [!] 现象：AI 连续 34 次建议 `17870`（毁坏），本地每次选
        //      `17869`（毁灭）—— **本地是对的**。
        //
        //  [!] 为什么 AI 选错：`威力表` 里**没有毁灭** =>
        //      `查威力(毁灭)` 返回 0 => 即使 prompt 给了"力NNN"字段，
        //      AI 也只看到 毁坏=140、毁灭=（空）—— 只能保守选瞬发的那个。
        //
        //  [!] 真值：毁坏 50 级 = 140（瞬发）；毁灭 = 150（1.5 秒读条）。
        //      站定 -> 150 更优；移动 -> 只能 140。
        //      补齐之后 AI 才能做这个比较。
        // ══════════════════════════════════════════════════════════════
        if (技能Id == SpellIds.取("毁灭"))
            return new[] { (0, 150) };

        // 毁坏（38 级学）→ 54 / 64 / 72 / 82 各提一档
        if (技能Id == SpellIds.取("毁坏"))
            return new[] { (82, 220), (72, 200), (64, 180), (54, 160), (0, 140) };

        // ══════════════════════════════════════════════════════════════
        //  ★ 魔炎法(64) / 死炎法(72) —— **补上，否则 64~81 级在打错技能** ★
        //
        //  [!] 现象（逐等级模拟发现）：
        //      64~81 级 `基础输出` 解析成 魔炎法 / 死炎法，
        //      而威力表**没有这两个** ⇒ `查威力` = 0 ⇒ 选不出来
        //      ⇒ 逐级落到「破阵法 165」⇒ **每发少打 75~90 威力**
        //        （魔炎法 240 / 死炎法 255  vs  破阵法 165）。
        //
        //  [!] 数值来源：**官方 `Action:<id>` 页**（wiki，权威）——
        //        `炎法精通II`（64级）：气炎法变为魔炎法，并将毁坏的威力提高到180
        //        `炎法精通III`（72级）：魔炎法变为死炎法，并将毁坏的威力提高到200
        //      ⇒ 240 / 255 是官方写明的，不是估的。
        //
        //  [!] 顺带证实：官方的"精通"特性把每个副作用都写明了，
        //      所以下面 破阵法(165@54) / 毁坏(160/180/200/220) 的档位**都是对的**。
        // ══════════════════════════════════════════════════════════════
        if (技能Id == SpellIds.取("魔炎法"))
            return new[] { (0, 240) };

        if (技能Id == SpellIds.取("死炎法"))
            return new[] { (0, 255) };

        // 极炎法（82 级学）→ 94 级提升一档
        if (技能Id == SpellIds.取("极炎法"))
            return new[] { (94, 320), (0, 295) };

        // ══════════════════════════════════════════════════════════════
        //  ★ 气炎法（54 级学）★ —— 补上，否则 54~81 级 AI 看不到它的威力
        //
        //  [!] 缺口：`基础输出` 的链条是
        //        极炎法(82) / 死炎法(72) / 魔炎法(64) / 气炎法(54) / 毁坏(38) / 毁灭(1)
        //      而 `威力表` 只覆盖了 破阵法/裂阵法/毁灭/毁坏/极炎法 ——
        //      **气炎法、死炎法、魔炎法全都不在里面** => `查威力` 返回 0。
        //
        //  ⇒ 54~81 级时 `基础输出` 取到气炎法，但清单里它的威力是空的，
        //     AI 只能拿它跟"毁坏 140"比 —— 而气炎法实际是 **220**，
        //     **每发少 80 威力**（比用户发现的 -10 严重得多）。
        //
        //  [!] 只写有依据的档位。不确定的**宁可不写** ——
        //      错的威力会让 AI 选错技能，比缺一个数字更糟。
        // ══════════════════════════════════════════════════════════════
        if (技能Id == SpellIds.取("气炎法"))
            return new[] { (0, 220) };

        // ══════════════════════════════════════════════════════════════
        //  ★ DoT 三档 + 能量吸收 —— **补上缺口**（用户要求：缺口会影响 AI 决策）★
        //
        //  [!] 为什么原来缺：**游戏数据宏不写它们的威力** ——
        //      `pow_potency.tsv` 里这三条只有
        //        「对目标附加无属性持续伤害状态」，**没有「威力：」那一句**。
        //      所以按数据宏建表时它们全是空的。
        //
        //  [!] 数值来源：`beta.xivapi.com/api/1/sheet/Action/<id>`
        //      （游戏 Action 表 + ActionTransient 的镜像）—— **不是攻略站**。
        //      逐字原文：
        //        17864 毒菌    Deals unaspected damage over time. Potency: 20  Duration: 30s
        //        17865 猛毒菌  Deals unaspected damage over time. Potency: 40  Duration: 30s
        //        16540 蛊毒法  Deals unaspected damage over time. Potency: 85  Duration: 30s
        //        167   能量吸收 Deals unaspected damage with a potency of 100.
        //
        //  [!] 口径 = **每跳**（和 `HoT恢复力` 同语义）——
        //      这三个 DoT 的描述里**只有一个 Potency**（它们没有直伤），
        //      和白魔「天辉 85」「烈风 50」同一口径（见 `WhiteMageACR.cs` L98-101）。
        //
        //  [!] 为什么值得补：
        //      DoT 走 `值得上Dot()`（判血量/血量倍数）**不比较威力** ——
        //      所以缺口**不会导致选错技能**。
        //      但提示词里 `力N` 空着时，AI 判该不该补 DoT只能凭训练记忆，
        //      这正是用户说的会影响 AI 决策。
        // ══════════════════════════════════════════════════════════════
        if (技能Id == SpellIds.取("毒菌")) return new[] { (0, 20) };
        if (技能Id == SpellIds.取("猛毒菌")) return new[] { (0, 40) };
        if (技能Id == SpellIds.取("蛊毒法")) return new[] { (0, 85) };
        
        // 能量吸收：直伤（不是 DoT），同样是输出能力技里唯一缺威力的那条
        if (技能Id == SpellIds.取("能量吸收")) return new[] { (0, 100) };
        
        return null;
    }

    // 能量吸收是"以太换输出"，卡 CD 打（跟法令一个道理）
    // 能量吸收是拿以太换输出。
    // ⚠️ 关键：以太**读不到**时不能判死 —— JobApiHelper 读失败会返回 0，
    //    如果直接写 "以太 >= 1"，读不到就等于"永远没以太"，永远不打能量吸收。
    /// <summary>
    /// 输出能力技（能量吸收）—— **默认留着，只在两种时机卸**。
    ///
    /// ══════════════════════════════════════════════════════════════════
    ///  ★ 机制（替换原来的"有豆子就卸"）★
    ///
    ///    **默认留**，只有满足下面任一条才打能量吸收：
    ///
    ///    ① **开爆发** —— 爆发窗口里豆子就该换输出，不受保留数限制
    ///    ② **以太超流快转好了**，且**无治疗压力** ——
    ///       在它转好之前把豆子清空
    ///
    ///  ── 为什么②是对的（这段是理解的关键）──
    ///
    ///    以太超流的机制是**补满到 3 颗**，**不是"加 3 颗"**。
    ///    所以如果它转好时你手里还攥着豆子，**那些豆子直接白溢出**。
    ///
    ///    ⇒ 在它转好前把手里清空 = **白赚输出**，没有任何代价。
    ///    ⇒ 反过来，转好还早的时候卸豆就是纯亏 ——
    ///       因为豆子留在手里既能应急、又能在它补满前一直存着。
    ///
    ///    这就是"默认留"的全部道理：**留到快溢出为止**。
    ///
    ///  ── 旧逻辑错在哪（留个记录，别再改回去）──
    ///
    ///    原来是"队伍血量健康 + 以太 > 保留数 → 卸"，
    ///    再加上"小怪阶段卸到剩 1 颗"和"满 3 颗必卸"。
    ///    问题：**转好还早就把豆子打光了**，
    ///    等到以太超流转好时手里没豆子，那 3 颗就只是"补回来"，
    ///    没有产生任何额外输出 —— 等于把资源浪费在"提前打掉"上。
    ///
    ///  ⚠️ 读不到以太时**不卸**（保守）：
    ///     旧代码是"读不到就卸"（`if (!读得到) return new[]{能量吸收}`）——
    ///     那在读取接口抽风时会把豆子无脑打光。现在改成读不到就留着。
    ///
    ///  ⚠️ 「以太保留数」设置有冲突：
    ///     新机制下"留着"是默认行为，这个设置已经**没有意义**了
    ///     （它想表达的"留几颗"就是现在的默认）。
    ///     保留它只是为了不破坏旧存档，界面上仍可调但不影响本逻辑。
    /// ══════════════════════════════════════════════════════════════════
    /// </summary>
    public override uint[] 输出能力技
    {
        get
        {
            var 能量吸收 = SpellIds.取("能量吸收");
            if (能量吸收 == 0) return Array.Empty<uint>();

            // ⚠️ 读不到以太 → **留着**（不要卸）。
            //    方向很重要：读不到就卸的话，接口一抽风豆子就没了。
            if (!JobApiHelper.读得到("以太")) return Array.Empty<uint>();

            // 总开关（用户可能想完全禁掉卸豆）
            if (!HealQt.GetQt("能量吸收", true)) return Array.Empty<uint>();

            // 蓝量见底时停手 —— 蓝要留给治疗
            if (蓝量.低蓝停手()) return Array.Empty<uint>();

            var 以太 = JobApiHelper.以太;
            if (以太 <= 0) return Array.Empty<uint>();   // 没豆子，等以太超流补

            // ── 条件①：爆发窗口 → 拿去换输出 ──
            if (以太管理.在爆发窗口()) return new[] { 能量吸收 };

            // ── 条件②：以太超流快转好 + 无治疗压力 → 清空免得溢出 ──
            // ══════════════════════════════════════════════════════════════
            //  ★ 卸豆诊断（用户报告「转好前没把豆子用完」）★
            //
            //  [!] 为什么要打这个：
            //      用户实测「以太超流补满 16 次 / 能量吸收 0 次」。
            //      但**那条日志大部分在脱战**（`以太超流` 只能战斗中放），
            //      所以那个数字**不能证明卸豆逻辑坏了**。
            //      ==> 让代码自己说：把判据的每一项都打出来。
            //
            //  [!] 只在该卸的窗口里打（`以太超流快转好()` 成立 + 有豆子），
            //      否则每帧一条会把日志刷满。
            // ══════════════════════════════════════════════════════════════
            if (以太 > 0 && 以太管理.以太超流快转好())
            {
                try
                {
                    var 告急人数 = HealTargetHelper.低于阈值人数(HealSettings.Instance.紧急单奶阈值);
                    var 群疗线人数 = HealTargetHelper.低于阈值人数(HealSettings.Instance.群体治疗阈值);
                    LogHelper.Info($"[卸豆] 以太={以太} 快转好=True" +
                                   $" 告急线={HealSettings.Instance.紧急单奶阈值:F2}({告急人数}人)" +
                                   $" 群疗线={HealSettings.Instance.群体治疗阈值:F2}({群疗线人数}人)" +
                                   $" 爆发窗口={以太管理.在爆发窗口()}" +
                                   $" => {(告急人数 == 0 ? "全卸" : "留着（有人告急）")}");
                }
                catch { }
            }
            
            // ══════════════════════════════════════════════════════════════
            //  ★ 条件②：以太超流快转好 -> **把剩下的豆子全卸掉** ★
            //
            //  [!] 机制（游戏数据，`Action:166`）逐字：
            //        "Restores 20% of maximum MP."
            //        "Additional Effect: **Aetherflow III**"
            //        "**Can only be executed while in combat.**"
            //      ==> 它**补满到 3 颗**（不是加 3 颗）。
            //          所以转好时手里还有豆子 -> **那些豆子白溢出**。
            //          转好前清空 = **白赚 100 威力 × N**。
            //      ==> 这是用户明确要求的：「下一个以太超流转好了记得把剩下的豆子全用了，
            //          没治疗缺口就能量吸收，不要浪费豆子」
            //
            //  [!] 判据 = **没有人告急**（不是没有人低于群疗线）——
            //
            //      原来写的是 `低于阈值人数(群体治疗阈值 = 0.62) == 0`，
            //      那是必须零治疗压力才敢卸。**太严了**：
            //        只要有 1 个人在 61% -> 一颗都不卸 -> 快转好时 3 颗全溢出。
            //      而真正的风险窗口只有**那 8 秒** —— 8 秒后补满到 3，
            //      我们卸掉的每一颗都换来实打实的 100 威力。
            //      ==> 改成只看有没有人告急：
            //            有人低于 `紧急单奶阈值`（默认 0.30）-> 留着（那才是真需要瞬时 Ability 的场景）
            //            无人告急                              -> 全卸
            //
            //  ⚠️ **不看 `以太保留数`**（用户设的那个）——
            //      快转好时那颗豆子**马上就会被覆盖掉**，留着等于白扔。
            //      保留数只在没快转好时有意义，而那条路已经无条件留着（见函数末尾）。
            // ══════════════════════════════════════════════════════════════
            if (以太管理.以太超流快转好())
            {
                var 告急人数 = 0;
                try { 告急人数 = HealTargetHelper.低于阈值人数(HealSettings.Instance.紧急单奶阈值); }
                catch { }
            
                // 没人告急 -> 全卸（8 秒后补满，等于白赚输出）
                if (告急人数 == 0) return new[] { 能量吸收 };
            }

            // ── 其他情况：一律留着 ──
            return Array.Empty<uint>();
        }
    }
}

public class SCHRotationEntry : HealerEntryBase
{
    private readonly SCHSpellTable _spells = new();

    public override Jobs TargetJob => Jobs.Scholar;
    public override string OverlayTitle => "小鲸鱼 · 学者（日随）";
    public override string Description =>
        "日随用学者 ACR。以太优先，小仙女 / 炽天使自动放，时间轴预报到伤害时拉炽天使。\n" +
        "1-100 级通用；脱战自动补以太，木桩模式打最优输出。";
    public override JobSpellTable Spells => _spells;

    protected override List<SlotResolverData> 构建决策队列_职业专属()
    {
        return new List<SlotResolverData>
        {
            new SlotResolverData(new Res_Sprint(), SlotMode.Always),              // 脱战自动疾跑
            new SlotResolverData(new SCH_AutoDissipation(), SlotMode.Always),   // 转化换豆（默认关）
            new SlotResolverData(new SCH_ForceAetherflow(), SlotMode.Always),   // 手动强制补（默认关）
            new SlotResolverData(new SCH_Aetherflow(), SlotMode.Always),   // 按错题集：能力技进 Always，不受 GCD 就绪的影响
            new SlotResolverData(new SCH_ChainStratagem(), SlotMode.Always),   // 按错题集：能力技进 Always，不受 GCD 就绪的影响
            new SlotResolverData(new Res_OffensiveAbility(_spells), SlotMode.Always),   // 按错题集：能力技进 Always，不受 GCD 就绪的影响
            // 宠物不在场就召唤（学者的朝日召唤）—— 排在脱战准备之前
            new SlotResolverData(new Res_SummonPet(_spells), SlotMode.Gcd),
            new SlotResolverData(new Res_PrepareResources(_spells), SlotMode.OffGcd),
            new SlotResolverData(new Res_Raise(_spells), SlotMode.Gcd),
            new SlotResolverData(new Res_Esuna(_spells), SlotMode.Gcd),
            // ★ 「必须奶满」机制 —— 插在最前面，理由是行号才是优先级。
            //   这类 debuff 是“奶到 100% 才解除”，晚一个 GCD 人就没了；
            //   而 Check() 的返回值**不参与仲裁**（反汇编已证），只有行号算数。
            //   原来它排在所有治疗 GCD 之后 —— 场上有人被再生/医济抢走 GCD 时，
            //   就永远轮不到它。详见 Res_MustFullHeal 的类注释。
            new SlotResolverData(new Res_MustFullHeal(_spells), SlotMode.Gcd),
            // ★ 预铺 / 瞬发治疗能力技 —— **必须在所有治疗 GCD 之前**。
            //   需求是“治疗应该优先能力技 / 不读条的技能”，
            //   而 Check() 的返回值**不参与仲裁** —— 排在哪一行才算数。
            //   参考实现的 resolver 列表也是能力技在前（IL 直证）。
            //   详见 Res_InstantHealAbility 的类注释。
            new SlotResolverData(new Res_HealEmergency(_spells), SlotMode.OffGcd),
            new SlotResolverData(new Res_InstantHealAbility(_spells), SlotMode.OffGcd),
            new SlotResolverData(new SCH_Accession(), SlotMode.Gcd),                 // 降临之章（炽天附体期间）
                        // ══════════════════════════════════════════════════════════════
            //  ★ 移动中开即刻咏唱 ★
            //
            //  [!] 为什么需要（用户实测："全程移动 ai 不奶了"）：
            //      `SpellUtil.移动中能放()` 只**尊重**即刻 buff，
            //      **没有任何地方主动开它** —— 全项目只有 `Res_PotionTail`
            //      （爆发药）和 `Res_Raise`（拉人）用了即刻。
            //      => 移动中所有读条治疗/盾全被挡住，oGCD 治疗资源一空就一口都放不出来。
            //
            //  [!] 位置：在第一个 GCD 治疗之前（否则那个 GCD 会被别处抢走），
            //      但在 `Res_MustFullHeal` / `Res_HealEmergency` / `Res_Raise` 之后
            //      —— 那些是真救命，不能被"开即刻"抢在前面。
            //
            //  [!] 它自己会判"真的有东西需要即刻吗"（血线告急 / 马上挨大伤害），
            //      不是一移动就烧 60 秒 CD —— 详见 Res_移动开即刻 的注释。
            // ══════════════════════════════════════════════════════════════
            new SlotResolverData(new Res_移动开即刻(_spells), SlotMode.Gcd),
            new SlotResolverData(new Res_HealAoEGcd(_spells), SlotMode.Gcd),
            new SlotResolverData(new Res_HealSingleGcd(_spells), SlotMode.Gcd),
            new SlotResolverData(new Res_HealShield(_spells), SlotMode.Gcd),
            new SlotResolverData(new Res_SpreadShield(_spells), SlotMode.Gcd),  // 展开战术：要有盾可扩散
            // ══════════════════════════════════════════════════════════════
            //  ★★ **从这里往下是【输出】，整段必须在所有治疗 GCD 之后** ★★
            //
            //  [!] 依据（两套参考实现的槽序，IL 实证）：
            //        youshu  34 槽：… 14 鼓舞激励之策 · 15 医术 · 17 以太契约 ·
            //                        27/28 双DOT/DOT · 30 裂阵法 · 32 毁坏
            //        shiyuvi 41 槽：… 6 AOEGCDHeal · 7 SingleGCDHeal ·
            //                        11 Dot · 13 AOE · 14 BaseGCD
            //      ==> **输出垫底**：先保证治疗把 GCD 拿走，没人需要治才打输出。
            //
            //  [!] 我们原来把输出**插在治疗之前**（本文件里 `Res_Dot` 排在第 10 位，
            //      而 `Res_HealAoEGcd` / `Res_HealSingleGcd` / `Res_HealShield` /
            //      `Res_SpreadShield` 在第 6~9 位）==>
            //      "到该补 DoT 的时候、同时有人掉到群疗线以下" 时**我们先补毒、参考先群疗**。
            //      第 38 轮按参考把整段搬到治疗之后。
            //
            //  [!] ⚠️ **不要再把任何输出项往上搬** —— 那会重现上面那个差异。
            //      （`Res_MoveGcd` 也在这个段里，它是输出的兜底填充，不是治疗。）
            // ══════════════════════════════════════════════════════════════
            //  ★ 段内次序：**DoT 必须在 AOE 之前**（对齐两套参考实现的槽序）★
            //
            //  [!] 原来这里是 `Res_AoEDamage` 在前，注释写的是
            //        「AOE 优先：3 个以上敌人时不该先给单只怪挂 DoT」。
            //
            //  [!] 但参考实现**两套的槽序都是 DoT 在 AOE 之前**（IL 实证）：
            //        shiyuvi 41 槽：… 11 Dot · 12 ForceRuin2 · 13 AOE · 14 BaseGCD
            //        youshu  34 槽：… 28 DOT · 29 即刻极炎法 · 30 裂阵法 · 31 毁坏
            //      ==> 「DoT 在 AOE 之前」这一点**两套没有分歧**。
            //
            //  [!] 而且原来那句注释**与代码不符**：`Res_AoEDamage` 的门槛是
            //        `AOE最少敌人数 = 2`（学者），**不是 3** ==>
            //        2 只敌人时 AOE 就够格了，DoT 会被推后一个 GCD。
            //
            //  [!] 差异范围（枚举验证过，不是猜）：
            //        · 1 只敌人：两边一样（AOE 门槛 2 不满足，落下来补 DoT）
            //        · DoT 还满着：两边一样（`Dot补判` 挡住，落下来放 AOE）
            //        · **只有「≥2 敌 且 DoT 到该补的时候」才有差异**
            //          —— 我方先 AOE，参考先补毒。
            //
            //  [!] 为什么改顺序而不是把门槛提到 3：
            //        · 门槛 2 = youshu 在 82 级以下的档位（它按等级分档 `>=82 ? 3 : 2`）
            //        · 提门槛会**同时改变「2 只敌人要不要打 AOE」**这个更基础的行为，
            //          影响面比换顺序大
            //        ==> 只换顺序，门槛保持 2（改动最小、与参考槽序一致）。
            //
            //  [!] `Res_Dot` 的守卫是完整的（移动中可用 / 值得上Dot / Dot补判 / 黑名单），
            //      提前不会造成"移动中卡住 DoT"那类问题 —— 它自己会让位。
            // ══════════════════════════════════════════════════════════════
            new SlotResolverData(new Res_Dot(_spells), SlotMode.Gcd),
            new SlotResolverData(new Res_AoEDamage(_spells), SlotMode.Gcd),
            new SlotResolverData(new SCH_BanefulImpaction(), SlotMode.Gcd),   // 埋伏之毒（需预备 buff）
            // ⚠️ 位置很重要：必须在 `Res_MoveGcd`（移动填充）**之前** ——
            //   药尾声补刀最该生效的场景就是**移动中**（读条放不出来），
            //   排在移动填充后面等于**永远选不到**。
            new SlotResolverData(new Res_PotionTailDamage(_spells), SlotMode.Gcd),
            // ★ 多目标 DoT：主目标 DoT 还在时，把 DoT 扩散到**其他被拉到的怪** ★
            //   ⚠️ 必须在 Res_MoveGcd 之前（否则永远抢不到这个 GCD）
            //   ⚠️ 必须在 Res_Dot 之后（主目标的 DoT 优先级更高）
            new SlotResolverData(new Res_MultiDot(_spells), SlotMode.Gcd),
            // 基础输出：**必须排在 Res_MoveGcd 之前**。
            // 破阵法（近战填充技）也是瞬发，该由它优先选；
            // 排在移动填充之后会把 GCD 抢成毁坏（实测过的问题）。
            new SlotResolverData(new Res_BaseDamage(_spells), SlotMode.Gcd),
            // 移动填充兜底：当 Res_BaseDamage 因为基础输出是读条技而让位时顶上。
            new SlotResolverData(new Res_MoveGcd(_spells), SlotMode.Gcd),

            // ══════════════════════════════════════════════════════════════
            //  ★★ **从这里往下是 oGCD 趟 —— 它的次序还没和参考逐项对齐** ★★
            //
            //  [!] 已核实的差异（第 38 轮，逐项对照过参考的 34 槽）：
            //        参考：意气轩昂之策(7) · 炽天附体(8) · 野战治疗阵(9) · 异想的幻光(10)
            //              · 慰藉(11) · 异想的祥光(12) · 仙光的低语(13) · 不屈(14)
            //              · 深谋远虑之策(15) · 以太契约(16) · 生命活性法(17)
            //              · 生命回生法(18) … 醒梦(22) · 转化(23) · 以太超流(24)
            //              · 能量吸收(25) · 连环计(26) · 埋伏之毒(27)
            //        本地：… · Res_SelfMitigation · Res_TeamMitigation · Res_LucidDreaming
            //              · Res_HealBooster（秘策/活化）· Res_Emergency（应急战术）…
            //      ==> **参考把"增疗/减伤类"放在治疗能力技【之前】**（第 7~9 位），
            //          而我们放在其后。实际差别：同一个能力技窗口里，
            //          我们**先交个人/团队减伤，后交增疗**。
            //
            //  [!] **为什么没有直接改过来**（不要以为这是漏了）：
            //      参考**没有**"减伤一律在治疗之前"这种通用规则 ——
            //      逐职业看，减伤的位置是**不同的**：
            //        白魔：节制(5) · 神爱抚(6) · 全大赦(7) · 庇护所(8) · 水流幕(9)  <- 最前
            //        贤者：自生 · 智慧之爱 · 寄生 · 输血 · 自动单奶 · 拯救 · 醒梦
            //              · 心关 · 根素 · 心神风息                          <- 减伤在末尾
            //      ==> 参考是**逐槽位显式排列**的，不是按类别分组。
            //          要精确对齐，必须知道【我们每个 resolver 对应参考的哪一项】，
            //          而那个对应关系**只能靠技能名猜**（学者没做过单项对照表）。
            //          猜错的风险是"减伤抢在急救之前" —— 比现在更糟。
            //      ==> 所以**保持现状 + 记下差异**，等拿到可靠对应关系再动。
            //          （第 38 轮试过两次通用规则，都因打破别的意图而回滚。）
            // ══════════════════════════════════════════════════════════════
            new SlotResolverData(new SCH_Consolation(), SlotMode.OffGcd),
            new SlotResolverData(new SCH_WhisperingDawn(), SlotMode.OffGcd),
            new SlotResolverData(new SCH_FeyBlessing(), SlotMode.OffGcd),
            new SlotResolverData(new SCH_FeyIllumination(), SlotMode.OffGcd),
            new SlotResolverData(new Res_HealAoEAbility(_spells), SlotMode.OffGcd),
            new SlotResolverData(new SCH_Aetherpact(), SlotMode.OffGcd),
            new SlotResolverData(new SCH_Seraph(), SlotMode.OffGcd),
            new SlotResolverData(new SCH_SummonFairy(), SlotMode.OffGcd),
            new SlotResolverData(new Res_SelfMitigation(_spells), SlotMode.OffGcd),
            new SlotResolverData(new Res_TeamMitigation(_spells), SlotMode.OffGcd),
            new SlotResolverData(new Res_LucidDreaming(_spells), SlotMode.OffGcd),
            new SlotResolverData(new Res_HealBooster(_spells), SlotMode.OffGcd),         // 秘策
            new SlotResolverData(new Res_Emergency(_spells), SlotMode.OffGcd),           // 应急战术
            new SlotResolverData(new Res_GroupMitigationExtra(_spells), SlotMode.OffGcd), // 疾风怒涛之计
            new SlotResolverData(new Res_SingleMitigation(_spells), SlotMode.OffGcd),    // 生命回生法
            new SlotResolverData(new SCH_Dissipation(), SlotMode.OffGcd),                // 转化
            new SlotResolverData(new SCH_Seraphism(), SlotMode.OffGcd),                  // 炽天附体(100)
            new SlotResolverData(new SCH_AdloquiumUpgrade(), SlotMode.OffGcd),           // 意气轩昂之策(96)
            new SlotResolverData(new Res_LimitBreak(), SlotMode.OffGcd),                  // 极限技
        };
    }

    protected override void 构建QT()
    {
        base.构建QT();
        加职业开关("以太超流", true);
        加职业开关("链式策略", true);
        加职业开关("小仙女", true);
        加职业开关("炽天使", true);
    }

    /// <summary>爆发轴（勾上「一键爆发」才生效）</summary>
    protected override AEAssist.CombatRoutine.Module.ISlotSequence[] 构建爆发轴()
        => new AEAssist.CombatRoutine.Module.ISlotSequence[] { new 学者爆发轴(Spells) };
}

// ============================================================================
//  学者专属
// ============================================================================

/// <summary>以太超流：脱战也能补（脱战准备那条会先用掉一次）。</summary>
public class SCH_Aetherflow : ISlotResolver
{
    private static uint 技能 => SpellIds.取("以太超流");

    public int Check()
    {
        // 木桩也要补以太 —— 能量吸收要靠它换输出，属于资源循环
        if (!HealQt.GetQt("以太超流", true)) return -101;
        if (!SpellUtil.已解锁(技能)) return -2;
            // ⚠️ 修正（2026-09-28）：以太超流是**补满到 3 颗**，不是"覆盖"。
            //    有 1 颗时开新的 → 变成 3 颗，**一点都不浪费**。
            //
            //    我原来写的是"必须一颗都不剩才补"，注释还说"新的会覆盖旧的、直接浪费" ——
            //    **那个理解是错的**。后果是一个死锁：
            //      有 1 颗 → 我不开 → 以太永远到不了 3 颗 → "满 3 才卸"永远不成立
            //      → 能量吸收永远不打（现象就是这个）
            //
            //    正确规则：只有**已经满了**（3 颗）才不开，否则 CD 好了就补。
            if (JobApiHelper.读得到("以太") && JobApiHelper.以太 >= 3) return -3;

        // ★ 低蓝时不补豆（对照同类 ACR：它的补豆 Check 里也有 IsLowMpStopActive）★
        //   理由：补豆是为了卸豆换输出，低蓝时该做的是省蓝治疗。
        if (蓝量.低蓝停手()) return -4;

        if (!CharacterExt.可以插能力技()) return -6;

        if (HealSettings.Instance.时间轴攒资源 && TimelineManager.未来有减伤(4.0)) return -5;

        return SpellUtil.可用(技能) ? 2 : -1;
    }

    public void Build(Slot slot)
    {
        var spell = SpellUtil.Get(技能);
        if (spell != null) slot.Add(spell);
    }
}

/// <summary>异想的祥光：小仙女给的免费群体治疗。</summary>
public class SCH_FeyBlessing : ISlotResolver
{
    private static uint 技能 => SpellIds.取("异想的祥光");

    public int Check()
    {
        if (HealTargetHelper.木桩模式) return -300;
        if (!HealQt.GetQt("奶人")) return -100;
        if (!HealQt.GetQt("群奶")) return -101;
        if (!HealQt.GetQt("小仙女", true)) return -103;
        if (!SpellUtil.已解锁(技能)) return -2;

        var s = HealSettings.Instance;
        // 小仙女技能是免费的，门槛比 GCD 群奶低一个人
        var 要求人数 = HealTargetHelper.群疗能力技人数要求(s.群奶最少人数);
        // ★ 用这个技能自己的阈值 ★  参考：shiyuvi FeyBlessing 0.6 ｜ youshu 祥光 70
        var 本技血线 = 治疗阈值表.取(技能, s.群体治疗阈值);
        if (HealTargetHelper.低于阈值人数(本技血线, 20f) < 要求人数) return -1;

        return SpellUtil.可用(技能) ? 18 : -1;
    }

    public void Build(Slot slot)
    {
        var spell = SpellUtil.Get(技能);
        if (spell != null) slot.Add(spell);
    }
}

/// <summary>
/// 以太契约（连线）：给小仙女指定目标持续回血。
///
/// ══════════════════════════════════════════════════════════════════
///  ★ 官方 `Action:7437` 机制（逐字，这决定本类的全部判据）★
///
///    "Orders faerie to execute Fey Union with target party member.
///     **Effect ends upon reuse.**"                       <- ① 再按一次 = 解除
///    "Faerie Gauge Cost: 10"
///    "Cure Potency: 300"
///    "**Faerie Gauge is depleted by 10 periodically while HP is restored.**"
///    "**Fey Union effect fades upon execution of other faerie actions**  <- ②
///     or when party member moves from within 30 yalms of the faerie."   <- ③
///
///  [!] 用户实测的 bug：「连线一直在中断反复挂 这个不正常 应该是一直挂着 不需要解除」
///
///  [!] 根因：`tank.有该技能的Buff(技能)` 用的是技能 ID 7437，
///      而 **`AuraIds` 里原来没有 7437 的 buff 映射**（连线的 buff 是 1223）
///      ==> `有该技能的Buff(7437)` **恒为 false** ==> 那句"已经在挂就跳过"
///      ==> **从来没生效过** ==> 每帧都可能再按一次
///      ==> 配合 ①`Effect ends upon reuse` ==> **按第二下就解除** ==> 反复挂/反复断。
///      （`AuraIds` 现在补了 `以太契约 => 1223`，那个守卫才真正开始工作。）
///
///  [!] 所以本类**绝不主动解除**（用户明确要求"不需要解除"）：
///      能量耗尽、目标超 30 米、用了别的仙女技能 —— 这三种由**游戏自己**断，
///      我们只管"断了就重挂"，**不主动去断**。
///      （参考实现里唯一解除它的是 `Scholar_DissolveUnion`，判据是 HP>99%，
///        而 shiyuvi 那条路的解除常量是 0.95 —— 我们不需要，因为我们要的是"一直挂着"。）
/// ══════════════════════════════════════════════════════════════════
/// </summary>
public class SCH_Aetherpact : ISlotResolver
{
    private static uint 技能 => SpellIds.取("以太契约");

    /// <summary>刚按过之后的静默时长：这期间**绝不重复按**（防"按第二下 = 解除"）。</summary>
    private const int 重按冷却毫秒 = 1500;
    private static long _上次按下;

    /// <summary>最近一次"用别的仙女技能"的时刻 —— 那些动作会断链，别紧接着重挂。</summary>
    private static long _上次仙女动作;

    /// <summary>由仙女系 resolver 在施放后调用（低语/幻光/祥光/慰藉/炽天召唤都会断链）。</summary>
    public static void 记仙女动作() { try { _上次仙女动作 = TimeHelper.Now(); } catch { } }

    public int Check()
    {
        if (HealTargetHelper.木桩模式) return -300;
        if (!HealQt.GetQt("奶人")) return -100;
        if (!HealQt.GetQt("小仙女", true)) return -103;
        if (!SpellUtil.已解锁(技能)) return -2;
        if (JobApiHelper.妖精能量 < 20) return -3;

        var tank = HealTargetHelper.主坦();
        if (tank == null) return -1;

        // ══════════════════════════════════════════════════════════════
        //  ★★ 接线：`妖精契约血线` —— 这个设置**原来没有任何 resolver 在读** ★★
        //
        //  [!] 发现经过：对照参考实现时发现我们有个"死设置"。
        //      `HealSettings.妖精契约血线_基础`（默认 0.80）在设置页有滑条、
        //      在 `AiThresholdAdapter` 里也能被 AI 调 ——
        //      但**全仓库没有一处代码读它**（我逐处搜过）。
        //      ==> 结果是"连线**无条件**挂在主坦身上"，血线完全不起作用。
        //
        //  [!] 参考实现的对应阈值（IL 实证，两者差 5 个点）：
        //        shiyuvi `ScholarSettings::Aetherpact = 0.6f`
        //                （`Scholar_Aetherpact` 的条件：`hp + shield/100 <= 0.6`）
        //        youshu  `ScholarSettingsData::链子阈值 = 55`（整数=55%）
        //      ==> 都是 **0.55~0.60**，而我们的默认是 **0.80**（高得多）。
        //          我没有擅自改默认值（那是设置项，应该由你决定）——
        //          只是**把它接上**，让它真的生效。
        //          如果你要跟参考实现对齐，把滑条调到 0.55~0.60。
        //
        //  [!] 判据用 `有效血量比例()`（含盾）而不是 `血量比例()`：
        //      参考实现是 `CurrentHpPercent + ShieldPercentage/100 <= 阈值`，
        //      同一个口径（我们的 `有效血量比例()` 就是这个和）。
        // ══════════════════════════════════════════════════════════════
        try
        {
            var 血线 = HealSettings.Instance.妖精契约血线;
            if (血线 > 0f && tank.有效血量比例() > 血线) return -7;
        }
        catch { }

        // ── ① 已经在挂 -> 绝对不碰（避免 `Effect ends upon reuse` 把它解除）──
        //   [!] 双重判据：目标身上的连线 + **小仙女身上的 union 状态**。
        //       单查目标有可能因为 buff 读取延迟而漏，查两处更稳。
        try { if (tank.HasAura(AuraIds.以太契约)) return -4; } catch { }
        try { if (CharacterExt.我有光环(AuraIds.以太契约)) return -4; } catch { }

        // ── ② 刚按过 -> 静默（防 buff 读取延迟/失败时反复按）──
        try
        {
            if (_上次按下 != 0 && TimeHelper.Now() - _上次按下 < 重按冷却毫秒) return -5;
        }
        catch { }

        // ── ③ 刚用过别的仙女技能 -> 缓一下再挂 ──
        //   官方："Fey Union effect fades upon execution of other faerie actions"
        //   ==> 那种时候挂上去会立刻被断，等于白烧 10 点能量。
        try
        {
            if (_上次仙女动作 != 0 && TimeHelper.Now() - _上次仙女动作 < 800) return -6;
        }
        catch { }

        return SpellUtil.可用(技能) ? 5 : -1;
    }

    public void Build(Slot slot)
    {
        // ⚠️ 必须和 Check 用**同一个判据**（审计发现过 Check 用设置值、Build 写死 0.8f
        //    导致"Check 通过但 slot 是空的"⇒ 技能静默不放）。
        var tank = HealTargetHelper.主坦();
        if (tank == null) return;
        // 再确认一次没在挂 —— Check 和 Build 之间隔了一小段，且这个技能"重复按 = 解除"
        try { if (tank.HasAura(AuraIds.以太契约)) return; } catch { }

        slot.Add(new Spell(技能, tank));
        try { _上次按下 = TimeHelper.Now(); } catch { }
    }
}

/// <summary>炽天召唤：把小仙女升级成炽天使（解锁慰藉群盾）。</summary>
public class SCH_Seraph : ISlotResolver
{
    private static uint 技能 => SpellIds.取("炽天召唤");

    public int Check()
    {
        if (HealTargetHelper.木桩模式) return -300;
        if (!HealQt.GetQt("奶人")) return -100;
        if (!HealQt.GetQt("小仙女", true)) return -103;
        if (!HealQt.GetQt("炽天使", true)) return -104;
        if (!SpellUtil.已解锁(技能)) return -2;
        if (JobApiHelper.炽天使剩余 > 0) return -3;

        // ★ 用这个技能自己的阈值 ★  参考：shiyuvi SummonSeraph 0.55
        var 本技血线 = 治疗阈值表.取(技能, HealSettings.Instance.大招血线);
        var 团队掉血 = HealTargetHelper.低于阈值人数(本技血线)
                       >= HealSettings.Instance.群奶最少人数;
        var 要来伤害 = TimelineManager.未来有减伤(3.0) || 减伤Helper.即将来大伤害();

        if (!团队掉血 && !要来伤害) return -1;

        return SpellUtil.可用(技能) ? 7 : -1;
    }

    public void Build(Slot slot)
    {
        var spell = SpellUtil.Get(技能);
        if (spell != null) slot.Add(spell);
    }
}

/// <summary>慰藉：炽天使的群体护盾，能放两次。</summary>
public class SCH_Consolation : ISlotResolver
{
    private static uint 技能 => SpellIds.取("慰藉");

    /// <summary>上次放慰藉的时间。慰藉有 **2 层充能**，不加限流的话
    /// 条件一成立就会瞬间把两层全交掉（应该分两次用，比如 AOE 前后各一次）。</summary>
    private static long 上次慰藉;

    public int Check()
    {
        if (HealTargetHelper.木桩模式) return -300;
        if (!HealQt.GetQt("奶人")) return -100;
        if (!HealQt.GetQt("炽天使", true)) return -104;
        if (!SpellUtil.已解锁(技能)) return -2;
        if (JobApiHelper.炽天使剩余 <= 0) return -3;

        // 慰藉 2 层充能：3 秒内只放一次，避免一口气全交
        // 慰藉 2 层充能（参考同类 ACR 的 GetCharges）：
        //   满 2 层时尽快交掉防溢出；只剩 1 层时保持较长限流，避免一口气全交。
        var 充能 = CharacterExt.充能数(技能);
        var 限流 = 充能 >= 2 ? 800 : 3000;
        if (TimeHelper.Now() - 上次慰藉 < 限流) return -7;

        var s = HealSettings.Instance;
        // ★ 用这个技能自己的阈值 ★  参考：youshu 慰藉 55
        var 本技血线 = 治疗阈值表.取(技能, s.大招血线);
        var 团队掉血 = HealTargetHelper.低于阈值人数(本技血线, 20f) >= s.群奶最少人数;   // 慰藉 20 米
        var 要来伤害 = TimelineManager.未来有减伤(2.0) || 减伤Helper.即将来大伤害();

        if (!团队掉血 && !要来伤害) return -1;

        return SpellUtil.可用(技能) ? 19 : -1;
    }

    public void Build(Slot slot)
    {
        var spell = SpellUtil.Get(技能);
        if (spell == null) return;
        slot.Add(spell);
        上次慰藉 = TimeHelper.Now();
    }
}

/// <summary>小仙女不在场就召唤。</summary>
public class SCH_SummonFairy : ISlotResolver
{
    private static uint 技能 => SpellIds.取("朝日召唤");

    public int Check()
    {
        // 木桩模式**不拦** —— 小仙女是常驻宠物，掉了就该补
        if (!HealQt.GetQt("小仙女", true)) return -103;
        if (!SpellUtil.已解锁(技能)) return -2;

        // 791 = 转化状态：转化期间小仙女被牺牲，召唤无效
        if (AuraIds.转化中 != 0 && CharacterExt.我有光环(AuraIds.转化中)) return -3;

        // 已经在场就不用召唤（HasPet 读得到，面板显示也证明它是准的）
        if (JobApiHelper.有小仙女) return -3;
        if (JobApiHelper.炽天使剩余 > 0) return -3;

        // 移动中不召唤（读不到就放行）
        try { if (MoveHelper.IsMoving()) return -3; } catch { }

        // ⚠️ 这里刻意**不检查 SpellUtil.可用()**。
        //    逆向同类 ACR 的 Scholar_GetPet 发现：它的 Check 里根本没有可用性检查，
        //    判断完条件就直接把技能塞进 slot 交给游戏。
        //    而我加的 IsReadyWithCanCast() 对召唤类技能返回 false，
        //    导致永远不召唤（日志：已解锁=True 能召唤=False）。
        return 1;
    }

    public void Build(Slot slot)
    {
        var spell = SpellUtil.当前形态(技能);
        if (spell != null) slot.Add(spell);
    }
}

/// <summary>连环计：团辅。木桩模式卡 CD 放，不攒。</summary>
public class SCH_ChainStratagem : ISlotResolver
{
    private static uint 技能 => SpellIds.取("连环计");

    public int Check()
    {
        if (!HealQt.GetQt("链式策略", true)) return -101;
        if (!SpellUtil.已解锁(技能)) return -2;
        if (HealTargetHelper.当前目标() == null) return -1;
        if (!CharacterExt.可以插能力技()) return -6;

        if (!HealTargetHelper.木桩模式)
        {
            // 需求 2：残血小怪不给团辅
            if (HealTargetHelper.目标快死了()) return -4;
            if (HealSettings.Instance.时间轴攒资源 && TimelineManager.未来有减伤(8.0)) return -5;
        }

        return SpellUtil.可用(技能) ? 2 : -1;
    }

    public void Build(Slot slot)
    {
        var spell = SpellUtil.Get(技能);
        if (spell != null) slot.Add(spell);
    }
}
