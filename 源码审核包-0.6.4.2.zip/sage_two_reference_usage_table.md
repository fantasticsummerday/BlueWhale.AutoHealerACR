# SAGE（贤者）per-skill usage table — two decompiled reference rotations

## 0. Sources, method, and how to read this document

| Item | Value |
|---|---|
| Impl **A** (call it `youshu`) | `.il\youshu.il.txt` (92,419 lines, complete dump) + `.il\cls_youshu\*.txt` (453 per-class files). Cross-checked against `.il\youshu.core.txt`. |
| Impl **B** (call it `shiyuvi`) | `.il\shiyuvi.il.txt` (complete dump) + `.il\cls_shiyuvi\*.txt` (435 per-class files). Cross-checked against `.il\shiyuvi.core.txt`. |
| Class heading form | A: `### 鍚岀被 ACR.Sage.Resolvers.GCD.单盾` — the 3-char prefix is mojibake for the assembly root; method bodies follow `  :: <signature>` lines as `IL_xxxx:` lines. |

**Method notes (important for trusting the quotes below).**
* `.il.txt` is the *complete* dump; `.core.txt` is a **lossy pruned** variant (e.g. it drops the fall-through `ldc.i4.m1 / ret` after `brfalse.s` in `ACR.Sage.神翼飞T热键::Check`). All quotes below come from `.il.txt` / `cls_*` files.
* To fit the volume I read mechanically condensed views (`.il\cond\*`), produced by dropping only pure stack shuffling (`ldarg*`, `ldloc*`, `stloc*`, `dup`, `pop`, `nop`, `stelem/ldelem`, `ldind/stind`) and short-aliasing namespace prefixes. **No constant, string, field, call or branch was dropped, and every branch target line was kept.** Consequence to keep in mind: when an argument was a *local* (e.g. `ldloc.2`), that push is missing from my quoted snippets; where this mattered I re-read the raw `.il.txt` and say so.
* Every number below is copied from an `ldc.i4* / ldc.r4 / ldc.r8 / ldstr / ldtoken` in the IL. Statements that are *not* literally in the IL are marked **INFERRED**.
* Bodies marked **NOT IN DUMP** were searched for (`cls_youshu`/`cls_shiyuvi` contain one file per dumped class) and have no definition.

---

## 1. Action-id map — the ids the IL actually shows

"Role (FROM IL)" = what the IL proves the id does, by which class uses it. "Likely name (INFERRED)" = game-data identification, **not** proven by the dump.

| Id | Role (FROM IL) | Likely name (INFERRED) | Used by (impl A) | Used by (impl B) |
|---|---|---|---|---|
| 24283 | GCD filler; always cast after `QueueEukrasiaIfNeeded` in the DoT resolver; also the instant-Dosis casts | Dosis | GCD.DOT, GCD.注药, GCD.即刻注药, GCD.移动走位即刻注药, Openers.空起手/自定义起手 | ACR.Sage.GCD.Dosis |
| 24284 | pure single-target heal GCD, no Eukrasia inserted | Diagnosis | GCD.诊断 | — |
| 24285 | ability applied to a *target* that then carries aura 2605 (Kardion) | Kardia | Ability.心关 | **absent** |
| 24286 | group-heal GCD; cast both raw (预后) and right after Eukrasia (群盾) | Prognosis | GCD.预后, GCD.群盾 | — |
| 24287 | raise action handed to `HealerRaiseResolver`/`HealerPasserbyRaiseResolver` | Egeiro/复苏 | Strategy.复苏, Strategy.过路圣人复活, SageTools.HasDeadAllyWithoutRaise | — |
| 24288 / 24302 | `Level < 60 ? 24288 : 24302`; group regen gated on auras 2617/2620 | Physis / Physis II | Ability.自生, ST.贤者奶满策略, AB.寄生/智慧之爱/自动单奶 recently-used | — |
| 24289 / 24307 | charge GCD; `GetAdjustedActionId(24289) == 24307` selects the "3 hit" AoE threshold | Phlegma / Phlegma III | GCD.发炎, GCD.强制发炎, OP.自定义起手 | — |
| 24290 | stance inserted as a non-GCD spell before shield/DoT casts; its own aura is 2606 | Eukrasia | SageTools.QueueEukrasiaIfNeeded, AB.自动减伤 | ACR3._0.Sage.GCD.Eukrasia (Build), Triggers.强制释放均衡技能 |
| 24291 | shield GCD cast after Eukrasia is queued | Eukrasian Diagnosis | GCD.单盾, SageEventHandler.QueueTankShieldBeforeCombat | ACR.Sage.GCD.Sage_LowHPSingleHeal (`spellid()`) |
| 24292 | group shield GCD (`Gcd(24292, 1)`) + `GetAdjustedActionId(24292)` unlock/ready gate | Eukrasian Prognosis | AB.自动减伤.TryAddShieldFallback, AB.自动减伤.Build | — |
| 24293 | second id passed to `GetAdjustedActionId(24283, 24293)` / `MarkPending` | Eukrasian Dosis | SageTools? (via GC.DOT), GCD.群DOT uses 24297 | ACR3._0.Sage.GCD.DOT (`IsTargetVisibleOrInRange(target, 24293)`) |
| 24294 | targeted ability: target must have aura **2605** (Kardion, source = me) and not 2610, HP ≤ 70 | uncertain (Pepsis-like) | Ability.拯救 | — |
| 24295 | ability cast on `SageTools::LowestHpTank()` | Icarus | ACR.Sage.神翼飞T热键 | — |
| 24296 | single-target Addersgall heal, gated by `灵橡阈值` (50) | Druochole (INFERRED) | AB.自动单奶, ST.贤者奶满策略 | — |
| 24297 | AoE GCD (失衡) and the base of the AoE DoT (群DOT, cast after Eukrasia) | Dyskrasia / Eukrasian Dyskrasia | GCD.失衡, GCD.群DOT | — |
| 24298 | AoE mitigation requiring `Addersgall ≥ 1` and `Level ≥ 50` | Kerachole (INFERRED) | AB.自动减伤 (canKerachole), GCD.群盾 | — |
| 24299 | Addersgall-spending instant group heal | Ixochole (INFERRED) | AB.寄生, ST.贤者奶满策略, AB.智慧之爱/自生/自动单奶 recently-used | — |
| 24300 | cast only when `!Me.HasAura(2611)`; precedes 24286 as "Zoe" | Zoe | GCD.群盾, GCD.预后, ST.贤者奶满策略 | — |
| 24303 | single-target Addersgall heal, gated by `白牛阈值` (65) | Taurochole (INFERRED) | AB.自动单奶, ST.贤者奶满策略 | — |
| 24304 | Addersting-spender GCD (QT `红豆`) | Toxikon (INFERRED) | GCD.箭毒, OP.自定义起手 | — |
| 24305 | single-target ability, gated `输血阈值` (70), refuses if target has 2612/2642 | Haima (INFERRED) | AB.输血, AB.自动单奶 | — |
| 24309 | **Addersgall generator**: refuses when `Addersgall ≥ 2`, needs `Level ≥ 76` | Rhizomata (INFERRED) | AB.根素 | — |
| 24310 | mitigation ability, readiness gate only | Holos (INFERRED) | AB.自动减伤 (canHolos), GCD.群盾 | — |
| 24311 | mitigation ability, readiness gate only | Panhaima (INFERRED) | AB.自动减伤 (canPanhaima), GCD.群盾 | — |
| 24313 | literal in the custom opener only | unknown | OP.自定义起手 | — |
| 24314 | Eukrasian DoT GCD used by B; also a literal in A's custom opener | Eukrasian Dosis (higher tier) | OP.自定义起手 | ACR3._0.Sage.GCD.DOT (Build), ACR.Sage.GCD.ExtraDOT (Build) |
| 24317 | ability cast on an ally without aura 2622, HP ≤ `GCD单奶阈值` | Krasis | AB.自动单奶 | ACR3._0.Sage.Ability.Krasis |
| 24318 | `GetAdjustedActionId(24318)`, QT `贤炮` | Pneuma | GCD.贤炮, ST.贤者奶满策略 | — |
| 37033 | oGCD damage ability, enemy-target logic, burst-hold logic | Psyche | AB.心神风息, OP.自定义起手 | ACR3._0.Sage.Ability.Psyche |
| 37035 | group heal oGCD with aura gates 3898/2620/3899 | Philosophia | AB.智慧之爱, ST.贤者奶满策略, AB.预后/自生/自动单奶 recently-used | — |
| 7561 | "instant" ability, aura 49 used as its buff | Swiftcast (INFERRED) | GCD.即刻注药, GCD.移动走位即刻注药, GCD.注药 | — |
| 7562 | MP-refund ability, QT `醒梦` | Lucid Dreaming (INFERRED) | AB.醒梦 | SageRotationEventHandler.AutoLucidDream, ACR.Sage.Ability.LucidDreaming |
| 7568 | dispel GCD | Esuna (INFERRED) | GCD.康复, GCD.绝亚康复 | ACR.Sage.GCD.Esuna |
| 3599 | 3rd id passed to `IsTargetVisibleOrInRange` in B's ExtraDOT Build | unknown | — | ACR.Sage.GCD.ExtraDOT |
| 25865 | UI icon id in the overlay | n/a (UI) | — | ACR.Sage.SageOverlay |

**Aura/status ids seen (id → where it is tested):** `43`/`44` (Me, 失衡 MP gate), `49` (Me: 即刻注药, 移动走位即刻注药, 心神风息, 发炎; remaining-time compared), `148` (dead ally has no raise buff), `167`,`1249`,`841`,`3884` (Me, "may cast while moving" in `HealerActionHelper::IsMovementBlockingCast`), `167` (B: Dosis movement guard), `1896` (B: Krasis target), `2604` (Me Kardia), `2605` (target Kardion; `SourceId == Me.EntityId` decides "mine"), `2606` (Me Eukrasia), `2607`,`2608`,`2609`,`2612`,`297`,`1918` (shield presence), `2611` (Zoe), `2612`/`2642` (输血 blocks), `2613`/`2643`, `3033`/`3365`, `2618` (mitigation tuple), `2614`,`2615`,`2616`,`3897` (B DoT auras), `2617`,`2620` (Physis), `2622` (Krasis in A), `3898`,`3899` (Philosophia gate), `938`,`700` (绝亚/Temporal-Stasis Esuna target).

---

## 2. Impl A (`youshu`) — published resolver order

`ACR.Sage.Resolvers.Strategy.贤者技能策略::.cctor` builds `List<SlotResolverData>` with `ldc.i4.s 31` elements (via `CollectionsMarshal.SetCount`/`AsSpan`) and stores it in `SlotResolvers`, which `ACR.Sage.SAGEACR::Build` passes to `new Rotation(...)`. Each entry is `new SlotResolverData(resolver, <int literal>)`; the int's meaning is inside `AEAssist...SlotResolverData` (**NOT IN DUMP**).

| # | Resolver | int literal |
|---|---|---|
| 0 | `ACR.Tool.Resolvers.HealerPotionResolver` (ctor args: two `Func<bool>`) | 2 |
| 1 | `ACR.Sage.Resolvers.Strategy.过路圣人复活` | 1 |
| 2 | `ACR.Sage.Resolvers.Strategy.复苏` | 1 |
| 3 | `ACR.Sage.Resolvers.GCD.绝亚康复` | 1 |
| 4 | `ACR.Sage.Resolvers.Ability.自动减伤` | 0 |
| 5 | `ACR.Sage.Resolvers.GCD.康复` | 1 |
| 6 | `ACR.Sage.Resolvers.GCD.群盾` | 1 |
| 7 | `ACR.Sage.Resolvers.GCD.预后` | 1 |
| 8 | `ACR.Sage.Resolvers.Ability.自生` | 2 |
| 9 | `ACR.Sage.Resolvers.Ability.智慧之爱` | 2 |
| 10 | `ACR.Sage.Resolvers.Ability.寄生` | 2 |
| 11 | `ACR.Sage.Resolvers.GCD.单盾` | 1 |
| 12 | `ACR.Sage.Resolvers.GCD.诊断` | 1 |
| 13 | `ACR.Sage.Resolvers.Ability.输血` | 2 |
| 14 | `ACR.Sage.Resolvers.Ability.自动单奶` | 2 |
| 15 | `ACR.Sage.Resolvers.Ability.拯救` | 2 |
| 16 | `ACR.Sage.Resolvers.Ability.醒梦` | 2 |
| 17 | `ACR.Sage.Resolvers.Ability.心关` | 2 |
| 18 | `ACR.Sage.Resolvers.Ability.根素` | 2 |
| 19 | `ACR.Sage.Resolvers.Ability.心神风息` | 2 |
| 20 | `ACR.Sage.Resolvers.GCD.强制发炎` | 1 |
| 21 | `ACR.Sage.Resolvers.GCD.即刻注药` | 1 |
| 22 | `ACR.Sage.Resolvers.GCD.群DOT` | 1 |
| 23 | `ACR.Sage.Resolvers.GCD.双DOT` | 1 |
| 24 | `ACR.Sage.Resolvers.GCD.DOT` | 1 |
| 25 | `ACR.Sage.Resolvers.GCD.移动走位即刻注药` | 1 |
| 26 | `ACR.Sage.Resolvers.GCD.发炎` | 1 |
| 27 | `ACR.Sage.Resolvers.GCD.箭毒` | 1 |
| 28 | `ACR.Sage.Resolvers.GCD.贤炮` | 1 |
| 29 | `ACR.Sage.Resolvers.GCD.失衡` | 1 |
| 30 | `ACR.Sage.Resolvers.GCD.注药` | 1 |

`Rotation` meta (same method): `TargetJob = 40`, `AcrType = 0`, `MinLevel = 0`, `MaxLevel = 100`, description string (verbatim: `"支持日随、高难，高难记得写轴，可自定义组合热键、模式、QT风格等等，自行探索！\n更新内容前往标签页的开发测试或DC查看！有任何问题或需求，DC同名贴找YouSh…"`). One `ISlotSequence` is added: `new 贤者奶满策略()`. Opener selection `SAGEACR::GetOpener(level)`: `level < 90` → `空起手`; else `settings.Opener == 0` → `空起手`, `== 1` → `自定义起手`, otherwise `null`.

Trigger actions registered in order (`ldc.i4.s 24` array): `QtSetting(0)`, `绝欧麻将状态(1)`, `绝欧目标选择(2)`, `副本自动吃药(3)`, `热键(4)`, `起手设置(5)`, `预读时间(6)`, `康复顺序(7)`, `失衡走位(8)`, `不上Dot阈值(9)`, `醒梦阈值(10)`, `群奶人数(11)`, `群减人数(12)`, `保留蓝豆数量(13)`, `保留红豆数量(14)`, `灵橡阈值(15)`, `白牛阈值(16)`, `输血阈值(17)`, `自生阈值(18)`, `寄生阈值(19)`, `贤炮阈值(20)`, `智慧之爱(21)`, `GCD单奶(22)`, `GCD群奶(23)`. Trigger conditions (`ldc.i4.5`): `QtCheck(0)`, `蓝豆状态(1)`, `红豆状态(2)`, `M10S狂浪腾空(3)`, `坦克无敌检测(4)`.

---

## 3. Impl A — settings fields and their **literal defaults from the settings constructor**

From `ACR.Sage.SageSettingsData::.ctor` (verbatim `ldc.i4*` → `stfld` order):

| Field | Default literal |
|---|---|
| 群奶人数 | 2 |
| 群减人数 | 2 |
| 群盾阈值 | 2 |
| 自生阈值 | 80 |
| 寄生阈值 | 75 |
| 智慧之爱阈值 | 70 |
| 输血阈值 | 70 |
| 白牛阈值 | 65 |
| 灵橡阈值 | 50 |
| 保留红豆数量 | 1 |
| 保留蓝豆数量 | 1 |
| 魂灵风息阈值 | 60 |
| GCD群奶阈值 | 50 |
| GCD单奶阈值 | 40 |
| 预读时间 | 1500 |
| 倒计时心关时间 | 15000 |
| 心关延迟时间 | 5000 |
| 不上Dot阈值 | 3 |
| 醒梦阈值 | 8000 |
| 复活延迟 | 1 |
| 起手发炎延迟 | 3 |
| 起手心神延迟 | 3 |
| 起手红豆数量 | 1 |
| 优先复活TN | 1 |
| 自动切换最优目标 | 1 |
| 单奶限制坦克 | 1 |
| 失衡走位 | 1 |
| 贤炮起手 | 1 |
| 群盾 | 1 |
| 活化 | 1 |
| 单盾队友2 | 1 |
| 单盾队友3 | 1 |
| ShowDevTest / ShowQt / ShowHotkey / 切换模式自动隐藏QT | 1 / 1 / 1 / 1 |
| 复活提醒频道列表 | `ldc.i4.1` element, `ldstr "/p "` |
| 复活提醒宏列表 / QtStates / QtOrder / HiddenQtNames / VisibleHotkeyNames / *HotkeyOrder* / CustomHotkeys / SystemHotkeyConfigs / QtHotkeyConfigs / CustomHotkeyConfigs / QtVisibilityOverridesByMode / 自定义模式列表 | empty collections; 当前自定义模式名称 = `String.Empty`; **接入MacroRedirection** (read in `BeforeSpell`) |

**Fields that the ctor does NOT initialise** (so their literal default is 0/false unless the JSON/UI sets them): `即刻咏唱延迟时间`, `箭毒延迟时间`, `高难模式`, `H1`, `智能AOE目标`, `过路圣人模式`, `单奶限制奶妈`, `单奶限制输出`, `Opener`, `ResetQtOnBattleEnd`, `接入MacroRedirection`. The dump shows only *reads* of `即刻咏唱延迟时间` / `箭毒延迟时间` (grep: 8 hits across all 4 jobs' sections, none a `stfld`).
**Fields whose value I never saw read anywhere in the Sage classes I inspected:** `群盾阈值`(2), `倒计时心关时间`(15000), `预读时间`(1500), `起手红豆数量`(1), `贤炮起手`(1), `活化`(1), `单盾队友2/3`(1), `复活延迟`/`优先复活TN` (both are passed *into* `HealerRaiseRuntime` helpers). Flagged rather than guessed.

---

## 4. Impl A — per-class conditions, in IL test order

Notation: `QT("x")` = `SageQT::GetQt("x")`. Any `return N` line is the resolver's priority code; the framework compares these codes to pick which resolver builds the slot (**comparison semantics NOT IN DUMP**).

### 4.1 `ACR.Sage.Resolvers.SageResolverBase` (base of all 31)
* `StopRequested()` = `QT("停手")`.
* `CanUseAction()` = `Me.CurrentHp > 0` (`ldc.i4.0`, `cgt.un`).
* `CanSpendAddersgall()` = `QT("保留蓝豆") ? SageTools::CanSpendAddersgall(settings.保留蓝豆数量) : true`.
* `CanSpendAddersting()` = `QT("保留红豆") ? SageTools::CanSpendAddersting(settings.保留红豆数量) : true`.

### 4.2 `GCD.注药` (filler, order #30)
1. `useSwiftcast = false`; `StopRequested()` → `-999`.
2. `HasSkillSilenceStatus()` (NOT IN DUMP) → `-1`.
3. `target = SageTools::CurrentTarget()`.
4. `target != null && HealerEnemyTargetHelper::HasAttackBlock(target)` → `-1`.
5. **`SageTools::IsEukrasiaActiveOrBuffed()` ( = `Me.HasAura(2606,0)`) → `-1`** — this is why the filler never runs while Eukrasia/均衡 is up.
6. `target == null || Distance(Me,target,7) > 25 + Min(AttackRange, 2.5) || IsDying(target)` → `-2`.
7. `Me.CurrentMp < 1500` → `-9`.
8. `HealerActionHelper::IsMovementBlockingCast(24283)`:
   * `!QT("即刻走位")` → `-1`; `!IsReady(7561)` → `-1`; `HasDeadAllyWithoutRaise()` → `-1`; else `useSwiftcast = true; return 0`.
9. `!IsReady(24283)` → `-3`.
10. `!Me.IsMoving()` → `1`, else `2`.
* `Build`: if `useSwiftcast` → `Ability(7561)`; always `Gcd(24283, 0)` (target-type literal `0`).

### 4.3 `GCD.DOT` (order #24)
1. `target = SageTools::CurrentTarget()`; `StopRequested()` → `-999`.
2. `!QT("DOT") || Me.Level < 30` → `-100` (`ldc.i4.s 30`).
3. silence → `-1`; `target == null` → `-2`; `!target.IsValid` → `-10`.
4. `HasAttackBlock(target)` → `-1`.
5. `IsDying(target) || Distance(Me,target,7) > 25 + Min(AttackRange,2.5)` → `-2`.
6. `DotBlacklistHelper::IsBlackList(target)` → `-10` (NOT IN DUMP).
7. `!IsReady(HealerActionHelper::GetAdjustedActionId(24283), target)` → `-3`.
8. `SageTools::ShouldSkipSingleTargetDot(target)` (= `HealerEnemyTargetHelper::ShouldSkipDotByHp(target, settings.不上Dot阈值/100f /*3 → 0.03*/, 12)`) → `-2`.
9. `hasVisibleDot = SageTools::HasAnyDot(target, 1000)` (1000 ms).
10. `HealerDotCastTracker::HasRecentlyApplied(target, GetAdjustedActionId(24293), hasVisibleDot)` → `-1`.
11. `!hasVisibleDot` → `50`; `!HasAnyDot(target, 3000)` → `40`; else `-1`.
* `Build`: `QueueEukrasiaIfNeeded(slot)`; `slot.Add(Gcd(24283, target))`; `HealerDotCastTracker::MarkPending(24283, target)`.
* **Same-id note:** the IL never branches between "filler id" and "DoT id" here — it always casts **24283** and relies on (a) `QueueEukrasiaIfNeeded` inserting **24290** first and (b) the game/framework `CheckActionChange(24283) → 24293` adjustment (`GetAdjustedActionId(24283, 24293)`); the *decision to run at all* is made by the 1000/3000 ms `HasAnyDot` window and by `ShouldSkipSingleTargetDot`.

### 4.4 `GCD.群DOT` (order #22)
1. `StopRequested()` → `-999`; `!QT("群DOT")` → `-100`; `Me.Level < 30` → `-100`; silence → `-1`.
2. `target = CurrentTarget()`; `target == null || !target.IsValid` → `-1`; `HasAttackBlock(target)` → `-1`.
3. `!IsReady(24297)` → `-3`; `ShouldSkipAoeDotByHp(target)` (= `ShouldSkipDotByHp(target, 不上Dot阈值/100f, 3)`) → `-1`; `IsBlackList(target)` → `-10`.
4. `IsDying(target) || Distance(Me,target,7) > 5` → `-200`.
5. `HasAoeDot(target, 4000)` (aura **3897**, 4000 ms) → `-1`.
6. `HasRecentlyApplied(target, GetAdjustedActionId(24297), HasAoeDot(target, 1000))` → `-1`.
7. `!ShouldRefreshAoeDot()` → `-1`; else `60`.
* `ShouldRefreshAoeDot()`: `Me.Level < 82` → false (`ldc.i4.s 82`); `TargetHelper::GetNearbyEnemyCount(Me,5,5) < 3` → false; over `TargetMgr::EnemysIn25`: if `ValidAoeDotCandidate(enemy)` and `!HasAnyDot(enemy,1000)` then `++needDot`, and **if `needDot >= 2` → true** (`ldc.i4.2`); else if `HasAoeDot(enemy,1000) && !HasAoeDot(enemy,4000)` → true; else false.
* `Build`: `QueueEukrasiaIfNeeded`; `Gcd(24297, 1)`; `MarkPending(24297, GetAdjustedActionId(24297))`.

### 4.5 `GCD.双DOT` (order #23) — derived from `ACR.Tool.Resolvers.HealerDoubleDotResolverBase`
Overrides only: `StopRequested()` = `QT("停手")`; `DotEnabled()` = `QT("DOT")`; `DoubleDotEnabled()` = `QT("双DOT") && Me.Level >= 30`; `CanDot(e)` = `SageTools::ValidTargetInRange(e, 25f) && !IsBlackList(e) && !ShouldSkipDotByHp(e)`; `HasDot(e)` = `SageTools::HasSingleTargetDotPresence(e)`; `HasDotRemaining(e, ms)` = `SageTools::HasSingleTargetDot(e, ms)`; `BeforeBuild(slot)` = `QueueEukrasiaIfNeeded(slot)`.
**GAP:** the base class body (`.il\cls_youshu\ACR.Tool.Resolvers.HealerDoubleDotResolverBase.txt`, 18,339 bytes — i.e. the bodies **are** in the dump) was **not** extracted by me. Its `Check()` ordering/window constants are therefore **not verified**.

### 4.6 `GCD.单盾` — shield form of 诊断 (order #11)
1. `target = null`; `StopRequested()` → `-999`.
2. `!QT("奶人") || !QT("单盾")` → `-100`; `Me.Level < 30` → `-100`; silence → `-1`; `Me.CurrentMp < 1000` → `-9`.
3. `id = GetAdjustedActionId(24291)`; `!SpellExtension::IsUnlock(id)` **or** `MemApiSpell::GetCooldown(id).TotalSeconds > 0` (`ldc.r8 0`) → `-3`.
4. `HealerEnemyTargetHelper::HasBossCastingTankbusterWithin(10000)` → `target = LowestUnshieldedTank()`; if `target != null` → `10`.
5. `target = ResolveShieldTarget()`; `target == null || !NeedsSingleTargetShield(target)` → `-1`.
6. `HasBleed(target) && !HasDispelStatus(target) && target.CurrentHpPercent < 0.85` (`ldc.r4 0.85`) → `8`.
7. not moving → `2`; moving → `4`.
* `Build`: `QueueEukrasiaIfNeeded(slot)`; `Gcd(24291, target)`.
* `ResolveShieldTarget()`: `threshold = Clamp(settings.GCD单奶阈值/100f /*40 → 0.4*/, 0, 1)`; `tank = LowestUnshieldedTank()`; if `tank != null && (IsEukrasiaActiveOrBuffed() || NeedsLivingDeadHeal(tank) || tank.CurrentHpPercent <= threshold)` → `tank`; else lowest-HP member of `CastableAlliesWithin30` with `CanReceiveHeal && CanSingleHealTarget && CurrentHpPercent <= threshold && NeedsSingleTargetShield`.
* `LowestUnshieldedTank()`: over `PartyHelper::CastableTanks`: `Distance(Me,tank,7) <= 30 + Min(AttackRange,2.5)`, `CanReceiveHeal`, `NeedsSingleTargetShield`, prefer `NeedsLivingDeadHeal`, lowest HP.

### 4.7 `GCD.诊断` — pure-heal form (order #12)
1. `target = null`; `StopRequested()` → `-999`; `!QT("奶人")` → `-100`.
2. `Me.CurrentMp < 600` → `-1`; `!IsReady(24284)` → `-3`.
3. `target = SageTools::DiagnosisTarget(settings.GCD单奶阈值)` (see 4.29); `target == null` → `-1`.
4. `IsMovementBlockingCast(24284)` → `-2`.
5. `threshold = Clamp(GCD单奶阈值/100f + (Me.Level < 30 ? 0.1f : 0.0f), 0, 1)`.
6. `NeedsLivingDeadHeal(target) || target.CurrentHpPercent <= threshold` → `6`; else `2`.
* `Build`: `Gcd(24284, target)` — **no Eukrasia is inserted anywhere in this class.**

### 4.8 `GCD.群盾` — shield form of 预后 (order #6)
1. `shouldUseZoe = false`; `StopRequested()` → `-999`.
2. `!QT("奶人") || !QT("减伤") || !QT("群盾")` → `-100`; `Me.Level < 30` → `-100`; silence → `-1`; `!IsReady(24286)` → `-3`.
3. `Me.CurrentMp < 1000 || Addersgall < 1` → `-9`.
4. **`Me.HasAura(2609) || SageTools::HasActiveMitigation(false)` → `-7`** (existing group shield / any mitigation ⇒ refuse).
5. `bleedCount = CountBleedingPartyMembers(80, 30)` (`ldc.i4.s 80`, `ldc.i4.s 30`): `CanReceiveHeal && Distance(Me,m,7) <= 30 && CurrentHpPercent*100 <= 80 && HasBleed(m) && !HasDispelStatus(m)`.
6. `bleedCount >= 4` → `shouldUseZoe = (Me.Level >= 45 && !Me.HasAura(2611))`, `return 10`.
7. else `bleedCount >= 2` → `shouldUseZoe = (Me.Level >= 45 && !Me.HasAura(2611))`, `return 4`.
8. else require `HasBossCastingAoeWithin(10000) && CountAlivePartyMembersInRangePlusSelf(30) >= settings.群减人数` else `-1`.
9. `CountPartyMembersWithoutScholarShield(20) < Clamp(settings.群减人数, 0, 8)` → `-1`.
10. `canHolos = IsReady(24310)`, `canPanhaima = IsReady(24311)`, `canKerachole = IsReady(24298) && Addersgall >= 1 && Me.Level >= 50`; tuple `mit = SageTools::CurrentMitigation()` = `(HasAura(2613)||HasAura(2643), HasAura(3033)||HasAura(3365), HasAura(2618))`.
11. composite gate (operand order partly obscured by dropped `ldloc` in my view; operands are `mit.Item3`, `canKerachole`, `mit.Item1`, `mit.Item2`, `canHolos`, `canPanhaima`) → if satisfied `-1`.
12. `mit.Item3 && …`-style gate (same caveat) plus `Me.HasAura(2609)` → `-1`; otherwise `shouldUseZoe = (Me.Level >= 56 && !Me.HasAura(2611))`, `return 8`.
* `Build`: `if (shouldUseZoe) Ability(24300)`; `QueueEukrasiaIfNeeded(slot)`; `Gcd(24286, 1)`.

### 4.9 `GCD.预后` — pure-heal form (order #7)
1. `shouldUseZoe = false`; `StopRequested()` → `-999`; `!QT("奶人") || !QT("群奶")` → `-100`.
2. `Me.CurrentMp < 1000` → `-1`; silence → `-1`; `!IsReady(24286)` → `-3`; `IsMovementBlockingCast(24286)` → `-5`.
3. `shouldUseZoe = IsReady(24300) && !Me.HasAura(2611)`.
4. `shieldCount = CountPartyMembersWithStatus(2609, 20)`; `count = CountLowHpPartyMembersInRange(settings.GCD群奶阈值 /*50*/, 20)`.
5. `count <= 0` → `-1`.
6. `shieldCount >= 4 && count >= settings.群奶人数 /*2*/` → `10`.
7. `!IsReady(24288) && !IsReady(37035) && !IsReady(24299) && count < 群奶人数` → `9`.
8. `count < 群奶人数` → `-1`; else `8`.
* `Build`: `if (shouldUseZoe) Ability(24300)`; `Gcd(24286, 1)` — **no Eukrasia.**

### 4.10 `GCD.发炎` (order #26)
1. `target = null; useSmartTarget = false`; `StopRequested()` → `-999`; `!QT("发炎")` → `-100`.
2. silence → `-1`; `cur != null && HasAttackBlock(cur)` → `-1`.
3. `cur == null || Distance(Me,cur,7) > 6 + Min(AttackRange,2.5) || IsDying(cur)` → `-2`.
4. `!settings.高难模式 && SageTools::ShouldHoldBurstForDyingTrash()` → `-50` (= `ShouldHoldBurstForDyingTrash(0.3f, 15000, false, BattleData.CurrBattleTimeInMs)`).
5. `spell = Gcd(24289, 0)`; `!SpellExtension::IsReadyWithCanCast(spell)` → `-3`.
6. `QT("保留发炎") && !QT("倾泻资源") && spell.Charges <= 1` (`ldc.r4 1`) → `-9`.
7. `QT("攒爆发") && !QT("倾泻资源")` → `-30`.
8. `target = cur`; `QT("倾泻资源")` → `50`.
9. `CurrBattleTimeInMs <= settings.起手发炎延迟 /*3*/ * 2500` → `-8`.
10. `CurrBattleTimeInMs <= 5000 && Distance(Me,target,7) > 6` → `-8`.
11. `threshold = (GetAdjustedActionId(24289) == 24307) ? 3 : 2` (`ldc.i4 24307`, `ldc.i4.3`, `ldc.i4.2`).
12. if `settings.智能AOE目标`: `best = HealerEnemyTargetHelper::SelectCircularAoeTarget(threshold, 6, 5, target, true)`; if `best != null && TargetHelper::GetNearbyEnemyCount(6,5) >= threshold` → `target = best; useSmartTarget = true`.
13. `useSmartTarget` → `20`.
14. `settings.高难模式 == 1 && Me.HasAura(49) && 3000 <= MemApiBuff::GetAuraTimeleft(Me,49,0) <= 28000` → `15`.
15. `spell.Charges > 1.9` (`ldc.r4 1.9`) → `10`; `Me.IsMoving()` → (`QT("保留发炎") ? -9 : 7`); else `-1`.
* `Build`: `SwitchTargetIfNeeded(target)`; `if (target != null) Gcd(24289, target)`.

### 4.11 `GCD.强制发炎` (order #20)
1. `target=null; actionId=0; useSmartTarget=false`; `StopRequested()` → `-999`; `!QT("强制发炎")` → `-100`; silence → `-1`.
2. `cur != null && HasAttackBlock(cur)` → `-1`; `cur == null || Distance(Me,cur,7) > 6 + Min(AttackRange,2.5) || IsDying(cur)` → `-200`.
3. `QT("攒爆发") && !QT("倾泻资源")` → `-30`.
4. `actionId = GetAdjustedActionId(24289)`; `!IsReady(actionId)` → `-1`.
5. `QT("倾泻资源")` → `target = cur; return 50`.
6. `CurrBattleTimeInMs <= 5000 && Distance(Me,cur,7) > 6` → `-9`.
7. `target = SelectTarget(actionId)`; `null` → `-1`; `!useSmartTarget` → `10`; else `20`.
* `SelectTarget(actionId)`: `!settings.智能AOE目标` → `CurrentTarget()`; `threshold = (actionId == 24307) ? 3 : 2`; `best = SelectCircularAoeTarget(threshold, 6, 5, CurrentTarget(), true)`; if `best != null && GetNearbyEnemyCount(6,5) >= threshold` → `useSmartTarget = true; return best`; else `CurrentTarget()`.
* `Build`: `SwitchTargetIfNeeded(target)`; `if (target != null && actionId != 0) slot.Add(new Spell(actionId, target))`.

### 4.12 `GCD.即刻注药` (order #21)
1. `!QT("即刻注药")` → `-100`.
2. `!Me.HasAura(49,0)` → `-100`; `t = MemApiBuff::GetAuraTimeleft(Me,49,0)`; `t <= 0 || t > 3000` → `-100`.
3. `HasDeadAllyWithoutRaise()` → `-1`; `Me.CurrentMp < 1500` → `-2`; silence → `-1`.
4. `target = CurrentTarget()`; `target != null && HasAttackBlock(target)` → `-1`.
5. `target == null || HealerEnemyTargetHelper::IsOutOfAttackRangeOrDead(target, 25f)` → `-2`.
6. `!IsReady(7561)` → `-9`; else `15`.
* `Build`: `Ability(7561)`; `Gcd(24283, 0)`.

### 4.13 `GCD.移动走位即刻注药` (order #25)
1. `StopRequested()` → `-999`; `!QT("即刻走位")` → `-100`; `!Me.IsMoving()` → `-100`; `Me.CurrentMp < 1500` → `-2`; silence → `-1`.
2. `target=CurrentTarget()`; `target != null && HasAttackBlock(target)` → `-1`; `target == null || IsOutOfAttackRangeOrDead(target,25f)` → `-2`.
3. `!IsReady(7561)` → `-3`; `BurstPotionEndingSoon()` → `-7` (= `Me.HasAura(49) && 0 < GetAuraTimeleft(Me,49,0) <= 3000`).
4. `MoveStartTimeMs > 0 && TimeHelper::Now - MoveStartTimeMs < settings.即刻咏唱延迟时间` → `-9`; else `15`.
* `Build`: `Ability(7561)`; `Gcd(24283, 0)`.

### 4.14 `GCD.箭毒` (order #27)
1. `target=CurrentTarget(); useSmartTarget=false`; `StopRequested()` → `-999`; `!QT("红豆")` → `-100`; silence → `-1`.
2. `target != null && HasAttackBlock(target)` → `-1`; `target == null || IsOutOfAttackRangeOrDead(target,25f)` → `-2`.
3. `settings.高难模式 == 1 && MoveStartTimeMs > 0 && Now - MoveStartTimeMs < settings.箭毒延迟时间` → `-8`.
4. `QT("攒爆发") && !QT("倾泻资源") && SageTools::Addersting <= 2` → `-30`.
5. `QT("倾泻资源") && Addersting <= 0` → `-9`.
6. `QT("保留红豆") && Addersting <= settings.保留红豆数量 /*1*/` → `-9`.
7. `Addersting <= 0` → `-9`; `!IsReady(24304, target)` → `-3`.
8. `QT("倾泻资源")` → `50`.
9. if `settings.智能AOE目标`: `best = SelectCircularAoeTarget(2, 25, 5, target, true)`; if `best != null && GetNearbyEnemyCount(25,5) >= 2` → `target = best; useSmartTarget = true`.
10. `!ValidTargetInRange(target, 25f)` → `-1`; `useSmartTarget` → `15`.
11. `Me.IsMoving() && GCDHelper::GetGCDDuration() == 0` → `-1`; else `10`.
* `Build`: `castTarget = target ?? CurrentTarget()`; `if (useSmartTarget) SwitchTargetIfNeeded(castTarget)`; `if (castTarget != null) Gcd(24304, castTarget)`.

### 4.15 `GCD.失衡` (order #29)
1. `StopRequested()` → `-999`; `!QT("失衡")` → `-100`; silence → `-1`.
2. `target = CurrentTarget()`; `target != null && HasAttackBlock(target)` → `-1`.
3. `IsEukrasiaActiveOrBuffed()` (aura 2606) → `-1`.
4. `blocked = Me.Level < 46 || terrId ∈ {293, 296, 1046}` (**verified in raw IL** — `stloc.2` + `brtrue` at `IL_0051`) → `-100`.
5. `!IsReady(7562) && Me.CurrentMp < 1000 && (Me.HasAura(43) || Me.HasAura(44))` → `-200`.
6. `target == null || !target.IsValid || Distance(Me,target,7) > 5 || IsDying(target)` → `-200`.
7. `!IsReady(24297)` → `-200`; `aoeCount = TargetHelper::GetNearbyEnemyCount(Me,5,5)`; `aoeCount == 0` → `-200`.
8. `Me.IsMoving()` → (`!settings.失衡走位 /*1*/ ? -1 : 0`).
9. `!QT("AOE") || aoeCount < SageTools::DyskrasiaAoeThreshold()` → `-1`; else `1`.
   `DyskrasiaAoeThreshold()` = `Me.Level < 82 ? 2 : 3`.
* `Build`: `Gcd(24297, 1)`.

### 4.16 `GCD.贤炮` (order #28)
1. `target=null; actionId=0; useSmartTarget=false`; `StopRequested()` → `-999`; `!QT("贤炮")` → `-100`; silence → `-1`.
2. `cur = CurrentTarget()`; `cur != null && HasAttackBlock(cur)` → `-1`; `cur == null || Distance(Me,cur,7) > 25 + Min(AttackRange,2.5) || IsDying(cur)` → `-2`.
3. `actionId = GetAdjustedActionId(24318)`; `!IsReady(actionId)` → `-3`; `IsMovementBlockingCast(actionId)` → `-1`.
4. `QT("攒爆发") && !QT("倾泻资源")` → `-30`; `QT("倾泻资源")` → `target = cur; return 50`.
5. `!settings.高难模式 && ShouldHoldBurstForDyingTrash()` → `-50`.
6. `best = settings.智能AOE目标 ? SelectLineAoeTarget(2, 25f, 3f) : null`; `cannotHeal = SageTools::CannotReceiveHeal()`.
7. `settings.高难模式 != 1 && (!QT("奶人") || cannotHeal)`: if `best != null && TargetHelper::GetEnemyCountInsideRect(Me,25f,3f) >= 2` → `target=best; useSmartTarget=true; return 2`; else `target = CurrentTargetOrSelf(); return 1`.
8. `!settings.高难模式 && !cannotHeal && GetEnemyCountInsideRect(Me,25f,3f) >= 6` → `target=best; useSmartTarget=true; return 3`.
9. `needHeal = CountLowHpPartyMembersInRange(settings.魂灵风息阈值 /*60*/, 25)`; `if (Me.CanReceiveHeal() && Me.CurrentHpPercent*100 <= 魂灵风息阈值) needHeal++`.
10. `needHeal >= settings.群奶人数 /*2*/` → `target = CurrentTargetOrSelf(); return 2`; `best != null` → `target=best; useSmartTarget=true; return 2`; else `-1`.
* `Build`: `if (actionId == 0) return`; if `useSmartTarget` → `SwitchTargetIfNeeded(target)` + `new Spell(actionId, target)`; else `new Spell(actionId, SageTools::CurrentTargetOrSelf())`.

### 4.17 `GCD.康复` (order #5)
1. `target=null`; `StopRequested()` → `-999`; `!QT("自动康复")` → `-100`; silence → `-1`.
2. `!IsReady()` (= `SpellExtension::IsReadyWithCanCast(Gcd(7568, 1))`) → `-200`.
3. `target = HealerEsunaTargetSelector::SelectGeneralTarget(settings.H1)`; `null` → `-7`; else `10`.
* `Build`: `Gcd(7568, target)`.

### 4.18 `GCD.绝亚康复` (order #3)
1. `MemApiZoneInfo::GetCurrTerrId() != 887` → `-100` (`ldc.i4 887` = TEA, INFERRED).
2. `!QT("自动康复")` → `-100`; `!IsReady()` → `-200`; `!HasAnyDispelTargetWithin30()` (any `CastableAlliesWithin30` with `TD.Helper::HasDispelStatus`) → `-7`.
3. `target = HealerEsunaTargetSelector::SelectTemporalStasisTarget(settings.H1)`; `null` → `-7`; else `1`.
* `Build`: `Gcd(7568, target)`. `IsReady()` = `IsReadyWithCanCast(Gcd(7568, 1))`.

### 4.19 `Ability.心关` — **Kardia** (order #17)
1. `target=null`; `StopRequested()` → `-999`; `!QT("自动心关")` → `-100`; silence → `-1`.
2. `!HealerResolverBase::CanUseOffGcd(1)` → `-4`.
3. `HealerActionHelper::RecentlyUsed(24285, settings.心关延迟时间 /*5000 ms*/)` → `-16`.
4. `target = ResolveKardiaTarget()`; `null` → `-1`; `!IsReady(24285, target)` → `-4`; else `1`.
* `Build`: `Ability(24285, target)`.
* **`ResolveKardiaTarget()`** (locals as named by the decompiler: `hasOwnKardiaTank, lowHpTank, currentEnemyTargetTank, lowestTankWithoutKardia, lowestTank, lowHpTankHp, lowestTankWithoutKardiaHp, lowestTankHp, targetOfTarget, nonTank, hasOwnKardia, tank, hp, fromCurrentSage`):
  * `hasOwnKardiaTank=false; lowHpTankHp = 0.75f; lowestTankWithoutKardiaHp = float.MaxValue; lowestTankHp = float.MaxValue`.
  * `targetOfTarget = CurrentTarget() != null ? CurrentTarget().GetCurrTarget() : null`.
  * over `PartyHelper::CastableTanks`: require `CanUseKardiaTarget(tank)`; `hp = tank.CurrentHpPercent`;
    - if `HasKardion(tank, out fromCurrentSage)` → `hasOwnKardiaTank |= fromCurrentSage` (then still falls through to the "lowest tank overall" bookkeeping at `IL_009f`), else:
      * `hp < 0.75` → `lowHpTankHp = hp; lowHpTank = tank`;
      * if `targetOfTarget != null && tank.EntityId == targetOfTarget.EntityId` and `hp < lowestTankWithoutKardiaHp` → `currentEnemyTargetTank = tank`;
    - always: `hp < lowestTankHp` → `lowestTank = tank`.
  * if `lowestTank != null`: return `lowHpTank` → else `currentEnemyTargetTank` → else `hasOwnKardiaTank ? null : (lowestTankWithoutKardia ?? lowestTank)`.
  * else (no castable tanks): `nonTank = LowestNonTankKardiaTarget(out hasOwnKardia)`; if non-null return it; then `if (hasOwnKardia || Me.HasAura(2604)) return null;` else `return Me`.
  * `LowestNonTankKardiaTarget(ref hasOwnKardia)`: over `CastableAlliesWithin30`, skip `IsTank`, require `CanUseKardiaTarget`; track `lowestAny`, `lowestWithoutKardia`, `lowestWithoutKardiaUnderHalf` (initial threshold `0.5f`); if `HasKardion(member,out fromCurrentSage)` → `hasOwnKardia |= fromCurrentSage` and skip; final return **verified in raw IL**: `lowestWithoutKardiaUnderHalf ?? (hasOwnKardia ? null : (lowestWithoutKardia ?? lowestAny))`.
  * `HasKardion(target, out fromCurrentSage)`: `fromCurrentSage=false`; scan `target.StatusList`; `StatusId == 2605` → if `SourceId == Me.EntityId` → `fromCurrentSage = true; return true`; else remember `hasKardion = true`; return `hasKardion`.
  * `CanUseKardiaTarget(t)`: `t.IsValid && !t.IsEnemy && t.CurrentHp > 0`.
* **Main-tank concept: YES.** It is expressed as (a) the lowest-HP tank below **75 %** (`0.75f`), (b) the tank that my current enemy target is attacking (`GetCurrTarget()` target-of-target), (c) "if my Kardia is already on a tank, do not move it" (`hasOwnKardiaTank`), (d) otherwise the lowest-HP tank, with a non-tank ladder ending at `Me` (self) at `0.5f`/50 %.

### 4.20 `Ability.拯救` (order #15)
1. `target=null`; `StopRequested()` → `-999`; `!QT("奶人") || !QT("单奶")` → `-100`; silence → `-1`; `!CanUseOffGcd(2)` → `-4`.
2. `target = ResolvePepsisTarget()`; `null` → `-1`; `!IsReady(24294, target)` → `-1`; else `1`.
* `ResolvePepsisTarget()`: over `CastableAlliesWithin30`: `CanReceiveHeal && CanSingleHealTarget && target.HasAura(2605,0) /*Kardion*/ && !target.HasAura(2610,0) && CurrentHpPercent*100 <= 70.0f`, lowest HP wins (the `70` is a hard literal, **not** `输血阈值`).
* `Build`: `Ability(24294, target)`.

### 4.21 `Ability.心神风息` (order #19)
1. `target=null; useSmartTarget=false`; `StopRequested()` → `-999`; `!QT("心神风息")` → `-100`.
2. `!IsReady(37033)` → `-1`; silence → `-1`; `target=CurrentTarget()`; `target != null && HasAttackBlock(target)` → `-1`.
3. `target == null || IsOutOfAttackRangeOrDead(target,25f)` → `-200`; `!CanUseOffGcd(2)` → `-4`.
4. `QT("攒爆发") && !QT("倾泻资源")` → `-30`; `QT("倾泻资源")` → `50`.
5. `CurrBattleTimeInMs <= settings.起手心神延迟 /*3*/ * 2500` → `-8`.
6. `!settings.高难模式 && ShouldHoldBurstForDyingTrash()` → `-10`.
7. if `settings.智能AOE目标`: `best = SelectCircularAoeTarget(2, 25, 5, target, true)`; if `best != null && GetNearbyEnemyCount(25,5) >= 2` → `target=best; useSmartTarget=true`.
8. `useSmartTarget` → `20`.
9. `Me.HasAura(49) && settings.高难模式 == 1 && GetAuraTimeleft(Me,49,0) > 0` → `15`; else `0`.
* `Build`: `if (useSmartTarget) SwitchTargetIfNeeded(target)`; if `target != null` → `useSmartTarget ? Ability(37033, target) : Ability(37033, 0)`.

### 4.22 `Ability.智慧之爱` (order #9)
1. `StopRequested()` → `-999`; `!QT("奶人") || !QT("群奶")` → `-100`; `!IsReady(37035)` → `-6`; `!CanUseOffGcd(2)` → `-4`.
2. `RecentlyUsed(24299,2000) || RecentlyUsed(24288,2000) || RecentlyUsed(24302,2000) || RecentlyUsed(24305,2000)` → `-5`.
3. `Me.HasAura(3898) || Me.HasAura(2620) || Me.HasAura(3899)` → `-8`.
4. `CountLowHpPartyMembersInRange(settings.智慧之爱阈值 /*70*/, 30) < Clamp(settings.群奶人数,0,8)` → `-1`; else `2`.
* `Build`: `Ability(37035)`.

### 4.23 `Ability.寄生` (order #10)
1. `StopRequested()` → `-999`; `!QT("奶人") || !QT("群奶")` → `-100`; silence → `-1`; `!IsReady(24299)` → `-6`; `!CanUseOffGcd(2)` → `-4`.
2. `SpellRecentlyUsed(24288,1000) || SpellRecentlyUsed(24302,1000) || SpellRecentlyUsed(37035,1000)` → `-5`.
3. `Me.HasAura(3898)` → `-7`; `!SageResolverBase::CanSpendAddersgall()` → `-8`.
4. `CountLowHpPartyMembersInRange(settings.寄生阈值 /*75*/, 20) < settings.群奶人数 /*2*/` → `-1`; else `10`.
* `Build`: `Ability(24299)`.

### 4.24 `Ability.自生` (order #8)
1. `cachedActionId = 0`; `StopRequested()` → `-999`; `!QT("奶人") || !QT("群奶") || Me.Level < 20` → `-100`; silence → `-1`; `!CanUseOffGcd(2)` → `-4`.
2. `cachedActionId = Me.Level < 60 ? 24288 : 24302`; `!IsReady(cachedActionId)` → `-103`.
3. `RecentlyUsed(24299|24288|24302|24305|37035, 2000)` (any) → `-5`.
4. `Me.HasAura(3898) || Me.HasAura(2617) || Me.HasAura(2620)` → `-8`.
5. `threshold = Clamp(settings.自生阈值 /*80*/ / 100f, 0, 1)`; count over `CastableAlliesWithin30`: `V1` = members with `CanReceiveHeal`, `V2` = those also with `CurrentHpPercent <= threshold`.
6. `V1 <= 1` → (`Me.CurrentHpPercent > threshold ? -1 : 2`).
7. `V2 < Clamp(settings.群奶人数,0,8)` → `-1`; else `2`.
* `Build`: `Ability(cachedActionId)`.

### 4.25 `Ability.输血` (order #13)
1. `target=null`; `StopRequested()` → `-999`; `!QT("奶人")` → `-100`; silence → `-1`; `!CanUseOffGcd(2)` → `-4`.
2. `target = CurrentTarget()?.GetCurrTarget()` (**target-of-target**); `target == null || !CanReceiveHeal(target) || !CanSingleHealTarget(target)` → `-2`.
3. `!IsReady(24305, target)` → `-3`; `target.HasAura(2612) || target.HasAura(2642)` → `-9`.
4. `(HasBossCastingTankbusterWithin(10000) && target.IsTank) || NeedsLivingDeadHeal(target)` → `10`.
5. `target.CurrentHpPercent*100 > settings.输血阈值 /*70*/` → `-1`; else `10`.
* `Build`: `Ability(24305, target)`.

### 4.26 `Ability.根素` (order #18)
1. `StopRequested()` → `-999`; `!QT("自动根素")` → `-100`; `!CanUseOffGcd(2)` → `-4`; `Me.Level < 76` → `-3`.
2. silence → `-1`; `!IsReady(24309, 1)` → `-1`; `SageTools::Addersgall >= 2` → `-2`; else `1`.
* `Build`: `Ability(24309, 1)`. **This is the only Addersgall *generator*; it refuses at ≥ 2 stacks.**

### 4.27 `Ability.醒梦` (order #16)
1. `StopRequested()` → `-999`; `Me.IsCasting` → `-1`; `Me.Level < 14` → `-3`; `!CanUseOffGcd(1)` → `-4`.
2. `Me.CurrentMp > settings.醒梦阈值 /*8000*/` → `-3`; silence → `-1`; `!IsReady(7562, 1)` → `-2`; else `0`.
* `Build`: `Ability(7562, 1)`.

### 4.28 `Ability.自动减伤` (order #4)
1. `cachedSpells.Clear()`; `StopRequested()` → `-999`; `!QT("奶人") || !QT("减伤")` → `-100`; silence → `-1`; `!CanUseOffGcd(2)` → `-4`.
2. `!(HasBossCastingAoeWithin(10000) && !HasActiveMitigation(true))` → `-1`; `Environment.TickCount64 < mitigationLockUntil` → `-1`.
3. `CountAlivePartyMembersInRangePlusSelf(30) < settings.群减人数 /*2*/` → `-1`; `FillMitigationSpells()`; `cachedSpells.Count <= 0` → `-1`; else `2`.
* `FillMitigationSpells()`: return immediately if any of `CurrentMitigation().Item2/.Item1/.Item3` is true; `canKerachole = Addersgall > 0 && Me.Level >= 50 && IsReady(24298)`; `canPanhaima = IsReady(24311)`; `canHolos = IsReady(24310)`; then in order: `canKerachole && canPanhaima` → `[24298, 24311]`; `canKerachole && canHolos` → `[24298, 24310]`; `canHolos` → `[24310]`; `canPanhaima` → `[24311]`; `canKerachole` → `[24298]`; else `TryAddShieldFallback()`.
* `TryAddShieldFallback()`: require `HasBossCastingAoeWithin(5000) && Me.CurrentMp > 1000 && SpellExtension::IsUnlock(GetAdjustedActionId(24292)) && IsReady(24292)`; `withoutShield` = count over `CastableAlliesWithin20` with `CanReceiveHeal && !HasAura(2607) && !HasAura(2608) && !HasAura(2609)`, **plus 1 if `Me` has none of 2607/2608/2609**; if `withoutShield > 4` → `LockAndAdd([Gcd(24292, 1)])`.
* `Build(slot)`: walks `cachedSpells`; if a spell's `Id == GetAdjustedActionId(24292)` → `QueueEukrasiaIfNeeded(slot)`; then adds at most **2** spells (`ldc.i4.2`).
* `LockAndAdd(spells)`: `mitigationLockUntil = Environment.TickCount64 + 6000` (6000 ms lock).

### 4.29 `Ability.自动单奶` (order #14)
1. `target=null; actionId=0; useKrasis=false`; `StopRequested()` → `-999`; `!QT("奶人") || !QT("单奶")` → `-100`; silence → `-1`; `!CanUseOffGcd(2)` → `-4`; `Me.Level < 35` → `-3`.
2. `actionId = SelectAction()`; `0` → `-5`; `HasRecentGroupHeal()` → `-21`; `actionId = SelectAction()` again; `0` → `-5`.
3. `threshold` = `24296 → 灵橡阈值(50)`, `24303 → 白牛阈值(65)`, `24305 → 输血阈值(70)`, else `0`.
4. `target = ResolveSingleHealTarget(threshold, tanksOnly: actionId is 24303 or 24305) ?? ResolveSingleHealTarget(0, false)`; `null` → `-1`.
5. `useKrasis = IsReady(24317, target) && !target.HasAura(2622) && target.CurrentHpPercent*100 <= settings.GCD单奶阈值 /*40*/`.
6. `actionId == 24305 ? 5 : 3`.
* `Build`: `if (useKrasis) Ability(24317, target)`; then `Ability(actionId, target)`.
* `SelectAction()`: `IsReady(24305)` → `24305`; if `Addersgall <= 0 || !CanSpendAddersgallStatic()` → `0`; `IsReady(24303) && !RecentlyUsed(24296,2000)` → `24303`; `IsReady(24296) && !RecentlyUsed(24296,2000) && !RecentlyUsed(24303,2000)` → `24296`; else `0`.
* `HasRecentGroupHeal()` = `RecentlyUsed(24299|24288|24302|37035, 2000)`.

### 4.30 `Strategy.贤者奶满策略` (the one `ISlotSequence`)
* `StartCheck()`: `HasSkillSilenceStatus()` → `-1`; `settings.高难模式 == 1` → `-1` (**disabled in savage**); `target = HealerFullHealTargetSelector::FindTarget()`; `null` → `-1`; else `1`.
* `BuildHealSlot(slot)`: `!QT("奶人") || !IsTargetInRange(target)` → return; then in order:
  1. `!Me.HasAura(3898) && !RecentlyUsed(37035,2000) && IsReady(37035)` → `Ability(37035)`; return.
  2. `!Me.HasAura(2617) && !Me.HasAura(2620) && !RecentlyUsed(24288,2000) && !RecentlyUsed(24302,2000)` → `id = Level < 60 ? 24288 : 24302`; `IsReady(id)` → `Ability(id)`; return.
  3. `QT("贤炮") && !IsMovementBlockingCast(24318) && IsReady(24318)` → `Gcd(24318, 0)`; return.
  4. `Addersgall > 0 && LowestHealTarget(settings.白牛阈值 /*65*/) != null && IsReady(24303)` → `Ability(24303, target)`; return.
  5. `!Me.HasAura(2611) && IsReady(24300)` → `Ability(24300)`; return.
  6. `Addersgall > 0 && IsReady(24299)` → `Ability(24299)`; return.
  7. `Addersgall > 0 && LowestHealTarget(settings.灵橡阈值 /*50*/) != null && IsReady(24296)` → `Ability(24296)`; return.
  8. `!IsMovementBlockingCast(24286) && IsReady(24286)` → `Gcd(24286, 1)`.
  * `LowestHealTarget(threshold)` = lowest member of `CastableAlliesWithin30` with `CanReceiveHeal && hp <= threshold`.

### 4.31 `Strategy.复苏` / `Strategy.过路圣人复活`
* `复苏` ctor: `new HealerRaiseResolver(24287, -999, 0, null, <5 cached `Func`s>)`; `Check()`/`Build()` delegate to the framework resolver (**NOT IN DUMP**).
* `过路圣人复活` ctor: `new HealerPasserbyRaiseResolver(40, 24287, "贤者复苏", -999, 0, null, <cached Func>)`; delegate only. Parameter names/order of both ctors are **NOT IN DUMP**.

### 4.32 `SageEventHandler` (wiring, all literals)
* `QueueTankShieldBeforeCombat()`: `QT("停手")` → return; `!QT("单盾") || HasSkillSilenceStatus() || PartyHelper::CastableParty.Count > 4` → return; `tank = SageTools::PreCombatShieldTank()`; require `IsTank`, `!InCutSceneState`, `!SageTools::HasSingleTargetSageShield(tank)`; `!IsReady(24291)` → return; build `new Slot(600)` and `QueueEukrasiaIfNeeded(slot)`, `slot.Add(Gcd(24291, tank).DontUseGcd())`, enqueue into `BattleData.HighPrioritySlots_GCD`. (600 = the `Slot` ctor literal.)
* `OnResetBattle`/`OnTerritoryChanged`: `SageTools::Reset()`, `HealerGcdHealTracker::Clear()`, `HealerDotCastTracker::Clear()`, and if `settings.ResetQtOnBattleEnd` → `SageQT::ResetCurrentModeDefaults()`.
* `OnBattleUpdate`: `CancelCastWhileJumping()`, `ClearInvalidNonBattleTarget()`, `SageTools::UpdateMovement(Me.IsMoving())`, `SageHotkeySystem::RunConfiguredHotkeys()`.
* `OnEnterRotation`: `HealerGcdHealTracker::Initialize()`, `HealerRuntimeTools::ShowWelcomeAndCheckSettings("贤者", <cached Func>, true)`.

### 4.33 `SageTools` (target-selection + gauges) — key members
| Method | Logic (FROM IL) |
|---|---|
| `CanSpendAddersgall(reserve)` | `System.Math::Clamp(Addersgall, 0, 3) > reserve` |
| `CanSpendAddersting(reserve)` | `System.Math::Clamp(Addersting, 0, 3) > reserve` |
| `IsEukrasiaActiveOrBuffed()` | `Me.HasAura(2606, 0)` |
| `ShouldInsertEukrasia()` | `SpellExtension::IsUnlock(24290) && !IsEukrasiaActiveOrBuffed()` |
| `QueueEukrasiaIfNeeded(slot)` | if `!ShouldInsertEukrasia()` → false; else `slot.Add(new Spell(24290, 1).DontUseGcd())`; true |
| `NeedsSingleTargetShield(t)` | `!HasAura(2607) && !HasAura(2608) && !HasAura(2609) && !HasAura(2612) && !HasAura(297) && !HasAura(1918)` — **presence only, no duration** |
| `HasSingleTargetSageShield(t)` | `HasAura(2607) || HasAura(2608)` |
| `HasShield(t)` | `HealerHealingHelper::HasAnyStatus(t, ShieldStatuses)` (7-element array; **values not in dump**) |
| `CurrentMitigation()` | `(HasAura(2613)‖HasAura(2643), HasAura(3033)‖HasAura(3365), HasAura(2618))` |
| `HasActiveMitigation(includeKerachole)` | `Item1 || Item2 || (includeKerachole && Item3)` |
| `HasSingleTargetDot(t, ms)` | any of `SingleTargetDotStatuses` (3-element array; **values not in dump**) with `t.HasMyAuraWithTimeleft(status, ms)` |
| `HasSingleTargetDotPresence(t)` | same array with `HasLocalPlayerAura(status)` |
| `HasAoeDot(t, ms)` | `t.HasMyAuraWithTimeleft(3897, ms)` |
| `HasAnyDot(t, ms)` | `HasSingleTargetDot(t, ms) || HasAoeDot(t, ms)` |
| `ShouldSkipDotByHp(t)` / `ShouldSkipAoeDotByHp(t)` | `HealerEnemyTargetHelper::ShouldSkipDotByHp(t, 不上Dot阈值/100f, 12)` / `(…, 3)` |
| `DyskrasiaAoeThreshold()` | `Level < 82 ? 2 : 3` |
| `SwitchTargetIfNeeded(t)` | require `settings.智能AOE目标 && settings.自动切换最优目标 && t != null`; if `CurrentTarget == null || CurrentTarget.EntityId != t.EntityId` → `Me.SetTarget(t)` |
| `ShouldHoldBurstForDyingTrash()` | `HealerEnemyTargetHelper::ShouldHoldBurstForDyingTrash(0.3f, 15000, false, BattleData.CurrBattleTimeInMs)` |
| `DiagnosisTarget(hpPct)` | `threshold = Clamp(hpPct/100f, 0, 1)`; `tot = CurrentTarget()?.GetCurrTarget()`; if `tot != null && CanReceiveHeal && CanSingleHealTarget && Distance(Me,tot,7) <= 30 && (NeedsLivingDeadHeal(tot) || tot.CurrentHpPercent <= threshold)` → `tot`; else lowest of `CastableAlliesWithin30` with `CanReceiveHeal && CanSingleHealTarget && CurrentHpPercent <= threshold` |
| `TargetOfTargetHealTarget(hpPct, tanksOnly)` | same ToT test, plus optional `JobId::Tanks.Contains(...)`, else `LowestHpSingleHealTarget(hpPct)` |
| `CanSingleHealTarget(t)` | if `!QT("单奶限制")` → true; if `单奶限制坦克/奶妈/输出` all false → true; else `JobId::Tanks.Contains(job) ? 单奶限制坦克 : JobId::Healers.Contains(job) ? 单奶限制奶妈 : 单奶限制输出` |
| `PreCombatShieldTank()` | `LowestMemberByHp(PartyHelper::CastableTanks) ?? Me` |
| `LowestHpTank()` | lowest-HP of `CastableTanks` with `CanReceiveHeal` |
| `LowestHpPartyMember(hpPct, includeSelf)` | lowest of `CastableParty` (self excluded unless `includeSelf`), requires `CanReceiveHeal`, `hp < hpPct` (`ldc.r4 101` initial) |
| `CountLowHpPartyMembers(hpPct)` | `CountLowHpPartyMembersInRange(hpPct, 30)`; range check uses `Distance(Me,m,7) <= range` only when `range < 30` |
| `CountPartyMembersWithoutScholarShield(range)` | `CanReceiveHeal && Distance <= range && !HasAura(297) && !HasAura(1918)` |
| `CountAlivePartyMembersInRangePlusSelf(range)` | `CurrentHp > 0` and (if `range < 30`) `Distance <= range`; over `CastableAlliesWithin30` |
| `CountPartyMembersWithStatus(status, range)` | `CanReceiveHeal && Distance <= range && HasAura(status)` |
| `PartyCountReached(lowHpCount, configuredCount)` | `configuredCount` clamped to `[1, Max(CastableParty.Count,1)]`; returns `lowHpCount >= that` |
| `DeadAllyWithoutRaise()` | first of `PartyHelper::DeadAllies` without aura `148` |
| `CanRaiseTargetNow(t)` | `!t.IsDead` → true; `delay = Max(settings.复活延迟,0)*1000`; `RaiseDeathTimestamps[t.Address] ??= Now`; return `Now - deathTime >= delay` |
| `SelectRaiseTarget()` | `HealerRaiseRuntime::SelectRaiseTarget(RaiseDeathTimestamps, settings.复活延迟, settings.优先复活TN)` |
| `IsHotkeyActive(name)` | timestamp dictionary, window `500` ms |
| `LowestHpRoleTarget(healer)` | lowest of `CastableParty` filtered to `JobId::Healers` (when `healer==1`) else non-tank-non-healer |
| `LowestMemberByHp(members)` | `ldc.r4 2` initial "lowest"; plain min over the enumerable |

---

## 5. Impl A — shared `ACR.Tool.*` code: **bodies that ARE in the dump**

These were the user's "framework helpers" candidates, but the per-class dump contains full bodies for the `ACR.Tool.*` ones:

| Helper | Body in dump? | What the dumped body does (FROM IL) |
|---|---|---|
| `ACR.Tool.Resolvers.HealerResolverBase::CanUseOffGcd(limit)` | **YES** | `AI.Instance.BattleData.HighPrioritySlots_OffGCD.Count < limit` (callers use 1 or 2) |
| `…HealerResolverBase::Check/Build` | abstract | no body |
| `…HealerEsunaTargetSelector` | **YES** | `SelectGeneralTarget(isH1)` = `SelectByPriority(isH1, IsGeneralDispelTarget)`; `IsGeneralDispelTarget` = `IsValidEsunaTarget && TD.Helper::HasDispelStatus`; `IsValidEsunaTarget` = `IsValid && IsTargetable && !HasAnyStatus(Status.不可选中合集) && Distance(Me,t,7) <= 30`; `SelectByPriority` scans `PartyHelper::Party` **forward when isH1, backward otherwise**, then `Me` if the party list is empty; `SelectTemporalStasisTarget` tries `Me` first (`HasAura(938) || HasAura(700)`) |
| `…HealerFullHealTargetSelector` | **YES** | `FindTarget()` = null if `HealerGcdHealTracker::IsHpRefreshPending()`; else first `(statusId, territoryId)` of the 12-element `FullHealStatuses` table `[(370,160),(210,188),(1769,826),(1769,973),(1769,1168),(1769,1169),(1769,1252),(1769,1346),(2303,922),(2303,923),(11,366),(1628,0)]` whose `HasAura(statusId) && CurrentHpPercent < 1.0` member exists in `CastableAlliesWithin30`; `IsTargetInRange` = `Distance <= 30` |
| `…HealerPotionResolver` | **YES** | `Check`: stopped → `-999`; `!isEnabled()` → `-100`; `Me.GetCurrTarget() != null && IsDying(...)` → `-1`; `!ItemHelper::CheckCurrJobPotion()` → `-2`; else `1`. `Build` = `SlotAction(Spell::CreatePotion(2, 10))` |
| `ACR.Tool.Runtime.HealerEnemyTargetHelper` | **YES** | `HasAttackBlock` = `HasAnyStatus(Status.敌人攻击无效状态合集)`; `IsDying` = `CurrentHp <= 0 \|\| !(CurrentHpPercent > 0.001f)`; `IsOutOfAttackRangeOrDead(t,r)` = `Distance(Me,t,7) + AttackRangeBonus() > r \|\| IsDying(t)`; `ShouldSkipDotByHp(t,ratio,mult)` = `IsDying \|\| CurrentHpPercent < ratio \|\| !(t.MaxHp*mult > Me.MaxHp)`; `HasBossCastingAoeWithin(ms)` = any `TargetMgr::Enemys` `TargetHelper::IsBoss` within 30y with `IsTargetCastingActionSoon(e,ms) && TD.Helper::IsAoeAction(e.CastActionId)`; `HasBossCastingTankbusterWithin(ms)` = same with `TD.Helper::IsTankDeathSentence`; `IsTargetCastingActionSoon` = `IsCasting && (TotalCastTime-CurrentCastTime)*1000 < ms`; `AttackRangeBonus()` = `Min(GeneralSettings.AttackRange, 2.5f)`; `SelectCircularAoeTarget(min,cast,dam,cur,incl)` = best of `TargetMgr::Enemys` by `CountCircularAoeHits`, returns `cur` unless `best != null && bestCount >= min`; `CountCircularAoeHits` = enemies with `IsValid && CurrentHp>0 && Distance(Me,e,7) <= cast+dam+(incl?Bonus:0) && !HasAttackBlock && Vector3.Distance(anchor,e) <= dam`; `ShouldHoldBurstForDyingTrash(hpRatio,ms,incl,battleMs)` = false if `!IsInCombat \|\| Party.Count==8 \|\| InBossBattle \|\| terrId==1048 \|\| battleMs <= 10000`, else aggregate non-boss `EnemysIn25` HP/DeathPrediction and compare with `hpRatio` / `deathPredictionMs` |
| `ACR.Tool.Runtime.HealerActionHelper` | **YES** | `Gcd/Ability(id,…)` = `new Spell(GetAdjustedActionId(id), …)`; `GetAdjustedActionId(id)` = `MemApiSpell::CheckActionChange(id)`; `IsReady(id)` = `IsReadyWithCanCast(Ability(id))`; `RecentlyUsed(id,ms)` = **`SpellExtension::RecentlyUsed`** (AEAssist, **NOT IN DUMP**); `SpellRecentlyUsed(id,ms)` = `SpellHistoryHelper::RecentlyUsed(Me, Gcd(id,1), ms)`; `IsMovementBlockingCast(id)` = false if `!IsMoving && !IsJumpingOrFalling`; false if `Me` has any of auras `167/1249/841/3884`; else looks up the Action sheet and tests `Cast100ms > 0`; `Charges(id)` = `MemApiSpell::GetCharges`; `Cooldown(id)` = `MemApiSpell::GetCooldown(GetAdjustedActionId(id))`; `GcdDurationMs()` = `MemApiSpell::GetGCDDuration` |
| `ACR.Tool.Runtime.HealerDotCastTracker` | **YES** | `MarkPending(actionId, target)` / `MarkPending(actionId, successId)`; `HasRecentlyApplied(actionId, successId, target, hasVisibleDot)` — pending window **5000 ms**, successful-cast window **27000 ms**, keyed by `(actionId, target.EntityId)`; a pending cast is treated as applied when `SpellHistoryHelper::GetLastSpellTime(successId) >= pendingTime` or `hasVisibleDot` |
| `ACR.Tool.Raise.HealerRaiseRuntime` / `HealerRaiseResolver` / `HealerPasserbyRaiseResolver` | dumped, **not analyzed by me** | used only through the two `Strategy` wrappers |

---

## 6. Impl B (`shiyuvi`) — classes, ids, conditions

Impl B has **no published resolver list**: `ACR.Sage.SAGEACR`-equivalent is `ACR.鍚岀被 ACRSageRotationEntry`; its `Build(settingFolder)` is UI wiring, its `BuildQt()` only creates QT entries, and its `.cctor` only builds the QT definition dictionary (`停输出`→0, `DOT`, `双目标DOT`, `混合`, `心神风息`, `康复`, all with `ldstr ""`). Skill execution order therefore lives in the shared `ACR3._0` framework (`ACR3._0.鍚岀被 ACRActionMonitor`, `…ACRTargetHelper` — both dumped but not analyzed by me). No `SlotResolverData`-style ordered list exists in the dumped Sage code.

| Class | Ids (`ldc.i4`) | Conditions (IL order) |
|---|---|---|
| `ACR3._0.Sage.SageRotationEventHandler` | 7562 | `AutoLucidDream(slot)`: `!SpellHelper::GetSpell(7562).IsReadyWithCanCast` → false; `Me.CurrentMp < 8000` → `slot.Add(new Spell(7562, Me))`, true; else false. `OnResetBattle`: `SageBattleData.Instance.Reset()`, `Scholar.Qt::Reset()`, `MeleePosHelper::Clear()`. Everything else empty. |
| `ACR3._0.Sage.Sage_QT` | — | UI only (`Combo`/radio → `JobViewWindow.SetQt`). Stub `Check()`. |
| `ACR3._0.Sage.Triggers.强制释放均衡技能` | 24290 | `Handle()`: if `!Resolve<JobApi_Sage>().Eukrasia` → `BattleData.AddSpell2NextSlot(new Spell(24290, Me))`; then `AddSpell2NextSlot(SpellConfig.Create())`. (`Draw()` text: `"所有技能的强制释放均会自动进入均衡后释放，请直接填写均衡变化后的技能ID，如均衡诊断"`.) |
| `ACR3._0.Sage.Triggers.强制队列改` | none found | no Kardia/skill ids; queue manipulation only (I grepped for 24285/2604/2605/心关 — **no hits**). |
| `ACR3._0.Sage.GCD.DOT` | 24293, 24314 | `target = Me.GetCurrTarget()`; `QT("停输出")` → `-1`; `!QT("DOT")` → `-2`; `target.HasMyAuraWithTimeleft(2616,4000) ‖ (2615,4000) ‖ (2614,4000) ‖ (3897,4000)` → `-3`; `!ACRTargetHelper::IsTargetVisibleOrInRange(target, 24293)` → `-99`; `!JobApi_Sage.Eukrasia` → `-100`; else `0`. `Build`: `slot.Add(new Spell(MemApiSpell::CheckActionChange(24314), () => target))`. |
| `ACR3._0.Sage.GCD.Eukrasia` | 24290, (2614/2615/2616/3897 checks), 24293 | `Check()`: `JobApi_Sage.Eukrasia` already true → `-100`; `!DOT()` → `1`; `!extradot()` → `2`; else `-1`. `DOT()`: `QT("停输出")`→`-1`; `!QT("DOT")`→`-2`; any of 2616/2615/2614/3897 with >4000 ms → `-3`; `!IsTargetVisibleOrInRange(target,24293)` → `-99`; `0`. `extradot()`: `QT("停输出")`→`-1`; `!QT("双目标DOT")`→`-1`; `!QT("DOT")`→`-2`; `minHp = Me.MaxHp * 15`; over `TargetMgr::Enemys`: skip null / `!IsValid` / `!IsTargetable` / `MaxHp < minHp` / `IsDead` / `HasAnyAura(HSSBuff.敌人无敌BUFF)` / `HasAura(680)` / `HasAura(942)` / `HasAura(3621)` / `!IsTargetVisibleOrInRange(e,24293)`; choose first free candidate; if `++count >= 3` → `-2`; then `candidate` checks → `-7`/`-10`/`-3`/`-12`/`-13`/`-14`/`-15`/`-99`; else `0`. `Build`: `slot.Add(new Spell(24290, Me))`. |
| `ACR3._0.Sage.Ability.Krasis` | 24317, 1896 | `!QT("混合")` → `-5`; `!SpellHelper::GetSpell(CheckActionChange(24317)).IsReadyWithCanCast` → `-1`; first of `FrameCache::CastableAlliesWithin30` with `CurrentHp > 0 && HasAura(1896,0)` → if valid `1` else `-99`. `Build`: `new Spell(CheckActionChange(24317), target)`. |
| `ACR3._0.Sage.Ability.Psyche` | 37033 | `!QT("心神风息")` → `-5`; `CheckActionChange(37033).IsReadyWithCanCast` → `0` else `-1`. `Build`: `slot.Add(GetSpell(CheckActionChange(37033)))`. |
| `ACR.Sage.GCD.Dosis` | 24283, 167 | `MemApiMove::IsMoving() && !Me.HasAura(167,0)` → `-20`; `QT("停输出")` → `-1`; `!IsTargetVisibleOrInRange(Me.GetCurrTarget(), 24283)` → `-99`; else `0`. `Build`: `GetSpell(CheckActionChange(24283))`. |
| `ACR.Sage.GCD.ExtraDOT` | 24293, 24314, 3599, 2614/2615/2616/3897, 680/942/3621 | `QT("停输出")`→`-1`; `!QT("双目标DOT")`→`-1`; `!QT("DOT")`→`-2`; `minHp = Me.MaxHp*15`; same enemy filter chain as Eukrasia.extradot (plus DoT-aura checks at 4000 ms and the `-7/-10/-3/-12/-13/-14/-15/-99` ladder); finally `!JobApi_Sage.Eukrasia` → `-100`. `Build`: re-scans enemies with the same filters and `IsTargetVisibleOrInRange(…, 3599)` and adds `new Spell(CheckActionChange(24314))`. |
| `ACR.Sage.GCD.Esuna` | 7568 | `FindDispelTargetForward()` null → `-2`; `!IsTargetVisibleOrInRange(target,7568)` → `-3`; `hasDispelTarget` = any `CastableAlliesWithin30` with `HasCanDispel`; `hasDispelTarget && QT("康复")` → `1` else `-1`. `Build`: `QT("正序康复") ? new Spell(7568, FindDispelTarget()) : new Spell(7568, FindDispelTargetForward())`. |
| `ACR.Sage.GCD.Sage_AOEHeal` | **none** | **STUB**: only `static IBattleChara Getshield() => Me;` |
| `ACR.Sage.GCD.Sage_LowHPSingleHeal` | 24291 | `Target()` = lowest `CurrentHpPercent` of `FrameCache::CastableAlliesWithin30` with `CurrentHp > 0 && IsValid && !HasAnyAura(Buff::Dead)`, else `Me`. `spellid()` = `24291`. No `Check/Build` (driven by framework). |
| `ACR.Sage.GCD.Sage_Resurrect` | none | `Target()` = `ACRTargetHelper::FindResurrectTargetForward()` (stub otherwise). |
| `ACR.Sage.Sage_Resurrect` | none | `Target()` = `QT("正序康复") ? FindResurrectTarget() : FindResurrectTargetForward()`. |
| `ACR.Sage.Ability.LucidDreaming` | 7562, 600, 8000 | `!GetSpell(7562).IsReadyWithCanCast` → `-1`; `GCDHelper::GetGCDCooldown() < 600` → `-7`; `Me.CurrentMp > 8000` → `-2`; else `0`. `Build`: `slot.Add(GetSpell(7562))`. ctor sets `SlotMode = 2`. |
| `ACR.Sage.SageBattleData` | 3 | `AethorflowReserve = 3` in ctor; `UpdateAethorflowTimes()` sets it to `0`; `Reset()` re-instantiates `Instance` and clears `SpellQueueGCD`/`SpellQueueAbility`. **I found no read of `AethorflowReserve` in any dumped Sage class.** |
| `ACR.Sage.SageSettings` | 2, 100 | `ConfigVersion = 2`; `DeploymentTacticsTarget = "PM1"`; `AutoReset = 1`; `JobViewSave.MainColor = (0.65882355, 0.078431375, 0.078431375, 0.8)`; `Time = 100`. **No gameplay thresholds at all** (unlike impl A). |
| `ACR.Sage.Qt` | — | thin wrappers over `JobViewWindow::GetQt/SetQt/ReverseQt/GetQtArray/NewDefault`; `Reset()` empty. |

`FrameCache` and `GCDHelper` (used by impl B) **are** dumped: `GCDHelper::RecentlyUsedGCD(ms)` = `GetGCDElapsed() < ms`, `GetGCDElapsed()` = `AEAssist.Helper.GCDHelper.GetGCDDuration() - GetGCDCooldown()`; `FrameCache` is an `IFramework.Update` subscriber caching `CastableAlliesWithin30` etc.

---

## 7. The Kardia system (心关) — both references

| Question | Impl A (`youshu`) | Impl B (`shiyuvi`) |
|---|---|---|
| Who is it placed on? | `ResolveKardiaTarget()`: ① lowest-HP **tank below 75 %** (`0.75f`), ② the tank that my current enemy target is attacking (`CurrentTarget().GetCurrTarget()`, compared by `EntityId`), ③ if my Kardia is already on a tank → **do nothing** (`null`), ④ lowest-HP tank without Kardia, else lowest-HP tank; if no castable tank exists: lowest **non-tank** below **50 %** (`0.5f`) without Kardia → lowest non-tank without Kardia → (if I already spread Kardia on a non-tank → `null`) → lowest non-tank → if `Me.HasAura(2604)` → `null` → else **Me (self)** | **Nothing.** No Kardia class, no `24285`, no `2604`/`2605` anywhere in the 22 Sage classes (grep-verified, incl. `Triggers.强制队列改`). Kardia is left to the AEAssist `JobApi_Sage` / user hotkeys. |
| Aura ids used to detect it | `2604` = Kardia on self; `2605` = Kardion on the target, and `IStatus::SourceId == Me.EntityId` distinguishes "mine" | — |
| When is it moved? | Only when a *better* target exists per the ladder above; "mine is already on a tank" ⇒ no move; a `RecentlyUsed(24285, settings.心关延迟时间)` guard of **5000 ms**; `CanUseOffGcd(1)` gate | — |
| Main-tank concept? | **Yes**, two independent notions: (a) the tank the boss/current target is attacking (target-of-target), (b) "the tank I already gave Kardia to". `SageTools::LowestHpTank()` (used by the 神翼飞T hotkey) is a third, simpler notion | none |
| Follow-ups (`拯救` / `魂灵风`) | `Ability.拯救` casts **24294** on the ally that carries aura `2605` (Kardion, source = me) and lacks `2610`, HP ≤ 70 (`ldc.r4 70`, hard literal) — i.e. it operates *on the Kardia target itself*; the name/effect of 24294 is not provable from the IL. `魂灵风息阈值` (default **60**) is read **only** by `GCD.贤炮` (`CountLowHpPartyMembersInRange(60, 25)` plus self if `Me.CurrentHpPercent*100 <= 60`); `心神风息` is a QT + resolver for **37033** | none |
| Hotkey | `神翼飞T热键` = `LowestHpTank()` + `IsReady(24295)` | — |

---

## 8. Addersgall (蓝豆) / Addersting (红豆) — every threshold that gates spending

| Gate | Impl A literal (IL) | Impl B |
|---|---|---|
| Generic spend check | `CanSpendAddersgall(reserve) = Clamp(Addersgall,0,3) > reserve`; `reserve = settings.保留蓝豆数量` (**default 1**) when `QT("保留蓝豆")`, else unlimited | none |
| Same for red | `CanSpendAddersting(reserve) = Clamp(Addersting,0,3) > reserve`; `reserve = settings.保留红豆数量` (**default 1**) when `QT("保留红豆")` | none |
| Blue-blooded spenders & their gates | `24299` (寄生, 贤者奶满策略, 智慧之爱 recent-use): `IsReady(24299)` + `CanSpendAddersgall()` (no explicit stack count); `24303` Taurochole: `Addersgall > 0` + `IsReady(24303)`; `24296` Druochole: `Addersgall > 0`; `24298` Kerachole: `Addersgall >= 1 && Level >= 50`; `群盾` requires `Addersgall >= 1` | — |
| Blue generator | `24309` Rhizomata: `Level >= 76`, `IsReady(24309,1)`, refuses when `Addersgall >= 2` (`-2`) | — |
| Red-blooded spenders | `24304` Toxikon: requires `Addersting > 0`; extra gates `QT("倾泻资源") && Addersting <= 0 → -9`, `QT("保留红豆") && Addersting <= 保留红豆数量(1) → -9`, `QT("攒爆发") && !QT("倾泻资源") && Addersting <= 2 → -30` | — |
| Addersting gain | none observed (gained by shielding, handled by the game; the ACR never writes it) | — |
| Reserve field in B | — | `SageBattleData.AethorflowReserve` = **3** at construction, set to **0** by `UpdateAethorflowTimes()`; **never read** in the dumped Sage classes |

---

## 9. Eukrasia (均衡) — stance and the pure-heal vs shield decision, exactly as the IL branches

**Impl A**
* Stance detection: `SageTools::IsEukrasiaActiveOrBuffed()` = `Me.HasAura(2606, 0)`. Stance action: **24290**, inserted by `SageTools::QueueEukrasiaIfNeeded(slot)` which is `new Spell(24290, 1).DontUseGcd()` and only fires when `SpellExtension::IsUnlock(24290) && !Me.HasAura(2606)`. There is **no other** test — no gauge, no buff duration.
* The pure/shield choice is **not** a branch inside one class; it is **two separate resolvers per action**, selected by QT flags and by the resolver order:

| Action id | Pure-heal resolver (order) | Shield resolver (order) | Selector the IL actually tests |
|---|---|---|---|
| 24284 / 24291 (诊断 vs 均衡诊断) | `GCD.诊断` (#12), `QT("奶人")`, **no Eukrasia** | `GCD.单盾` (#11), `QT("奶人") && QT("单盾")`, `QueueEukrasiaIfNeeded` then casts **24291** | `单盾` additionally requires `NeedsSingleTargetShield(target)` = target has **none** of auras 2607/2608/2609/2612/297/1918, and `SpellExtension::IsUnlock(GetAdjustedActionId(24291)) && Cooldown == 0`; `诊断` uses `DiagnosisTarget(GCD单奶阈值)` and the `Clamp(GCD单奶阈值/100 + (Level<30 ? 0.1 : 0))` threshold |
| 24286 / 24286+Eukrasia (预后 vs 均衡预后) | `GCD.预后` (#7), `QT("奶人") && QT("群奶")`, **no Eukrasia** | `GCD.群盾` (#6), `QT("奶人") && QT("减伤") && QT("群盾")`, `QueueEukrasiaIfNeeded` then casts **24286** | `群盾` refuses when `Me.HasAura(2609)` (group shield already up) or `HasActiveMitigation(false)`; then needs bleed counts 4 / 2, `HasBossCastingAoeWithin(10000)`, `CountAlivePartyMembersInRangePlusSelf(30) >= 群减人数(2)`, `CountPartyMembersWithoutScholarShield(20) >= Clamp(群减人数,0,8)` |
| 24283 (注药 vs 均衡注药) | `GCD.注药` (#30) casts raw 24283 and **refuses outright while `IsEukrasiaActiveOrBuffed()`** (`-1`) | `GCD.DOT` (#24) `QueueEukrasiaIfNeeded` then 24283 → adjusted 24293 | see §11 |
| 24297 (失衡 vs 均衡失衡) | `GCD.失衡` (#29) casts raw 24297 and also refuses while Eukrasia is up (`-1`) | `GCD.群DOT` (#22) `QueueEukrasiaIfNeeded` then 24297, gated on aura 3897 windows | `QT("群DOT")`, level ≥ 30, `IsReady(24297)`, `ShouldSkipAoeDotByHp` (=`不上Dot阈值(3)/100`, multiplier 3), `ShouldRefreshAoeDot()` (level ≥ 82, ≥ 3 enemies within 5 y, ≥ 2 candidates without any DoT, or 3897 with 1000 < remaining < 4000 ms) |

**Impl B**
* Stance detection is **not** an aura id in the dump: `AEAssist.Core::Resolve<AE.JobApi.JobApi_Sage>().Eukrasia` (framework property; the underlying status id is **NOT IN DUMP**).
* The DoT resolvers *require* the stance to be already active: `ACR3._0.Sage.GCD.DOT` → `!JobApi_Sage.Eukrasia` ⇒ `-100`; `ACR.Sage.GCD.ExtraDOT` → same (`-100`) as its last test. The stance itself is applied by a dedicated GCD resolver, `ACR3._0.Sage.GCD.Eukrasia` (Build = `new Spell(24290, Me)`), whose `Check()` first refuses if the stance is already true (`-100`) and otherwise scores `1` if the single-target DoT is missing, `2` if the second-target DoT is missing, else `-1`.
* Shield form: the only shield cast is `ACR.Sage.GCD.Sage_LowHPSingleHeal` (`spellid() = 24291`, target = lowest-HP living ally within 30 y, else self) — **with no Eukrasia gate and no shield-existence check**. `Sage_AOEHeal` is a stub (`Getshield() => Me`).

---

## 10. The shields (均衡诊断 / 均衡预后 / 泛输血 / 整体论) and existing-shield checks

| Item | Impl A | Impl B |
|---|---|---|
| 均衡诊断 (24291) | `GCD.单盾`: existing-shield test = `NeedsSingleTargetShield` → refuses if the target has **any** of `2607, 2608, 2609, 2612, 297, 1918` (`HasAura(id, 0)`); **no remaining-duration constant is compared** | `Sage_LowHPSingleHeal` casts 24291 with **no** shield check |
| Deeper shield test used elsewhere | `SageTools::HasShield(t)` = `HealerHealingHelper::HasAnyStatus(t, ShieldStatuses)` where `ShieldStatuses` is a **7-element** array whose values come from a `<PrivateImplementationDetails>` blob → **values NOT IN DUMP**. `HasSingleTargetSageShield(t)` = `2607 ‖ 2608` (used by the pre-pull tank shield) | none |
| 均衡预后 (24292 / 24286+Eukrasia) | `GCD.群盾` refuses on `Me.HasAura(2609)` and on any mitigation; `AB.自动减伤.TryAddShieldFallback` counts party members (within **20 y**) having none of `2607/2608/2609` and requires `> 4` of them (self counted if unshielded), plus `HasBossCastingAoeWithin(5000)`, `Me.CurrentMp > 1000`, `IsUnlock(GetAdjustedActionId(24292))`, `IsReady(24292)`, then `Gcd(24292, 1)` with `QueueEukrasiaIfNeeded` inserted in `Build` when the cached spell's id is the adjusted 24292 | none |
| 泛输血 (24311, INFERRED) / 整体论 (24310, INFERRED) | **No dedicated resolver.** Both appear only as readiness gates inside `AB.自动减伤.FillMitigationSpells()` (combos `[24298,24311]`, `[24298,24310]`, `[24310]`, `[24311]`) and as `canHolos`/`canPanhaima` in `GCD.群盾`. The prior checks are `CurrentMitigation()` (auras `2613/2643`, `3033/3365`, `2618`) and a **6000 ms** re-entry lock (`mitigationLockUntil = TickCount64 + 6000`, plus the `HasBossCastingAoeWithin(10000)` + `CountAlivePartyMembersInRangePlusSelf(30) >= 群减人数(2)` gate). **No shield-remaining-duration constant exists anywhere in impl A's shields** | absent |
| Where a duration *is* compared | only ever for **DoT auras** (1000 / 3000 / 4000 ms) and buff `49` (0 < t ≤ 3000 ms in 即刻注药 and `BurstPotionEndingSoon`; `t > 0` in 心神风息) | DoT auras `2614/2615/2616/3897` at exactly **4000 ms** |

---

## 11. The damage-over-time action and the shared filler/DoT id

| Aspect | Impl A | Impl B |
|---|---|---|
| Single-target DoT action | casts **24283** after `QueueEukrasiaIfNeeded`; the *adjusted* id 24293 is only used for the ready-check and for `MarkPending`/`HasRecentlyApplied` | casts `CheckActionChange(24314)` (24293 only used for `IsTargetVisibleOrInRange`) |
| How the same id serves filler and DoT | The IL **never branches on the id**. ① `GCD.注药` (filler) refuses whenever `Me.HasAura(2606)` (Eukrasia up) ⇒ while the stance is up only the DoT resolver can act. ② `GCD.DOT` always queues Eukrasia if needed and then casts 24283; the game's `CheckActionChange` turns it into 24293. ③ The *decision to run* is `ShouldSkipSingleTargetDot` + `HasAnyDot(target, 1000/3000)` | `ACR3._0.Sage.GCD.DOT` refuses unless `JobApi_Sage.Eukrasia` is **already** true (`-100`) and the target has no DoT aura above 4000 ms; `ACR.Sage.GCD.Dosis` (24283) handles the filler and refuses while moving without aura `167` |
| Remaining-duration thresholds | `HasAnyDot(target, 1000)` → cast (score 50); `HasAnyDot(target, 3000)` → cast (score 40); else `-1`; `HealerDotCastTracker` treats a pending cast as applied within **5000 ms** and remembers a successful cast for **27000 ms** | refuses if `2616 | 2615 | 2614 | 3897` has `> 4000 ms` remaining (i.e. refresh window = 4000 ms); no cast-history tracker in the dumped B code |
| DoT aura ids | `SingleTargetDotStatuses` = **3-element `uint[]` from a data blob, values NOT IN DUMP**; AoE DoT = `3897` (hard-coded) | hard-coded `2614`, `2615`, `2616` (single target) and `3897` (AoE) |
| Double DoT | `GCD.双DOT` (#23) subclass of `HealerDoubleDotResolverBase`; per-target rules `ValidTargetInRange(e,25) && !IsBlackList && !ShouldSkipDotByHp`; base body **not extracted (GAP)** | `ACR.Sage.GCD.ExtraDOT` + `Eukrasia.extradot()`: target must have `MaxHp >= Me.MaxHp * 15`, no auras `680/942/3621`/`敌人无敌BUFF`, be visible & in range of `24293`; refuse when `count >= 3` |
| AoE DoT | `GCD.群DOT` (#22) with aura `3897`, windows 1000/4000 ms, `ShouldRefreshAoeDot` (level ≥ 82, ≥ 3 enemies within 5 y) | no Eukrasian Dyskrasia resolver; `3897` is only used as a blocker in the DoT checks |
| AoE filler | `GCD.失衡` (#29) 24297, needs `QT("AOE")` and `GetNearbyEnemyCount(Me,5,5) >= (Level < 82 ? 2 : 3)` | none |

---

## 12. Shared healer resolvers used from `ACR.Tool.Resolvers` (impl A)

| Shared type | Used by | Verified internals |
|---|---|---|
| `HealerResolverBase` | base of all 31; `CanUseOffGcd(1)` (心关, 醒梦) / `CanUseOffGcd(2)` (寄生, 心神风息, 拯救, 智慧之爱, 根素, 自动减伤, 自动单奶, 自生, 输血) | body in dump: `HighPrioritySlots_OffGCD.Count < limit` |
| `HealerDoubleDotResolverBase` | `GCD.双DOT` | dumped (18,339 B) but **not extracted — GAP** |
| `HealerEsunaTargetSelector` | `GCD.康复`, `GCD.绝亚康复` | body in dump (see §5) |
| `HealerFullHealTargetSelector` | `Strategy.贤者奶满策略` | body in dump (12-entry status/territory table reproduced in §5) |
| `HealerPotionResolver` | resolver #0 of the ordered list | body in dump |
| `ACR.Tool.Runtime.HealerActionHelper` | every resolver | body in dump except `SpellExtension::RecentlyUsed` |
| `ACR.Tool.Runtime.HealerDotCastTracker` | `GCD.DOT`, `GCD.群DOT` | body in dump (5000/27000 ms) |
| `ACR.Tool.Runtime.HealerEnemyTargetHelper` | most resolvers | body in dump |
| `ACR.Tool.Runtime.HealerHealingHelper` | `HasAnyStatus/HasBleed/CanReceiveHeal/NeedsLivingDeadHeal/FarthestPartyMember/LowestHpAlly` | dumped (19,640 B), **not read by me** |
| `ACR.Tool.Runtime.HealerRuntimeTools` | `HasSkillSilenceStatus`, `IsHotkeyBlocked`, `CancelCastWhileJumping`, `ClearInvalidNonBattleTarget`, `ShowWelcomeAndCheckSettings`, `PrepareSpellExecution`, `SetMacroRedirectionExecuting` | dumped (28,826 B), **not read by me** |
| `ACR.Tool.Raise.*` | `复苏`, `过路圣人复活`, `SageTools::HasDeadAllyWithoutRaise/SelectRaiseTarget` | dumped, **not read by me** |

### Bodies that are NOT in the dump (checked: one file per dumped class in `cls_youshu`/`cls_shiyuvi`)
`AEAssist.Helper.SpellExtension::{IsUnlock, IsReadyWithCanCast, RecentlyUsed}` (**the user's named example — confirmed absent**; `HealerActionHelper::RecentlyUsed` only forwards to it), `AEAssist.Helper.SpellHistoryHelper::RecentlyUsed/GetLastSpellTime`, `AEAssist.Helper.TargetHelper::{IsBoss, GetNearbyEnemyCount, GetEnemyCountInsideRect, targetCastingIsBossAOE}` (`targetCastingIsBossAOE` occurs **11 times as a call target** in the two dumps and has **no class definition** in either per-class dump), `AEAssist.MemoryApi.{MemApiSpell, MemApiBuff, MemApiMove, MemApiZoneInfo, MemApiDuty, MemApiCondition}` members, `AEAssist.Helper.PartyHelper::*`, `AEAssist.Helper.ItemHelper::CheckCurrJobPotion`, `AEAssist.Helper.DotBlacklistHelper::IsBlackList`, `AEAssist.Helper.TimeHelper::{Now}`, `AEAssist.Helper.GCDHelper::*`, `AEAssist.CombatRoutine.Module.SlotResolverData` (the int literal's semantics), `AEAssist.Module.BattleData/Slot/Spell`, `AEAssist.JobApi.JobApi_Sage::get_Eukrasia`.
`FrameCache` and `GCDHelper` (the global-namespace ones impl B uses) **are** dumped — so the user's `FrameCache::*` example is *not* an unknown in this dump.

---

## 13. 两套参考实现的差异 (where the two references DISAGREE)

1. **Architecture / published order.** A publishes an explicit ordered list of 31 `SlotResolverData` entries (see §2) — the only place a skill order exists. B publishes **no** order in the dumped Sage code; its skills are classes driven by the shared `ACR3._0` framework (the entry's `BuildQt`/`.cctor` only carry QT definitions). A direct "same-skill, different priority" comparison is therefore impossible except for the shared 31-entry table.
2. **Kardia (心关).** A implements the whole system (target ladder incl. a main-tank notion, 5000 ms move guard). B has **no Kardia code at all** — no `24285`, no `2604/2605`, not even in `Triggers.强制队列改`.
3. **Eukrasia strategy.** A: *insert then cast* — every shield/DoT resolver calls `QueueEukrasiaIfNeeded` (guarded by `SpellExtension::IsUnlock(24290) && !Me.HasAura(2606)`) and then casts the **base** action id, letting the game adjust it. B: *stance first, cast later* — the DoT resolvers **refuse** (`-100`) while `JobApi_Sage.Eukrasia` is false and a separate GCD resolver casts 24290. Also: A tests aura **2606**; B tests a framework property whose status id is not in the dump.
4. **Eukrasian DoT id.** A: `24283` cast, `24293` used only for adjustment/ready/pending. B: casts `CheckActionChange(24314)`, and uses `24293` only as an "in range" range/id argument. **24314 vs 24293 is a genuine disagreement about which id represents 均衡注药.**
5. **DoT refresh window.** A: 1000 ms / 3000 ms `HasAnyDot` windows (plus a 5000 ms pending + 27000 ms success cast tracker). B: a single hard **4000 ms** remaining-time test on auras 2614/2615/2616/3897.
6. **DoT status enumeration.** A keeps the 3 single-target DoT ids in a **data-blob array whose values are not in the dump**; B hard-codes 2614/2615/2616 (+3897) in the IL.
7. **AoE damage DoT.** A has `GCD.群DOT` (Eukrasian Dyskrasia via 24297+Eukrasia) and `GCD.失衡` (Dyskrasia spam). B has neither; it only *blocks* on aura 3897.
8. **Shield-existence checks.** A checks existing shields in 4 distinct places (`NeedsSingleTargetShield` = 2607/2608/2609/2612/297/1918; `HasSingleTargetSageShield` = 2607/2608; `SheldStatuses`-based `HasShield`; `TryAddShieldFallback`'s 2607/2608/2609 count > 4) — always **presence-only, never a remaining-duration constant**. B has **no** shield-existence check at all.
9. **Gauge (Addersgall/Addersting) gating.** A: per-spender gates with defaults 保留蓝豆=1 / 保留红豆=1, `Clamp(g,0,3) > reserve`, Toxikon-specific `Addersting<=2` burst hold, Rhizomata refusal at `Addersgall>=2`, Kerachole at `Addersgall>=1 && Level>=50`. B: only `AethorflowReserve` (ctor 3 → set 0, never read) ⇒ no effective gating in the dumped code.
10. **Swiftcast/instant ids.** A treats aura **49** as the "instant" buff (`0 < t <= 3000 ms`) in `即刻注药` and `BurstPotionEndingSoon`, and aura **167** as one of four "can cast while moving" buffs in `IsMovementBlockingCast`. B uses aura **167** as the movement guard in `ACR.Sage.GCD.Dosis`. The two references therefore attach different meanings to 167.
11. **Krasis buff id.** A blocks Krasis when the target **has** `2622` (`!target.HasAura(2622)` required). B inverts the test: its Krasis resolver *looks for* an ally that **has** `1896`. Both agree on the action id **24317**.
12. **Lucid Dreaming. ** Both use **7562** and the same MP constant **8000**, but A gates on `CurrentMp > 醒梦阈值(8000) → refuse` + `!IsCasting` + `CanUseOffGcd(1)` + level ≥ 14, while B has two independent paths: `AutoLucidDream` (`MP < 8000`, no GCD check) and `Ability.LucidDreaming` (requires `GCDHelper::GetGCDCooldown() >= 600` and `MP <= 8000`).
13. **Settings surface.** A exposes 30+ numeric settings (defaults in §3, e.g. 群奶人数=2, 群减人数=2, 白牛阈值=65, 灵橡阈值=50, 输血阈值=70, 自生阈值=80, 寄生阈值=75, 智慧之爱阈值=70, 魂灵风息阈值=60, GCD单奶阈值=40, GCD群奶阈值=50, 不上Dot阈值=3, 心关延迟时间=5000, 起手发炎延迟=3, 起手心神延迟=3). B's `SageSettings` contains **no gameplay thresholds at all** (`ConfigVersion=2`, `DeploymentTacticsTarget="PM1"`, `AutoReset=1`, `Time=100`, colours) — every threshold in B is a hard literal in the skill class.
14. **Party-size gating.** A uses 群奶人数/群减人数 everywhere (default 2). B has no such concept.
15. **Stub classes.** B's `ACR.Sage.GCD.Sage_AOEHeal` is a stub (`Getshield() => Me`); `Sage_LowHPSingleHeal`, `Sage_Resurrect`, `Sage_Resurrect` expose only `Target()`/`spellid()` because the framework owns `Check/Build`. A has no such stubs except the deliberately-thin `Strategy.复苏`/`过路圣人复活` and one-line hotkeys.

---

## 14. 无法确证的部分 (explicitly not determinable from these dumps)

1. **`SageTools::SingleTargetDotStatuses` (3 × uint) and `ShieldStatuses` (7 × uint) literal contents.** They are initialised by `ldtoken <PrivateImplementationDetails>::DADA7BAB…` / `FC4FCA95…` + `RuntimeHelpers::InitializeArray`; no `PrivateImplementationDetails` class is dumped (`grep '^### .*PrivateImplementationDetails'` → 0 hits), so the bytes are unavailable. Consequence: the exact single-target DoT aura ids used by impl A, and the exact 7 shield statuses, are **unknown**. INFERRED (not proven): `ShieldStatuses ⊇ {2607, 2608, 2609, 2612, 297, 1918}` because those six are tested literally in `NeedsSingleTargetShield` and the array has exactly 7 elements.
2. **QT defaults.** Every resolver is gated on `SageQT::GetQt(name)`, and the default on/off state of each QT lives in `SageSettingsData.QtStates`/`QtOrder`, filled by `SageQT::EnsureStateDefaults`/`EnsureOrderDefaults`/`ReapplyCurrentMode` (in `ACR.Sage.SageQT.txt`, 50,883 B, **not read**). So "is this skill enabled out of the box" cannot be answered from what I read. The settings booleans `群盾=1`, `活化=1`, `单盾队友2=1`, `单盾队友3=1`, `失衡走位=1`, `贤炮起手=1` are the only on-by-default signals (their consumers are QT/UI, not the resolvers I read).
3. **`SlotResolverData` int semantics / how a resolver's returned code is compared.** `AEAssist.CombatRoutine.Module.SlotResolverData` is not in the dump, so the `2 / 1 / 0` literals in §2 cannot be interpreted (they look like a mode/priority but that is **INFERRED**).
4. **`AEAssist` internals** listed at the end of §12, incl. the user-named `TargetHelper::targetCastingIsBossAOE` (11 call sites, no body), `SpellExtension::RecentlyUsed`, and `JobApi_Sage::get_Eukrasia` (so impl B's Eukrasia status id is unknown).
5. **`TD.Status` / `TD.Helper` sets**: `敌人攻击无效状态合集`, `不可选中合集`, `无法接受治疗合集`, `HasDispelStatus`, `IsAoeAction`, `IsTankDeathSentence`, `IsFullHealMap`. These decide `HasAttackBlock`, the Esuna target filter, and the boss-AoE detection; their literal id sets were **not** extracted.
6. **`HealerDoubleDotResolverBase::Check/Build`** (impl A `GCD.双DOT`'s real logic) — file exists, body **not extracted**.
7. **`ACR3._0.鍚岀被 ACRTargetHelper` (134,029 B)** — impl B's `IsTargetVisibleOrInRange`, `FindDispelTarget(Forward)`, `FindResurrectTarget(Forward)` bodies exist in the dump but were **not read**; the range/visibility rules of impl B are therefore unverified.
8. **Impl B's skill execution order / framework gating** (`ACR3._0` action monitor, hotkey-driven queue) — not extracted; B's `强制队列改` contains no skill ids/Kardia.
9. **Openers (impl A)** — I extracted only literals: `空起手` uses **24283**; `自定义起手` uses timings `3000, 1500, 2000, 6000, 5000, 6500, 2000, 6500, 6000, 5000, 1000, 15000, 14000, 12500, 11500, 20000, 19000, 17500, 16500, 15000, 14000, 13000, 12000, 13000, 12000, 10000, 9000` and ids `24304, 24314, 24289, 24313, 37033`; `贤者起手辅助` tests auras `2604` and `2605` (Kardia/Kardion). The step-by-step order, conditions and level gates are **not extracted** (the class is 24,592 B).
10. **`群盾阈值` (default 2)** — I found **no read** of it in any dumped Sage resolver/tool class; its consumer is unknown.
11. **`倒计时心关时间` (15000), `预读时间` (1500), `起手红豆数量` (1), `贤炮起手` (1), `活化` (1)** — set in the ctor but not read in the classes I inspected; consumers unknown (likely the opener/QT/UI).
12. **`即刻咏唱延迟时间`, `箭毒延迟时间`** have **no default literal in the ctor** (only reads exist) ⇒ default 0 unless the JSON file or the settings UI supplies a value; the UI default was not checked.
13. **`ACR.Astrologian/Scholar` cross-reads** were not attempted; only Sage sections were analysed.
