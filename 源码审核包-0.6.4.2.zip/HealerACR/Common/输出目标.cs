using System.Numerics;
using AEAssist;
using AEAssist.Extension;
using AEAssist.Helper;
using Dalamud.Game.ClientState.Objects.Types;

namespace HealerACR.Common;

/// <summary>
/// **输出目标选择器** —— 决定"这一发打谁"，带粘滞防乱切。
///
/// ══════════════════════════════════════════════════════════════════
///  ★ 为什么需要它（实测指出的问题）★
///
///  ── 现象 ──
///     · 一直切目标
///     · 坦克拉到怪了，却不去打那只，反而打远处的
///
///  ── 根因 ──
///    我们原来**根本没有"选目标"这一步** —— 输出和 DoT 全部直接读
///    <c>Core.Me.GetCurrTarget()</c>，也就是**玩家手动选中的那个**。
///    于是：玩家选中远处的怪 → 打远处；玩家手动换来换去 → 跟着切。
///    ACR 完全没有自己的判断。
///
///  ── 参考实现是怎么做的（IL 直证）──
///    它们有一层 `HealerEnemyTargetHelper` + `SwitchTargetIfNeeded`：
///    自己算该打谁，需要时**主动切**过去。
///
///  ── 我们的做法：算，但**不抢选中** ──
///    本类只**返回**该打的目标，由调用方用
///    `new Spell(id, 目标)` 打出去（技能自带目标，框架按它施放）。
///
///    ⇒ **玩家选中的目标不会被改** —— 比"主动 SetTarget"克制得多，
///      少了"ACR 抢我目标"这种烦人行为，也不会和玩家抢操作。
///
///  ══════════════════════════════════════════════════════════════════
///  ★ 粘滞（防乱切）是这里的核心 ★
///
///    纯打分函数有两个致命毛病：
///      ① **抖动** —— 两个怪分数接近时，每帧算出来的赢家会来回换，
///         表现就是"一直切目标"
///      ② **快死的不补刀** —— 一只怪 5% 血了，另一只满血，
///         如果按"满血优先"打分就会放掉快死的那只，
///         结果它被队友收掉、或者更糟：拖到它读完一个 AOE
///
///    ⇒ 所以：
///      · 目标还有效（活着 + 有仇恨 + 在打得到的范围内）时**继续用它**
///      · 只有它失效才重新挑 —— 这就是粘滞
///      · 快死的怪给**加分**（收掉它 = 少一个敌人），不是减分
/// ══════════════════════════════════════════════════════════════════
/// </summary>
public static class 输出目标
{
    /// <summary>
    /// 认定"还能打得到"的距离（米）。
    ///
    /// ⚠️ 用 25 米是**施法距离**，不是伤害范围。
    ///    超过它连技能都放不出去，再"有价值"也没用。
    /// </summary>
    private const float 可打距离 = 25f;

    /// <summary>
    /// 目标血量低于这个比例时**加分**（优先收掉）。
    ///
    /// 收掉一个快死的怪 = 场上少一个敌人（少一份伤害、少一次读条）。
    /// 但加分**不能盖过"近"** —— 远处的快死怪跑过去打反而亏。
    /// </summary>
    private const float 补刀血线 = 0.25f;

    /// <summary>补刀加分（乘以自身血量越低加得越多）</summary>
    private const float 补刀权重 = 60f;

    /// <summary>距离权重：每米扣多少分</summary>
    private const float 距离权重 = 2f;

    /// <summary>粘住的目标 ID（粘滞回退用）</summary>
    private static ulong _粘住的目标;

    /// <summary>上次确认 `_粘住的目标` 可用的时刻</summary>
    private static long _粘住的时间;

    /// <summary>
    /// **粘滞窗口（毫秒）** —— 目标短暂不可用时，这段时间内继续用它。
    ///
    /// ⚠️ 200 是**参考实现用的值**（IL 里的常量 `200`）。不要随便调大：
    ///     调大了目标真死了还在打空气；调小了读条/无敌那一瞬会空转 GCD。
    /// </summary>
    private const int 粘滞毫秒 = 200;

    /// <summary>
    /// **这一发该打谁**。
    ///
    /// 拿不到合适的就返回 null，调用方应当退回"不放技能"
    /// （而不是硬打一个远处的怪）。
    /// </summary>
    /// <summary>最近一次 选() 返回 null 的原因（给调试窗 / AI 诊断用，2026-10-03 排查新增）</summary>
    public static string 最近空原因 = "还没调用过";

    public static IBattleChara? 选()
    {
        try
        {
            // ══════════════════════════════════════════════════════════
            //  ① **优先用当前选中的**（玩家手动选的 / 框架自动选的）
            //
            //  ⚠️ 这一步是核心 —— 参考实现就是这么做的：
            //     它不自己选目标，而是**读**框架已经选好的那个。
            //     AEAssist 的自动选目标（TargetSelectorConfig）会在
            //     "你没选目标"时自动挑一个最近的敌人，
            //     我们在这里**接受**它的结果即可。
            //
            //  自己重新打分排序 = 覆盖玩家的手动选择 = 抢方向盘。
            // ══════════════════════════════════════════════════════════
            var 当前 = 当前选中的();
            if (当前 != null)
            {
                _粘住的目标 = 当前.GameObjectId;
                _粘住的时间 = TimeHelper.Now();
                最近空原因 = "";
                return 当前;
            }

            // ══════════════════════════════════════════════════════════
            //  ② **200ms 粘滞回退**（照抄参考实现的做法）
            //
            //  ⚠️ 为什么需要它：
            //     目标在**一瞬间**会被判成不可用 ——
            //       · 正在读条（`IsTargetable` 会短暂为 false）
            //       · 刚被控住 / 转阶段无敌
            //       · 网络抖动导致对象查询失败
            //     这些都不是"目标没了"。不粘滞的话，
            //     ACR 会在这 100~200ms 里**空转一个 GCD**。
            //
            //  200ms 是参考实现用的值（IL 里的常量 `200`）。
            //  再长就会"目标真死了还在打空气"。
            // ══════════════════════════════════════════════════════════
            if (_粘住的目标 != 0 && TimeHelper.Now() - _粘住的时间 <= 粘滞毫秒)
            {
                var 旧 = 找个(_粘住的目标);
                if (旧 != null) { 最近空原因 = ""; return 旧; }
            }

            // ══════════════════════════════════════════════════════════
            //  ③ **兜底**：自己挑一个
            //
            //  什么时候会走到这：
            //     · 框架的自动选目标**关掉了**（用户配置里 Enable=false）
            //     · 玩家没选目标、框架也没选出来（比如刚进本那一帧）
            //     · 目标是友方/无效对象
            //
            //  ⚠️ 兜底**只挑"有仇恨"的** —— 没被坦克拉住的怪打了就是 ADD。
            //     挑不出来就返回 null（不出手），
            //     **不硬打一个远处的怪** —— 少一点输出比打错目标好。
            // ══════════════════════════════════════════════════════════
            var 兜底 = 挑一个();
            if (兜底 != null)
            {
                _粘住的目标 = 兜底.GameObjectId;
                _粘住的时间 = TimeHelper.Now();
                最近空原因 = "";
            }
            else
            {
                最近空原因 = "没有选中目标（或选中的是友方/已死/不可选中），200ms 粘滞也失效，兜底也没挑到有仇恨的";
            }

            return 兜底;
        }
        catch
        {
            return null;
        }
    }

    /// <summary>
    /// **当前选中的目标** —— 玩家手动选的，或框架自动选的。
    ///
    /// ⚠️ 必须**验证可用性**再返回，不能拿到就用：
    ///     目标可能是**友方**（玩家点了队友）、刚死、或者不可选中。
    ///     不验证的话，输出技能会对着友方按下去 —— 放不出来，
    ///     而且会把 GCD 卡住（一直重试同一个放不出的技能）。
    ///
    /// 参考实现的 `IsValidAttackTarget` 检查项（IL 直证）：
    ///     `IsValid` + `IsTargetable` + 是敌人 + 活着
    /// </summary>
    private static IBattleChara? 当前选中的()
    {
        try
        {
            var t = CharacterExt.我的目标();
            if (t == null) return null;

            // 活着
            if (t.CurrentHp == 0) return null;

            // 是敌人（防止玩家点了队友 / NPC）
            try { if (!t.IsEnemy()) return null; } catch { }

            // 可选中（读条中/无敌时会短暂 false，那一瞬间靠 ② 的粘滞兜）
            try { if (!t.IsTargetable) return null; } catch { }

            return t;
        }
        catch
        {
            return null;
        }
    }

    /// <summary>当前粘住的目标（诊断 / 显示用）</summary>
    public static ulong 粘住的目标 => _粘住的目标;

    /// <summary>换本 / 脱战时清掉，别把上个副本的目标带过来</summary>
    public static void 重置()
    {
        _粘住的目标 = 0;
        _粘住的时间 = 0;
    }

    /// <summary>按 ID 找回目标，并检查它**还值不值得继续打**</summary>
    private static IBattleChara? 找个(ulong id)
    {
        if (id == 0) return null;

        try
        {
            foreach (var e in 候选())
            {
                if (e.GameObjectId != id) continue;

                // 活着 + 有仇恨 + 够得着，三个都满足才继续粘
                if (e.CurrentHp == 0) return null;
                if (!HealTargetHelper.稳定仇恨(e)) return null;

                var 距离 = Vector3.Distance(CharacterExt.我的位置(), e.Position);
                if (距离 > 可打距离) return null;

                return e;
            }
        }
        catch { }

        return null;
    }

    /// <summary>
    /// 从候选里**挑一个**。
    ///
    /// ══════════════════════════════════════════════════════════════════
    ///  ★ 打分规则（按重要性排）★
    ///
    ///    ① **只考虑有仇恨的** —— 没被坦克拉住的怪打了就是 ADD，
    ///       这在日随里是会被骂的。所以这是**硬门槛**，不是扣分项。
    ///
    ///    ② **近的优先**（扣 距离×2 分）
    ///       坦克拉住的怪一定在近战位附近 —— 打它既安全又不掉输出。
    ///       而远处的怪很可能是**还没进战**的（打了就 ADD）。
    ///
    ///    ③ **快死的加分**（血量 < 25% 时最多 +60）
    ///       收掉它 = 场上少一个敌人。但权重压在"近"之下：
    ///       远处的快死怪让近战去收，我们不去追。
    ///
    ///    ④ **当前选中目标小幅加分**（+15）
    ///       尊重玩家的选择 —— 他手动选了一个，通常是有意的
    ///       （比如"就打这只"）。但只是**微调**，不足以让我们
    ///       放着一堆近处的怪不打、跑去打他选的远处怪。
    ///
    ///  ⚠️ 全部拿不到时返回 **null**，不返回一个乱挑的 ——
    ///     "不放技能"比"打错目标"好：打错会 ADD，不放只是少一点输出。
    /// ══════════════════════════════════════════════════════════════════
    /// </summary>
    private static IBattleChara? 挑一个()
    {
        try
        {
            IBattleChara? 最佳 = null;
            var 最高分 = float.MinValue;

            ulong 选中 = 0;
            try { 选中 = CharacterExt.我的目标()?.GameObjectId ?? 0; } catch { }

            foreach (var e in 候选())
            {
                var 分 = 0f;

                // ① 硬门槛：没仇恨直接跳过（绝不 ADD）
                if (!HealTargetHelper.稳定仇恨(e)) continue;

                var 距离 = Vector3.Distance(CharacterExt.我的位置(), e.Position);
                if (距离 > 可打距离) continue;

                // ② 近的优先
                分 -= 距离 * 距离权重;

                // ③ 快死的加分（越接近死加得越多）
                var 血比 = e.MaxHp > 0 ? e.CurrentHp / (float)e.MaxHp : 1f;
                if (血比 < 补刀血线)
                    分 += 补刀权重 * (1f - 血比 / 补刀血线);

                // ④ 玩家选中的小幅倾斜
                if (选中 != 0 && e.GameObjectId == 选中) 分 += 15f;

                if (分 > 最高分)
                {
                    最高分 = 分;
                    最佳 = e;
                }
            }

            return 最佳;
        }
        catch
        {
            return null;
        }
    }

    /// <summary>候选敌人列表（统一的取法，不在这里过滤）</summary>
    private static IEnumerable<IBattleChara> 候选()
    {
        var 列表 = new List<IBattleChara>();

        try
        {
            var 全部 = Data.AllHostileTargets;
            if (全部 == null) return 列表;

            foreach (var o in 全部)
            {
                if (o is IBattleChara b && b.CurrentHp > 0) 列表.Add(b);
            }
        }
        catch { }

        return 列表;
    }
}
