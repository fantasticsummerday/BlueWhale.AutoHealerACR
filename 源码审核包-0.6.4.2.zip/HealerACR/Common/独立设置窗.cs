using System;
using System.Reflection;
using AEAssist.Helper;
using Dalamud.Bindings.ImGui;

namespace HealerACR.Common;

/// <summary>
/// **独立设置窗** —— 把设置界面搬到一个**自己的悬浮窗**里，
/// 由 Dalamud 的绘制回调驱动，**完全不经过 AEAssist 的 `AcrUiSandbox`**。
///
/// ══════════════════════════════════════════════════════════════════════════
///  [!] 为什么必须搬走（用户实测 + AEAssist 反编译实证）
///
///      症状：AEAssist 的「ACR设置」页签里，我们画的文字**逐帧出现/消失**；
///            而 QT 面板（悬浮窗）完全正常。
///
///      根因：AEAssist 把 `OnDrawSetting` 包在 `AcrUiSandbox` 里跑：
///
///          // AEAssist/CombatRoutine/CombatRoutine2.cs L1999
///          AcrUiSandbox.Draw(currRotation2.RotationEntry.AuthorName,
///                            currRotation2.RotationEntry.OnDrawSetting);
///
///      而这个沙箱**每次调用**都会：
///        ① 快照 `g.Style` 的 55 个颜色 + 30 个标量（反编译 `xgMBDC63Qv`）
///        ② 退出时**整份写回**（`PZPB8dHx4A` → `epjBTm3kGt`）
///
///      实测这个回调每秒被调 **~520 次**
///      （日志：`路标=0` 累计 70461 -> 71475，每秒 +520）
///      ==> 每秒 520 次把全局样式写回去
///      ==> 同一帧里被 ImGui 读到的样式值在抖
///      ==> **文字逐帧出现/消失**。
///
///      ==> **这不是我们能修的** —— 它是 AEAssist 的行为，
///          我们唯一能做的是**不走那条路**。
///
///  [!] 所以本类的做法：**自己订阅 Dalamud 的绘制回调**
///
///      AEAssist 自己就是这么挂主绘制的（实证）：
///          // AEAssist/Plugin.cs L118
///          Svc.PluginInterface.UiBuilder.Draw += W8qybFkoGG;
///
///      我们挂同一个事件 ==> 一条**独立**的绘制路径
///      ==> **不经过 `AcrUiSandbox`** ==> 不会被它的样式快照/写回干扰。
///
///  [!] 设置内容怎么复用（**关键设计**）
///
///      设置内容（13 段 + AI 设置页 + 记忆库）**原封不动留在
///      `HealerEntryBase.OnDrawSetting()` 里**，一个字符都没搬。
///
///      两条路的区分靠本类的 `绘制中` 标记：
///        · 本类绘制前置 `绘制中 = true` ==> `OnDrawSetting` **正常画**
///        · AEAssist 的沙箱调时它是 false ==> `OnDrawSetting` **直接挡回**
///
///      ==> 既复用同一份代码，又**零结构风险**（不搬代码就不会改坏花括号）。
///
///  [!] 开关方式：QT 面板上的「设置」页签（`视图窗口.AddTab`）
///      那个页签**不画窗口**，只当按钮 —— 窗口由 Dalamud 回调常驻绘制。
///      画在页签里的话，一切页签窗口就消失（本项目踩过两次的坑）。
/// ══════════════════════════════════════════════════════════════════════════
/// </summary>
public static class 独立设置窗
{
    /// <summary>窗口是否显示（由 QT 面板的「设置」页签切换）。</summary>
    public static bool 显示;

    /// <summary>
    /// **本类正在绘制** —— `OnDrawSetting()` 靠它区分"是独立窗口在调"还是"沙箱在调"。
    ///
    /// [!] 只有本类会把它置 true，且**用 try/finally 保证复位**
    ///     （中途抛异常也必须复位，否则沙箱那条路永远画不了）。
    /// </summary>
    public static bool 绘制中;

    /// <summary>
    /// **画设置用的那个入口实例** —— 由第一个 `Build()` 的入口登记。
    ///
    /// [!] 为什么需要：`OnDrawSetting()` 是**实例方法**，而本类的绘制回调是静态的。
    ///
    /// [!] 为什么谁先登记就用谁：设置内容对 5 个职业入口是**同一份代码**
    ///     （都在 `HealerEntryBase` 里，读共享的 `HealSettings`），用哪个都一样。
    /// </summary>
    public static HealerEntryBase? 绘制者;

    private static bool _已挂载;
    private static bool _失败已报;

    /// <summary>
    /// **本回调挂到的那个 UiBuilder 实例** —— `卸载()` 要靠它去摘订阅。
    ///
    /// [!] 为什么要存下来：`RemoveEventHandler` 需要"事件所在的那个对象"。
    ///     只存 `_已挂载 = true` 的话，卸载时**没有东西可摘**。
    /// </summary>
    private static object? _挂到的UiBuilder;

    /// <summary>是否已经成功挂上 Dalamud 的绘制回调。</summary>
    public static bool 已挂载 => _已挂载;

    // ══════════════════════════════════════════════════════════════════════
    //  ★★★ **"只让最新那一份副本画窗口"**（2026-10-03，用户复现步骤逼出来的）★★★
    //
    //  [!] 用户复现（原话）：
    //      「在调试窗开关开着的情况下**关闭 ae**，这时候调试窗**还在**
    //       （应该自动关闭的），同时调试窗内容变为"避免崩溃"那样…
    //        再次启用 ae … 进设置看调试窗开关是开启的，但是开关后调试窗**还是没内容**」
    //
    //  [!] 机理（两个现象同一个根）：
    //      ACR / 插件重载**不会卸载旧程序集**，而 0.6.0.x 里每份副本都把
    //      **它自己的** `每帧画` 挂在 Dalamud 的 `UiBuilder.Draw` 上、**从不摘除**。
    //        · 关闭 AE 之后：旧副本还在被每帧调用，但它引用的 **AEAssist 已经卸载**
    //          ⇒ `Core.Resolve<MemApiCondition>()` 抛异常
    //          ⇒ `可以读游戏状态 = false` ⇒ 窗口只剩"（换区 / 加载中 …避免崩溃）"
    //          ⇒ **窗口既不消失、内容也变成那一行**。
    //        · 再次启用 AE 之后：新副本画【有内容】的窗口，
    //          旧副本**同帧**又画一次【同一个窗口名】的占位版本
    //          ⇒ 谁最后画谁赢 ⇒ 用户看到"开关开了还是没内容"。
    //
    //  [!] ✅ 修法：**给每份副本发一个"世代号"，存在 AppDomain 数据槽里**
    //      （一个进程只有一份，所以旧副本也读得到）：
    //        · 挂载时：世代号 +1，并把自己的世代号记在 `_我的世代`
    //        · 每帧画之前：自己的世代号 ≠ 当前世代号 ⇒ **说明我不是最新的那份** ⇒ 直接不画
    //      ⇒ 旧副本会**自动退出**，不需要去猜它是谁、也不用去摘它的订阅。
    //
    //  [!] 另一道门 `停止键`：**最新的那份被卸载之后，谁都不许再画**。
    //      由 `卸载()` 置位（只有最新那份有权置），由下一次挂载清除。
    //      ⇒ 关闭 AE 时窗口会**立刻消失**，而不是留着一个空壳。
    //
    //  [!] ⚠️ 这两个键都是**内部协调用的**，不是用户状态 ——
    //      千万别把用户开关也塞进来（那是上一版翻车的地方，见 `调试窗全局开关`）。
    // ══════════════════════════════════════════════════════════════════════
    private const string 世代键 = "BlueWhale.AutoHealerACR.绘制世代";
    private const string 停止键 = "BlueWhale.AutoHealerACR.停止绘制";

    /// <summary>本副本的世代号（挂载时写入；0 = 还没挂载过）。</summary>
    private static int _我的世代;

    /// <summary>
    /// **本副本是否已经复位过"调试窗开关"** —— 保证"每次加载默认关"只执行一次。
    ///
    /// [!] 见 `尝试挂载()` 里那段说明：`尝试挂载()` 一份副本内会被调多次，
    ///     每次复位会把用户刚打开的窗口关掉。
    /// </summary>
    private static bool _本次加载已复位开关;

    /// <summary>
    /// **本副本的版本串**（形如 `0.6.1.7+构建戳`）—— 给日志和调试窗用。
    ///
    /// ══════════════════════════════════════════════════════════════════
    ///  [!] 为什么必须有（2026-10-03 用户实测）：重载不卸载 ⇒ 进程里同时活着
    ///      好几份副本，而**外观完全一样**。排查时反复出现"这个现象到底是
    ///      新副本还是旧副本产生的" —— 靠时间猜过好几次，猜错过。
    ///      ⇒ 把版本串打出来：日志一行、调试窗一行 **（截图里就能看到）**。
    ///
    ///  [!] 构成：`AssemblyInformationalVersion`（csproj 的 `<Version>` +
    ///      构建戳，形如 `0.6.1.7+abc1234`）。
    ///      拿不到就退回程序集版本，再拿不到给 "(未知)" —— 绝不抛。
    /// ══════════════════════════════════════════════════════════════════
    /// </summary>
    public static string 本副本版本
    {
        get
        {
            if (_本副本版本 != null) return _本副本版本;
            try
            {
                var 程序集 = typeof(独立设置窗).Assembly;
                var 戳 = 程序集
                    .GetCustomAttributes(typeof(System.Reflection.AssemblyInformationalVersionAttribute), false)
                    .OfType<System.Reflection.AssemblyInformationalVersionAttribute>()
                    .FirstOrDefault()?.InformationalVersion;
                _本副本版本 = string.IsNullOrEmpty(戳)
                    ? (程序集.GetName().Version?.ToString() ?? "(未知)")
                    : 戳;
            }
            catch { _本副本版本 = "(未知)"; }
            return _本副本版本;
        }
    }

    private static string? _本副本版本;

    private static int 读世代()
    {
        try { if (AppDomain.CurrentDomain.GetData(世代键) is int v) return v; } catch { }
        return 0;
    }

    /// <summary>
    /// **当前绘制世代**（只读）—— 给调试窗那边的诊断用：
    /// 它能把"这一份副本是第几代"写进窗口和诊断文件里，方便判断"是谁在画"。
    /// </summary>
    public static int 当前世代 => 读世代();

    private static void 写世代(int v)
    {
        try { AppDomain.CurrentDomain.SetData(世代键, v); } catch { }
    }

    private static bool 读停止()
    {
        try { if (AppDomain.CurrentDomain.GetData(停止键) is bool b) return b; } catch { }
        return false;
    }

    private static void 写停止(bool v)
    {
        try { AppDomain.CurrentDomain.SetData(停止键, v); } catch { }
    }

    /// <summary>
    /// **挂上 Dalamud 的绘制回调**（幂等 —— 5 个职业入口都会调，只挂一次）。
    ///
    /// [!] 为什么用反射找 `UiBuilder`：
    ///      本工程只 `PackageReference` 了 `AEAssist.NET`；`Dalamud.dll`
    ///      虽然随包提供，但 ACR 运行在宿主的加载上下文里、版本由宿主决定。
    ///      反射取"属性 + 事件"最稳：**找不到就什么都不做**（降级，不影响其他功能）。
    ///
    /// [!] 候选路径（逐个尝试）：
    ///      ① `ECommons.DalamudServices.Svc.PluginInterface`（AEAssist 自己用的）
    ///      ② `DalamudApi.PluginInterface`
    /// </summary>
    public static void 尝试挂载(HealerEntryBase? 入口 = null)
    {
        if (入口 != null) 绘制者 ??= 入口;

        // ══════════════════════════════════════════════════════════════════
        //  ★ **每次调到这里都要做的两件事**（放在 `_已挂载` 提前返回【之前】）★
        //
        //  [!] 为什么不能放在后面：框架在切 ACR / 重载时会先 `Dispose` 再 `Build`，
        //      而 `_已挂载` 还是 true ⇒ 后面直接 return
        //      ⇒ 如果复位放在后面，"本副本已被卸载"这个状态就**永远解除不了**
        //        （单向门：所有窗口再也不画，而且一点日志都没有）。
        //
        //  ① 宣告"**我是最新那一份副本**" —— 世代号 +1，旧的副本下一帧就会自己停
        //  ② 解除 `停止绘制` —— 我来了，就该恢复画
        // ══════════════════════════════════════════════════════════════════
        var 新世代 = 读世代() + 1;
        写世代(新世代);
        _我的世代 = 新世代;
        写停止(false);

        // ══════════════════════════════════════════════════════════════════
        //  ★ **每次加载把"调试窗开关"复位为【关】** —— 用户明确要求
        //
        //  [!] 用户原话：「把逻辑改成**每次启动加载的时候**调试窗开关改成**默认关**」。
        //      `调试窗全局开关` 现在是**全进程一份**（AppDomain 数据槽，见它的类注释），
        //      所以"默认关"必须有人来复位 —— 就是这里，每个新副本**加载时复位一次**。
        //
        //  [!] ⚠️ **必须只复位一次**（用下面的副本内标记）：
        //      `尝试挂载()` 在同一份副本里会被调**多次** ——
        //      5 个职业入口的 `Build()`，以及 QT 面板那个「设置」按钮（`切换()`）。
        //      如果每次都复位，用户开着调试窗、顺手点一下 QT 的「设置」，
        //      窗口就会**自己关掉**（那是比现在更怪的 bug）。
        //
        //  [!] ⚠️ 也别放在"判断 `_已挂载` 之后" —— 框架切 ACR / 重载时会
        //      先 `Dispose` 再 `Build`，那时 `_已挂载` 还是 true ⇒ 复位永远轮不到。
        // ══════════════════════════════════════════════════════════════════
        if (!_本次加载已复位开关)
        {
            _本次加载已复位开关 = true;
            try { 调试窗全局开关.启用 = false; } catch { }
        }

        if (_已挂载) return;

        try
        {
            var 接口 = 找插件接口();
            if (接口 == null)
            {
                报一次("找不到 Dalamud 插件接口");
                return;
            }

            var uiBuilder = 接口.GetType().GetProperty("UiBuilder")?.GetValue(接口);
            if (uiBuilder == null)
            {
                报一次("插件接口没有 UiBuilder 属性");
                return;
            }

            var 事件 = uiBuilder.GetType().GetEvent("Draw");
            if (事件 == null)
            {
                报一次("UiBuilder 没有 Draw 事件");
                return;
            }

            // ══════════════════════════════════════════════════════════════════
            //  ★ 调试窗开关：这里原来有一句 `调试窗全局开关.启用 = false;`
            //    （"每次加载强制复位为关"）—— **已删除（2026-10-03）**
            //
            //  [!] 它当初是为满足「每次启动加载的时候把调试窗开关改成默认关」，
            //      目的只有一个：**一加载 AE 不要自己冒出调试窗**。
            //
            //  [!] ⚠️ 但它造成了新问题（用户随后报的原话）：
            //      「第一遍加载调试窗有内容，切换别的 acr 再切回来、
            //        或者重载 AE 就没了」
            //      因为**切 ACR / 重载 AE 都会加载一份新副本**，
            //      而这一句在新副本里又把开关抹成 false ⇒ 窗口自己关掉。
            //
            //  [!] ✅ 现在由 `调试窗全局开关` 自己保证"启动时是关"：
            //      值存在 **AppDomain 数据槽**里 ——
            //        · 新进程里没有数据 ⇒ 启动时一定是关（原来那个目的仍然满足）
            //        · 同一进程内所有副本读同一份 ⇒ 切换/重载**不会丢**用户的勾选
            //      ⇒ 这里**不需要也不应该**再强制抹掉用户的选择。
            //
            //  [!] 留一行诊断：加载时报出"本会话的开关值"。
            //      排查"切换/重载后窗口没了 / 自己冒出来"这类问题，这一行就是判据
            //      —— 它应当等于用户最后一次勾选的值。
            // ══════════════════════════════════════════════════════════════════
            LogHelper.Info("[HealerACR] 独立设置窗：本次加载开始（调试窗开关默认=关，" +
                           "世代=" + _我的世代 + "｜版本=" + 本副本版本 + "）");

            // ══════════════════════════════════════════════════════════════════
            //  ★★★ **摘掉"上一份副本"遗留的绘制订阅** ★★★
            //
            //  [!] 为什么必须做（这才是"一加载 AE 就冒出调试窗"的真正原因）：
            //      ACR 重载**不会卸载旧程序集**（本项目反复实测过：一个游戏进程里
            //      能堆 20~30 份副本）。旧副本里的 `独立设置窗` 把**它自己的**
            //      `每帧画` 挂在 Dalamud 的 `UiBuilder.Draw` 上，而且**从来不摘**
            //      （0.6.0.x 全工程没有一处 RemoveEventHandler）。
            //      那些旧副本里，有的加载时读到的开关是 `true`
            //      （`调试窗开关.json` 在 22:26 之前一直是 true）
            //      ⇒ **它们会一直画那个窗口**，而我改的任何新代码都管不到旧副本
            //      ⇒ 用户看到的就是"改了好几版还是一加载就冒出来"。
            //
            //  [!] 判据（只摘"自己人但是别的副本"）：
            //        · `Method.Name == "每帧画"`
            //        · `DeclaringType.FullName == "HealerACR.Common.独立设置窗"`
            //        · `DeclaringType.Assembly != 本程序集`   ← 关键：绝不摘自己
            //      ⇒ 摘不到、或 Dalamud 以后换成自定义事件（没有背后的字段）
            //        都只是"什么都不做"，不影响本次挂载。
            //
            //  [!] ⚠️ 顺序：**先清旧的，再挂自己的** —— 反了的话可能把自己摘掉。
            // ══════════════════════════════════════════════════════════════════
            摘掉旧副本的订阅(事件, uiBuilder);

            事件.AddEventHandler(uiBuilder, new Action(每帧画));
            _已挂载 = true;
            _挂到的UiBuilder = uiBuilder;   // ★ 存下来 —— `卸载()` 要用它摘订阅
            LogHelper.Info("[HealerACR] 独立设置窗：已挂上 Dalamud 的绘制回调" +
                           $"（接口={接口.GetType().FullName}）" +
                           $"｜世代={_我的世代}");
        }
        catch (Exception e)
        {
            报一次("挂载异常：" + e.Message);
        }
    }

    /// <summary>
    /// **摘掉"上一份/上几份程序集副本"留在 Dalamud 绘制事件上的回调**。
    ///
    /// [!] 见调用点那段说明：旧副本的 `每帧画` 从来不摘，而它们里的开关可能是
    ///     `true`（当年 json 里存过 true）⇒ 它们会永远画那个调试窗。
    ///     不重启游戏的话，**只有把它们从这个事件上摘下来**才能让窗口真的消失。
    ///
    /// [!] 只摘"类型全名相同、但属于**别的程序集**"的委托：
    ///     · 名字对不上 ⇒ 不动（可能是 Dalamud 自己的或别的插件的）
    ///     · 程序集相同 ⇒ 不动（那是**本次**加载挂的，摘了就没人画了）
    ///
    /// [!] 全程 try/catch：这是"顺手清理"，失败绝不能影响本次挂载。
    /// </summary>
    private static void 摘掉旧副本的订阅(EventInfo 事件, object uiBuilder)
    {
        try
        {
            var 本程序集 = typeof(独立设置窗).Assembly;

            // 字段式事件的背后字段就叫事件名（Dalamud 的 UiBuilder 是 `public event Action Draw`）
            var 字段 = uiBuilder.GetType().GetField(事件.Name,
                BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (字段?.GetValue(uiBuilder) is not Delegate 当前) return;

            var 摘掉 = 0;
            foreach (var d in 当前.GetInvocationList())
            {
                try
                {
                    var 声明类型 = d.Method.DeclaringType;
                    if (声明类型 == null) continue;
                    if (d.Method.Name != "每帧画") continue;
                    if (声明类型.FullName != "HealerACR.Common.独立设置窗") continue;
                    if (ReferenceEquals(声明类型.Assembly, 本程序集)) continue;   // ★ 别摘自己

                    事件.RemoveEventHandler(uiBuilder, d);
                    摘掉++;
                }
                catch { }
            }

            if (摘掉 > 0)
            {
                LogHelper.Info($"[HealerACR] 独立设置窗：已摘掉 {摘掉} 个【旧副本】遗留的绘制回调" +
                               "（它们会一直画调试窗 —— 这是「重载而不重启」的后果）");
            }
        }
        catch { }
    }

    private static void 报一次(string 原因)
    {
        if (_失败已报) return;
        _失败已报 = true;
        LogHelper.Info($"[HealerACR] 独立设置窗不可用（{原因}）—— " +
                       "设置仍可在「ACR设置」页签看到（但那一页会闪）");
    }

    /// <summary>逐个尝试已知路径，返回第一个拿到的插件接口对象。</summary>
    private static object? 找插件接口()
    {
        foreach (var 类型名 in new[] { "ECommons.DalamudServices.Svc", "DalamudApi" })
        {
            var 值 = 取静态属性(类型名, "PluginInterface");
            if (值 != null) return 值;
        }
        return null;
    }

    /// <summary>按类型全名取静态属性值（在已加载程序集里找，找不到返回 null）。</summary>
    private static object? 取静态属性(string 类型全名, string 属性名)
    {
        try
        {
            foreach (var 程序集 in AppDomain.CurrentDomain.GetAssemblies())
            {
                Type? 类型 = null;
                try { 类型 = 程序集.GetType(类型全名, false); } catch { }
                if (类型 == null) continue;

                var 值 = 类型.GetProperty(属性名,
                                          BindingFlags.Public | BindingFlags.Static)?.GetValue(null);
                if (值 != null) return 值;
            }
        }
        catch { }
        return null;
    }

    /// <summary>
    /// **每帧的绘制**（由 Dalamud 的 `UiBuilder.Draw` 驱动）。
    ///
    /// [!] 这里**不开任何节流门** —— 悬浮窗必须每帧提交，
    ///    少提交一帧它在那一帧就"不存在"（这正是原来调试窗闪的原因之一）。
    /// </summary>
    private static void 每帧画()
    {
        using var _深度 = HealerACR.Common.调用深度.进("独立设置窗.每帧画");

        // ══════════════════════════════════════════════════════════════════
        //  ★★★ **第一道门：我不是最新那一份副本 ⇒ 一个像素都不画** ★★★
        //
        //  [!] 为什么必须有（用户复现的原话）：
        //      「在调试窗开关开着的情况下关闭 ae，这时候调试窗**还在**
        //       （应该自动关闭的），同时调试窗内容变为"避免崩溃"那样…
        //        再次启用 ae … 开关后调试窗**还是没内容**」
        //
        //  [!] 机理：重载 ACR / 重启 AE 都会留下**旧副本**，
        //      而 0.6.0.x 里旧副本的绘制订阅**从来没摘过**：
        //        · 关掉 AE 之后：旧副本还在被每帧调用，但它引用的 AEAssist 已经卸载
        //          ⇒ 读游戏状态的判据必然失败 ⇒ 它画的窗口**只剩占位文本**，
        //            而且**窗口不消失**。
        //        · 重新启用 AE 之后：新副本画【有内容】的窗口，旧副本**同帧**
        //          又画一次【同一个窗口名】的占位版本 ⇒ 谁后画谁赢
        //          ⇒ 用户看到"开关开了还是没内容"。
        //
        //  [!] ✅ 判据用**世代号**（AppDomain 数据槽 ⇒ 全进程只有一份，旧副本也读得到）：
        //      挂载时本副本记下自己是第几代；这里发现"当前世代 ≠ 我的世代"
        //      ⇒ 说明后面又加载了新副本 ⇒ 我这份已经过时 ⇒ **自己停手**。
        //      ⇒ 旧副本自动退出 —— 不用去猜它是谁，也不用去摘它的订阅。
        // ══════════════════════════════════════════════════════════════════
        if (_我的世代 == 0 || _我的世代 != 读世代()) return;

        // ══════════════════════════════════════════════════════════════════
        //  ★★★ **第二道门：最新那一份已被卸载 ⇒ 谁都不许再画** ★★★
        //
        //  [!] 为什么（用户原话：「关闭 ae，这时候调试窗还在（**应该自动关闭的**）」）：
        //      `卸载()` 置这个标志 ⇒ 窗口**当场消失**，
        //      而不是留一个读不到游戏状态的空壳挂在屏幕上。
        //      标志由下一次挂载清除（"我来了就恢复画"）。
        // ══════════════════════════════════════════════════════════════════
        if (读停止()) return;

        // ══════════════════════════════════════════════════════════════════
        //  ★★ **调试窗也在这里画** —— 它和设置窗是**同一条受信的路** ★★
        //
        //  [!] 为什么（用户实测：「这下有了，但是调试窗打不开了」）：
        //      调试窗原来的画点在 `HealerEntryBase.OnDrawSetting()` 里
        //      （`面板路标(5)` 与 `面板路标(6)` 之间）。
        //      而我们已经把那条路（沙箱路）**挡回了** ⇒ 那个画点不再执行
        //      ⇒ **调试窗打不开**。
        //
        //  [!] 而且它**本来就不该挂在设置页上**：
        //      · 它是**常驻悬浮窗**（用户勾了开关就该一直在屏幕上）
        //      · 挂在设置页上 ⇒ 不开设置页它就不刷新（历史 bug：
        //        「不开设置页，悬浮窗就不更新」）
        //
        //  ==> 它和设置窗一样是**自己的 ImGui 窗口**，同属"受信的路"，
        //      所以放在这里最自然：**独立于设置窗的开关**，
        //      只由它自己的全局开关（`调试窗全局开关.启用`）控制。
        //
        //  [!] ⚠️ **它必须在 `显示` 判断【之前】** ——
        //      否则"设置窗没开"时调试窗也不会画（那就又回到打不开了）。
        //
        //  [!] ⚠️ **每帧都要提交**，不能加节流门：
        //      少提交一帧，窗口在那一帧就"不存在"（这正是它以前闪的成因）。
        //      `画AI层调试窗()` 内部有它自己的失败计数/冷却，防的是"反复抛异常"。
        // ══════════════════════════════════════════════════════════════════
        try
        {
            // ★ 开关判断**不在这里** —— 交给 `绘制者.画调试窗()` ★
            //
            //  [!] 为什么（用户实测「开关关不掉 / 窗口提前出现」）：
            //      `调试窗全局开关` 在这个进程里有**两份**（两个程序集各一份
            //      静态字段）。如果这里读，读到的可能是另一份的值
            //      ⇒ 设置窗里取消勾选，窗口照样出现。
            //      ==> 只让**入口那一侧**读（和 Checkbox 是同一份），
            //          这里只管"有没有入口实例可以问"。
            //
            //  [!] 同时这也修了「ACR 没加载窗口就出现」：
            //      `绘制者` 是 `Build()` 里登记的，没构建就没有它
            //      ⇒ 不会再出现"没加载 ACR 却弹出窗口"。
            if (绘制者 != null)
                绘制者.画调试窗();
        }
        catch { }

        if (!显示) return;

        try
        {
            ImGui.SetNextWindowSize(new System.Numerics.Vector2(560f, 640f),
                                    ImGuiCond.FirstUseEver);

            var 开着 = true;
            if (!ImGui.Begin("小鲸鱼 · 设置", ref 开着, ImGuiWindowFlags.NoCollapse))
            {
                // `Begin` 返回 false 也必须 `End`（ImGui 契约，见工程里的说明）
                ImGui.End();
                return;
            }

            try
            {
                if (绘制者 == null)
                {
                    ImGui.TextDisabled("  设置尚未就绪（入口还没构建完）。");
                }
                else
                {
                    // 置标记 ==> `OnDrawSetting()` 会走"正常画"那一条
                    绘制中 = true;
                    try { 绘制者.OnDrawSetting(); }
                    finally { 绘制中 = false; }
                }

                ImGui.Separator();
                if (ImGui.Button("关闭"))
                    显示 = false;
            }
            finally
            {
                ImGui.End();
            }

            if (!开着) 显示 = false;
        }
        catch (Exception e)
        {
            LogHelper.Info("[HealerACR] 独立设置窗绘制异常（已忽略）：" + e.Message);
        }
    }

    /// <summary>
    /// **卸载** —— 让所有副本**立刻停止绘制**、摘掉自己的订阅、丢掉入口实例。
    ///
    /// ══════════════════════════════════════════════════════════════════
    ///  [!] 用户原话（2026-10-03）：
    ///      「在调试窗开关开着的情况下关闭 ae，这时候调试窗**还在**
    ///       （**应该自动关闭的**）」
    ///
    ///  [!] 为什么光摘自己的订阅不够：
    ///      旧副本（更早加载的那些）仍然挂在 Dalamud 的绘制事件上，
    ///      它们也会继续画同一张窗口 —— 摘掉"我这一份"根本管不到它们。
    ///      ⇒ 所以这里是**置一个全进程可见的标志**（AppDomain 数据槽）：
    ///        每一份副本的 `每帧画` 都会先读它 ⇒ **所有副本一起停** ⇒ 窗口立刻消失。
    ///
    ///  [!] ⚠️ **只有"最新那一份"有权置这个标志**：
    ///      旧副本被框架 Dispose（切 ACR / 重载时很常见）时不许停掉全局绘制，
    ///      否则刚加载的新副本会被一个临时的 Dispose 连带停掉。
    ///
    ///  [!] 幂等：可以重复调（框架可能对同一入口多次 Dispose）。
    /// ══════════════════════════════════════════════════════════════════
    /// </summary>
    public static void 卸载()
    {
        // ① 只有最新那一份有权"叫停全场"
        if (_我的世代 != 0 && _我的世代 == 读世代()) 写停止(true);

        // ② 摘掉自己的订阅（失败也无所谓 —— ① 已经让所有副本停手了）
        try
        {
            var uiBuilder = _挂到的UiBuilder;
            if (uiBuilder != null)
            {
                var 事件 = uiBuilder.GetType().GetEvent("Draw");
                事件?.RemoveEventHandler(uiBuilder, new Action(每帧画));
            }
        }
        catch { }

        _挂到的UiBuilder = null;
        _已挂载 = false;

        // ③ 丢入口 + 收窗口（静态状态清干净）
        //  [!] `绘制者` 指向的实例可能属于**已卸载的程序集**，留着它就是留着 AV 风险。
        绘制者 = null;
        绘制中 = false;
        显示 = false;
    }

    /// <summary>切换显示（QT 面板的「设置」页签调它）。</summary>
    public static void 切换()
    {
        尝试挂载();
        显示 = !显示;
    }
}
