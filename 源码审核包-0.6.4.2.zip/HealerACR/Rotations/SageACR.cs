using AEAssist;
using AEAssist.CombatRoutine;
using AEAssist.CombatRoutine.Module;
using AEAssist.Extension;
using AEAssist.Helper;
using HealerACR.Common;
using HealerACR.Resolvers;
using HealerACR.Timeline;

namespace HealerACR.Rotations;

/// <summary>贤者技能表。技能 ID 走 SpellIds 内置表（中文名）。</summary>
public class SGESpellTable : JobSpellTable
{
    public override Jobs Job => Jobs.Sage;
    public override string 职业名 => "贤者";

    public override uint 基础输出 => SpellUtil.取已解锁(
        SpellIds.取("注药III"), SpellIds.取("注药II"), SpellIds.取("注药"));

    /// <summary>药尾声补刀用的瞬发填充技 —— 贤者：注药（24283）—— 即刻下变瞬发。</summary>
    /// <summary>
    /// **药尾声填充技 = 基础输出**（自动取最高档：注药III / 注药II / 注药）。
    ///
    /// [!] 原来写死 `注药`（最低档 180/250/300）——
    ///     82 级后基础输出是 `注药III`(330/380)，
    ///     写死低档等于**每个爆发药窗口少 80~130 威力**。
    /// </summary>
    public override uint 药尾声填充技 => 基础输出;
    public override uint 群体输出 => SpellUtil.取已解锁(
        SpellIds.取("失衡II"), SpellIds.取("失衡"));

    /// <summary>
    /// **贤者的 AOE 门槛：94 级起用 3**（不是 2）。
    ///
    /// [!] 算术依据（恰好 2 只怪时群体技是负收益）：
    ///     94+：失衡II 170×2 = 340  <  注药III 380  -> 少 40 威力（10.5%）
    ///
    /// [!] 82-94 段：失衡II 340  vs  注药III 330 -> **正收益**，保持 2。
    ///     72-82 段：失衡 320 vs 注药II 320 -> **持平**，
    ///     持平时不改门槛（改了没收益，反而少覆盖一只怪）。
    /// </summary>
    public override int AOE门槛(int 等级) => 等级 >= 94 ? 3 : 2;
    // 写"注药III/II/注药"的等级链：均衡注药是它们的形态，
    // 只写 1 级的"注药"的话，高等级取不到"均衡注药III"
    /// <summary>
    /// **自身 AOE 技**（`CastType=2 Range=0`）。
    ///
    /// ⚠️ 数据依据（`tools\CastProbe`）：
    ///       失衡   24297  Lv46  咏唱**0.0**  射程0  范围5  威力160
    ///       失衡II 24315  Lv82  咏唱**0.0**  射程0  范围5  威力170
    ///
    /// ⚠️ 贤者的失衡是**瞬发** —— 所以移动中也能用（比占星强）。
    /// </summary>
    public override uint[] 自身AOE候选 => new[]
    {
        SpellIds.取("失衡II"),    // 82 级
        SpellIds.取("失衡"),      // 46 级
    };

    /// <summary>
    /// **威力档位** —— 数据逐字来自游戏数据宏（`tools\HealPotency raw`）。
    ///
    ///    注药    24283  Lv1   if(等级>=64) 300 else if(等级>=54) 250 else 180
    ///    注药II  24306  Lv72  320
    ///    注药III 24312  Lv82  if(等级>=94) 380 else 330
    ///    失衡    24297  Lv46  160
    ///    失衡II  24315  Lv82  170
    ///
    /// ⚠️ 注药有**三档**（180/250/300），别只写两档。
    /// </summary>
    protected override (int 等级, int 威力)[]? 威力表(uint 技能Id)
    {
        if (技能Id == SpellIds.取("注药"))    return new[] { (64, 300), (54, 250), (0, 180) };
        if (技能Id == SpellIds.取("注药II"))  return new[] { (82, 330), (0, 320) };
        if (技能Id == SpellIds.取("注药III")) return new[] { (94, 380), (0, 330) };
        if (技能Id == SpellIds.取("失衡"))    return new[] { (82, 170), (0, 160) };
        if (技能Id == SpellIds.取("失衡II"))  return new[] { (0, 170) };

        return null;
    }

    /// <summary>
    /// **咏唱时间**（秒）—— 来自游戏 `Cast100ms`。
    ///
    /// ⚠️ 注药系列是 **1.5 秒读条**，失衡系列是 **瞬发**。
    ///    两者复唱都是 2.5 秒 ⇒ 都占一个 GCD ⇒ 威力排序里约掉。
    /// </summary>
    public override IReadOnlyDictionary<uint, float> 咏唱时间表 { get; } = new Dictionary<uint, float>
    {
        [SpellIds.取("注药")] = 1.5f,
        [SpellIds.取("注药II")] = 1.5f,
        [SpellIds.取("注药III")] = 1.5f,
        [SpellIds.取("失衡")] = 0f,      // 瞬发
        [SpellIds.取("失衡II")] = 0f,    // 瞬发
    };

    /// <summary>自身 AOE 的半径（贤者是 5 米）</summary>
    public override (bool 是, float 半径) 自身AOE半径(uint 技能Id)
        => (技能Id == SpellIds.取("失衡") || 技能Id == SpellIds.取("失衡II"))
            ? (true, 5f) : (false, 0f);


    // ══════════════════════════════════════════════════════════════════
    //  ★ 治疗候选集 ★  —— 数据来自游戏数据（见 `WhiteMageACR` 同处的说明）
    //
    //  ⚠️ 贤者的恢复力档位在说明宏里是 `if(等级>=85, 高, 低)`（不是 85 级，
    //    是"85 级"这个门槛）—— 见 `tools\HealPotency raw` 的输出。
    // ══════════════════════════════════════════════════════════════════
    private 治疗候选集? _治疗候选;

    /// <summary>
    /// **按等级查两档恢复力**（高等级档 / 低等级档）。
    ///
    /// [!] 不分档会出错：诊断 450/400（85 级提升）——
    ///     写死 450 会让 85 级以下**高估 12.5%**，
    ///     而诊断 vs 预后只差 150，高估 50 就可能翻转选择。
    ///
    /// 来源：`dump_healpot.tsv`（游戏 ActionTransient 说明）。
    /// </summary>
    private static int 档位(uint 技能Id, int 高, int 低, int 提升等级)
    {
        try { return CharacterExt.我的等级() >= 提升等级 ? 高 : 低; }
        catch { return 低; }
    }
    
    public override 治疗候选集 治疗候选
    {
        get
        {
            if (_治疗候选 != null) return _治疗候选;

            var c = new 治疗候选集();

            // ── 单体 GCD ──
            c.加(new 治疗技能 { Id = SpellIds.取("诊断"), 名 = "诊断", 等级 = 2,
                恢复力 = 档位(SpellIds.取("诊断"), 450, 400, 85), MP = 400, 咏唱 = 1.5f, 复唱 = 2.5f });

            // ── 群体 GCD ──
            c.加(new 治疗技能 { Id = SpellIds.取("预后"), 名 = "预后", 等级 = 10,
                // [!] **修正：预后是纯治疗 300，没有盾**（数据核对）
                //     原文只有「恢复自身及周围队员的体力　恢复力：300」。
                //     盾来自**均衡预后**（另一个技能，buff 2609/2866）。
                //     标错 `是盾` 会让打分给它凭空加一份吸收量 ⇒ 高估它。
                恢复力 = 300, MP = 700, 咏唱 = 2.0f, 复唱 = 2.5f, 群体 = true });

            // ── 单体能力技 ──
            //
            // ★ **顺序照抄槽位定义**（`瞬发单奶能力技` 是 `取已解锁(输血, 白牛清汁, 灵橡清汁)`）★
            //
            //  [!] 为什么这一条必须补（本轮审计发现）：槽位里**第一个**是 `输血`，
            //      但治疗候选池里原来**没有它** ==>
            //        ① AI 的候选集里看不到"输血" ⇒ **建议不了它**
            //        ② 而本地 resolver 会从槽位里选出它（只要它已解锁且可用）
            //      ==> **AI 和本地看到的动作集合不一致** ——
            //          这正是"AI 建议的东西本地不做 / 本地做了 AI 没建议"的一类成因。
            //
            //  [!] 数值：输血是**单体大盾 + 持续治疗**（不占 GCD，2 分钟 CD）。
            //      恢复力按官表 1200（它是盾 + HoT 的组合技，这里只填直接治疗部分；
            //      盾由 `是盾` 那条路算，见 `治疗技能` 的说明）。
            c.加(new 治疗技能 { Id = SpellIds.取("输血"), 名 = "输血", 等级 = 76,
                恢复力 = 1200, MP = 0, 咏唱 = 0f, 冷却 = 120f, 是盾 = true });

            c.加(new 治疗技能 { Id = SpellIds.取("灵橡清汁"), 名 = "灵橡清汁", 等级 = 45,
                恢复力 = 600, MP = 0, 咏唱 = 0f, 冷却 = 1f, 资源消耗 = 1 });

            c.加(new 治疗技能 { Id = SpellIds.取("白牛清汁"), 名 = "白牛清汁", 等级 = 62,
                恢复力 = 700, MP = 0, 咏唱 = 0f, 冷却 = 45f });


            // ── 群体能力技 ──
            c.加(new 治疗技能 { Id = SpellIds.取("自生"), 名 = "自生", 等级 = 20,
                恢复力 = 100, MP = 0, 咏唱 = 0f, 冷却 = 60f, 群体 = true,
                HoT恢复力 = 100, HoT持续 = 15f });

            c.加(new 治疗技能 { Id = SpellIds.取("自生II"), 名 = "自生II", 等级 = 60,
                恢复力 = 130, MP = 0, 咏唱 = 0f, 冷却 = 60f, 群体 = true,
                HoT恢复力 = 130, HoT持续 = 15f });

            c.加(new 治疗技能 { Id = SpellIds.取("寄生清汁"), 名 = "寄生清汁", 等级 = 52,
                恢复力 = 400, MP = 0, 咏唱 = 0f, 冷却 = 30f, 群体 = true, 资源消耗 = 1 });

            c.加(new 治疗技能 { Id = SpellIds.取("整体论"), 名 = "整体论", 等级 = 76,
                恢复力 = 300, MP = 0, 咏唱 = 0f, 冷却 = 120f, 群体 = true, 是盾 = true });


            // ── 消化（Lv58，群体，需要蛇胆）──
            //    ⚠️ 审计发现：它在 `群体治疗能力技` 槽位，但**不在候选集**。
            //       数据里的 `450 + 350` 是"打敌人 + 给带心关的人回血"，
            //       对队伍而言的有效治疗量取 **350**（心关部分）。
            c.加(new 治疗技能 { Id = SpellIds.取("消化"), 名 = "消化", 等级 = 58,
                恢复力 = 350, MP = 0, 咏唱 = 0f, 冷却 = 1f, 群体 = true, 资源消耗 = 1 });

            // ── 魂灵风息（Lv90，`600 + 170/130`）──
            c.加(new 治疗技能 { Id = SpellIds.取("魂灵风息"), 名 = "魂灵风息", 等级 = 90,
                // [!] **修正：600 是纯治疗**（数据核对）
                //     原文：「令自身及周围 20 米内的队员恢复体力　恢复力：600
                //            追加效果：令带有关心状态的目标恢复体力　恢复力：…」
                //     170/130 是**关心（心关）那一口**的恢复力，**不是 HoT**。
                //     原来标了 `是盾` + `HoT恢复力=170`，两项都错。
                恢复力 = 600, MP = 700, 咏唱 = 1.5f, 冷却 = 120f, 群体 = true,
                // [!] **显式标能力技** —— 推导判据（`MP > 0 || 冷却 == 0`）会把它
                //     判成 GCD（因为项目给它的 MP 填了 700），
                //     但它实际是 90 级能力技（不占 GCD）。
                //     这是 51 个候选里唯一需要手工标注的一个。
                是能力技 = true,
                HoT恢复力 = 170, HoT持续 = 15f });

            // ── 智慧之爱（Lv100，群体 150）──
            c.加(new 治疗技能 { Id = SpellIds.取("智慧之爱"), 名 = "智慧之爱", 等级 = 100,
                恢复力 = 150, MP = 0, 咏唱 = 0f, 冷却 = 180f, 群体 = true });

            _治疗候选 = c;
            return c;
        }
    }

    public override uint Dot技能 => SpellUtil.取已解锁(
        SpellIds.取("注药III"), SpellIds.取("注药II"), SpellIds.取("注药"));
    public override uint DotBuff => AuraIds.贤者Dot;
    // 均衡注药有三档 buff（2614/2615/2616，另有 2864 同名的另一档），
    // 只查一档的话满级会一直认为"没上 DoT"→ 无限补
    public override uint[] 所有DotBuff => new[]
    {
        AuraIds.贤者Dot, AuraIds.贤者DotAlt, AuraIds.贤者DotAlt2, AuraIds.贤者DotAlt3,
        AuraIds.贤者Dot2, AuraIds.贤者Dot1
    };

    public override uint 单体治疗GCD => SpellIds.取("诊断");
    public override uint 群体治疗GCD => SpellIds.取("预后");
    public override uint 紧急单奶 => SpellUtil.取已解锁(
        SpellIds.取("输血"), SpellIds.取("白牛清汁"), SpellIds.取("灵橡清汁"));

    /// <summary>
    /// 白牛清汁 / 灵橡清汁：瞬发单体治疗（蛇胆资源，不读条）。
    ///
    /// ⚠️ 参考实现的贤者能力技顺序（IL 直证）：
    ///      输血 → 白牛清汁 → 灵橡清汁
    ///    而且有"最近用过就不重复"的时间窗（2000ms）。
    /// </summary>
    public override uint 预铺单奶能力技 => SpellUtil.取已解锁(SpellIds.取("白牛清汁"));

    /// <summary>输血 / 白牛：不读条，移动中也能用。</summary>
    public override uint 瞬发单奶能力技 => SpellUtil.取已解锁(
        SpellIds.取("输血"), SpellIds.取("白牛清汁"), SpellIds.取("灵橡清汁"));

    /// <summary>蛇胆系瞬发治疗的阈值 45%（和学者活性法同档）。</summary>
    public override float 瞬发单奶血线 => 0.45f;
    public override uint 群体治疗能力技 => SpellIds.取("消化");

    // ⚠️ 写"诊断/预后"而不是"均衡诊断/均衡预后"：
    //    后者是前者在均衡状态下的 action change 形态，硬放会被游戏拒绝。
    //    配合 SpellUtil.当前形态() 使用，游戏自己会变成均衡版。
    public override uint 单体盾 => SpellIds.取("诊断");
    public override uint 群体盾 => SpellIds.取("预后");
    public override uint 护盾前置 => SpellIds.取("均衡");
    public override uint 团队减伤 => SpellIds.取("坚角清汁");

    /// <summary>
    /// 均衡状态下"注药"会被游戏替换成"均衡注药"。
    /// 这时候基础输出必须让路 —— 否则 DoT 已经上过之后，
    /// Res_BaseDamage 还会再放一次均衡注药，白白覆盖掉 DoT。
    /// 交给 SGE_Dot 统一处理。
    /// </summary>
    public override bool 有特殊输出形态 => JobApiHelper.均衡中;

    public override uint 复活 => SpellIds.取("复苏");
    public override uint 驱散 => SpellsDefine.Esuna;
    public override uint 醒梦 => SpellsDefine.LucidDreaming;

    // 需求 3：蛇胆就是贤者的"群奶能力技资源"，没蛇胆就退回 GCD 群奶
    // ★ 保留数按队伍规模调整：四人本（单奶）留更多，八人本有搭档可以少留 ★
    public override bool 治疗资源充足 => JobApiHelper.蛇胆 >=
        HealTargetHelper.资源保留调整(HealSettings.Instance.蛇胆保留数);

    // 需求 4：脱战补蛇胆
    public override uint[] 脱战准备技能 => new[] { SpellIds.取("根素") };
}

// ══════════════════════════════════════════════════════════════════════
//  ★ 条件编译：这份源码会被编译进【两个】程序集 ★
//
//  [!] 背景：`BlueWhale.AutoHealerACR.csproj` 用
//        &lt;Compile Include="..\HealerACR\**\*.cs" /&gt;
//      把 HealerACR 的源码又编译了一遍 ==> 基础设施**各有一份静态状态**。
//      正在改成「BlueWhale 引用 HealerACR」（见该 csproj 的注释）。
//
//  [!] 但直接引用会带来一个问题：
//      AEAssist 会用反射扫 ACR 程序集里的职业入口类
//      （`GetExportedTypes` + `IsAbstract` + `IsClass` + `CreateInstance`）。
//      ==> HealerACR.dll 的入口类也会被扫到
//      ==> 职业列表里多出 "HealerACR·白魔"，**而用户只要小鲸鱼**。
//
//  [!] 解法：**在 BlueWhale 里把入口类声明成 `abstract`** ——
//      扫描器跳过抽象类；而 `BlueWhaleWhiteMageEntry` 继承它，
//      **是唯一的具体实现**。
//      ==> HealerACR 独立编译时仍是具体类（那个 ACR 依然可用）。
// ══════════════════════════════════════════════════════════════════════
#if HEALERACR_STANDALONE
    public class SGERotationEntry : HealerEntryBase
#else
    // 在 BlueWhale 里声明为 abstract —— 让 AEAssist 的扫描器跳过它
    // （`BlueWhaleEntry` 才是具体实现）。详见上面的条件编译说明。
    public abstract class SGERotationEntry : HealerEntryBase
#endif
{
    private readonly SGESpellTable _spells = new();

    public override Jobs TargetJob => Jobs.Sage;
    public override string OverlayTitle => "小鲸鱼 · 贤者（日随）";

    public override string Description =>
        "日随用贤者 ACR。自动心关、均衡 DoT、蛇胆优先、毒刺不浪费。\n" +
        "贤者 70 级转职，实际可用 70-100；脱战自动补蛇胆。";
    public override JobSpellTable Spells => _spells;

    protected override List<SlotResolverData> 构建决策队列_职业专属()
    {
        return new List<SlotResolverData>
        {
            new SlotResolverData(new Res_Sprint(), SlotMode.Always),              // 脱战自动疾跑
            new SlotResolverData(new Res_OffensiveAbility(_spells), SlotMode.Always),   // 按错题集：能力技进 Always，不受 GCD 就绪的影响
            // 宠物不在场就召唤（学者的朝日召唤）—— 排在脱战准备之前
            new SlotResolverData(new Res_SummonPet(_spells), SlotMode.Gcd),
            new SlotResolverData(new Res_PrepareResources(_spells), SlotMode.OffGcd),
            new SlotResolverData(new Res_Raise(_spells), SlotMode.Gcd),
            new SlotResolverData(new Res_Esuna(_spells), SlotMode.Gcd),
            // ★ 「必须奶满」机制 —— 插在最前面，理由是行号才是优先级。
            //   这类 debuff 是“奶到 100% 才解除”，晚一个 GCD 人就没了；
            //   而 Check() 的返回值**不参与仲裁**（反汇编已证），只有行号算数。
            //   原来它排在所有治疗 GCD 之后 —— 场上有人被再生/医济抢走 GCD 时，
            //   就永远轮不到它。详见 Res_MustFullHeal 的类注释。
            new SlotResolverData(new Res_MustFullHeal(_spells), SlotMode.Gcd),
            // ★ 预铺 / 瞬发治疗能力技 —— **必须在所有治疗 GCD 之前**。
            //   需求是“治疗应该优先能力技 / 不读条的技能”，
            //   而 Check() 的返回值**不参与仲裁** —— 排在哪一行才算数。
            //   参考实现的 resolver 列表也是能力技在前（IL 直证）。
            //   详见 Res_InstantHealAbility 的类注释。
            new SlotResolverData(new Res_HealEmergency(_spells), SlotMode.OffGcd),
            new SlotResolverData(new Res_InstantHealAbility(_spells), SlotMode.OffGcd),
            new SlotResolverData(new Res_GroupShield(_spells), SlotMode.Gcd),
                        // ══════════════════════════════════════════════════════════════
            //  ★ 移动中开即刻咏唱 ★
            //
            //  [!] 为什么需要（用户实测："全程移动 ai 不奶了"）：
            //      `SpellUtil.移动中能放()` 只**尊重**即刻 buff，
            //      **没有任何地方主动开它** —— 全项目只有 `Res_PotionTail`
            //      （爆发药）和 `Res_Raise`（拉人）用了即刻。
            //      => 移动中所有读条治疗/盾全被挡住，oGCD 治疗资源一空就一口都放不出来。
            //
            //  [!] 位置：在第一个 GCD 治疗之前（否则那个 GCD 会被别处抢走），
            //      但在 `Res_MustFullHeal` / `Res_HealEmergency` / `Res_Raise` 之后
            //      —— 那些是真救命，不能被"开即刻"抢在前面。
            //
            //  [!] 它自己会判"真的有东西需要即刻吗"（血线告急 / 马上挨大伤害），
            //      不是一移动就烧 60 秒 CD —— 详见 Res_移动开即刻 的注释。
            // ══════════════════════════════════════════════════════════════
            new SlotResolverData(new Res_移动开即刻(_spells), SlotMode.Gcd),
new SlotResolverData(new Res_HealAoEGcd(_spells), SlotMode.Gcd),
            new SlotResolverData(new Res_HealSingleGcd(_spells), SlotMode.Gcd),
            new SlotResolverData(new Res_HealShield(_spells), SlotMode.Gcd),
            // ══════════════════════════════════════════════════════════════
            //  ★ 顺序修正：**DoT 必须在 AOE 之前**（对齐两套参考实现的槽序）★
            //
            //  [!] 原来这里是 AOE 在前，注释写的是
            //        「AOE 优先：3 个以上敌人时不该先给单只怪挂 DoT」。
            //
            //  [!] 但参考实现**两套的槽序都是 DoT 在 AOE 之前**（IL 实证）：
            //        shiyuvi 41 槽：… 11 Dot · 12 ForceRuin2 · 13 AOE · 14 BaseGCD
            //        youshu  34 槽：… 28 DOT · 29 即刻极炎法 · 30 裂阵法 · 31 毁坏
            //      ==> 「DoT 在 AOE 之前」这一点**两套没有分歧**。
            //
            //  [!] 而且原来那句注释**与代码不符**：`Res_AoEDamage` 的门槛是
            //        `AOE最少敌人数 = 2`，**不是 3** ==>
            //        2 只敌人时 AOE 就够格了，DoT 会被推后一个 GCD。
            //
            //  [!] 差异范围（枚举验证过，不是猜）：
            //        · 1 只敌人：两边一样（AOE 门槛 2 不满足，落下来补 DoT）
            //        · DoT 还满着：两边一样（`Dot补判` 挡住，落下来放 AOE）
            //        · **只有「≥2 敌 且 DoT 到该补的时候」才有差异**
            //
            //  [!] 为什么改顺序而不是把门槛提到 3：
            //        门槛 2 = youshu 在 82 级以下的档位（它按等级分档 `>=82 ? 3 : 2`）；
            //        提门槛会**同时改变「2 只敌人要不要打 AOE」**这个更基础的行为。
            //
            //  [!] 两个 resolver 的守卫都是完整的（移动中可用 / 值得上Dot / Dot补判 /
            //      黑名单 / AOE 门槛），提前不会造成"移动中卡住"那类问题。
            // ══════════════════════════════════════════════════════════════
            new SlotResolverData(new SGE_Dot(_spells), SlotMode.Gcd),
            new SlotResolverData(new Res_AoEDamage(_spells), SlotMode.Gcd),
            new SlotResolverData(new SGE_Phlegma(), SlotMode.Gcd),   // 发炎：DoT 之后才轮到它
            new SlotResolverData(new SGE_Toxikon(), SlotMode.Gcd),
            // ⚠️ 位置很重要：必须在 `Res_MoveGcd`（移动填充）**之前** ——
            //   药尾声补刀最该生效的场景就是**移动中**（读条放不出来），
            //   排在移动填充后面等于**永远选不到**。
            new SlotResolverData(new Res_PotionTailDamage(_spells), SlotMode.Gcd),
            // ★ 多目标 DoT：主目标 DoT 还在时，把 DoT 扩散到**其他被拉到的怪** ★
            //   ⚠️ 必须在 Res_MoveGcd 之前（否则永远抢不到这个 GCD）
            //   ⚠️ 必须在 Res_Dot 之后（主目标的 DoT 优先级更高）
            new SlotResolverData(new Res_MultiDot(_spells), SlotMode.Gcd),
            // 基础输出：**必须排在 Res_MoveGcd 之前**。
            // 破阵法（近战填充技）也是瞬发，该由它优先选；
            // 排在移动填充之后会把 GCD 抢成毁坏（实测过的问题）。
            new SlotResolverData(new Res_BaseDamage(_spells), SlotMode.Gcd),
            // 移动填充兜底：当 Res_BaseDamage 因为基础输出是读条技而让位时顶上。
            new SlotResolverData(new Res_MoveGcd(_spells), SlotMode.Gcd),

            new SlotResolverData(new SGE_Philosophia(), SlotMode.OffGcd),            // 智慧之爱（Lv100 群疗大招）
            new SlotResolverData(new Res_HealAoEAbility(_spells), SlotMode.OffGcd),
            new SlotResolverData(new SGE_Kardia(_spells), SlotMode.OffGcd),
            new SlotResolverData(new SGE_CholeOverflow(), SlotMode.OffGcd),
            new SlotResolverData(new SGE_Rhizomata(), SlotMode.OffGcd),
            new SlotResolverData(new Res_SelfMitigation(_spells), SlotMode.OffGcd),
            new SlotResolverData(new Res_TeamMitigation(_spells), SlotMode.OffGcd),
            new SlotResolverData(new Res_LucidDreaming(_spells), SlotMode.OffGcd),
            new SlotResolverData(new SGE_Psyche(), SlotMode.OffGcd),
            new SlotResolverData(new Res_HealBooster(_spells), SlotMode.OffGcd),          // 活化
            new SlotResolverData(new Res_HealAmp(_spells), SlotMode.OffGcd),              // 混合
            new SlotResolverData(new Res_KardiaBoost(_spells), SlotMode.OffGcd),          // 拯救
            new SlotResolverData(new Res_Emergency(_spells), SlotMode.OffGcd),            // 寄生清汁
            new SlotResolverData(new Res_GroupHoT(_spells), SlotMode.OffGcd),             // 自生
            new SlotResolverData(new Res_GroupShieldAbility(_spells), SlotMode.OffGcd),   // 泛输血
            new SlotResolverData(new Res_BigAoEHeal(_spells), SlotMode.OffGcd),           // 整体论/魂灵风息
            new SlotResolverData(new Res_LimitBreak(), SlotMode.OffGcd),                  // 极限技
        };
    }

    protected override void 构建QT()
    {
        base.构建QT();
        加职业开关("自动心关", true);
        加职业开关("根素", true);
        加职业开关("箭毒", true);
        加职业开关("发炎", true);
    }
}

// ============================================================================
//  贤者专属
// ============================================================================

/// <summary>均衡注药（DoT）：没开均衡就先开均衡。</summary>
public class SGE_Dot : ISlotResolver
{
    private readonly JobSpellTable _t;

    public SGE_Dot(JobSpellTable table) => _t = table;

    private static uint 均衡 => SpellIds.取("均衡");
    private static uint 技能 => SpellIds.取("均衡注药");

    public int Check()
    {
        if (!HealQt.GetQt("DOT", true)) return -100;
        if (!HealQt.GetQt("输出", true)) return -101;
        if (蓝量.低蓝停手()) return -9;   // 蓝留给治疗
        if (!SpellUtil.已解锁(均衡)) return -2;

        var target = HealTargetHelper.当前目标();
        if (target == null) return -1;
        if (!HealTargetHelper.木桩模式 && target.血量比例() <= HealSettings.Instance.不挂Dot血线) return -3;

        // ⚠️ 判断走**共享**的 Dot补判（含防死循环保险丝）——
        //    原来这里是自己写的一套（自留 `上次DoT` 字段），
        //    和 `Res_Dot` 的逻辑各写一份 → 改一处漏一处。
        //    而且 AI 建议那条路也走 Dot补判，三边必须看同一份数据
        //    （开发约定 F③ 的推广）。
        if (!Dot补判.该补(target, _t.所有DotBuff, HealSettings.Instance.Dot持续时间 - 3f))
            return -4;

        return SpellUtil.可用(均衡) ? 6 : -1;
    }

    public void Build(Slot slot)
    {
        var target = HealTargetHelper.当前目标();
        if (target == null) return;

        // 不在均衡中：这一轮只开均衡，等服务器确认了下一轮再放 DoT。
        // 同一帧里按完均衡就立刻放"均衡注药"是放不出来的。
        if (!JobApiHelper.均衡中)
        {
            var ek = SpellUtil.Get(均衡);
            if (ek != null) slot.Add(ek);
            return;
        }

        var 当前 = SpellUtil.当前形态(技能);
        if (当前 == null) return;

        slot.Add(new Spell(当前.Id, target));

        // ⚠️ 记到**共享**的 Dot补判（不是本类的静态字段）——
        //    保险丝必须和 Res_Dot / AI 建议路径共用，否则那条路能绕过它。
        Dot补判.记一次施放(target);   // 按目标记
        Dot黑名单.记按下(target, _t.所有DotBuff);
    }
}

/// <summary>箭毒：毒刺快溢出或打 AOE 时泄掉。</summary>
public class SGE_Toxikon : ISlotResolver
{
    // 箭毒 66 级、箭毒II 82 级，用等级链取当前该用的那个
    private static uint 技能 => SpellUtil.取已解锁(SpellIds.取("箭毒II"), SpellIds.取("箭毒"));

    public int Check()
    {
        if (!HealQt.GetQt("输出")) return -100;
        if (!HealQt.GetQt("箭毒", true)) return -101;
        if (!SpellUtil.已解锁(技能)) return -2;

        var 毒刺 = JobApiHelper.毒刺;
        if (毒刺 <= 0) return -3;
        if (毒刺 < HealSettings.Instance.箭毒泄刺阈值 && HealTargetHelper.周围敌人数量() < 2) return -4;

        if (!HealTargetHelper.木桩模式)
        {
            if (HealSettings.Instance.时间轴攒资源 && TimelineManager.未来有减伤(8.0)) return -5;
        }

        return SpellUtil.可用(技能) ? 4 : -1;
    }

    public void Build(Slot slot)
    {
        var spell = SpellUtil.Get(技能);
        if (spell != null) slot.Add(spell);
    }
}

/// <summary>心关：给坦克挂上，之后打输出顺带回血。</summary>
public class SGE_Kardia : ISlotResolver
{
    private readonly JobSpellTable _t;

    public SGE_Kardia(JobSpellTable table) => _t = table;

    private static uint 技能 => SpellIds.取("心关");

    public int Check()
    {
        if (HealTargetHelper.木桩模式) return -300;
        if (!HealQt.GetQt("自动心关", true)) return -101;
        if (!SpellUtil.已解锁(技能)) return -2;

        // [!] **必须用 `主坦()`，不能用血量最低的坦克()**（MT/ST 修正）——
        //     心关是打敌人顺带治 MT的机制，**钉错人整场少一大块治疗**。
        //     而 `血量最低的坦克()` 是跟着谁掉血跑的 ==> 八人本 ST 掉血时会跑到 ST 上。
        //     用户原话：「t应该看的是**主仇恨的 mt**，八人本直接就区分 mtst」。
        var tank = HealTargetHelper.主坦();
        if (tank == null) return -1;
        if (AuraIds.有心关(tank)) return -3;

        return SpellUtil.可用(技能) ? 3 : -1;
    }

    public void Build(Slot slot)
    {
        var tank = HealTargetHelper.主坦();
        if (tank == null) return;
        slot.Add(new Spell(技能, tank));
    }
}

/// <summary>根素：补蛇胆，有豆子就不放。</summary>
public class SGE_Rhizomata : ISlotResolver
{
    private static uint 技能 => SpellIds.取("根素");

    public int Check()
    {
        // 木桩也要补蛇胆 —— 补了才有得花，属于资源循环
        if (!HealQt.GetQt("根素", true)) return -101;
        if (!SpellUtil.已解锁(技能)) return -2;
        if (JobApiHelper.蛇胆 >= 1) return -3;

        // ★ 低蓝时不补蛇胆（和学者的补豆同一个道理）★
        //   补资源是为了花出去换治疗/输出，低蓝时该省蓝。
        if (蓝量.低蓝停手()) return -4;

        if (!CharacterExt.可以插能力技()) return -6;

        return SpellUtil.可用(技能) ? 2 : -1;
    }

    public void Build(Slot slot)
    {
        var spell = SpellUtil.Get(技能);
        if (spell != null) slot.Add(spell);
    }
}
