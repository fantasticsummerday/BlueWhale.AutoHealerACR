# 回退完整性审计 —— AI 层会不会让循环比"只用本地层"更差

审计对象：`HealerACR\`（本地优先级队列）与 `BlueWhale.AutoHealerACR\`（AI 层）
框架语义来源：`localnuget\extracted\lib\net10.0\AEAssist.dll` 反汇编（见文末"框架证据"）
结论一句话：**GCD 不会被"判了不用"浪费掉（框架会把空 Build 退回给本地队列），
但 AI 层有 3 条确认的、会让 AI-on 比 AI-off 更差的路径：低蓝停手被绕过、必须奶满被抢、
oGCD 窗口被"非能力技建议"吃掉。另有 2 条状态污染：阈值偏移残留、DoT 保险丝按"进槽"记账。**

---

## 1. `AiSuggestionResolver.cs` 的全部接受 / 拒绝路径

### 1.1 `Check()` —— 拒绝 = `return -1`，框架继续往下扫（本地一定拿到这一帧）

| # | 行 | 条件 | 调 `拦截()`? | 设重试冷却? |
|---|---|---|---|---|
| 1 | 87 | `if (!s.启用决策层) return -1;` | 否 | 否 |
| 2 | 98-99 | `var 建议 = AiDecisionLayer.当前建议; if (建议 == null) return -1;`（队列空 / 全过期） | 否 | 否 |
| 3 | 101-102 | `if (id == 0) return -1;` | 否 | 否 |
| 4 | 119-123 | 同一 ID 在 `重试冷却毫秒 = 1500` 内被拒过 → **静默** `return -1` | 否 | — |
| 5 | 133-138 | `if (!SpellUtil.已解锁(id))` | 是 | 是 |
| 6 | 145-153 | `if (!SpellUtil.可用(id))`（CD/形态） | 是 | 是 |
| 7 | 167-187 | `判目标类型(id) == 施法目标类型.不支持` | 是 | 是 |
| 8 | 190-194 | 敌人类但 `HealTargetHelper.当前目标() == null` | 是 | 是 |
| 9 | 197-201 | 待复活类但 `待复活队友() == null` | 是 | 是 |
| 10 | 231-236 | `if (!SpellUtil.移动中可用(id))`（移动守卫） | 是 | 是 |
| 11 | 241-247 | 敌人 + `!技能数据.打得到(...)`（视线/射程） | 是 | 是 |
| 12 | 288-310 | DoT 且 `!Dot补判.该补(...)` 且 `!完全采信` | 是 | 是 |
| 13 | 339-369 | 群体输出且 `敌数 < 需要` 且 `!完全采信` | 是 | 是 |
| 14 | 400-404 | `!完全采信 && 是输出技能(id) && 有人需要治疗()` | 是 | 是 |
| 15 | 411-415 | `catch (Exception e)` → `return -1` | 否（只打日志） | 否 |

**接受路径**（`AiSuggestionResolver.cs:407-409`）：

```csharp
本帧采纳 = true;
本帧技能 = id;
return 100;   // 最高优先级（比 Always 队列里的其他都高）
```

### 1.2 `Build()` —— 拒绝 = **不加任何 Spell**（框架会退回给本地队列）

| # | 行 | 条件 | 调 `拦截()`? |
|---|---|---|---|
| a | 422-423 | `建议 == null` | 否 |
| b | 425-426 | `id == 0` | 否 |
| c | 549-559 | 候选指定了队友/敌人，但 `找目标()` 找不到（`拦截("候选指定的队友已失效（死亡/退队）—— 不换目标，放弃这条")`） | 是 |
| d | 575-578 | 老格式敌人类但 `当前目标() == null` | 是 |
| e | 595-599 | 待复活类但无待复活队友 | 是 |
| f | 606-627 | `default:` 判不出类别 | 是 |
| g | 629-633 | `施法目标 == null` | 是 |
| h | 638-641 | `catch (Exception e)` | 否（只打日志） |

**接受路径**：`519-526`（候选声明 `目标模式.自己`）、`544-565`（候选带显式目标且找得到）、
`635-636`（老格式按类别推断）。三条都走 `收尾()`（`661-689`，含 `Dot补判.记一次施放` 与
`AiDecisionLayer.消费()`）。

### 1.3 「拒绝之后本地这一帧还有没有机会」—— 框架层裁决（**关键**）

`PVE_RunSlotHelper+<CheckNext>d__4::MoveNext`（`.scratch\checknext.il.txt`）：

```
IL_000e: ldfld  <CheckNext>d__4.v
IL_0013: callvirt  ISlotResolver.Check
IL_0018: stloc.2
IL_0065: ldloc.2
IL_0066: ldc.i4.0
IL_0067: blt  L016e          ; Check() < 0  -> 直接 return false（没进过 Build）
IL_006c: ldc.i4  600
IL_0071: newobj  Slot..ctor
IL_0078: ... callvirt  ISlotResolver.Build      ; Check()>=0 -> Build 一定会被调
IL_008c: ldfld  Slot.Actions
IL_0093: callvirt  ...get_Count
IL_0098: brfalse  L0112                        ; ★ Actions.Count == 0 -> 走"空 Build"分支
...
IL_014a: ldstr  "异常情况: "
IL_015f: ldstr  " 的Build方法没有构造一个可用的技能"
IL_0164: call  String.Concat
IL_0169: call  LogHelper.Error
IL_016e: ldc.i4.0
IL_016f: stloc.1  -> SetResult(false)           ; ★ 返回 false
```

`PVE_RunSlotHelper+<RunSlotResolvers>d__2::MoveNext`（`.scratch\slotresolvers.il.txt`）：

```
IL_0333..IL_0340: call  PVE_RunSlotHelper.CheckNext
IL_03a0: brfalse  L03aa        ; CheckNext 返回 false -> 跳到枚举器 MoveNext（继续扫下一个 resolver）
IL_03a5: leave   L0405         ; CheckNext 返回 true  -> 整个方法结束
```

**裁决：`Check()` 拒绝 → `return -1` → 本地 resolver 同一帧照常被扫到。
`Check()` 通过但 `Build()` 拒绝 → `Actions.Count == 0` → `CheckNext` 返回 **false** →
本地 resolver 同一帧照常被扫到（只是框架会多打一条 `异常情况: … 的Build方法没有构造一个可用的技能`）。**

> 这一条推翻了"AI 的 Check 抢到槽位、Build 又拒绝 → GCD 空转"的假设。
> **被拒绝的建议不花掉 GCD，也不花掉这一帧的机会。**

---

## 2. 队列饿死 / 重复消费（double spending）

### 2.1 一个建议不会被"判 A 放 B"、也不会被吃两次

- `Check()` 用 `当前建议`（Peek，`AiDecisionLayer.cs:207-213` → `找新鲜()` `147-156`），
  `Build()` 再 Peek 一次，**两者之间没有 await**（`CheckNext` 里 `Check` 与 `Build` 是连续 `call`），
  所以拿到的是同一个对象。
- 消费只发生在 `收尾()`（`AiSuggestionResolver.cs:683` `AiDecisionLayer.消费();`），
  即"技能真的进了 slot"之后；`消费()` 内部先 `清理过期()` 再 `出队()`（`AiDecisionLayer.cs:1270-1282`），
  而 `清理过期()` 会把队首所有不新鲜的出掉（`507-529`）→ 出队的对象 == `找新鲜()` 返回的对象。

**裁决：`当前建议`/`消费` 的配对是自洽的，没有"Check 判 A、Build 放 B"，也没有重复消费。**

### 2.2 ⚠️ CONFIRMED：AI 建议会在 **oGCD 趟**再被吃一次，且它可能是**读条 GCD 技能**

注册处（`BlueWhaleEntries.cs:559-565`，白魔/学者/占星/贤者四处同构）：

```csharp
队列.Insert(0, new SlotResolverData(new AiHeartbeat(), SlotMode.Always));
队列.Insert(0, new SlotResolverData(new AiSuggestionResolver(), SlotMode.Always));
```

`SlotMode.Always` 的枚举值是 **0**，框架 IL 里 0 = 两趟都收（`.scratch\slotresolvers.il.txt`）：

```
IL_0300: bne.un  L031d   ; limit==1(GCD 趟) 时 SlotMode==1 才收
IL_0315: bne.un  L031d   ; limit==2(oGCD 趟) 时 SlotMode==2 才收
IL_0324: brtrue  L032c   ; SlotMode != 0 -> 不收
IL_0329: ldc.i4.1; stloc.s 8   ; SlotMode == 0(Always) -> 两趟都收
```

`InternalCalSlot+d__1`（`.scratch\internal.il.txt`）：

```
IL_0359: call  GCDHelper.CanUseGCD
IL_035e: brfalse  L03cf        ; GCD 转好了 -> 只跑 GCD 趟
...
IL_03cf: BattleData.get_AbilityCount ... IL_03e6: ldc.i4.2 -> RunSlotResolvers(2)  ; GCD 转着 -> 跑 oGCD 趟
```

而 `AiSuggestionResolver` **不区分建议的技能是 GCD 还是能力技**——`Check()` 通篇没有任何
GCD/能力技类型判据，一律 `return 100`。`SlotAction.Run`（`.scratch\slotaction.il.txt`）：

```
IL_00b8: ldfld  SlotAction.Spell
IL_00be: call  SpellExtension.IsAbility
IL_00c3: brtrue  L0174        ; 是能力技 -> 直接放
IL_00c8: call  GCDHelper.GetGCDCooldown
IL_00db: ble  L0174           ; GCD 剩余 <= 排队的窗口 -> 直接放
IL_00e0..: CoroutineSystem.WaitAsync(cd - ActionQueueInMs)   ; ★ 读条技能 -> 等到 GCD 快转好
```

于是：**只要 oGCD 趟轮到时队首是一条"读条 GCD 技能"的建议，AI resolver 就会赢下这一趟**：

- `RunSlot` 里 `SlotAction.Run` 要么等 GCD 转好再把这一发打出去（等于**替下一发 GCD 提前拍板**），
  要么放不出去 → `RemoveAt(0)` → `Count == 0` → `Run` 返回 true（`.scratch\runslot.il.txt` `IL_0240: ldc.i4.1`）
  → `CheckNext` 返回 true → **外层循环 `leave L0405` 直接结束**；
- 两种情况下 **本地全部 OffGcd resolver 这一趟都没被扫到**（包括 `Res_LimitBreak`、`AST_Draw`、
  `Res_HealEmergency`、`Res_TeamMitigation`…）；
- 而且 `收尾()` 已经把这条建议 `消费()` 掉了，下一帧换下一条继续吃 oGCD 趟。

对比本地：本地的 `SlotMode.Always` resolver 只有 4 个，**全部是能力技**
（`Res_Sprint` / `Res_OffensiveAbility` / `SCH_Aetherflow` / `SCH_ChainStratagem`），
所以本地层从不会把读条技能塞进 oGCD 趟 —— **这是 AI 路径独有的行为差异。**

**裁决：[LIKELY]（机制 100% 证实；"队首恰好是 GCD 技能"取决于 AI 的候选选择，属常见情形，但我无法在静态代码里证明其发生率）。**

### 2.3 未配置 / 熔断时，**已经排在队列里**的建议仍会被执行

`AiSuggestionResolver.Check()` 只查 `启用决策层`（`87`），**不查 `AiSettings.已配置`，也不查
`DeepSeekClient.该停发(通道.决策)`**。而 `AiDecisionLayer.每帧更新()` 查这两个（`467`、`477`）——
所以拔掉 Key / 熔断之后：补货停了，但队列里 ≤ `有效期毫秒 = 5000`（`AiDecisionLayer.cs:69`）
的建议还会被消费掉。

**裁决：[CONFIRMED]，但影响有界（≤5 秒）。属"熔断不是立即回退"的语义缺口，不是致命问题。**

### 2.4 统计污染（不是战斗污染）

`本帧采纳 = true; 本帧技能 = id;` 在 `Check()` 里就写了（`407-408`），**早于 `Build()`**。
若随后 `Build()` 拒绝、本地 resolver 放了**同一个 ID**，`战斗记忆.判来源()`
（`战斗记忆.cs:309-320`，判据 `AiSuggestionResolver.本帧技能 == 技能Id`）会把这次施放记成
`来源类型.AI`。记忆库会被喂回给 AI 的提示词，属二次污染。

**裁决：[CONFIRMED]，只影响统计 / 记忆库，不影响当场战斗。**

---

## 3. 状态污染逐项核对

| 状态 | AI 路径会改吗 | 本地会读吗 | 被拒 / 过期建议会不会把它带坏 | 裁决 |
|---|---|---|---|---|
| `Dot补判` | **会**：`AiSuggestionResolver.cs:677 if (是Dot) Dot补判.记一次施放(施法目标);` | 会：`Res_Damage.cs:79`、`SageACR.cs:401` 都调 `该补()` | **会**。`记一次施放` 按"技能进 slot"记账（`Dot补判.cs:181-206`），不是按"真的放出去"。放失败时 `_按目标[id].已确认成功` 一直是 false → 走挂起窗口 `5000ms`（`78`、`142`）→ **这 5 秒内 `该补()` 对这个目标恒返回 false**。若 buff 其实上去了（别的来源挂的同一 buff），会升级成 `抑制窗口毫秒() = min(27s, Dot持续时间-3s)` 的整段抑制（`90`、`99-111`、`139`）→ 本地 `Res_Dot` 整段不补 | **[CONFIRMED]（有界：5 s 硬抑制；27 s 抑制需 buff 实际存在）** |
| `本地施放记录` | **不会**。全项目只有 `HealerEntryBase.cs:1694`（`AfterSpell` 回调，真施放后才触发）写它 | 会：`Res_Heal.cs:851 本地施放记录.刚放过(_t.单体盾)` | 不会 | **SOUND** |
| `技能熔断` | 不会（`BlueWhale.AutoHealerACR` 里 0 处引用） | **其实没人读**：`技能熔断.可以尝试()` 在整个解决方案里没有任何调用点，只有 `HealerEntryBase` 的 `重置()` | 不会 | **SOUND（但该模块是死代码）** |
| `OffGcd闸门` | 不会（0 处引用） | 会：`Res_AllExtra.cs:903`、`Res_Heal.cs:353,469` | 不会污染状态；但 AI resolver 在 `Insert(0)` 抢在它们前面 → **闸门被绕过**（见 §4） | **SOUND（状态）/ 叠加 §4** |
| `以太管理` | 不会（0 处引用）；`每帧更新` 已移回本地层（`HealerEntryBase.cs:1771`） | 会：`ScholarACR.cs:528,531` | 不会 | **SOUND** |
| `技能诊断` | 不会（0 处引用） | 会：`WhiteMageACR.cs:741` | 不会 | **SOUND** |
| `记录模式` | 只读（守卫）：`BlueWhaleEntries.cs:553/678/803/928` 与本地 `HealerEntryBase.cs:119` 判据**逐字相同** | 会 | 不会 | **SOUND** |
| `幻觉校验` | AI 层自己写自己读（`幻觉校验.cs:76-165`），注释明写"只打日志，不做任何拦截"（`153-155`） | **不读** | 不会 | **SOUND** |
| `坦克压力` | AI 层自己采样（`BlueWhaleEntries.cs:1278`）；本地层**不引用** `坦克压力.*` | 不读 | 不会 | **SOUND** |
| `局面监控` | AI 层自己；只**读**本地 `输出目标.粘住的目标`（`局面监控.cs:151`）与 `HealTargetHelper` | 不读 | 不会 | **SOUND** |
| `伤害预测` | 只读（`候选集.cs:756,820,822`、`AiSituation.cs:796,1717`）；`减伤乘数.加上()` 是**纯函数**（`减伤乘数.cs:91-104`，无写入） | 会：`治疗决策.cs:412` 等 | 不会 | **SOUND** |
| `输出目标` 粘滞 | **不改 `_粘住的目标`**：AI 路径用的是 `HealTargetHelper.当前目标()`，不是 `输出目标.选()` | 会 | 不污染；但**用错了选择器**（见 §4.3） | **SOUND（状态）/ 见 §4.3** |
| `AiDecisionLayer` 队列 / 世代 | 自己 | 不读 | `_世代`（`AiDecisionLayer.cs:585,765,1088,1157,1197,1307`）保证过期结果一个字都不进队列 | **SOUND** |
| **`阈值钩子`（额外发现，任务清单里没列）** | **会，而且卸载不回来**：`AiThresholdAdapter.cs:225` 把 `AiThresholdAdapter.单体治疗阈值` 挂成永久钩子 | **会**：`HealSettings.cs:112-116`、`127-131` —— `单体治疗阈值` / `群体治疗阈值` 的 getter **每次读都过钩子** | **会**。`偏移()`（`AiThresholdAdapter.cs:110-147`）由 `AiStrategyLayer.当前倾向` 决定；而 `AiStrategyLayer.刷新()` 失败时**故意保留上次结论**（`219 // 失败：保持上一次的结论不变（比清空更安全）`），`当前倾向` 只在 `重置()`（`359-373`）里清，而 `重置()` 只被 `清AI状态()`（`BlueWhaleEntries.cs:289-297`）调用 → **只在切职业 / 重载 ACR 时**。换本走的是 `状态重置钩子`，只 `Ai初始化.重置()`（`BlueWhaleEntries.cs:156`），**不清阈值**。`AiHookInstaller.卸载()` 只在入口 `Dispose()` 里（`BlueWhaleEntries.cs:521/646/771/896/1387`） | **[CONFIRMED]** 关掉策略层 / 拔 Key / 熔断之后，本地治疗阈值**仍然带着最多 ±0.10 的 AI 偏移**，直到切职业或重载 ACR。`AiStrategyLayer.cs:219` 的"保留上次结论"是刻意设计，但它没有区分"AI 仍然可用"与"AI 已经死了" |

---

## 4. 被遮蔽的本地决策（AI 开着就永远轮不到）

AI resolver 在 `Insert(0)` 之后是**整个队列的第 0 位**，而 `Res_低蓝闸门.套上()` 在
`HealerEntryBase.构建决策队列()`（`116-125`）里就地把**已有的** resolver 包了一遍——
AI resolver 是**之后**才插进去的（`BlueWhaleEntries.cs:559-565`），
**所以它没有过这道闸**。逐个核对：

### 4.1 [CONFIRMED] 低蓝停手（`蓝量.低蓝停手()`，阈值 2000 MP）被完全绕过

- 本地：`蓝量.cs:14 public const int 停手阈值 = 2000;`，`Res_低蓝闸门.cs:54-63`
  `if (蓝量.低蓝停手()) return -9;`，并且 `Res_Damage.cs:39/193/309/738`、
  `SageACR.cs:389/508`、`ScholarACR.cs:522/689`、`ScholarExtra.cs:135`、
  `SageExtra.cs:116`、`Res_PotionTail.cs:51`、`爆发轴.cs:453` 各自还有一份。
  `Res_低蓝闸门.cs:27-39` 明写"**绝对不要把这个装饰器套到治疗上**"——它只拦输出，是"把蓝留给治疗"。
- AI：`grep 低蓝停手` 在整个 `BlueWhale.AutoHealerACR\` 里 **0 处命中**。
  `AiSuggestionResolver.Check()`（`78-416`）没有任何蓝量判据。
- ⇒ AI 建议一条输出技能（读条填充 / AOE / DoT）时，只要过了 `SpellUtil.可用` 与
  §1.1 的 14 道闸，就**可以直接在 2000 MP 以下把蓝打光**。AI-off 时这种情况一次都不会发生。

**这一条是"AI 存在使循环更差"里最硬的一条**：它的后果是"接下来治不了人"。

### 4.2 [CONFIRMED] `Res_MustFullHeal`（必须奶满 / 中 Doom 类机制）被抢

- 本地：`Res_Heal.cs:40-53` `Res_MustFullHeal.Check()` 第一句实质判据是
  `if (必须奶满.找目标() == null) return -1;`，命中时 `return 40`（`107`），
  排在 `Res_HealSingleGcd` 之前（`WhiteMageACR.cs:411`，`SlotMode.Gcd`）。
- AI：`必须奶满` 在 `BlueWhale.AutoHealerACR\` 里只出现在
  **提示词 / 场面描述 / 候选评分**（`AiDecisionLayer.cs:443,879-886`、`AiSituation.cs:382-405`、
  `候选集.cs:1132-1135`），**执行器 `AiSuggestionResolver.cs` 里一处都没有**。
- 而它拦输出的那道闸用的是 `有人需要治疗()`（`849-860`）= `低于阈值人数(单体治疗阈值) > 0`。
  **中 Doom 的人血量可能很健康**（提示词 `AiDecisionLayer.cs:882-884` 自己写着"他可能血量看着很健康"）
  → 这道闸**不会**触发 → AI 的输出建议拿到 100 分，赢下 GCD，
  **`Res_MustFullHeal` 这一帧完全没被扫到**。
- 现在唯一的保护是"提示词第 7~9 条让 AI 自觉"。**提示词约束是不可验证的**
  （`幻觉校验.cs:14` 自己承认这一点）。

### 4.3 [CONFIRMED] AI 的输出目标走的是**未经校验**的 `当前目标()`

- 本地：`输出目标.选()`（`输出目标.cs:96-164`）→ `当前选中的()`（`177-199`）明确校验
  `CurrentHp>0` + `IsEnemy()` + `IsTargetable`，注释（`169-176`）就写着"不验证的话，
  输出技能会对着友方按下去 —— 放不出来，而且会把 GCD 卡住"。
- AI：`AiSuggestionResolver.cs:190` 与 `573` 用的是
  `HealTargetHelper.当前目标()` = `HealTargetHelper.cs:371-376`：

  ```csharp
  var t = Core.Me.GetCurrTarget();
  if (t == null) return null;
  return t.CurrentHp > 0 ? t : null;      // ← 没有 IsEnemy / IsTargetable
  ```
  视线/射程那条（`241-247`）只判距离与遮挡，**不判敌我**。
- ⇒ 玩家选中队友 / 选中不可选中的敌人时，AI 的运动建议会通过全部终审、
  `Build` 加 `new Spell(id, 施法目标)`、`收尾()` 消费掉，然后**放不出去**
  （`RunSlot` → `SlotAction.Run` 返回 false → `RemoveAt(0)` → `Count==0` → 返回 true
  → `CheckNext` true → **外层循环结束**）。这一帧本地 resolver 全被跳过，
  而且建议已经被消费 —— 下一帧换下一条继续。
  **这与 `Check()` 直接拒绝不一样：拒绝会退回本地，放失败不会。**

### 4.4 [LIKELY] AI 无法表达的本地决策

判据取自 `AiDecisionLayer.在可选清单里()`（`1328-1401`）+ `判目标类型()`（`936-1024`）：
可表达的 ID 只有 `表` 的具名栏位 + `治疗候选.全部` + `输出能力技` + `脱战准备技能`。
逐个核对下来**不在任何栏位、因而 AI 永远无法建议**的本地决策：

| 本地 resolver | 位置 | AI 能否表达 | 后果 |
|---|---|---|---|
| `Res_Sprint`（脱战自动疾跑） | `*ACR.cs` 第 2 位，`SlotMode.Always` | **不能**（疾跑不在任何 `JobSpellTable` 栏位里） | AI resolver 在 Always 位抢在它前面。脱战时 AI 队列通常为空，风险低 |
| `Res_LimitBreak`（奶妈 LB3 群体复活） | 各 ACR 最后一位，`SlotMode.OffGcd`；`Res_QualityOfLife.cs:60-72` | **不能**（极限技不在任何栏位里） | oGCD 趟被 AI 建议占掉时，**LB3 这一帧轮不到**。见 §2.2：占掉之后外层循环直接结束 |
| `AST_Draw` / `AST_Play` / `AST_CrownPlay` / `AST_MinorArcana` / `AST_Divination` / `AST_Lightspeed` | `AstrologianACR.cs:336-343`，全部 `SlotMode.OffGcd` | **不能**（`治疗候选` 里只有吉星/福星/阳星/先天禀赋/天星交错/擢升/命运之轮/天星冲日/天宫图/地星/小宇宙 —— `AstrologianACR.cs:120-195`，抽卡出卡系一个都没有） | 占星的整个卡牌经济（抽卡会过期）在 AI 开着时可能被 oGCD 趟的 AI 建议反复挤掉 |
| `SCH_Dissipation`（转化）/ `SCH_Seraphism`（炽天附体） | `ScholarACR.cs:641-642` | **不能**（不在 `治疗候选`：`ScholarACR.cs:108-173` 只有医术/鼓舞/士气/意气轩昂/生命活性/深谋远虑/不屈/异想祥光/慰藉/仙光低语） | 中 |

**裁决：这些本地决策在 AI 开着时不是"永远跑不到"，而是"oGCD 趟被抢时跑不到"；
但 §2.2 已证明"被抢 → 外层循环结束"，所以只要 AI 建议持续供应，它们就会被持续压制。**

---

## 5. 失败模式覆盖（AI 关 / AI 坏 的每一条，是否真的回退）

| 失败模式 | 证明代码 | 真回退？ |
|---|---|---|
| **未配置 API Key** | `AiDecisionLayer.cs:467 if (!s.启用决策层 \|\| !s.已配置) return;`（不补货）；`AiSuggestionResolver.cs:98-99 建议 == null → return -1`；`DeepSeekClient.cs:788 if (!s.已配置) return null;` | ✅ 回退。**但**：`Check()` 不查 `已配置`，队列里 ≤5s 的存货仍会执行（§2.3）；**阈值钩子仍挂着**（§3 表末行） |
| **`禁用决策层` 开关** | `AiSuggestionResolver.cs:87 if (!s.启用决策层) return -1;` | ✅ 干净回退（`Check` 第一句），阈值偏移仍残留（策略层开关是另一个） |
| **初始化失败 / 放弃重试** | `Ai初始化.cs:610 已完成 = false;`（超时）、`452`（异常）；`grep 已完成` 的结果：**读取点只有一处** —— `局面监控.cs:107 AI还没好 = !Ai初始化.已完成;` | ❌ **不回退决策层**：`AiDecisionLayer.每帧更新()`（`463-505`）与 `AiSuggestionResolver.Check()`（`78-416`）**都不读 `已完成`**。所以"初始化超时 → 全程走本地策略"（`Ai初始化.cs:604-605`）**只对 `局面监控` 成立**；决策层照样预取、照样执行。 |
| **通道熔断 `该停发`** | `AiDecisionLayer.cs:477 if (DeepSeekClient.该停发(DeepSeekClient.通道.决策)) return;`、`649`；`AiStrategyLayer.cs:157`；`DeepSeekClient.cs:1420 该停发(道) => 强制熔断 \|\| 熔断中(道)` | ⚠️ 部分：停发成立（不补货），但 `Check()` 不查熔断 → 队列存货 ≤5s 继续执行（§2.3） |
| **队列空** | `AiDecisionLayer.cs:207-213 当前建议 => 找新鲜()`；`98-99 return -1` | ✅ 回退 |
| **队首过期** | `找新鲜()`（`147-156`）只返回 `还新鲜` 的（`84`，`有效期毫秒 = 5000`）；`清理过期()`（`507-529`）出掉过期队首 | ✅ 回退 |
| **被每一道终审拒绝** | §1.1 / §1.2 全部 `return -1` / 不加 slot；框架 `CheckNext` 返回 false（§1.3） | ✅ 回退（不花 GCD） |
| **世代在飞行中被撞** | `AiDecisionLayer.cs:686 我的世代 = _世代` → `765-769 if (我的世代 != _世代) { …丢弃本次结果 } return;` → `1157`、`1197-1202` 入队前再校验 → `800-806 finally if (_预取世代 == 我的世代) _预取世代 = 0;` | ✅ 不回退失败（`_预取世代` 一定会释放），但结果整批丢弃；本地层这一帧本来就在跑 |
| **AI 层内部异常** | `AiSuggestionResolver.cs:411-415`（Check 的 catch）、`638-641`（Build 的 catch）；`AiDecisionLayer.cs:795-799`（预取的 catch）；`BlueWhaleEntries.cs:1307-1310`（心跳整段 catch） | ✅ 回退（`return -1` / 空 Build → 框架退回本地） |
| **「完全采信 AI」打开** | `AiSuggestionResolver.cs:303,356,400` | ⚠️ 这是**用户显式打开的高风险开关**（`HealerEntryBase.cs` 注册，默认 false，`读完全采信()` `884-895` 兜底返 false）。它**主动**跳过 DoT 时机 / AOE 敌数 / 治疗让路三道闸 → 这不是 bug，是语义 |

---

## 6. 时序：AI 路径会不会阻塞主线程

**结论：没有任何同步等待 / 阻塞调用。**

- 全局 grep `.Result` / `.Wait()` / `Thread.Sleep` / `GetAwaiter().GetResult` → **0 处命中**。
- 唯一的 HTTP 出口 `DeepSeekClient.提问`（`780-856`）全程 `await … .ConfigureAwait(false)`；
  `发一次` 用 `CancellationTokenSource` 而非阻塞等待。
- `AiDecisionLayer.每帧更新()`（`463-505`）在 `AiHeartbeat.Check()` 里被调，结尾是
  `_ = 预取();`（`504`）—— 即"发射后不管"。
- 队列访问有锁（`AiDecisionLayer.cs:112-171`），临界区都是 O(1)/O(≤3)，无长持锁。

**但有一处我无法证明其耗时**：`预取()` 在**第一个 `await` 之前**同步跑了

```
AiDecisionLayer.cs:708  var 本次快照 = 候选集.生成();
AiDecisionLayer.cs:709  var 局面 = AiSituation.采集(本次快照);
AiDecisionLayer.cs:726-736 提示词落盘（只在文件不存在时写一次）
```

而 `AiHeartbeat` 是决策队列的第 1 位、**排在本层全部 resolver 之前**
（`BlueWhaleEntries.cs:559-561`）。所以这三段是**在本地 resolver 被扫到之前**、在游戏线程上跑的。
`候选集.生成()` 内部要跑 `加治疗候选/加输出候选/加减伤候选/加功能候选`（`候选集.cs:455-472`）
并做分桶排序（`475`），`AiSituation.采集` 要拼出约 5000 字符的报告（`AiDecisionLayer.cs:720` 自述）。
**我没有 profiler，无法给出毫秒数，也无法证明它一定会超过一个 GCD 的容差**——
只能说：这是 AI 层唯一一处"在本地决策之前、主线程上做重活"的地方，需要实测。

**裁决：[UNPROVEN]（结构上存在，量级未知）。**

---

## 最终排名：AI-on 可能比 AI-off 更差的场景

1. **[CONFIRMED] 低蓝停手被绕过 → 蓝打空，接下来治不了人。**
   AI 建议的输出技能不过 `Res_低蓝闸门`（`Res_低蓝闸门.cs:177-197` 的地毯式包装发生在
   AI resolver 被 `Insert(0)` 之前），`BlueWhale.AutoHealerACR\` 里 `低蓝停手` 0 处引用。
   场景：蓝 1800，AI 建议 `25859 闪灼` → 过 `可用()` / 移动 / 目标三道闸 → 100 分 → 打出去。
   AI-off 时 `Res_Damage.cs:39` 会 `return -9`。

2. **[CONFIRMED] 必须奶满被输出建议抢掉。**
   `AiSuggestionResolver` 里没有任何 `必须奶满` 判据；唯一的"治疗优先"闸
   `有人需要治疗()`（`849-860`）按血量阈值判，而中 Doom 的人血量可能健康。
   场景：有人中「必须奶满」且血量 80%，AI 按"全队 >85% → 去打输出"（提示词 23 条）
   建议填充技 → 100 分赢下 GCD → `Res_MustFullHeal` 这一帧没被扫到。

3. **[CONFIRMED] 建议放失败时，本帧本地 resolver 全部被跳过（与"被拒绝"不同）。**
   两种触发：
   (a) §4.3 —— 玩家选中的是**队友 / 不可选中目标**，AI 的输出建议通过全部终审后
       `new Spell(id, 友方)`，放不出去，`收尾()` 已经 `消费()`，`Run` 返回 true 结束外层循环；
   (b) §2.2 —— oGCD 趟被"读条 GCD 技能"建议占掉，本地全部 OffGcd resolver 这一趟没被扫到。
   对比：`Check()` 拒绝是**安全**的（框架 `CheckNext` 返回 false，会退回本地）。

4. **[LIKELY] oGCD 窗口被 AI 的 GCD 技能建议吃掉（§2.2）。**
   `SlotMode.Always`（枚举值 0，IL 直证）让 AI resolver 在 GCD 趟和 oGCD 趟各被问一次；
   `SlotAction.Run` 对非能力技会 `WaitAsync(GCD剩余 - ActionQueueInMs)`。
   本地 4 个 Always resolver 全是能力技，从不这么干 —— 这是 AI 独有的。

5. **[CONFIRMED] 阈值偏移在 AI 死后仍然生效（§3 末行）。**
   `阈值钩子` 由 `AiHookInstaller.挂载()`（`AiThresholdAdapter.cs:225`）装成**永久**钩子，
   只有 ACR `Dispose()` 才摘；`_当前倾向` 失败时**刻意保留**（`AiStrategyLayer.cs:219`），
   只在切职业 / 重载时清（`BlueWhaleEntries.cs:289-297`，换本不清）。
   场景：AI 判「激进」→ 阈值 -0.10 → 拔 Key / 熔断 / 关开关 →
   `HealSettings.cs:114,129` 的 getter 仍然返回 -0.10 后的值，直到切职业。
   ⇒ **"关掉 AI 之后的本地层" ≠ "从来没开过 AI 的本地层"。**

6. **[LIKELY] `记录模式` 相关的错觉不存在，但"初始化失败"没有真正回退决策层（§5 第 3 行）。**
   `已完成` 全项目只有 `局面监控.cs:107` 一个读取点。初始化失败后
   `AiDecisionLayer.每帧更新()` 仍满足 `启用决策层 && 已配置 && !该停发`，照样预取、照样执行。
   面板横幅却写"继续走本地策略"（`Ai初始化.cs:441`）——**承诺与实现不一致**。

7. **[LIKELY] `Dot补判` 按"进槽"记账（§3 第 1 行）。**
   AI 的 DoT 建议进了 slot 就 `记一次施放`（`AiSuggestionResolver.cs:677`），
   即便随后放失败 / 打到别的目标：该目标 5 秒内 `该补()` 恒 false（`Dot补判.cs:78,142`）。
   用户描述的"记了没放的 DoT、把下一次 DoT 挡掉一整段"确实存在，量级是 5 秒；
   要升到 27 秒需要那个 buff 事实上存在（别的来源挂的同一 buff 也算）。

8. **[LIKELY] oGCD 生命线被压制：`Res_LimitBreak` / 占星抽卡出卡 / 学者转化·炽天附体
   这些 AI 无法表达的动作（§4.4），在 AI 建议持续供应时会被 oGCD 趟反复挤掉。**
   最重的是奶妈 LB3 群体复活。

---

## 已经核实为"没问题"的部分（ALREADY SOUND）

1. **拒绝不花 GCD、不花这一帧机会。** `CheckNext` 在 `Actions.Count == 0` 时返回 false，
   `RunSlotResolvers` 继续扫下一个 resolver（IL 直证，§1.3）。这是本审计最重要的正面结论：
   "AI 抢到槽位又反悔"不会饿死本地层。
2. **`Check` 与 `Build` 之间没有 await**，`当前建议` 用的是 Peek（`AiDecisionLayer.cs:89-97, 207-213`），
   `消费()` 只由 `收尾()` 在"技能进 slot"后调用（`661-689`）→ 没有"判 A 放 B"、
   没有重复消费、没有"建议永久丢失"。
3. **世代校验三道齐全**：请求前记世代（`686`）、返回后校验（`765`）、
   解析入队前再校验（`1157, 1197`）、`finally` 按持有者释放（`800-806`）。
   过期请求一个字都进不了队列，`_预取世代` 也不会永久卡死。
4. **`局面剧变()` 把 `_世代++` 放在最前面**（`585`，任何 early return 之前），
   修掉了"队列已空 → 在飞请求永不作废"的漏洞。
5. **AI 路径不改这些本地状态**：`本地施放记录`、`以太管理`、`技能诊断`、`OffGcd闸门`、
   `技能熔断`、`幻觉校验`、`坦克压力`、`局面监控`、`伤害预测`、`输出目标` 粘滞、
   `AiDecisionLayer` 队列本身（逐项见 §3 表）。
   `减伤乘数.加上()` 经核对是纯函数（`减伤乘数.cs:91-104`），
   所以 `候选集` → `伤害预测.减伤收益()` 这条链**不会**污染本地减伤数学。
6. **`记录模式` 的守卫在本地层与 AI 层判据逐字一致**（`HealerEntryBase.cs:119` vs
   `BlueWhaleEntries.cs:553/678/803/928`），且 `HealQt.每帧更新()` / `以太管理.每帧更新()` /
   `进本识别` 都已从 `AiHeartbeat` 搬回本地层（`HealerEntryBase.cs:1756,1771,1818`）——
   这些本地逻辑不再依赖 AI 存活。
7. **没有任何同步阻塞调用**（`.Result` / `.Wait()` / `Thread.Sleep` 全项目 0 处命中）；
   HTTP 全程 `ConfigureAwait(false)` 且可取消（`DeepSeekClient.取消在途` / `取消全部在途`）。
8. **`完全采信AI` 的读法失败方向正确**：`读完全采信()`（`884-895`）读不到返回 **false**，
   即"读不到就不放权"。

---

## 我无法证明的事（明说）

- **`SlotAction.Run` 等到 GCD 转好之后到底是"放成功"还是"放失败"**：
  我读完了 `.scratch\slotaction.il.txt` 的 `IL_0000–IL_0173`（等到 `cd - ActionQueueInMs`），
  后续 `IL_0174+` 的实际施放分支没读完。所以我把 §2.2 的后果写成
  "oGCD 窗口被消费 + **要么**下一发 GCD 被提前拍板**要么**这一趟白费"，
  而不是断言其中一种。
- **§2.2 的发生率**：机制 100% 证实，但"oGCD 趟轮到时队首恰好是读条技能"取决于 AI 选了什么，
  静态代码证明不了频率。
- **§6 的耗时量级**：`候选集.生成()` + `AiSituation.采集()` 在游戏线程上、
  且在本地 resolver 之前跑，这是结构事实；会不会超过 GCD 容差需要实测（无 profiler）。
- **`技能熔断` 是否只是死代码**：我 grep 到 `可以尝试` 只有定义没有调用点，
  但我没有搜索整个解决方案（含 `ref\` 与 `tools\`）来 100% 排除。

---

## 框架证据（可复核）

为拿到"第一个 `Check() >= 0` 者胜出、空 Build 会退回"的直证，我反汇编了
`localnuget\extracted\lib\net10.0\AEAssist.dll`（只读元数据，不执行）：

- 新增工具 `tools\IlAll\`（`tools\IlAll\Program.cs` + `.csproj`）——
  与既有 `tools\IlPeek` 相同，但**不跳过编译器生成类型**（`<X>d__N` 状态机），
  因为关键逻辑全在状态机里。构建：`dotnet build tools\IlAll\IlAll.csproj -c Release`。
- 反汇编产物（临时目录 `.scratch\`）：
  - `ae.dll`（AEAssist.dll 的副本）、`ae.il.txt`
  - `checknext.il.txt` —— `PVE_RunSlotHelper+<CheckNext>d__4`
  - `slotresolvers.il.txt` —— `PVE_RunSlotHelper+<RunSlotResolvers>d__2`
  - `runslot.il.txt` —— `PVE_RunSlotHelper+<RunSlot>d__5`
  - `slotaction.il.txt` —— `AEAssist.CombatRoutine.Module.SlotAction+<Run>d__7`
  - `internal.il.txt` —— `PVE_RunSlotHelper+<InternalCalSlot>d__1`
  - `slotmode.il.txt` —— `SlotResolverData`

这两个目录是本次审计新增的**分析产物**，不在 `HealerACR\` / `BlueWhale.AutoHealerACR\` 里，
**没有改动任何插件源码**。
