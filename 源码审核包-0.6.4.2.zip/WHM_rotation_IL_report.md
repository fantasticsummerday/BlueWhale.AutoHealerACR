# 白魔 (WHITE MAGE) 循环 —— 两份反编译 IL 的逐技能使用表

工作区：`C:\Users\MECHREVO\Documents\deepseek-harness\default-workspace`
证据来源：`.il\youshu.il.txt`、`.il\shiyuvi.il.txt`（及同内容的 `.core.txt`）。

---

## 0. 结论前置：任务前提的一处重要修正

**`shiyuvi.core.txt` / `shiyuvi.il.txt` 中不存在 `ACR3._0.WHM` 或 `ACR.WHM.*` 命名空间，也不存在白魔 PvE 循环类。**

我做的验证（可复现）：

1. 把两份 shiyuvi 文件按 `### ` 标题切开，各得到 **441 个类**，两份标题集合完全相同（`.il.txt` 是 `.core.txt` 的完整 IL 版本，方法体更全）。
2. 441 个标题里与 WHM 相关的只有 18 个：
   - `ACR3._0.PvPWHMRotationEntry`
   - `ACR3._0.WHMPVP.*`（PvPWHMOverlay / PVPWHMRotationEventHandler / PvPWHMSettings / PvPWHMSettingUI / PvPWHMBattleData / GCD.{冲刺,净化,愈疗,药,闪灼,飒闪} / Ability.{水流幕,自动LB,自然的奇迹,苦难之心}）
   - 无命名空间的 `WHMQt`、`白魔LB`
3. 两份文件全部 132 个命名空间的清单里，`ACR3._0` 的子命名空间是 `BLM / FA / Monk / Sage / Triggers / WHMPVP`，`ACR.` 的子命名空间是 `AST / BLM / BLM_7 / BlueMage / CombatRoutine / Gunbreaker / Machinist / MCH / Sage / Scholar / SharedJobView / Viper / 同类ACR / 同类ACRBlack`。**没有 WHM。**
4. shiyuvi 里确实有 PvE 的学者 / 贤者 / 占星（`ACR.Scholar.*`、`ACR.Sage.*`、`ACR.Astrologian.*`），但白魔只有 PvP 一套。

> 因此本报告的「参考实现 B」= **Shiyuvi 的白魔 PvP 循环**，不是 PvE。它使用的技能 id 是 PvP 专用 id（29056 / 29057 / 29223 / 29225 / 29226 / 29227 / 29228 / 29230 / 29711），与 PvE id 完全不同，**不能**与 YouShu 的 PvE 阈值做同维度对比。两者唯一的可比项是「配置构造器里的字面量默认值」和「判定结构」。

**YouShu 才是本任务真正的白魔 PvE 参考实现**（`ACR.WhiteMage.*`，Resolvers 36 + Timeline 32 + Openers 4）。

### 关于 IL 文本本身

- 原始 dump 里 `同类` 这个前缀是 GBK/UTF-8 混乱产生的乱码，**其余中文全部正常可读**（我一开始误判为整文件乱码，用 GBK 反解反而破坏了正常文本，已纠正）。本报告全部基于原始 `.il\*.txt` 直接读取，未做任何转码。
- `.core.txt` 是**有损**版本（缺 `ldloc/ldarg/ldarg.s/stloc/ret/br/leave` 等指令，分支目标也会错位）。**所有结论取自 `.il.txt`**。例如 `GCD.DOT::Check` 在 `.core.txt` 里的分支目标 `brtrue.s IL_001e` 在 `.il.txt` 中实为 `IL_0019: call GetQt` / `IL_001e: brtrue.s IL_0023`，语义完全不同。

---

## 1. 参考实现 A —— YouShu（`ACR.WhiteMage.*`，PvE）

### 1.1 注册信息（proven，`ACR.WhiteMage.WHMACR::Build`）

| 项 | 值 | IL 证据 |
|---|---|---|
| TargetJob | 24 (WHM) | `IL_000b: ldc.i4.s 24` + `Rotation::set_TargetJob` |
| AcrType | 0 | `IL_0013: ldc.i4.0` |
| MinLevel | 0 | `IL_001a: ldc.i4.0` |
| MaxLevel | 100 | `IL_0021: ldc.i4.s 100` |
| SlotSequence 数量 | 1 个：`Resolvers.Strategy.白魔奶满策略` | `IL_0035: ldc.i4.1` + `newarr ISlotSequence` |
| TriggerAction 数量 | 30 | `IL_0056: ldc.i4.s 30` |
| TriggerCond 数量 | 8 | `IL_0169: ldc.i4.8` |

### 1.2 Resolver 执行顺序（proven，`Resolvers.Strategy.白魔技能策略::.cctor`，共 **34** 项：`IL_0000: ldc.i4.s 34`）

序号即 `SlotResolverData` 在 `SlotResolvers` 数组中的下标，也就是实际尝试顺序。
第二列 = 传给 `SlotResolverData::.ctor` 的整型（`ldc.i4.1` / `ldc.i4.2`）。**推断**（非 IL 直接证明）：`1` = GCD 槽，`2` = oGCD/能力技槽；依据是每个类的性质与该值完全一致。

| # | 类 | type | 技能 (id) |
|---|---|---|---|
| 0 | `ACR.Tool.Resolvers.HealerPotionResolver` | 2 | 爆发药（构造函数收 2 个 `Func<bool>` 委托，见 §5） |
| 1 | `Resolvers.Strategy.过路圣人复活` | 1 | 复活 125 |
| 2 | `Resolvers.Strategy.复活` | 1 | 复活 125 |
| 3 | `Resolvers.GCD.绝亚康复` | 1 | 康复 7568（仅限副本 887） |
| 4 | `Resolvers.GCD.康复` | 1 | 康复 7568 |
| 5 | `Resolvers.Ability.节制` | 2 | 节制 16536 |
| 6 | `Resolvers.Ability.神爱抚` | 2 | 神爱抚 37011 |
| 7 | `Resolvers.Ability.全大赦` | 2 | 全大赦 7433 |
| 8 | `Resolvers.Ability.庇护所` | 2 | 庇护所 3569 |
| 9 | `Resolvers.Ability.水流幕` | 2 | 水流幕 25861 |
| 10 | `Resolvers.GCD.狂喜之心` | 1 | 狂喜之心 16534 |
| 11 | `Resolvers.GCD.医养` | 1 | **133** |
| 12 | `Resolvers.GCD.医治` | 1 | 124 |
| 13 | `Resolvers.Ability.法令` | 2 | 法令 3571 |
| 14 | `Resolvers.Ability.铃铛` | 2 | 礼仪之铃 25862 |
| 15 | `Resolvers.GCD.安慰之心` | 1 | 安慰之心 16531 |
| 16 | `Resolvers.GCD.再生` | 1 | 再生 137 |
| 17 | `Resolvers.GCD.救疗` | 1 | 120 / 135 |
| 18 | `Resolvers.GCD.愈疗` | 1 | 愈疗 131 |
| 19 | `Resolvers.Ability.天赐` | 2 | 天赐祝福 140 |
| 20 | `Resolvers.Ability.神名` | 2 | 神名 3570 |
| 21 | `Resolvers.Ability.神祝祷` | 2 | 神祝祷 7432 |
| 22 | `Resolvers.Ability.醒梦` | 2 | 醒梦 7562 |
| 23 | `Resolvers.Ability.无中生有` | 2 | 无中生有 7430 |
| 24 | `Resolvers.Ability.神速咏唱` | 2 | 神速咏唱 136 |
| 25 | `Resolvers.GCD.苦难之心` | 1 | 苦难之心 16535 |
| 26 | `Resolvers.GCD.双DOT` | 1 | 双目标 DOT |
| 27 | `Resolvers.GCD.DOT` | 1 | 天辉 16532 |
| 28 | `Resolvers.GCD.闪飒` | 1 | `GetAdjustedActionId(37009)` |
| 29 | `Resolvers.GCD.蓝花走位` | 1 | 16534 或 16531 |
| 30 | `Resolvers.GCD.即刻闪灼` | 1 | 7561 + 25859 |
| 31 | `Resolvers.GCD.豪圣` | 1 | `GetAdjustedActionId(139)` |
| 32 | `Resolvers.GCD.移动走位即刻闪灼` | 1 | 7561 + 25859 |
| 33 | `Resolvers.GCD.闪灼` | 1 | `GetAdjustedActionId(25859)` |

`WHMACR` 的 TriggerAction 顺序（`ldc.i4.0..29`）：`QtSetting`、`ACR.Tool.Timeline.绝欧麻将状态`、`绝欧目标选择`、`副本自动吃药`、`场地中轴半程放置`、`热键`、`起手设置`、`预读时间`、`康复顺序`、`蓝花走位`、`DOT走位`、`不上Dot阈值`、`醒梦阈值`、`群奶人数`、`群减人数`、`保留蓝花数量`、`天赐阈值`、`神名阈值`、`神祝祷阈值`、`水流幕阈值`、`安慰之心阈值`、`狂喜之心阈值`、`法令阈值`、`医治阈值`、`医养阈值`、`愈疗阈值`、`庇护所阈值`、`全大赦阈值`、`GCD单奶`、`GCD群奶`。
TriggerCond 顺序：`QtCheck`、`红花层数`、`蓝花层数`、`无中生有层数`、`神名层数`、`神祝祷层数`、`ACR.Tool.Timeline.M10S狂浪腾空`、`坦克无敌检测`。

### 1.3 设置默认值（proven，`ACR.WhiteMage.WhiteMageSettingsData::.ctor`，全部来自 `ldc.i4`）

| 字段 | 默认值 | 类型 |
|---|---|---|
| 群奶人数 | 2 | int |
| 群减人数 | 2 | int |
| 保留蓝花数量 | 1 | int |
| 天赐阈值 | 20 | int (%) |
| 神名阈值 | 75 | int (%) |
| 神祝祷阈值 | 70 | int (%) |
| 安慰之心阈值 | 40 | int (%) |
| 狂喜之心阈值 | 75 | int (%) |
| 水流幕阈值 | 70 | int (%) |
| 法令阈值 | 70 | int (%) |
| 医养阈值 | 65 | int (%) |
| 医治阈值 | 45 | int (%) |
| 愈疗阈值 | 40 | int (%) |
| 庇护所阈值 | 80 | int (%) |
| 全大赦阈值 | 35 | int (%) |
| GCD群奶阈值 | 55 | int (%) |
| GCD单奶阈值 | 40 | int (%) |
| 预读时间 | 1500 | int (ms) |
| 倒计时再生延迟 | 5000 | int (ms) |
| 移动中DOT延迟时间 | 1000 | int (ms) |
| 不上Dot阈值 | 3 | int (%) |
| 醒梦阈值 | 8000 | int (MP) |
| 复活延迟 | 1 | int (s) |
| 倒计时再生 | true | bool |
| H1 | true | bool |
| DOT走位 | true | bool |
| 优先复活TN | true | bool |
| 自动切换最优目标 | true | bool |
| 单奶限制坦克 | true | bool |
| 无中生有防溢出 | true | bool |
| 无中生有防耗蓝 | true | bool |
| 法令起手 | true | bool |
| 庇护所优先场中 | true | bool |
| 庇护所优先自己 | true | bool |
| 铃铛优先场中 | true | bool |
| 铃铛优先自己 | true | bool |
| ShowDevTest / ShowQt / ShowHotkey / 切换模式自动隐藏QT | true | bool |
| 复活提醒频道列表 | `["/p "]` | List\<string\> |

### 1.4 **在整份 dump 中从未被赋值的设置字段**（proven by exhaustive scan）

我对全部 453 个类做了「字段名出现 vs `stfld` 出现」的差集。以下白魔设置字段**只被读取、从未被写入**，因此它们的值**无法从 IL 确证**，只能是 JSON 反序列化值或 CLR 默认值（bool=`false`、int=`0`）：

| 字段 | 若为 CLR 默认值时的后果 |
|---|---|
| `蓝花走位` | `false` → `GCD.蓝花走位` 恒返回 -10（永不执行） |
| `蓝花走位延迟时间` | `0` |
| `即刻咏唱延迟时间` | `0` → `移动走位即刻闪灼` 的延迟守卫失效 |
| `智能AOE目标` | `false` → `苦难之心` / `闪飒` 的智能多目标选敌永不生效；`SwitchTargetIfNeeded` 也恒不切目标 |
| `神速咏唱限制` | `false` → `神速咏唱::ShouldHoldForFourPlayerDuty()` 第一行即返回 `false`（该守卫恒不生效） |
| `高难模式` | int，会被 `WhiteMageQT::ApplyMode` 写入（见 §1.5） |
| `治疗模式` | 会被 `WhiteMageSettingsUI/Tab/SettingControls` 写入 |
| `庇护所开挂模式`、`庇护所优先目标位置`、`铃铛开挂模式`、`铃铛优先目标位置` | 仅被 `庇护所/铃铛` 的 `Build` 与 `WhiteMageHotkeySystem`、`WhiteMageSettingsTab` 读取，全 dump 无写入 |
| `单奶限制奶妈`、`单奶限制输出` | 仅被 `WhiteMageTools::MatchesSingleHealLimit` 调用点读取 |
| `不切换目标`、`过路圣人模式`、`接入MacroRedirection`、`HotkeyInterruptCast`、`ResetQtOnBattleEnd`、`IsOpenCommandWindow` | 从未被赋值 |
| `Opener` | 会被 `Timeline.Actions.起手设置::Handle` 写入 |

### 1.5 QT 开关（proven，`WhiteMageQT::.cctor` 的 `ValueTuple<string,bool>` 数组，共 **35** 项：`IL_0000: ldc.i4.s 35`）

| 顺序 | QT 名 | 默认 |
|---|---|---|
| 0 | 爆发药 | false |
| 1 | 停手 | false |
| 2 | DOT | **true** |
| 3 | 双DOT | false |
| 4 | AOE | **true** |
| 5 | 红花 | **true** |
| 6 | 保留红花 | false |
| 7 | 红花对齐 | false |
| 8 | 闪飒 | **true** |
| 9 | 即刻复活 | **true** |
| 10 | 读条复活 | false |
| 11 | 奶人 | **true** |
| 12 | 减伤 | **true** |
| 13 | GCD奶 | **true** |
| 14 | 能力技奶 | **true** |
| 15 | 单奶限制 | false |
| 16 | 神速咏唱 | **true** |
| 17 | 无中生有 | **true** |
| 18 | 节制 | **true** |
| 19 | 再生 | **true** |
| 20 | 天赐 | **true** |
| 21 | 神名 | **true** |
| 22 | 法令 | **true** |
| 23 | 铃铛 | **true** |
| 24 | 安慰之心 | **true** |
| 25 | 狂喜之心 | **true** |
| 26 | 保留蓝花 | false |
| 27 | 全大赦 | **true** |
| 28 | 自动康复 | **true** |
| 29 | 即刻走位 | false |
| 30 | 即刻闪灼 | false |
| 31 | 攒爆发 | false |
| 32 | 倾泻资源 | false |
| 33 | 日随模式 | false |
| 34 | 高难模式 | false |

`高难模式` 实际是 int 字段：`WhiteMageQT::ApplyMode(int mode, ...)`（`IL_0006: stfld 高难模式`）与 `ApplyCustomMode`（`IL_0008: stfld 高难模式`）写入；日随模式 / 高难模式切换走 `ApplyModeSwitch`（`IL_0001: ldstr "日随模式"`、`IL_0014: ldstr "高难模式"`，`IL_0006` 处 `ApplyMode`）。`再生` resolver 用 `高难模式 == 1` 判定（见 §1.6）。

### 1.6 逐技能使用表（参考实现 A = YouShu，PvE）

**图例**：`QT(x)` = `WhiteMageQT::GetQt("x")`；`S` = `HealerRuntimeTools::HasSkillSilenceStatus()`；`Off(n)` = `HealerResolverBase::CanUseOffGcd(n)`（已证明 = `AI.Instance.BattleData.HighPrioritySlots_OffGCD.Count < n`）；`Stop` = `WhiteMageResolverBase::StopRequested()` = `QT("停手")`；返回值负数即放弃（数值=优先级/原因码）。

| 技能 | id | 类 | 前置 QT / 门禁（按 IL 顺序） | 阈值与字面量 | 负面守卫 | 返回值 |
|---|---|---|---|---|---|---|
| **飞石 / 坚石 / 垒石 / 崩石 / 闪耀 / 闪灼** | 不直接使用 | — | YouShu **完全不使用** 119 / 127 / 3568 / 7431 / 16533 | — | — | — |
| **闪灼(Glare 系)** | `GetAdjustedActionId(25859)` | `GCD.闪灼` | 无 QT 门禁，仅 `Stop` | 攻击距离 `ldc.r4 25`；MP `ldc.i4 400`；圣光 aura `ldc.i4 3879`，需求时间 `GetAuraStack(3879)*2000 + 1500` | `IsOutOfAttackRangeOrDead(t,25f)`→-200；`MP<400`→-2；`!HasMyAuraWithTimeleft(3879, stack*2000+1500)`→**-33**；`IsMovementBlockingCast(spellId)`→-1；`!IsReadyWithCanCast`→**-9999** | 不移动 1 / 移动中 2 |
| **闪飒(Glare IV)** | `GetAdjustedActionId(37009)` | `GCD.闪飒` | `QT("AOE") && QT("闪飒")` | 距离 `ldc.r4 25`；智能选敌 `SelectCircularAoeTarget(3, ldc.i4.s 30, ldc.i4.5, target, 1)`；`GetNearbyEnemyCount(best,25,5) >= ldc.i4.3` | 无 `HasAura(3879)`→-4；`Stop`→-999；`!InCombat`→-5；无目标/`HasAttackBlock`→-1；越界→-200；`!高难模式 && ShouldHoldBurstForDyingTrash()`→-10；`!IsReadyWithCanCast`→**-9999**；攒爆发&&!倾泻→-50 | 倾泻 50 / 智能选敌 20 / 普通 10 |
| **豪圣(Holy)** | `ldc.i4 139`→`GetAdjustedActionId` | `GCD.豪圣` | `QT("AOE")` | 等级 `ldc.i4.s 46`（低于即放弃）、`ldc.i4.s 82`（≥82 需 `ldc.i4.3` 个敌人，否则 `ldc.i4.2`）；`GetNearbyEnemyCount(Me, ldc.i4.8, ldc.i4.8)`；禁用副本 `ldc.i4 293 / 296 / 1046`；MP `ldc.i4 1000`；迅捷/无中生有 aura `ldc.i4.s 43` / `ldc.i4.s 44`；醒梦 `ldc.i4 7562` | `CheckExtraCondition()` 返回 false→-999；`!IsReadyWithCanCast`→-200，敌人==0→-200；`IsMovementBlockingCast`→-200；`count < needCount`→-1；`!高难模式 && ShouldHoldBurstForDyingTrash()` 不在此类 | `!Me.IsMoving`（`IsMoving==false` 才是 true） |
| **苦难之心(Afflatus Misery)** | `ldc.i4 16535` | `GCD.苦难之心` | `QT("AOE") && QT("红花") && !QT("保留红花")` | **血花必须 == 3**（`get_BloodLilyStacks; ldc.i4.3; beq`）；战斗时间 `ldc.i4 5000`；距离 `ldc.r4 25`；神速咏唱 `ldc.i4 136`，CD 窗口 `ldc.r8 0` ~ `ldc.r8 15` 秒；`RecentlyUsed(136, ldc.i4 2000)`；智能选敌 `SelectCircularAoeTarget(3, ldc.i4.s 25, ldc.i4.5, target, 1)`，`GetNearbyEnemyCount(best,25,5) >= ldc.i4.3`；`Distance(t,Me, ldc.i4.7)` vs `ldc.r4 25` | `S`→-1；无目标/`HasAttackBlock`→-1；越界→-200；`CurrBattleTimeInMs <= 5000`→-8；血花≠3→-1；`!IsReadyWithCanCast`→-2；`!高难模式 && ShouldHoldBurstForDyingTrash()`→-10；攒爆发&&!倾泻→**-30**；红花对齐 && CD∈(0,15]→**-40**；红花对齐 && CD==0 && `!RecentlyUsed(136,2000)`→**-41** | 倾泻 50 / 智能 20 / 普通 10 |
| **天辉(Dia / 单体 DOT)** | `ldc.i4 16532` | `GCD.DOT` | `QT("DOT")` | 距离 `ldc.r4 25`；`HasMyDot(t, ldc.i4 1000)`、`HasMyDot(t, ldc.i4 3000)`；`DotBlacklistHelper::IsBlackList`；`不上Dot阈值/100`（默认 `3/100=0.03`）交给 `ShouldSkipDotByHp(t, 0.03f, ldc.i4.s 12)`；移动延迟 = `移动中DOT延迟时间`（默认 `ldc.i4 1000`）；aura `ldc.i4 167`；`DOT走位`（默认 true） | `Stop`→-999；`!QT("DOT")`→-8；`S`→-1；无目标/`HasAttackBlock`→-1；`!IsReady(16532,t)`→-3；黑名单→-10；`ShouldSkipSingleTargetDot`→-1；越界→-200；移动中且 aura 167 → **-20**；移动中且 `Now-MoveStartTimeMs < 移动中DOT延迟时间` → **-21** | 移动中：45 / 30 / 35；静止：50 / -1 / 40（详见 §1.7） |
| **双目标 DOT** | 走基类 | `GCD.双DOT` | 无自己的 `Check()`；`StopRequested()=QT("停手")`、`DotEnabled()=QT("DOT")`、`DoubleDotEnabled()=QT("双DOT")` | `CommonCanDot(enemy, 不上Dot阈值/100)` = `(0.03f)`；`HasDot` = `HasWhiteMageDot`（aura `1871 / 144 / 143`）；`HasDotRemaining` = `HasMyDot` | 全在 `ACR.Tool.Resolvers.HealerDoubleDotResolverBase`（**该类有文件但 `Check()` 体在 dump 中未展开**，见 §5） | — |
| **再生(Regen)** | `ldc.i4 137` | `GCD.再生` | `QT("再生")`；若 `高难模式 != 1` 还需 `QT("奶人") && QT("GCD奶")` | 阈值 = `GCD单奶阈值/100`（默认 `40/100=0.40`，**无 Clamp**）；MP `ldc.i4 400`；`RecentlyUsed(140, ldc.i4 3000)` | `!QT`→-100；`S`→-1；刚用天赐(140,3000ms)→-1；`MP<400`→-2；无目标→-1；`!IsReadyWithCanCast`→-2 | 坦克 30 / 非坦克 20 |
| **医养(Cure 系群疗)** | `ldc.i4 133` | `GCD.医养` | `QT("奶人") && QT("GCD奶")` | 阈值 = `医养阈值/100`（默认 `65/100=0.65`，**无 Clamp**）；MP `ldc.i4 800`；`CountLowHpAlliesNear(anchor, 0.65, ldc.r4 10) >= Max(ldc.i4.2, 群奶人数=2)`；目标 aura `ldc.i4 3880` / `ldc.i4 150` | `S`→-1；`MP<800`→-2；`!CanUseGroupHeal()`→-200（= 距上次`MarkGroupHeal`不足 `ldc.i4 1000` ms）；`IsMovementBlockingCast(133)`→-200；无锚点→-200；`HasAnyStatus(anchor, 无法接受治疗合集)`→-7；aura 3880/150→-8；`!IsReadyWithCanCast`→-2；`count < limit`→-1；`IsCastingGroupHeal()`→-9 | 1 |
| **医治(Medica)** | `ldc.i4.s 124` | `GCD.医治` | `QT("奶人") && QT("GCD奶")` | 阈值 = `Clamp(医治阈值/100, 0, 1)`（默认 `45/100=0.45`）；MP `ldc.i4 700`；`CountLowHpAlliesNear(anchor, 0.45, ldc.r4 10) >= Clamp(群奶人数,0,8)=2` | 同上；`S`→-1；`MP<700`→-2；`!CanUseGroupHeal()`→-200；`IsMovementBlockingCast(124)`→-200；无锚点→-200；`无法接受治疗合集`→-7；`!IsReadyWithCanCast`→-2；`IsCastingGroupHeal()`→-9；`count<limit`→-1 | 1 |
| **愈疗(Cure III)** | `ldc.i4 131` | `GCD.愈疗` | `QT("奶人") && QT("GCD奶")` | 阈值 = `愈疗阈值/100`（默认 `40/100=0.40`，**无 Clamp**）；MP `ldc.i4 700`；`CountLowHpAlliesNearSelf(0.40, ldc.r4 10) >= Max(ldc.i4.2, 群奶人数=2)` | `S`→-1；`!IsReadyWithCanCast`→-2（**注意：MP 检查在此之后**）；`MP<700`→-2；`!CanUseGroupHeal()`→-200；`IsMovementBlockingCast(131)`→-200；`LocalPlayerCannotReceiveHeal()`→-7；`IsCastingGroupHeal()`→-9；`count<limit`→-1 | 1 |
| **救疗(Cure II / Cure)** | `ldc.i4.s 120` 与 `ldc.i4 135` | `GCD.救疗` | `QT("奶人") && QT("GCD奶")` | 阈值 = `GCD单奶阈值/100`（默认 `0.40`，**无 Clamp**）；`IsMovementBlockingCast(120)`；MP 门槛 `ldc.i4 1400`（用 135）/ `ldc.i4 800`（用 120） | `S`→-1；`IsMovementBlockingCast(120)`→-200；无目标→-1；两个 id 都不可用→-2；`useCure2 = (135可用 && MP>=1400)`；`cureAvailable = (120可用 && MP>=800)`；两者皆假→-2 | Cure II 40 / Cure 20 |
| **安慰之心(Afflatus Solace)** | `ldc.i4 16531` | `GCD.安慰之心` | `QT("奶人") && QT("GCD奶") && QT("安慰之心")` | **蓝花 `get_LilyStacks >= ldc.i4.1`**；**血花 `!= ldc.i4.3`**；`RecentlyUsed(140, 3000)`；`RecentlyUsed(16531, ldc.i4 1500)`；阈值 = `安慰之心阈值/100`（默认 `0.40`，**无 Clamp**）；`aoeHealCount = Max(ldc.i4.2, 群奶人数=2)`；`CountLowHpCastableAlliesInRange(0.40, ldc.r4 30)` | `S`→-1；刚天赐→-1；刚用安慰之心 1.5 s→-200；`GetAdjustedActionId(16531)` 未解锁→-3；蓝花<1→-5；血花==3→-4；`QT("保留蓝花") && LilyStacks <= 保留蓝花数量(1)`→-5；**低血人数 >= aoeHealCount → -1（让位给狂喜之心）**；无单体目标→-1 | 2 |
| **狂喜之心(Afflatus Rapture)** | `ldc.i4 16534` | `GCD.狂喜之心` | `QT("奶人") && QT("GCD奶") && QT("狂喜之心")` | 蓝花 `>= ldc.i4.1`；血花 `!= ldc.i4.3`；`RecentlyUsed(16534, ldc.i4 1500)`；阈值 = `狂喜之心阈值/100`（默认 `75/100=0.75`，**无 Clamp**）；`CountLowHpCastableAlliesInRange(0.75, ldc.r4 30) >= Max(ldc.i4.2, 群奶人数=2)`；**蓝花计时 `get_LilyTimer >= ldc.i4 16000`（且蓝花==2）**；蓝花==3 直接放行 | `S`→-1；刚用 1.5 s→-200；未解锁→-3；蓝花<1→-5；`LocalPlayerCannotReceiveHeal()`→-7；血花==3→-4；`preventOverflow = (低血人数>=上限) \|\| (蓝花==3) \|\| (蓝花==2 && LilyTimer>=16000)`，为假→-1；`QT("保留蓝花") && LilyStacks <= 保留蓝花数量`→-5 | 1 |
| **蓝花走位** | `ldc.i4 16534` / `ldc.i4 16531` | `GCD.蓝花走位` | 需要 `Me.IsMoving && 蓝花走位 && InCombat` | 等级 `ldc.i4.s 52`（<52 放弃）、`ldc.i4.s 72`（>=72 优先 16534）；aura `ldc.i4 167`；`蓝花走位延迟时间`（默认未赋值=0）；`lilyStacks > ldc.i4.1`；`reserve = QT("保留蓝花") ? 保留蓝花数量 : ldc.i4.1` | `!移动 \|\| !蓝花走位 \|\| !InCombat`→-10；`等级<52 \|\| HasAura(167)`→-3；`S`→-1；`lilyStacks<=1 \|\| (MoveStartTimeMs>0 && elapsed < 蓝花走位延迟时间)`→**-7**；`lilyStacks <= reserve`→**-8**；否则若无目标或不可用→-1 | 16534 优先 **90**；16531 **85** |
| **神圣 / 豪圣 (139/25860)** | `139` → `GetAdjustedActionId` | `GCD.豪圣` | 见上 | 未直接出现 `25860`（由 `GetAdjustedActionId(139)` 在 ≥82 级时映射） | 见上 | 见上 |
| **治疗(Cure) 系列** | `120` | 见「救疗」 | — | — | — | — |
| **复活(Raise)** | `ldc.i4.s 125` | `Strategy.复活` | `HealerRaiseResolver(125, -999, 7430, CanUseAssistAction, λ)` | 辅助技 `ldc.i4 7430`（无中生有）；`CanUseAssistAction()` 还需 `!Me.HasAura(ldc.i4 1217)` | `CanUseAssistAction`: `!IsReady(7430, ldc.i4.1)`→false；`HasAura(1217)`→false | 委托给 `HealerRaiseResolver::Check()`（**方法体不在 dump**） |
| **复活(过路圣人)** | `ldc.i4.s 125` | `Strategy.过路圣人复活` | `HealerPasserbyRaiseResolver(ldc.i4.s 24, 125, "白魔复活", -999, 7430, CanUseAssistAction, λ)` | TargetJob = `ldc.i4.s 24` | 同上 | 方法体不在 dump |
| **康复(Esuna)** | `ldc.i4 7568` | `GCD.康复` | `QT("自动康复")` | `IsReady()` = `Gcd(7568, ldc.i4.1).IsReadyWithCanCast`；目标选择 `HealerEsunaTargetSelector::SelectGeneralTarget(H1)` | `Stop`→-999；`!QT`→-100；`S`→-1；`!IsReady`→-200；无目标→-7 | 10 |
| **康复(绝亚专用)** | `ldc.i4 7568` | `GCD.绝亚康复` | **副本 id 必须 == `ldc.i4 887`**，否则 -100；再 `QT("自动康复")` | `HasAnyDispelTargetWithin30()`（遍历 `PartyHelper::CastableAlliesWithin30` 调 `ACR.Tool.Data.Helper::HasDispelStatus`）；目标选择 `SelectTemporalStasisTarget(H1)` | 副本≠887→-100；`!QT`→-100；`!IsReady`→-200；无驱散目标→-7；无目标→-7 | 1 |
| **神速咏唱(Presence of Mind)** | `ldc.i4 136` | `Ability.神速咏唱` | `QT("神速咏唱")` | `ShouldHoldForFourPlayerDuty()`: `神速咏唱限制 && 高难模式 != ldc.i4.1 && IsBoundByDuty && Party.Count == ldc.i4.4 && !CommonMapIds::IsDirectBossDungeon(terrId)`，再 `!HealerEnemyTargetHelper::IsInBossBattle()` | `Stop`→-999；`!QT`→**-8**；`S`→-1；`!IsReady(136)`→**-6**；`!Off(2)`→-4；攒爆发&&!倾泻→-50；`!高难模式 && ShouldHoldBurstForDyingTrash()`→-10；4人本守卫→-1 | 倾泻 50 / 常规 **0** |
| **节制(Temperance)** | `ldc.i4 16536` | `Ability.节制` | `QT("减伤") && QT("奶人") && QT("节制")` | `CanUseGroupMitigation()` 互斥窗 = `ldc.i4 5500` ms；自身 aura `ldc.i4 1911`、`ldc.i4 1873`、`ldc.i4 1219`；`CastableAlliesWithin30.Count(λ) + ldc.i4.1 >= Clamp(群减人数,0,8)`；`HasBossCastingAoeWithin(ldc.i4 3000)`；`RecentlyUsed(7433, ldc.i4 5000)`；`threshold = Clamp((GCD群奶阈值 - ldc.i4.s 10)/100, 0, 1)` = `0.45`；`CountLowHpCastableAlliesInRange(0.45, ldc.r4 20)` | `S`→-1；`!IsReady(16536)`→-2；`!Off(2)`→-4；`!InCombat`→-5；`CanUseGroupMitigation() && (HasAura(1911)\|\|HasAura(1873))`→-5；人数不足→-1；`HasAura(1219)`→-5；Boss 读条分支里 `RecentlyUsed(7433,5000)`→-5、任一队友 `HasAura(1219)`→-5；非 Boss 分支 `count < 群奶人数`→-2 | Boss 读条 **60** / 常规 **10**；`Build` 额外调 `MarkGroupMitigation()` |
| **神爱抚(Divine Caress)** | `ldc.i4 37011` | `Ability.神爱抚` | `QT("减伤")` | aura `ldc.i4 3881`；`RecentlyUsed(16536, ldc.i4 1500)`（刚开节制） | `S`→-1；`!IsUnlock(37011)`→-100；`!刚用节制 && !IsReady(37011)`→-2；`!刚用节制 && !Me.HasAura(3881)`→-3；`!Off(2)`→-4；`!InCombat`→-5 | 5 |
| **全大赦(Plenary Indulgence)** | `ldc.i4 7433` | `Ability.全大赦` | `QT("奶人") && QT("减伤") && QT("能力技奶") && QT("全大赦")` | 阈值 = `Clamp(全大赦阈值/100, 0, 1)`（默认 `35/100=0.35`）；`HasBossCastingAoeWithin(ldc.i4 3000)`；`RecentlyUsed(16536, ldc.i4 5000)`；`CountLowHpCastableAlliesInRange(0.35, ldc.r4 20) >= Clamp(群奶人数,0,8)` | `Stop`→-999；`!QT`→-100；`S`→-1；`!IsReady(7433)`→-2；`!Off(2)`→-4；`!InCombat`→-5；**必须 `CanUseGroupMitigation()==true` 且 `!Me.HasAura(1873)`**，否则 -5；Boss 读条分支 `RecentlyUsed(16536,5000)`→-5；人数不足→-2 | Boss 读条 **30** / 常规 **12**；`Build` 调 `MarkGroupMitigation()` |
| **庇护所(Asylum)** | `ldc.i4 3569` | `Ability.庇护所` | `QT("奶人") && QT("能力技奶") && QT("减伤")` | 自身 aura `ldc.i4 1911`、`ldc.i4 1873`；`HadBossCastingAoeWithin(ldc.i4 3000)`；阈值 = `Clamp(庇护所阈值/100,0,1)`（默认 `80/100=0.80`）；`CountLowHpCastableAlliesInRange(0.80, ldc.r4 20) >= Clamp(群奶人数,0,8)`；`Build` 用 `HealerGroundTargetHelper::GroundCastPosition(庇护所优先场中, 庇护所开挂模式, 庇护所优先目标位置, CurrentTarget)` | `S`→-1；`!IsReady(3569)`→-2；`!Off(2)`→-4；`!InCombat`→-5；`HasAura(1911)\|\|HasAura(1873)`→-5；`LocalPlayerCannotReceiveHeal()`→-7；人数不足→-2 | Boss 读条 **40** / 常规 **15** |
| **水流幕(Aquaveil)** | `ldc.i4 25861` | `Ability.水流幕` | `QT("减伤")` | `AquaVeilTarget()`: 坦克阈值 `Clamp((水流幕阈值 - ldc.i4.s 10)/100, 0, 1)` = `0.60`，非坦克 `Clamp(水流幕阈值/100,0,1)` = `0.70`，同条件**优先坦克**；`RecentlyUsed(140, ldc.i4 3000)` | `S`→-1；刚用天赐→-1；`!Off(2)`→-4；`!InCombat`→-5；无目标→-1；`!IsReady`→-2 | 4 |
| **神名(Tetragrammaton)** | `ldc.i4 3570` | `Ability.神名` | `QT("奶人") && QT("能力技奶")`，且 `QT("神名")`（否则 **-8**） | `SingleAbilityHealTarget(神名阈值=75, QT("单奶限制"), ldc.i4.2)`；`RecentlyUsed(140, ldc.i4 3000)`；内建 CD 键 `"神名_"+GameObjectId` 和 **`"天赐_"+GameObjectId`**，窗口均 `ldc.i4 1000` | `!QT`→-100；`!QT("神名")`→-8；`S`→-1；刚天赐→-1；`!Off(2)`→-4；无目标→-1；`!IsReady(3570,t)`→-2；`Now - GetBuiltInCooldown("神名_"+id) < 1000`→**-200**；`Now - GetBuiltInCooldown("天赐_"+id) < 1000`→**-1** | 25 |
| **神祝祷(Divine Benison)** | `ldc.i4 7432` | `Ability.神祝祷` | `QT("减伤")` | `AbilityHealTarget(神祝祷阈值=70, applySingleHealLimit=ldc.i4.0)`；目标 aura `ldc.i4 1218`；内建 CD 键 `"神祝祷_"+id` 窗口 `ldc.i4 1000` | `S`→-1；`!Off(2)`→-4；`无目标 \|\| HasAura(1218)`→-1；`!IsReady(7432,t)`→-2；`!InCombat`→-5；内建 CD<1000ms→**-200** | 30 |
| **法令(Assize)** | `ldc.i4 3571` | `Ability.法令` | `QT("AOE") && QT("法令")`；若 `!高难模式` 还需 `QT("奶人")` | `GetAdjustedActionId(3571)` + `IsUnlock(Spell(id, ldc.i4.1))`；战斗时间 `ldc.i4 15000`（`法令起手` 默认 true）；`TargetMgr::EnemysIn25` 中 `CanAttackTargetInRange(t, ldc.r4 20, ldc.i4.0)` | `Stop`→-999；`!QT`→-100；未解锁→-100；`S`→-1；`!Off(2)`→-4；`!InCombat`→-5；`战斗时间<=15000 && !法令起手`→-100；`!IsReady(3571)`→-2；无 20 码内敌人→-5；`!高难模式 && ShouldHoldBurstForDyingTrash()`→-10；攒爆发&&!倾泻→-50 | **50** |
| **铃铛(Liturgy of the Bell)** | `ldc.i4 25862` | `Ability.铃铛` | `QT("奶人") && QT("能力技奶") && QT("铃铛")` | `RecentlyUsed(25862, ldc.i4 1000)`；自身 aura `ldc.i4 2728`、`ldc.i4 1873`、`ldc.i4 1219`；`HasBossCastingAoeWithin(ldc.i4 3000)`；阈值 = `Clamp(GCD群奶阈值/100,0,1)` = `0.55`；`CountLowHpCastableAlliesInRange(0.55, ldc.r4 20) >= Clamp(群奶人数,0,8)`；`Build` 用 `GroundCastPosition(铃铛优先场中, 铃铛开挂模式, 铃铛优先目标位置, CurrentTarget)` | `S`→-1；`!IsReady`→-2；`!Off(2)`→-4；刚用 1 s→**-200**；`!InCombat`→-5；`LocalPlayerCannotReceiveHeal()`→**-71**；`HasAura(2728)`→-1；`LocalPlayerHasBleedWithoutDispel()`→20；Boss 读条 && (aura 1873 或 1219)→-5；人数不足或 aura 1873/1219 →-2 | Boss 读条 **10** / 常规 **10** / 流血优先 **20** |
| **无中生有(Thin Air)** | `ldc.i4 7430` | `Ability.无中生有` | `QT("无中生有")` | `无中生有防溢出`（默认 true，为 false 直接 -1）；`Charges >= MaxCharges - ldc.r4 0.1`；MP `ldc.i4 2400`；GCD 冷却 `ldc.i4 300` | `Stop`→-999；`!QT`→-100；`S`→-1；`!InCombat`→-5；`!IsReadyWithCanCast`→-2；`!Off(2)`→-4；`!防溢出`→-1；充能不足→-1；`MP>2400 && GCDcd<=300`→-1；`MP>2400 && GCDcd>300 && CanUseGCD`→-1 | 5 |
| **醒梦(Lucid Dreaming)** | `ldc.i4 7562`，`IsReady(7562, ldc.i4.1)` | `Ability.醒梦` | 无 QT 门禁 | 等级 `ldc.i4.s 14`；MP 阈值 = `醒梦阈值`（默认 `ldc.i4 8000`） | `Me.IsCasting`→-1；`等级<14`→-3；`!Off(ldc.i4.1)`→-4；`MP > 醒梦阈值`→-3；`S`→-1；`!IsReady`→-2 | **0** |
| **天赐祝福(Benediction)** | `ldc.i4 140` | `Ability.天赐` | `QT("奶人") && QT("能力技奶") && QT("天赐")` | `AbilityHealTarget(天赐阈值=20, QT("单奶限制"))`；内建 CD 键 `"天赐_"+id` 窗口 `ldc.i4 1000` | `Stop`→-999；`!QT`→-100；`S`→-1；`!Off(2)`→-4；无目标→-1；`!IsReady(140,t)`→-2；`!InCombat`→-5；内建 CD<1000ms→**-200** | **50** |
| **疾风/烈风/天辉** | 121 / 132 / 16532 | 只用 `16532` | — | 见「天辉」 | — | — |
| **以太变移(37008)** | `ldc.i4 37008` | `面向以太变移` / `鼠标位置以太变移` | `CanUse()`: `!IsHotkeyBlocked() && !HasSkillSilenceStatus() && IsReady(37008)` | `CameraForwardRotation()` 用 `ldc.r8 3.141592653589793`；`Run()` 先 `MemApiMove::SetRot(...)` 再 `Ability(37008)` 并 `HealerHotkeyExecutor::QueueHighPriorityOffGcd` | 静默 / 热键封锁 | — |
| **极限技(LB)** | 不在 WHM resolver 中 | — | — | YouShu 白魔的 36 个 resolver 里**没有 LB**；`WhiteMageHotkeySystem` 提到 `ldc.i4 31399`（极限技）与 `ldc.i4 20708`（爆发药）作为热键技能 | — | — |
| **PvE 中未使用的 id** | 119, 127, 3568, 7431, 16533, 25860, 121, 132, 126(实际用 7568), 138, 7444, 3583 | — | 119/127/3568/7431（飞石~崩石）与 16533（闪耀）在**全部 453 个 YouShu 类里一次都没出现**；25860 只通过 `GetAdjustedActionId(139)` 间接得到；126 被 7568 取代；138 / 7444 / 3583 未出现 | — | — | — |

> **`医养` 命名与 id 的冲突（重要）**：resolver 类 `Resolvers.GCD.医养` 施放的是 **`133`**；但 `WhiteMageHotkeySystem` 里名为「医养」的热键用的是 **`37010`**，而「医济」热键才是 `133`。`WhiteMageTools::IsCastingGroupHeal` 同时把 `131 / 124 / 133 / 37010` 视为群疗。所以该实现内部对「医养/医济」的命名不一致，`37010` 只出现在热键与群疗判定里，**resolver 本体从不施放 37010**。

### 1.7 `GCD.DOT::Check` 完整分支语义（proven，`.il.txt` 全文）

局部变量：`V0=target, V1=hasVisibleDot, V2=hasDot, V3=dotExpiring, V4=delay`。

1. `cachedTarget = null`
2. `Stop`→`-999`；`!QT("DOT")`→`-8`；`S`→`-1`
3. `V0 = WhiteMageTools::CurrentTarget`；`V0==null || V0.HasAttackBlock`→`-1`
4. `cachedTarget = V0`
5. `!IsReady(16532, V0)`→`-3`
6. `V0` 在 `DotBlacklistHelper` 中→`-10`
7. `ShouldSkipSingleTargetDot(V0)`→`-1`（= `ShouldSkipDotByHp(V0, 不上Dot阈值/100, 12)`）
8. `IsOutOfAttackRangeOrDead(V0, 25f)`→`-200`
9. `V1 = HasMyDot(V0, 1000)`（aura `1871 | 144 | 143`，且剩余时间 > 1000 ms）
10. `recent = HealerDotCastTracker::HasRecentlyApplied(GetAdjustedActionId(16532), V0, V1)`；`V2 = recent | V1`
11. `V3 = (!recent && V2) ? !HasMyDot(V0, 3000) : false` —— 即「已有 ≥1000ms 的 DOT 但不足 3000ms」= 即将到期
12. 若 `Me.IsMoving` 且 `DOT走位==true` 且 `MoveStartTimeMs > 0`：
    - `Me.HasAura(167)` → **-20**
    - `Now - MoveStartTimeMs < 移动中DOT延迟时间(1000)` → **-21**
    - 否则 `!V2`→45；`!V3`→30；其余 35
13. 静止分支：`!V2`→**50**；`!V3`→**-1**；其余 **40**
14. `Build`：`Slot.Add(Gcd(16532, cachedTarget).DontUseGcd)`，再 `HealerDotCastTracker::MarkPending(16532, cachedTarget)`

### 1.8 Openers（proven，`ACR.WhiteMage.Openers.*`）

`Opener` 设置字段 int 含义（`Timeline.Actions.起手设置::Draw` 与 `OpenerNames`）：
`0 = "空起手"`、`1 = "2GCD神速起手"`、`2 = "3GCD神速起手"`（`ldc.i4.3` 个名字数组；默认 `selectedOpener = "空起手"`）。

| Opener | StartCheck | InitCountDown | 步骤（每步是 `Sequence` 里一个 `Action<Slot>`） |
|---|---|---|---|
| 空起手 | `DailyOpenerStartCheck()`：非战斗且 `!QT("停手")`；`CastableParty.Count >= ldc.i4.8` 或（有目标且 `IsDummy`）→ 0，否则 **-100** | `AddCountdownRegenIfNeeded` + `AddCountdownPotionIfNeeded` + `AddCountdownGlare` | `Sequence` 为空列表（`List<Action<Slot>>.ctor`，无元素） |
| 2GCD神速起手 | `InCombat`→-1；`QT("停手")`→-1；否则 `HighEndOpenerStartCheck(ldc.i4.1)` | `AddCountdownPotionIfNeeded` + `AddCountdownGlare`（**不预铺再生**） | Step0: `QT("DOT")` 时 `Gcd(16532, CurrentTarget)`；Step1: `Gcd(25859, 0)`；Step2: `Ability(136)` + `Gcd(25859,0)`，若 `法令起手` 且 `IsUnlock(GetAdjustedActionId(3571))` 再 `Ability(3571)` |
| 3GCD神速起手 | 同上，`HighEndOpenerStartCheck(ldc.i4.2)` | 同「空起手」（再生 + 药 + 闪耀） | Step0: `QT("DOT")`→`Gcd(16532)` **然后总是** `Gcd(25859,0)`；Step2: `Gcd(25859,0)` + `Ability(136)`；Step3: 血花`==ldc.i4.3` 时 `Gcd(16535,0)`，`法令起手` 且解锁则 `Ability(3571)`；Step4: 有蓝花则 `Gcd(16534,0)`；`Me.HasAura(3879)` 时把同一个 `Gcd(37009,0)` 加入 slot **三次**；Step5: 有蓝花 `Gcd(16534,0)`（两次独立判断）、血花==3 `Gcd(16535,0)` |

`HighEndOpenerStartCheck(int opener)`：`InCombat`→-1；`QT("停手")`→-1；`Opener != opener || !高难模式`→-1；`CastableParty.Count > ldc.i4.4` 或（有目标且 `IsBoss`）→ 0，否则 -100。

`白魔起手辅助` 辅助常量：`SelectTankWithStance()` 用 `Distance(t, Me, ldc.i4.7) <= ldc.r4 30` + `ACR.Tool.Data.Helper::HasTankStance`；`HasRegen(t)` = `HasAura(ldc.i4 158) || HasAura(ldc.i4 1330)`；`AddCountdownRegenIfNeeded` 用 `倒计时再生延迟`（默认 5000）且受 `倒计时再生`（默认 true）门禁；`AddCountdownPotionIfNeeded` 在 `QT("爆发药")` 时用 `预读时间 - ldc.i4.s 100`；`AddCountdownGlare` 用 `预读时间`。

### 1.9 Timeline 动作 / 条件（proven）

**全部阈值类 Action 的滑条范围**：`IntSettingTimelineAction(名称, 当前值, ldc.i4.0, ldc.i4.s 100, setter, Save)`，即 **0–100**，作用于对应设置字段。
**例外**：`保留蓝花数量` = `ldc.i4.0 .. ldc.i4.3`；`群奶人数` / `群减人数` = `ldc.i4.0 .. ldc.i4.8`；`醒梦阈值` = `ldc.i4.0 .. ldc.i4 10000`；`预读时间` = `ldc.i4.0 .. ldc.i4 3000`。
**布尔类**：`DOT走位`、`蓝花走位` 用 `BoolSettingTimelineAction`。
`康复顺序`：`DrawRadioRow("康复顺序", ["H1","H2"])`，`Handle()` 执行 `H1 = (顺序 == ldc.i4.0)`。
`起手设置`：见 §1.8。
条件类（`ACR.WhiteMage.Timeline.Conditions.*`）：
- `红花层数`：`DrawRadioRow("检测红花的数量", ["0个","1个","2个","3个"])`；`Handle` = `Red != 0 ? (BloodLilyStacks >= Red) : (BloodLilyStacks == 0)`
- `蓝花层数`：同上，用 `LilyStacks`
- `神名层数`：`MemApiSpell::GetCharges(ldc.i4 3570)`，`Stacks != 0 ? stacks >= Stacks : stacks == 0`
- `神祝祷层数`：同上，`ldc.i4 7432`
- `无中生有层数`：同上，`ldc.i4 7430`
- `QtCheck`：`IsDefined(key) ? GetQt(key) : false`

### 1.10 目标选择辅助的共享下限（proven，`WhiteMageTools`）

- `SingleAbilityHealTarget(hpPercent, applySingleHealLimit, maxCandidateCount)`：`threshold = Clamp(hpPercent/100, 0, 1)`；遍历 `PartyHelper::CastableAlliesWithin30` + 自己，`CanReceiveHeal` 且 `HealerHealingHelper::MatchesSingleHealLimit(isTank, 单奶限制坦克, 单奶限制奶妈, 单奶限制输出)`；`NeedsLivingDeadHeal` 目标优先（`IsBetterLivingDeadPriorityTarget`）；最后 `count > maxCandidateCount → null`。
- `AbilityHealTarget(p, limit)` = `SingleAbilityHealTarget(p, limit, ldc.i4 2147483647)`。
- `SolaceTarget(threshold, limit)`：额外要求 `CurrentHp > ldc.i4.0`、`Distance(t, Me, ldc.i4.7) <= ldc.r4 30`。
- `LocalPlayerHasBleedWithoutDispel()` = `HealerHealingHelper::HasBleed(Me) && !Helper::HasDispelStatus(Me)`。
- `ShouldHoldBurstForDyingTrash()` = `HealerEnemyTargetHelper::ShouldHoldBurstForDyingTrash(ldc.r4 0.25, ldc.i4 6000, ldc.i4.1, CurrBattleTimeInMs)`。
- `CanUseGroupHeal()` = `Now - GetBuiltInCooldown("群疗互斥") >= ldc.i4 1000`；`MarkGroupHeal()` 写该键。
- `CanUseGroupMitigation()` = `Now - GetBuiltInCooldown("白魔_群减互斥_节制全大赦") >= ldc.i4 5500`；`MarkGroupMitigation()` 写该键。
- `IsCastingGroupHeal()` = `Me.IsCasting && CastActionId ∈ {131, 124, 133, 37010}`。
- `AddThinAirIfNeeded(slot)`：`无中生有防耗蓝(true)` && `MP <= Clamp(醒梦阈值, ldc.i4.0, ldc.i4 10000)` && `IsReady(7430)` → 追加 `Ability(7430)`。
- `HasMyDot(t, minTimeLeft)` = `HasMyAuraWithTimeleft(t, 1871, min) || ...(144) || ...(143)`。
- `HasWhiteMageDot(t)` = `HasLocalPlayerAura(t, 1871|144|143)`。
- `HasRegen(t)` = `MemApiBuff::GetAuraTimeleft(t, 158, 1) > 0 || GetAuraTimeleft(t, 1330, 1) > 0`。
- `HasLily()` = `LilyStacks > ldc.i4.0`；`CanSpendLily(reserve)` = `LilyStacks > Clamp(reserve, ldc.i4.0, ldc.i4.3)`。
- `SwitchTargetIfNeeded(cur, target)`：仅当 `智能AOE目标 && 自动切换最优目标 && cur!=null && target!=null && cur.EntityId != target.EntityId` 时 `Me.SetTarget(target)`。

---

## 2. 参考实现 B —— Shiyuvi（`ACR3._0.WHMPVP.*`，**PvP**）

### 2.1 注册信息（proven，`ACR3._0.PvPWHMRotationEntry::Build`）

`TargetJob = ldc.i4.s 24`、`AcrType = ldc.i4.3`、`MinLevel = ldc.i4.1`、`MaxLevel = ldc.i4.s 100`、Description = `"大莱莱气哭萨姆来"`。
`GetOpener(level)` 返回 `null`（**无起手**）。
内部 `SlotResolvers` 是一个 `List<SlotResolverData>`（**不是数组**），按 `Add` 顺序执行；`SlotResolverData::.ctor` 的整型参数全部是 **`ldc.i4.0`**（与 YouShu 的 1/2 不同）。

### 2.2 Resolver 顺序（proven，`PvPWHMRotationEntry::.ctor`，共 9 项）

| # | 类 | type | 技能 id |
|---|---|---|---|
| 0 | `WHMPVP.GCD.净化` | 0 | 29056 |
| 1 | `WHMPVP.GCD.药` | 0 | 29711 |
| 2 | `WHMPVP.Ability.自然的奇迹` | 0 | 29228 |
| 3 | `WHMPVP.Ability.水流幕` | 0 | 29227 |
| 4 | `WHMPVP.GCD.愈疗` | 0 | 29225 |
| 5 | `WHMPVP.Ability.苦难之心` | 0 | 29226 |
| 6 | `WHMPVP.GCD.飒闪` | 0 | `get__spellid`（**属性体不在 dump**） |
| 7 | `WHMPVP.GCD.闪灼` | 0 | 29223 |
| 8 | `WHMPVP.GCD.冲刺` | 0 | 29057（`Build` 中 `ldc.i4 29057`） |

QT 定义（`DefaultQtDefinitions`，全部默认 `true`，即 `JobViewQtDefinition(name, ldc.i4.1, "", null)`）：
`愈疗、闪灼、水流幕、自然的奇迹、苦难之心、喝热水、自动净化、冲刺、闪飒`（共 9 个，`Dictionary` 逐个 `set_Item`）。
`DefaultHiddenQts = Array.Empty<string>()`（`ldc.i4.0` 长度数组）。
热键（`JobViewWindow::AddHotkey`）：`"疾跑"` → `HotKeyResolver_NormalSpell(29057, ldc.i4.1, ldc.i4.0)`；`"龟壳"` → `龟壳::.ctor`；`"热水"` → `HotKeyResolver_NormalSpell(29711, ldc.i4.1, ldc.i4.0)`；`"智能目标:LB能命中最多目标"` → `白魔LB::.ctor`。

### 2.3 设置默认值（proven，`ACR3._0.WHMPVP.PvPWHMSettings::.ctor`）

| 字段 | 默认值 | 证据 |
|---|---|---|
| ConfigVersion | 2 | `ldc.i4.2` |
| 药血量 | 70 | `ldc.i4.s 70` |
| 智能LB | true | `ldc.i4.1` |
| 自动LB最少命中 | 3 | `ldc.i4.3` |
| 自动LB安全血量 | 75 | `ldc.i4.s 75` |
| JobViewSave.MainColor | `Vector4(0.7294118f, 0.54901963f, 0.38431373f, 0.8f)` | `ldc.r4` ×4 |
| `自动LB允许移动释放` | **从未赋值** → CLR 默认 `false` | 全 dump 扫描 |

### 2.4 逐技能使用表（参考实现 B = Shiyuvi，PvP）

| 技能 (PvP) | id | 类 | 条件（IL 顺序） | 阈值 / 字面量 | 负面守卫 | 返回值 |
|---|---|---|---|---|---|---|
| **净化** | `ldc.i4 29056` | `GCD.净化` | `QT("自动净化")` | 充能 `MemApiSpell::GetCharges(29056) >= ldc.r4 1`；`PVPHelper::净化判断()` | `!QT`→-9；充能<1→-2；`!净化判断`→-3 | 1 |
| **药（喝热水）** | `ldc.i4 29711` | `GCD.药` | `QT("喝热水")` | `PVPHelper::CanActive`；`SpellHelper::GetSpell(技能药).IsReadyWithCanCast`；`Me.CurrentHpPercent <= 药血量/100`（默认 `70/100=0.70`） | `!QT`→-9；`!CanActive`→-3；`!IsReadyWithCanCast`→-2；`HP > 阈值`→**0（返回 0 = 不做）** | -1 |
| **自然的奇迹** | `ldc.i4 29228` | `Ability.自然的奇迹` | `get_通用权限`；`QT("自然的奇迹")`；`CanActive` | `通用距离检查(ldc.i4.s 10)`；`通用技能释放Check(29228, ldc.i4.s 10)`；充能 `>= ldc.r4 1`；`TargetSelector::Get黑骑镰刀目标(ldc.i4.s 10, 29228)` | 无权限→**-999999**；`!QT`→-9；`!CanActive`→-1；距离→-2；释放检查→-3；充能<1→-4；无目标→-1 | 1 |
| **水流幕** | `ldc.i4 29227` | `Ability.水流幕` | `get_通用权限`；`QT("水流幕")`；`CanActive` | 充能 `>= ldc.r4 1`；先在本方 `FrameCache::CastableAlliesWithin30` 中找带 aura **`ldc.i4 3202`** 的队友；否则 `TargetSelector::Get康复目标(ldc.i4.s 30, 29227)` | 无权限→-999999；`!QT`→-9；`!CanActive`→-1；充能<1→-3；两个目标来源都为空→-2 | 找到 aura 目标 1 / 普通 0 |
| **愈疗** | `ldc.i4 29225` | `GCD.愈疗` | `get_通用权限`；`QT("愈疗")`；`CanActive` | 自身 aura **`ldc.i4 3083`** 必须存在；`HasMyAuraWithTimeleft(3083, ldc.i4 2000)`；在本方 `CastableAlliesWithin30` 中找 `CurrentHp > ldc.i4.0 && CurrentHpPercent <= ldc.r4 0.7` 的队友；`ACRTargetHelper::IsTargetVisibleOrInRange(29225, target)` | 无权限→-999999；`!QT`→-9；`!CanActive`→-1；无 aura 3083→-2；剩余<2000ms→**2**；目标不可见/超距→-3 | 1 |
| **苦难之心** | `ldc.i4 29226` | `Ability.苦难之心` | `get_通用权限`；`QT("苦难之心")`；`CanActive` | `通用距离检查(ldc.i4.s 25)`；`通用技能释放Check(29226, ldc.i4.s 25)`；充能 `>= ldc.r4 1`；`Get最合适目标(25, 29226)` + `Get目标周围安全敌人数量(target, ldc.r4 25, ldc.r4 5) >= ldc.i4.2`；或（`Get目标周围敌人数量 >= ldc.i4.1` 且 `target.CurrentHpPercent < ldc.r4 0.3`） | 无权限→-999999；`!QT`→-9；`!CanActive`→-1；距离→-5；释放检查→-6；充能<1→-7；都不满足→-1 | 多目标 1 / 残血 2 |
| **飒闪** | `get__spellid`（**值不在 dump**） | `GCD.飒闪` | `get_通用权限`；`QT("闪飒")` | 自身 aura **`ldc.i4 4326`** 必须存在；`通用距离检查(ldc.i4.s 25)`；`通用技能释放Check(spellid, ldc.i4.s 25).IsReadyWithCanCast`；`Build` 用 `通用技能释放(spellid, ldc.i4.s 25)` | 无权限→-999999；`!QT`→-9；无 aura 4326→**-10**；`!CanActive`→-1；距离→-5；释放检查→-6 | 1 |
| **闪灼** | `ldc.i4 29223` | `GCD.闪灼` | `get_通用权限`；`QT("闪灼")` | `MoveHelper::IsMoving` 必须为 false；`通用距离检查(ldc.i4.s 25)`；`通用技能释放Check(29223, ldc.i4.s 25).IsReadyWithCanCast` | 无权限→-999999；`!QT`→-9；移动中→**-10**；`!CanActive`→-1；距离→-5；释放检查→-6 | 1 |
| **冲刺** | `ldc.i4 29057`（`技能净化` 字段初值 `ldc.i4 29056`） | `GCD.冲刺` | `QT("冲刺")` | 自身 aura `ldc.i4 1342` 必须不存在；`Linto.PvPSettings::无目标冲刺`；`GCDHelper::GetGCDCooldown() == 0`；`PVPHelper::check坐骑()` | `!QT`→-9；`HasAura(1342)`→-2；`!无目标冲刺`→-3；GCD 未就绪→-4；坐骑中→-5；`!CanActive`→-6 | 0 |
| **自动LB** | `ldc.i4 29230`（`SpellHelper::GetSpell(29230)`） | `Ability.自动LB` | `get_通用权限`；`QT("自动LB")` | `check坐骑`；`CanActive`；`净化判断`；`自动LB允许移动释放`（默认 false）→ 移动中直接 -3 并记 `_lastMoveTickMs`；停止后需 `环境Tick - _lastMoveTickMs >= ldc.i4 500`；自身 aura `ldc.i4 1342` 不得存在；`RecentlyUsed(29057, ldc.i4 1500)`、`RecentlyUsed(29229, ldc.i4 1500)`；`Me.CurrentHpPercent >= 自动LB安全血量/100`（默认 `75/100=0.75`）；`IsReadyWithCanCast`；`TryFindBestLbTarget` 的 `effectiveHits >= 自动LB最少命中(3)`；`!IsUnsafeToLb()`；命中矩形 `IsInRectangle(me.Pos, dir, ldc.r4 40, ldc.r4 6, enemy.Pos, hitbox)`，宽 6、长 40；候选筛选 `DistanceToPlayer <= ldc.r4 40`、`IsTargetVisibleOrInRange`；免疫/格挡 aura = `3039 / 1302 / 2413 / 3054`；千点 aura = `ldc.i4 1240`（出现即整条候选作废） | 无权限→-999999；`!QT`→-9；坐骑→-13；`!CanActive`→-1；`净化判断`→-2；移动中→-3；刚停下<500ms→-4；`HasAura(1342)`→-5；刚用 29057/29229→-6；血少→-7；不可释放→-8；无候选→-10；命中不足→-11；`IsUnsafeToLb`→-12 | **100** |
| **白魔LB（手动热键）** | `ldc.i4 29230` | `白魔LB` | `Check()` 恒 `0` | `BattleData.NextSlot`（若为空则新建 `Slot(ldc.i4 600)`）；`ACRTargetHelper::SmartTargetLineAOE(Me.GetCurrTarget(), ldc.r4 40, ldc.r4 6, 29230, ldc.i4.1, ldc.i4.s 40)` | 无目标→直接返回 | —（手动执行） |
| **PvP 未使用的 PvE id** | 全部 PvE id（119…37011）在 `ACR3._0.WHMPVP.*` 中**完全未出现** | — | — | — | — | — |

---

## 3. 两套参考实现的差异

### 3.1 结构性差异（最重要）

| 维度 | YouShu（A，PvE） | Shiyuvi（B，PvP） |
|---|---|---|
| 覆盖范围 | 完整 PvE 白魔：36 Resolver + 4 Opener + 32 Timeline + QT + 热键 + 设置 UI | **只有 PvP**，9 个 resolver，无 Opener（`GetOpener` 返回 `null`），无 Timeline |
| Resolver 容器 | `SlotResolverData[]`，`ldc.i4.s 34` 数组，**顺序即下标** | `List<SlotResolverData>`，9 次 `Add` |
| `SlotResolverData` 第二参数 | `ldc.i4.1`(GCD) / `ldc.i4.2`(oGCD) | 全部 `ldc.i4.0` |
| AcrType | `ldc.i4.0` | `ldc.i4.3` |
| MinLevel | `ldc.i4.0` | `ldc.i4.1` |
| 放弃码体系 | 丰富：`-999 / -200 / -100 / -71 / -50 / -41 / -40 / -33 / -30 / -21 / -20 / -10 / -9 / -8 / -7 / -6 / -5 / -4 / -3 / -2 / -1` | 少：`-999999 / -13 / -12 / -11 / -10 / -9 / -7 / -6 / -5 / -4 / -3 / -2 / -1`，另有 `+100 / +2 / +1 / 0` |
| 互斥/节流机制 | 有内建 CD 字典（`群疗互斥`=1000ms、`白魔_群减互斥_节制全大赦`=5500ms、目标键 `天赐_/神名_/神祝祷_`=1000ms）、`HealerDotCastTracker`、`HealerGcdHealTracker` | 只有 `Environment.TickCount64` + `SpellExtension::RecentlyUsed` |
| 起手 | 3 套（空 / 2GCD 神速 / 3GCD 神速），含倒计时预读 | 无 |
| QT 系统 | 35 个 QT，默认值逐个显式给定 | 9 个 QT，全部默认 true |
| 配置持久化 | `JsonFile::LoadOrCreate<WhiteMageSettingsData>` + `EnsureDefaults()` | `File.Exists` / `JsonHelper::FromJson` + try/catch 回退，`ConfigVersion = 2` |

### 3.2 可直接对比的「同类概念」差异

| 概念 | YouShu (A) | Shiyuvi (B) | 说明 |
|---|---|---|---|
| 群疗人数阈值 | `群奶人数` 默认 **2**（滑条 0–8） | 无此概念 | — |
| 群减人数阈值 | `群减人数` 默认 **2**（滑条 0–8） | 无 | — |
| 单奶血量阈值 | `天赐阈值 20` / `神名阈值 75` / `神祝祷阈值 70` / `安慰之心阈值 40` | 无（PvP 只按 `CurrentHpPercent <= 0.7` 找最残血队友） | B 的 0.7 是**硬编码** `ldc.r4 0.7`，不可配 |
| 群疗血量阈值 | `医养阈值 65` / `医治阈值 45` / `愈疗阈值 40` / `狂喜之心阈值 75` / `庇护所阈值 80`（全部 ×1/100） | 无 | — |
| 自我保命血量阈值 | 无「安全血量」概念（靠 aura 与 MP 判定） | `自动LB安全血量` 默认 **75**、`药血量` 默认 **70** | B 有「血量百分比安全线」，A 没有 |
| 「保留资源」策略 | 有：`保留蓝花数量` 默认 **1**、`保留红花` QT、`攒爆发`/`倾泻资源` QT、`无中生有防溢出`/`防耗蓝` | 无（PvP 资源模型不同） | — |
| 移动中施法 | 允许 DoT（`DOT走位` 默认 **true** + `移动中DOT延迟时间` 1000ms）、`蓝花走位`、`即刻走位` | 明确禁止：`闪灼` 移动中直接 -10；`自动LB` 默认不允许移动释放（`自动LB允许移动释放` 未赋值 → false），且停下后要等 **500ms** | **最直接的策略冲突** |
| 复活 | 两套 Raise resolver（普通 + 过路圣人模式），`复活延迟` 默认 1 | 无复活逻辑 | — |
| 康复/驱散 | `康复`（通用）+ `绝亚康复`（仅副本 id 887，用 `SelectTemporalStasisTarget`） | `净化`（29056），`PVPHelper::净化判断()` | A 的绝亚分支硬编码副本 id |
| 减伤层数检查 | 自身 aura `1873` / `1911` / `1219` / `1218` / `2728` / `1217` / `3881` | 自身 aura `3083` / `4326` / `1342`；目标 aura `3202` | 完全不同套 id |
| 群减互斥窗 | **5500 ms**（`MarkGroupMitigation`） | 无 | — |
| 群疗互斥窗 | **1000 ms**（`MarkGroupHeal`） | 无 | — |
| 智能多目标选敌 | `智能AOE目标`（默认 **false**，未赋值）+ `自动切换最优目标`（默认 true），`SelectCircularAoeTarget(3, r, 5, t, 1)` + `GetNearbyEnemyCount >= 3` | 每个技能自带矩形/圆形判定，`Get目标周围安全敌人数量 >= 2` 或 `周围敌人数量 >= 1 且 HP < 0.3` | A 依赖一个默认关闭的开关；B 是硬编码多档 |
| 阈值可被 Timeline 改写 | 是（30 个 TriggerAction，16 个阈值 Action 滑条 0–100） | 否（无 Timeline） | — |

### 3.3 两者**唯一真正同名的技能**（id 完全不同的对照）

| 中文名 | YouShu (PvE) id | Shiyuvi (PvP) id |
|---|---|---|
| 水流幕 | 25861 | 29227 |
| 苦难之心 | 16535 | 29226 |
| 愈疗 | 131 | 29225 |
| 闪灼 | `GetAdjustedActionId(25859)` | 29223 |

---

## 4. 完整 id 清单（proven，扫描全部 453 个 YouShu 类中的 `ldc.i4`）

Plugin 自带的 `.cctor` 名称表（`WhiteMageHotkeySystem`，最权威）：

| 名称 | id | | 名称 | id |
|---|---|---|---|---|
| 极限技 | 31399 | | 安慰之心 | 16531 |
| 爆发药 | 20708 | | 狂喜之心 | 16534 |
| 庇护所 | 3569 | | 神速咏唱 | 136 |
| 礼仪之铃 | 25862 | | 无中生有 | 7430 |
| 以太变移 / 面向以太变移 / 鼠标位置以太变移 | 37008 | | 法令 | 3571 |
| 医济 | 133 | | 全大赦 | 7433 |
| 医养 | 37010 | | 水流幕 | 25861 |
| 救疗 | 135 | | 天赐祝福 | 140 |
| 节制 | 16536 | | 复活 | 125 |
| 再生 | 137 | | 康复 | 7568 |
| 愈疗 | 131 | | 即刻咏唱 | 7561 |
| 神祝祷 | 7432 | | 沉稳咏唱 | 7559 |
| 神名 | 3570 | | 营救 | 7571 |
| 医治 | 124 | | 沉静 | 16560 |

Resolvers 中出现但**没有名称表条目**的 id：`16532`（天辉/Dia）、`16535`（苦难之心）、`25859`、`37009`、`37011`（神爱抚）、`7430/7432/7433`、`139`（由 `GetAdjustedActionId` 调整）、`7562`（醒梦）、`120`、`131`。
**Aura / status id（名称不在 dump 中，故只报数字）**：`167, 143, 144, 150, 158, 1217, 1218, 1219, 1240, 1249, 1302, 1330, 1342, 1871, 1873, 1911, 2413, 2728, 3039, 3054, 3083, 3202, 3879, 3880, 3881, 3884, 4326, 841, 49, 43, 44`。
**副本 / 区域 id**：`293, 296, 1046`（豪圣禁用）、`887`（绝亚康复限定）。
**等级门槛**：`14`（醒梦）、`30`（救疗 MP 分支）、`46` / `82`（豪圣）、`52` / `72`（蓝花走位）、`4`（`HighEndOpenerStartCheck` 的队伍人数）、`8`（`DailyOpenerStartCheck` 的队伍人数）。

**任务给出的 id 列表与实际 IL 的对照**（重要修正）：

| 任务预期 | 实际 IL |
|---|---|
| 119 飞石 / 127 坚石 / 3568 垒石 / 7431 崩石 / 16533 闪耀 | **全部 453 个类里一次都没出现**（该实现完全不使用低级石系/闪耀） |
| 25860 豪圣 | 只通过 `GetAdjustedActionId(139)` 间接产生，**没有裸 `ldc.i4 25860`** |
| 131 医术(mislabeled?) | `131` 是 `Resolvers.GCD.愈疗`（Cure III），名称表里 `131 = 愈疗` |
| 133 医济 | `133` 出现在 `Resolvers.GCD.医养`；名称表里 `133 = 医济`、`37010 = 医养` → **resolver 名与名称表冲突**（见 §1.6 注） |
| 126 康复 | 实际用 **`7568`**（126 未出现） |
| 138 神速咏唱? | 实际用 **`136`**（138 未在 resolver 中出现） |
| 37008? | 存在，被「以太变移」系列热键/`面向以太变移`/`鼠标位置以太变移` 使用 |
| 7444 天辉? | **未出现**（天辉 = `16532`） |
| 3583? / 25862? | `3583` 未出现；`25862` 存在（礼仪之铃） |
| 121 疾风 / 132 烈风 | 均未在 WHM resolver 中出现（`132` 只作为无关类的数字出现） |

---

## 5. 无法确证的部分

以下条目**明确无法从这两份 dump 确证**，重实现时需自行决定；我按「已知的调用契约 / 完全未知」分类。

### 5.1 完全不在 dump 中的方法体（只有调用点）

| 方法 | 调用方传入 | 状态 |
|---|---|---|
| `AEAssist.Helper.SpellExtension::RecentlyUsed(actionId, ms)` | 多个 resolver 传入 `(140,3000)`、`(7423/16531,1500)`、`(16534,1500)`、`(25862,1000)`、`(16536,5000)`、`(136,2000)` | **内部实现未知**（`ACR.Tool.Runtime.HealerActionHelper::RecentlyUsed` 只做转发，已证明） |
| `HealerEnemyTargetHelper::HasBossCastingAoeWithin(ms)` | `3000` | **未知**（「Boss 正在读条一个 AOE 且在 ms 内」是命名推测） |
| `HealerEnemyTargetHelper::HasAttackBlock(target)` | target | **未知** |
| `HealerEnemyTargetHelper::IsOutOfAttackRangeOrDead(target, float)` | `25f` | **未知** |
| `HealerEnemyTargetHelper::ShouldSkipDotByHp(target, float, long)` | `(t, 不上Dot阈值/100, 12L)` | **未知**（第 3 个参数 12 的语义未知） |
| `HealerEnemyTargetHelper::IsInBossBattle()` | — | **未知** |
| `HealerEnemyTargetHelper::CanAttackTargetInRange(t, 20f, 0)` | `(t, 20f, 0)` | **未知** |
| `HealerEnemyTargetHelper::SelectCircularAoeTarget(3, r, 5, t, 1)` | `(3, 25f 或 30f, 5, target, 1)` | **未知**（前 3 个参数含义只能猜） |
| `TargetHelper::GetNearbyEnemyCount(origin, r1, r2)` | `(Me, 8f, 8f)` 与 `(best, 25f, 5f)` | **未知** |
| `HealerDotCastTracker::HasRecentlyApplied / MarkPending / Clear` | `(adjustedId, target, bool)` / `(16532, target)` | **未知** |
| `HealerGcdHealTracker::Initialize / Clear / Dispose` | — | **未知** |
| `HealerHealingHelper::CanReceiveHeal / NeedsLivingDeadHeal / IsBetterLivingDeadPriorityTarget / MatchesSingleHealLimit / HasBleed` | 见 §1.10 | **未知**（`MatchesSingleHealLimit(isTank, 单奶限制坦克, 单奶限制奶妈, 单奶限制输出)` 的参数顺序可从调用点推断，判定逻辑未知） |
| `HealerRuntimeTools::HasSkillSilenceStatus()` | 几乎所有 resolver | **未知**（「技能被沉默/封印」是命名推测） |
| `HealerRuntimeTools::BuffTimeLessThan(auraId, ms)` | `(49, 3000)` | **未知** |
| `HealerRuntimeTools::IsHotkeyBlocked()` | `面向以太变移` | **未知** |
| `HealerEnemyTargetHelper::GroundCastPosition(场中, 开挂模式, 优先目标位置, target)` | 4 个参数 | **签名已知，语义未知** |
| `HealerRaiseRuntime::HasDeadAllyWithoutRaise(125, 过路圣人模式)` / `SelectRaiseTarget(dict, 复活延迟, 优先复活TN)` / `HandleSuccessfulSpell(spell)` | 见 §1.6 | **未知** |
| `HealerRaiseResolver::Check/Build`、`HealerPasserbyRaiseResolver::Check/Build` | 构造函数参数已知（`125, -999, 7430, CanUseAssistAction, 6 个 λ`） | **方法体未知** —— 复活的实际判定全部在这些类里，dump 中没有 |
| `HealerDoubleDotResolverBase::CommonCanDot / Check / Build` | `(enemy, 不上Dot阈值/100)` | **未知** —— `双DOT` resolver 的全部逻辑都在这 |
| `HealerFullHealTargetSelector::FindTarget()` | — | **未知** |
| `HealerEsunaTargetSelector::SelectGeneralTarget(H1)` / `SelectTemporalStasisTarget(H1)` | `H1`（默认 true） | **未知** |
| `HealerPotionResolver::.ctor(Func<bool>, Func<bool>)` | 两个编译器生成的 λ | **未知**（连 λ 体也不在 dump） |
| `MemApiSpell::GetCharges / CheckActionChange / GetCooldown / GetGCDDuration`、`MemApiBuff::GetAuraTimeleft`、`MemApiZoneInfo::GetCurrTerrId / IsBoundByDuty`、`MemApiMove::SetRot`、`MemApiChatMessage::Toast2` | — | AEAssist 框架 API，**未知** |
| `GCDHelper::GetGCDCooldown / CanUseGCD` | `无中生有`；Shiyuvi 的 `冲刺` | **未知** |
| `PartyHelper::CastableAlliesWithin30 / CastableParty / CastableTanks / Party` | 多处 | **未知**（只知是列表） |
| `DotBlacklistHelper::IsBlackList(target)`、`TargetMgr::EnemysIn25` | — | **未知** |
| `ACR.Tool.Data.Helper::HasAnyStatus / HasDispelStatus / HasTankStance`、`ACR.Tool.Data.Status::无法接受治疗合集` | — | **未知**（`无法接受治疗合集` 是 uint 集合，内容不在 dump） |
| Shiyuvi 侧：`PVPHelper::通用权限 / CanActive / 通用距离检查 / 通用技能释放Check / 通用技能释放 / 净化判断 / check坐骑 / 等服务器Spell / Get目标周围安全敌人数量 / Get目标周围敌人数量`、`TargetSelector::Get最合适目标 / Get康复目标 / Get黑骑镰刀目标`、`FrameCache::CastableAlliesWithin30`、`ACRTargetHelper::IsTargetVisibleOrInRange / SmartTargetLineAOE`、`MoveHelper::IsMoving`、`Linto.PvPSettings::*`、`龟壳` | — | **全部未知**（这些是 Linto PvP 框架，不在 dump） |

### 5.2 编译器生成类不在 dump（`<>c` / `<>O` / `<>c__DisplayClass*`）

dump 中出现的所有 `ldftn <>c::<X>b__Y_Z` **都没有对应的 `<>c` 类**（我对 `youshu.il.txt` 全文搜索：`^### .*(<>c|<>O)` 命中 0，`^\s+:: .*b__` 命中 0）。受影响的具体位置：

- `白魔技能策略::.cctor` 的两个 λ `<>c::<.cctor>b__1_0` / `b__1_1` —— 它们是 `HealerPotionResolver` 构造函数的两个 `Func<bool>`，**内容未知**。
- `Strategy.复活::.ctor` 的 λ `b__1_0..b__1_6` —— **未知**（其中 `b__1_5` 返回 `List<string>`、`b__1_6` 返回 `IReadOnlyList<string>`，推测是复活宏/频道列表，但**无法确证**）。
- `Strategy.过路圣人复活::.ctor` 的 λ `b__1_0..b__1_3`（其中一个返回 `int`）—— **未知**。
- `白魔起手辅助` 的 λ `b__3_0`（再生 Spell 工厂）、`b__5_0`（闪耀 Spell 工厂）、`<>c__DisplayClass6_0::<AddCountdownAction>b__0` —— **未知**（所以倒计时具体预读哪个技能 id 无法确证；只能从名字推断是再生/闪耀）。
- `白魔2GCD/3GCD起手` 的 `<>O::<n>__StepN` 缓存字段 —— 无影响（只是委托缓存）。
- `WhiteMageTools` 的 `<>c__DisplayClass22_0/25_0/26_0` 本地函数体**部分在 dump**（`<SingleAbilityHealTarget>g__UpdateCandidate|22_0` 等三个有体，已读），但 `<>c__DisplayClass*` 类本身的方法有缺失。

### 5.3 dump 中从未赋值 → 值不可知的白魔设置字段

见 §1.4 表格。**其中最影响行为的是 `智能AOE目标`、`蓝花走位`、`神速咏唱限制`、`即刻咏唱延迟时间`、`蓝花走位延迟时间`、`单奶限制奶妈`、`单奶限制输出`、`庇护所开挂模式`、`庇护所优先目标位置`、`铃铛开挂模式`、`铃铛优先目标位置`、`高难模式`（`高难模式` 由 QT 运行时写入，但 JSON 里没有默认值）。**

### 5.4 `LilyStacks` / `BloodLilyStacks` / `LilyTimer` / `MoveStartTimeMs` / `CurrentTarget` 的定义不在 dump

这些属性**被大量读取**（`WhiteMageTools::get_LilyStacks` 等），但我对 453 个类做了穷举搜索：`:: ... get_LilyStacks(` / `get_BloodLilyStacks(` / `get_LilyTimer(` / `get_MoveStartTimeMs(` / `get_CurrentTarget(` **没有任何一个是方法定义**。所以：

- 蓝花计数、血花计数、蓝花计时、移动起始时间戳、当前目标的**取值方式未知**（推测来自 `WhiteMageTools` 的另一个 partial 部分或另一程序集）。
- `HealerMovementRuntimeState::Update/Reset` **有体**（`MoveStartTimeMs` 在「本帧移动且上帧未移动」时置为 `TimeHelper::Now`，停止移动时置 0），所以时间戳语义可确证；但 `WhiteMageTools::get_MoveStartTimeMs` 到它的映射（大概是读那个 state）**是推断**。

### 5.5 其他不确定项

- `SlotResolverData::.ctor(resolver, int)` 的第二参数语义（1=GCD / 2=oGCD）**是推断**，非 IL 直接证明。
- `面向以太变移` / `鼠标位置以太变移` 使用的 `37008` 的**技能名未在 dump 中给出**；只能确定它先 `MemApiMove::SetRot(CameraForwardRotation())` 再 `Ability(37008)`。
- Shiyuvi 的 `飒闪::get__spellid` **属性体完全不在 dump**，因此 `飒闪` 的实际 PvP id **无法确证**。
- `HealerPotionResolver` 的实际药水 id / 触发时机**不在 dump**（构造函数只收两个 `Func<bool>`）。
- 所有 aura/status **名称**都不在 dump（`ACR.Tool.Data.Status` 只有 uint 集合，没有字符串）。本报告中括号里的技能中文名来自 plugin 自己的热键名称表（§4），是可靠的；但 aura id 到名称的映射**没有**任何 dump 依据，只有「用法 → 推测含义」（已在表中标注为用法而非名称）。
