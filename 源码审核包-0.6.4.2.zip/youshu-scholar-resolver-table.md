# YouShu Scholar (学者) — complete per-skill resolver table

Reconstructed from decompiled IL to allow faithful reimplementation.

## Sources and method

| File | What it gave |
|---|---|
| `.il\youshu.core.txt` (2.96 MB, 53409 lines) | Class bodies for all 78 requested classes. **Lossy**: drops many short-form `ldc.i4.0…8` / `ldc.i4.m1` / `ldarg` operand pushes and some `ret`s. |
| `.il\youshu.il.txt` (3.86 MB, 92419 lines) | Companion dump. **Lossless** for the same classes (`ACR.Scholar.Timeline` 53106–54038, `ACR.Scholar.Resolvers` 54039–58997, `ACR.Scholar.Openers` 58998–59326). Also holds `ScholarSettingsData::.ctor` (46734) and `ScholarSettingsUI::ApplySettings` (52969). |
| `.il\youshu.core.txt` 26135–26879 | `ACR.Scholar.ScholarTools` bodies — **present**, contrary to the assumption in the brief. |
| `.il\youshu.core.txt` 23268–23675 | The 5 `ACR.Tool.Resolvers` classes — **present**. |
| `.scratch\scholar_consts.txt` | Derived: every `ldc`/`ldstr`/`ret` from `youshu.il.txt` 54039–59326, keyed by IL offset, used to recover the constants `.core.txt` dropped. |

**Every number below is quoted from an `ldc.i4*` / `ldc.r4` / `ldc.r8` / `ldstr` opcode that was actually read.** Where a constant is absent from both dumps it is marked `UNKNOWN (absent from dump)` — never guessed.

Labels used: **[IL]** = proven from an opcode; **[inferred]** = name/semantics deduced, not proven; **[gap]** = not determinable from these dumps.

### Critical caveat about the dumps

`youshu.core.txt` **silently drops operand pushes**. Example: `不屈不挠之策` appears there as

```
IL_0038: ldc.i4.s -100
IL_003c: call HealerResolverBase::CanUseOffGcd      <- argument missing
```

The lossless dump shows the real sequence is

```
IL_0038: ldc.i4.s -100
IL_003a: ret
IL_003b: ldc.i4.2                                   <- the argument
IL_003c: call HealerResolverBase::CanUseOffGcd
```

All constants below were taken from the lossless dump for this reason. **A reimplementer must not use `youshu.core.txt` alone.**

### Skills referenced (CN class name → EN action, all names **[inferred]** from CN client naming; IDs are **[IL]**)

| ID | Action | ID | Action |
|---|---|---|---|
| 166 | Aetherflow | 7436 | Chain Stratagem |
| 167 | Energy Drain | 7437 | Aetherpact |
| 185 | Adloquium | 7561 | Swiftcast |
| 186 | Succor | 7562 | Lucid Dreaming |
| 188 | Sacred Soil | 7568 | Esuna |
| 189 | Lustrate | 7869 | Fey Union (link cancel) |
| 190 | Physick | 17215 | Summon Eos |
| 315 | Whispering Dawn (self buff) | 17864 | Biolysis |
| 3583 | Indomitability | 17869 | Ruin (BroilFiller lvl<38) |
| 3584 | Ruin II (lvl 54–63) | 17870 | Ruin (毁坏) |
| 3585 | Deployment Tactics | 25867 | Protraction |
| 3586 | Emergency Tactics | 25868 | Expedient |
| 3587 | Dissipation | 37012 | Baneful Impaction |
| 7434 | Excogitation | 37014 | Seraphism |
| 7435 | Broil (lvl≥64 filler) | 37015/37016 | Adloquium/Succor (Recitation) |
| 16537 | Whispering Dawn | 16542 | Recitation |
| 16538 | Fey Illumination | 16543 | Fey Blessing |
| 16539 | Art of War | 16545 | Summon Seraph |
| 16546 | Consolation | 1896 | Recitation (self aura) |
| 791 | Seraph present (self aura) | 3884 | Recitation (GCD shield aura) |
| 1220 | Excogitation (target aura) | 1221 | Chain Stratagem (target aura) |
| 1222 | Fey Union link (target aura) | 3882 | Baneful Impaction (target aura) |
| 2711 | Expedient (party aura) | 297/1918/2607/2608/2609 | Scholar shield statuses |
| 792 | Emergency Tactics (self aura) | 49 | Swiftcast (self aura) |

---

## 1. Settings defaults — authoritative

Two independent sources disagree; both are reported.

`ScholarSettingsData::.ctor` (`youshu.il.txt` 46734–46919) — field initialisers:

| Field | Default | IL evidence |
|---|---|---|
| 不上Dot阈值 | **3** | `IL_0001: ldc.i4.3` |
| 醒梦阈值 | **8000** | `IL_0008: ldc.i4 8000` |
| 群奶人数 | **2** | `IL_0013: ldc.i4.2` |
| 群减人数 | **2** | `IL_001a: ldc.i4.2` |
| 保留豆子数量 | **2** | `IL_0021: ldc.i4.2` |
| 绿帽阈值 | **60** | `IL_0028: ldc.i4.s 60` |
| 链子阈值 | **55** | `IL_0030: ldc.i4.s 55` |
| 活性法阈值 | **45** | `IL_0038: ldc.i4.s 45` |
| 回生法阈值 | **35** | `IL_0040: ldc.i4.s 35` |
| 低语阈值 | **70** | `IL_0048: ldc.i4.s 70` |
| 不屈阈值 | **70** | `IL_0050: ldc.i4.s 70` |
| 祥光阈值 | **70** | `IL_0058: ldc.i4.s 70` |
| 野战治疗阵阈值 | **35** | `IL_0060: ldc.i4.s 35` |
| 慰藉阈值 | **55** | `IL_0068: ldc.i4.s 55` |
| 变身阈值 | **40** | `IL_0070: ldc.i4.s 40` |
| 单盾阈值 | **45** | `IL_0078: ldc.i4.s 45` |
| 群盾阈值 | **55** | `IL_0080: ldc.i4.s 55` |
| 应急战术阈值 | **35** | `IL_0088: ldc.i4.s 35` |
| GCD群奶阈值 | **50** | `IL_0090: ldc.i4.s 50` |
| GCD单奶阈值 | **45** | `IL_0098: ldc.i4.s 45` |
| 预读时间 | **1500** | `IL_00a0: ldc.i4 1500` |
| 倒计时召唤延迟 | **18000** | `IL_00ab: ldc.i4 18000` |
| 复活延迟 | **1** | `IL_00b6: ldc.i4.1` |
| 智能扩散盾目标索引 | **1** | `IL_00bd: ldc.i4.1` |
| 煤球走位 | **true** | `IL_00c4: ldc.i4.1` |
| 倒计时召唤 | **true** | `IL_00cb: ldc.i4.1` |
| 智能扩散盾_回生法 | **true** | `IL_00d2: ldc.i4.1` |
| 智能扩散盾_即刻咏唱 | **true** | `IL_00d9: ldc.i4.1` |
| 优先复活TN | **true** | `IL_00e0: ldc.i4.1` |
| 自动切换最优目标 | **true** | `IL_00e7: ldc.i4.1` |
| 单奶限制坦克 | **true** | `IL_00ee: ldc.i4.1` |
| 罩子优先场中 | **true** | `IL_00f5: ldc.i4.1` |
| 罩子优先自己 | **true** | `IL_00fc: ldc.i4.1` |
| ShowDevTest | **true** | `IL_0103: ldc.i4.1` |
| ShowQt | **true** | `IL_010a: ldc.i4.1` |
| ShowHotkey | **true** | `IL_0111: ldc.i4.1` |
| 切换模式自动隐藏QT | **true** | `IL_0118: ldc.i4.1` |
| 复活提醒频道列表 | **`["/p "]`** | `IL_01f5: ldstr "/p "` |
| 当前自定义模式名称 | **`String.Empty`** | `IL_020c: ldsfld System.String::Empty` |
| 治疗模式, 高难模式, 消散阈值, 单奶限制奶妈, 单奶限制输出, 罩子优先目标位置, 罩子开挂模式, 智能AOE目标, 过路圣人模式, Opener, ResetQtOnBattleEnd, 接入MacroRedirection | **no initialiser in this ctor** | default `0`/`false` from the CLR |

`ScholarSettingsData::EnsureDefaults` (`youshu.il.txt` 46569): migrates a legacy `消耗豆子数量` (`Nullable<int>`): if it `HasValue`, then `保留豆子数量 = Math.Clamp(value, 0, 3)` — `IL_0019: ldc.i4.0`, `IL_001a: ldc.i4.3`, `IL_001b: call Math::Clamp` — and the nullable is cleared (`initobj Nullable<int>`).

### `ScholarSettingsUI::ApplyDefaultPreset` (52897) — the "默认" preset button

It passes 20 literals positionally to `ScholarSettingsUI::ApplySettings` (52969). The parameter **names** in the decompiled signature are unreliable (e.g. arg 5 is named `feyIllumination` but is stored into `绿帽阈值`, and arg 13 named `seraphism` is stored into `慰藉阈值`). The **field stores** are authoritative:

| arg | Field stored (from `ApplySettings` IL) | ApplyDefaultPreset | ApplyConservativePreset | ApplyOutputPreset |
|---|---|---|---|---|
| 0 | 治疗模式 | 0 | 1 | 2 |
| 1 | 高难模式 | 0 | 0 | 0 |
| 2 | 醒梦阈值 | 8000 | 8000 | 8000 |
| 3 | 群奶人数 | 2 | 2 | **3** |
| 4 | 群减人数 | 2 | 2 | 2 |
| 5 | 绿帽阈值 | 60 | 60 | 60 |
| 6 | 链子阈值 | 55 | 55 | 55 |
| 7 | 活性法阈值 | 45 | 50 | 40 |
| 8 | 回生法阈值 | 35 | 40 | 30 |
| 9 | 低语阈值 | 70 | 70 | 65 |
| 10 | 不屈阈值 | **65** | 75 | 70 |
| 11 | 祥光阈值 | 70 | 75 | 65 |
| 12 | 野战治疗阵阈值 | 35 | 45 | 35 |
| 13 | 慰藉阈值 | 55 | 60 | 55 |
| 14 | 变身阈值 | 40 | 45 | 35 |
| 15 | 单盾阈值 | 45 | 50 | 40 |
| 16 | 群盾阈值 | 55 | 60 | 50 |
| 17 | 应急战术阈值 | 35 | 35 | 35 |
| 18 | GCD群奶阈值 | 50 | 60 | 40 |
| 19 | GCD单奶阈值 | 45 | 50 | 35 |

> **Discrepancy — flag for reimplementation.** `不屈阈值` default is **70** in `ScholarSettingsData::.ctor` (`IL_0050: ldc.i4.s 70`) but **65** in `ApplyDefaultPreset` (`IL_0013: ldc.i4.s 65`). Every other field agrees between the two sources. A fresh settings file uses 70; pressing the default preset button overwrites it with 65.

`ScholarSettingControls::SaveCustomHealingMode` (53098) sets `治疗模式 = 3` (`IL_0005: ldc.i4.3`) and saves.

---

## 2. Resolver order — `Strategy.学者技能策略::.cctor`

`youshu.core.txt` 33291–33430 (34 entries), constants recovered from `youshu.il.txt` 58668+.
`IL_0000: ldc.i4.s 34` sizes the list. Each entry is `SlotResolverData(resolver, int)`.

| # | Class | 2nd ctor int | Skill |
|---|---|---|---|
| 0 | `ACR.Tool.Resolvers.HealerPotionResolver` | 2 | potion |
| 1 | `Strategy.过路圣人复活` | 1 | raise (passer-by) |
| 2 | `Strategy.复生` | 1 | raise |
| 3 | `绝亚康复` | 1 | Esuna (Temporal Stasis) |
| 4 | `自动减伤` | 0 | auto mitigation |
| 5 | `康复` | 1 | Esuna |
| 6 | `意气轩昂之策` | 1 | Succor 186 / 37016 |
| 7 | `炽天附体` | 2 | Seraphism 37014 |
| 8 | `野战治疗阵` | 2 | Sacred Soil 188 |
| 9 | `异想的幻光` | 2 | Fey Illumination 16538 |
| 10 | `慰藉` | 2 | Consolation 16546 / Summon Seraph 16545 |
| 11 | `异想的祥光` | 2 | Fey Blessing 16543 |
| 12 | `仙光的低语` | 2 | Whispering Dawn 16537 |
| 13 | `不屈不挠之策` | 2 | Indomitability 3583 / Recitation 16542 |
| 14 | `鼓舞激励之策` | 1 | Adloquium 185 / 37015 |
| 15 | `医术` | 1 | Physick 190 |
| 16 | `深谋远虑之策` | 2 | Excogitation 7434 / Recitation 16542 |
| 17 | `以太契约` | 2 | Aetherpact 7437 / Fey Union 7869 |
| 18 | `生命活性法` | 2 | Lustrate 189 |
| 19 | `生命回生法` | 2 | Protraction 25867 |
| 20 | `朝日召唤` | 1 | Summon Eos 17215 |
| 21 | `醒梦` | 2 | Lucid Dreaming 7562 |
| 22 | `转化` | 2 | Dissipation 3587 |
| 23 | `以太超流` | 2 | Aetherflow 166 |
| 24 | `能量吸收` | 2 | Energy Drain 167 |
| 25 | `连环计` | 2 | Chain Stratagem 7436 |
| 26 | `埋伏之毒` | 2 | Baneful Impaction 37012 |
| 27 | `双DOT` | 1 | Biolysis (2 targets) |
| 28 | `DOT` | 1 | Biolysis 17864 |
| 29 | `即刻极炎法` | 1 | Swiftcast 7561 + filler |
| 30 | `裂阵法` | 1 | Art of War 16539 |
| 31 | `毁坏` | 1 | Ruin 17870 |
| 32 | `移动走位即刻极炎法` | 1 | Swiftcast 7561 + filler |
| 33 | `极炎法` | 1 | Broil filler |

Evidence for the index↔entry pairing: `Span::get_Item` is preceded by `IL_0019: ldc.i4.0`, `IL_004d: ldc.i4.1`, `IL_0061: ldc.i4.2` … `IL_02e5: ldc.i4.s 33`, in the same order as the `newobj <Resolver>::.ctor` instructions at `IL_003f, 0053, 0067, 007b, 008f, 00a3, 00b7, 00cb, 00df, 00f4, 0109, 011e, 0133, 0148, 015d, 0172, 0187, 019c, 01b1, 01c6, 01db, 01f0, 0205, 021a, 022f, 0244, 0259, 026e, 0283, 0298, 02ad, 02c2, 02d7, 02ec`. The trailing ints are `2,1,1,1,0,1,1,2,2,2,2,2,2,2,1,1,2,2,2,2,1,2,2,2,2,2,2,1,1,1,1,1,1,1`.

**Not in the ordering list** (so no index): `ScholarResolverBase` (abstract base), `Strategy.学者奶满策略` (a `ISlotSequence`, registered separately via `Rotation::AddSlotSequences`), `Strategy.学者技能策略` (owns the list), and all 4 `Openers` (driven by `CountDownHandler`, not the resolver list).

---

## 3. Master table — one row per skill

`idx` = position in the ordering list above. "Guard" lists the *negative* guards in the order the IL tests them. Codes are the `Check()` return values.

| Class | idx | Action IDs | Settings fields (default) | Other literals | Negative guards, in IL order | Terminal outcomes |
|---|---|---|---|---|---|---|
| `不屈不挠之策` | 13 | 3583; 16542 | 不屈阈值 (70), 群奶人数 (2) | 20 (%hp arg), Clamp(群奶人数, **0**, **8**), aura 1896 | Stop → -999; QT 奶人/群奶/不屈 → -100; silence → -1; `CanUseOffGcd(2)` → -4; count < Clamp(群奶人数,0,8) → -2; `!IsReady(3583)` → -200; QT 秘策 + `!IsReady(16542)` → skip | 3583 set → 0; 16542 set → 5; fallthrough → -8 |
| `仙光的低语` | 12 | 16537 | 低语阈值 (70), 群奶人数 (2) | 20.0f range, Clamp(群奶人数,0,8), aura 315, aura 791, 2000 ms, 3000 ms | Stop → -999; QT 奶人/群奶/低语 → -100; silence → -1; `CanUseOffGcd(2)` → -4; self aura 315 → -8; count < Clamp(群奶人数,0,8) → -2; self aura 791 → -5; `!HasFairy` → -3; `SpellRecentlyUsed(16537, 2000)` → -4; `IsSeraphEndingSoon(3000)` → -5; `!IsReady(16537)` → -200 | ready → 0 |
| `以太契约` | 17 | 7437; 7869 | 链子阈值 (55) | 0.95f hp, 16545/23000 ms, gauge > 0 | Stop → -999; QT 奶人+以太契约 → -100; silence → -1; `CanUseOffGcd(2)` → -4; link target hp ≥ 0.95 → -200 (queues 7869 if ready); else -2; `RecentlyUsed(16545, 23000)` → -3; `!HasFairy` → -3; `AetherpactTarget(...)==null` → -200; `FairyGauge <= 0` → -2; `!IsReady(7437)` → -200 | ready → 0 |
| `以太超流` | 23 | 166; 3587; 67212(quest) | — | 1500 ms, 15000 ms, 16545/22000 ms | Stop → -999; QT 以太超流 → -100; silence → -1; `CanUseOffGcd(2)` → -4; `SpellRecentlyUsed(3587,1500)` → -8; `!IsReady(166)` → -200; stacks ≤ **0** && battle ≤ **15000** ms → -30; QT 能量吸收 → -30; QT 转化 && IsReady(3587) && quest 67212 complete && `!SpellRecentlyUsed(16545,22000)` → -4 | ready → 0 |
| `埋伏之毒` | 26 | 37012 | 高难模式 (0), 智能AOE目标 (0) | aura 3882, 5000 ms, 25 yd, 20, 50, -10, -30 | Stop → -999; QT 埋伏之毒 → -100; `!IsReady(37012)` → -200; silence → -1; target null / `HasAttackBlock` / `IsDying` → -1; `CanUseOffGcd(1)` → **UNKNOWN (absent)**; self aura 3882 → -1; `GCDHelper::CanUseOffGcd` → -8; `!InCombat` → -1; `!高难模式 && ShouldHoldBurstForDyingTrash` → -10; QT 攒爆发 && !QT 倾泻资源 → -30; QT 倾泻资源 → 50; smart-AOE select with radius 25, needs ≥ 20 nearby enemies (radius 25) → 20 | target chosen → 0 |
| `异想的幻光` | 9 | 16538 | 应急战术阈值 (35), 群奶人数 (2) | Clamp(应急战术阈值, **0**, **100**), Clamp(群奶人数, **0**, **8**), aura 791, 3000 ms | Stop → -999; QT 奶人+幻光 → -100; silence → -1; `CanUseOffGcd(2)` → -4; `!IsReady(16538)` → -200; self aura 791 → -3; `!HasFairy` → -3; `IsSeraphEndingSoon(3000)` → -5; low-HP-within-20 count < Clamp(群奶人数,0,8) → -2 | count ≥ → 10 |
| `异想的祥光` | 11 | 16543 | 祥光阈值 (70), 群奶人数 (2) | 20.0f range, Clamp(群奶人数,0,8), aura 791, 3000 ms | Stop → -999; QT 奶人+祥光 → -100; silence → -1; `CanUseOffGcd(2)` → -4; self aura 791 → -3; `!HasFairy` → -3; count < Clamp(群奶人数,0,8) → -2; `IsSeraphEndingSoon(3000)` → -3; `!IsReady(16543)` → -200 | ready → 0 |
| `慰藉` | 10 | 16546; 16545 | 慰藉阈值 (55), 群奶人数 (2) | 30.0f range, Clamp(群奶人数,0,8), 3000 ms, aura 791, charges ≥ 1 | Stop → -999; QT 奶人/慰藉/大天使 → -100; silence → -1; `CanUseOffGcd(2)` → -4; self aura 791 → -3; `!IsUnlock(16546)` → -200; `!IsUnlock(16545)` → -200; count < Clamp(群奶人数,0,8) → -2; `IsSeraphActive && Charges <= 0` → -200; `!IsReady(cached)` → -12 (or -200 for 16545) | 16546 → 1; 16545 → 2 |
| `深谋远虑之策` | 16 | 7434; 16542 | 绿帽阈值 (60) | 2500 ms, aura 1896, aura 1220 | Stop → -999; QT 奶人/单奶/绿帽 → -100; silence → -1; `CanUseOffGcd(2)` → -4; `RecentlyUsed(7434, 2500)` → -3; `ExcogitationTarget(绿帽阈值, QT 单奶限制)==null` → -200; `!IsReady(7434)` → -200; QT 秘策 && `!IsReady(16542)` → skip | 7434 set → 20; 16542 set → 5; fallthrough → -2 |
| `炽天附体` | 7 | 37014 | 变身阈值 (40), 群奶人数 (2) | Clamp(变身阈值, **0**, **100**), Clamp(群奶人数,0,8), aura 791, 16545/22000 ms | Stop → -999; QT 奶人+变身 → -100; silence → -1; `CanUseOffGcd(2)` → -4; self aura 791 → -3; `RecentlyUsed(16545, 22000)` → -5; count < Clamp(群奶人数,0,8) → -2; `!HasFairy` → -3; `!IsReady(37014)` → -200 | ready → 0 |
| `生命回生法` | 19 | 25867 | 回生法阈值 (35) | — | Stop → -999; QT 奶人/单奶/回生法 → -100; silence → -1; `CanUseOffGcd(2)` → -4; `ProtractionTarget(...)==null` → -200; `!IsReady(25867)` → -200 | ready → 0 |
| `生命活性法` | 18 | 189 | 活性法阈值 (45) | 2500 ms, aura 1896, aura 1220 | Stop → -999; QT 奶人/单奶/活性法 → -100; silence → -1; `CanUseOffGcd(2)` → -4; `RecentlyUsed(189, 2500)` → -3; `!IsReady(189)` → -200; `LustrateTarget(...)==null` → -200; QT 绿帽 && (excog ready or target has aura 1220) → -2; `!HasAetherflow` → -2; `!CanSpendAetherflow && !self aura 1896` → -2 | ready → 0 |
| `能量吸收` | 24 | 167 | 醒梦阈值 (8000), 保留豆子数量 (2) | 3301 ms, 4, Clamp(保留豆子数量, **0**, **3**), double.MaxValue | Stop → -999; QT 能量吸收 → -100; silence → **UNKNOWN (absent)**; `!IsReady(167)` → -200; `CanUseOffGcd(2)` → -4; `CurrBattleTimeInMs <= 3301` → -3; target null / `!IsValid` / `IsDying` → -4; `AetherflowStacks <= 0` → -2; cooldown-vs-GCD comparison using **4** and `double.MaxValue` → 1; QT 消耗豆子 && stacks ≤ Clamp(保留豆子数量,0,3) → -2; cooldown == MaxValue → -2; `!CanSpendAetherflow` → -5; `CurrentMp < 醒梦阈值` → -1; else → -2 | as listed |
| `自动减伤` | 4 | 188; 16538; 25868; 16546; 16545; 3585; 185; 186; 16542; 7561 | 群减人数, 罩子优先目标位置, 罩子优先场中, 罩子开挂模式, 智能扩散盾_即刻咏唱 (true) | 10000 ms, 30, 15.0f, 5000 ms, 20, 1000 MP, 6000 ms lock, 3000 ms lock, aura 2711/3000 ms, 3000 ms | Stop → -999; QT 奶人+减伤 → -100; silence → -1; `HasBossCastingAoeWithin(10000)` → -1; only proceeds when `CountAlivePartyMembersInRangePlusSelf(30) >= 群减人数`; `CanUseOffGcd(2)` → -4 | queue list driven |
| `转化` | 22 | 3587 | — | 16545/22000 ms | Stop → -999; QT 转化 → -100; silence → -1; `CanUseOffGcd(2)` → -4; `AetherflowStacks <= 1` → -2; `RecentlyUsed(16545, 22000)` → -3; `!HasFairy` → -3; `!IsReady(3587)` → -200 | ready → 0 |
| `连环计` | 25 | 7436 | 高难模式 (0), 连环计限制 | 5000 ms, aura 1221, party count **4** | Stop → -999; QT 连环计 → -100; silence → -1; target null / `HasAttackBlock` / `IsDying` → -1; `CanUseOffGcd(2)` → -4; `CurrBattleTimeInMs <= 5000` → -9; `!CanAttack` → -200; target aura 1221 → -2; `!IsReady(7436)` → -200; `!高难模式 && ShouldHoldBurstForDyingTrash` → -10; QT 攒爆发 && !QT 倾泻资源 → -30; QT 倾泻资源 → 50 | → 0 |
| `醒梦` | 21 | 7562 | 醒梦阈值 (8000) | level 14 | Stop → -999; `IsCasting` → -1; level < 14 → -3; `CanUseOffGcd(1)` → -4; `CurrentMp > 醒梦阈值` → -3; silence → -1; `!IsReady(7562)` → -2 | → 0 |
| `野战治疗阵` | 8 | 188 | 野战治疗阵阈值 (35), 群奶人数 (2), 罩子优先目标位置, 罩子优先场中, 罩子开挂模式 | Clamp(野战治疗阵阈值, **0**, **100**), Clamp(群奶人数,0,8), **20**, 15.0f | Stop → -999; QT 奶人 → -100; silence → -1; `CanUseOffGcd(2)` → -4; `!HasAetherflow` → -3; count < Clamp(群奶人数,0,8) → -2; `!IsReady(188)` → -200 | → 0 |
| `DOT` | 28 | 17864 | DOT走位, DOT走位延迟时间 | 25 yd, 3000 ms, aura 167, -20/-21/30/35/40/45/50 | Stop → -999; QT DOT → -8; silence → -1; target null / `!IsValid` / `HasAttackBlock` → -1; `!IsReady(17864)` → -3; `IsBlackList` → -10; `ShouldSkipSingleTargetDot` → -1; 25 yd out-of-range/dead → -200; `HasScholarDot && HasRecentlyApplied` → -1; `HasScholarDotRemaining(3000)` → -1; moving + aura 167 → -20; `MoveStartTimeMs <= DOT走位延迟时间` → -21 | 45/30/35/40/50 |
| `医术` | 15 | 190 | GCD单奶阈值 (45), 单奶限制坦克/奶妈/输出 (true/0/0) | level 30, aura 167, 7, 30.0f, 100.0f, 0.0f, 1.0f, 10, 0.2f, 20 | Stop → -999; level < 30 → -3; QT 奶人/单奶 → -100; silence → -1; `IsMovementBlockingCast(190)` → -8; `HasAura(167) && HasDeadAllyWithoutRaise` → -9; target null / `!CanReceiveHeal` → -6; distance > 30 → -6; hp < threshold → -6; `!IsReady(190)` → -200 | → 20 |
| `即刻极炎法` | 29 | 7561; filler | — | aura 49, 3000 ms, 400 MP, 25 yd, 2.5f, 15 | Stop → -999; QT 即刻极炎法 → -100; `!HasAura(49)` → -100; `BuffTimeLessThan(49, 3000)` → -100; `HasDeadAllyWithoutRaise` → -1; `CurrentMp < 400` → -2; silence → -1; target null / `HasAttackBlock` → -1; distance > min(25, AttackRange+2.5) → -2; `IsDying` → -2; `!IsReady(7561)` → -9; `!filler.IsReadyWithCanCast` → -200 | → 15 |
| `双DOT` | 27 | inherited | 不上Dot阈值 (3) | `Cap = 100.0f` | `StopRequested()` = `GetQt("停手")`; `DotEnabled()` = `GetQt("DOT")`; `DoubleDotEnabled()` = `GetQt("双DOT")`; `CanDot(enemy)` = `HealerDoubleDotResolverBase::CommonCanDot(enemy, 100)` with minHpRatio passed as `Math.Clamp(不上Dot阈值, 0, 100)` | delegates to base |
| `康复` | 5 | 7568 | H1 | — | Stop → -999; QT 自动康复 → -100; silence → -1; `!IsReady()` → -200; `SelectGeneralTarget(H1)==null` → -7 | → 10 |
| `意气轩昂之策` | 6 | 186/37016; 3586; 16542 | 群奶人数 (2), 应急战术阈值 (35), 群盾阈值 (55) | Clamp(群奶人数,0,8)@`IL_008a/008b`=`0,8`; Clamp(应急战术阈值, **10**, **100**)@`IL_00ac/00af/00b0`; aura 3884, 792; 1000 MP; 3001 ms | Stop → -999; QT 奶人/减伤/群盾 → -100; silence → -1; `IsMovementBlockingCast(186 or 37016)` → -8; `CurrentMp < 1000` → -9; `CountLowEffectiveHpPartyMembersWithin20 < Clamp(应急战术阈值,10,100)` → -6; `CountNeededGroupShieldsWithin20 < 群盾阈值` → -6; `RecentlyUsed(3001)` → -8; `!IsReadyWithCanCast` → -200 | 3/4/6/10 |
| `朝日召唤` | 20 | 17215 | — | aura 791, 16545/24000 ms, 3587/32000 ms | Stop → -999; QT 自动召唤 → -100; silence → -1; `HasFairy` → -7; self aura 791 → -7; `SpellRecentlyUsed(16545, 24000)` → -8; `SpellRecentlyUsed(3587, 32000)` → -8; `IsMovementBlockingCast(17215)` → -2; `!IsReady(17215)` → -200 | → 1 |
| `极炎法` | 33 | filler | — | 400 MP, 25 yd, 2.5f, level 46/82, 2/3/5, 5 | Stop → -999; silence → -1; target null / `HasAttackBlock` → -1; distance > min(25, AttackRange+2.5) → -2; `IsDying` → -2; `CurrentMp < 400` → -9; level 46 ≤ lvl < 82 && nearby-enemies < 3 → -2 (values `2`,`3`,`5`,`5` at `IL_009a–00a5`); `IsMovementBlockingCast` → -3; `!IsReadyWithCanCast` → -200 | → 1 or 2 |
| `毁坏` | 31 | 17870 | 煤球走位 (true), 煤球走位延迟时间 | 400 MP, 25 yd, 2.5f, level 38, 64, 5.0f, 5, 2 | Stop → -999; silence → -1; target null / `HasAttackBlock` → -1; distance > min(25, AttackRange+2.5) → -2; `IsDying` → -2; `CurrentMp < 400` → -9; level < 38 → -3; moving-time ≥ 64 ms → -3; `!target` → -2; `!IsReady(17870)` → -200 | → 0 or 1 |
| `移动走位即刻极炎法` | 32 | 7561; filler | 即刻咏唱延迟时间 | 400 MP, 25 yd, 2.5f, 3000 ms, aura 49, 15 | Stop → -999; QT 即刻走位 → -100; not moving → -100; `HasDeadAllyWithoutRaise` → -1; `CurrentMp < 400` → -2; silence → -1; target null / `HasAttackBlock` → -1; distance > min(25, AttackRange+2.5) → -2; `IsDying` → -2; `!IsReady(7561)` → -3; `BuffTimeLessThan(49, 3000)` → -7; move-delay not elapsed → -9; `!IsReadyWithCanCast` → -200 | → 15 |
| `绝亚康复` | 3 | 7568 | H1 | territory **887** | territory ≠ 887 → -100; QT 自动康复 → -100; `!IsReady()` → -200; `!HasAnyDispelTargetWithin30()` → -7; `SelectTemporalStasisTarget(H1)==null` → -7 | → 1 |
| `裂阵法` | 30 | 16539 | — | level 46, 82; territories 293, 296, 1046; 1000 MP; auras 43, 44; 5, 5 | Stop → -999; QT AOE → -100; silence → -1; target null / `HasAttackBlock` → -1; `level < 46` → -999; territory ∈ {293,296,1046} → -999; `!IsReady(7562)` → -200; `CurrentMp < 1000` → -999; `HasAura(43) || HasAura(44)` → -999; `!IsReady(16539)` → -200; no nearby enemies → -200; level < 82 → -999; moving → -1 | 0/1/2/3 |
| `鼓舞激励之策` | 14 | 185/37015 | 单盾阈值 (45) | — | Stop → -999; QT 奶人/单盾 → -100; silence → -1; `IsMovementBlockingCast(185 or 37015)` → -8; `CurrentMp < 1000` → -9; tankbuster branch needs `HasBossCastingTankbusterWithin(10000)`; `!IsReadyWithCanCast` → -200; `ShieldTarget==null` → -6; `HasScholarShield(target)` → -7; `!IsReadyWithCanCast` → -200 | 2 or 10 |

---

## 4. Per-class conditions in exact IL order

### 4.1 `ACR.Scholar.Resolvers.ScholarResolverBase` — base, no index

```
:: static bool StopRequested()      -> ScholarQT::GetQt("停手")
:: static bool CanSpendAetherflow() -> !GetQt("保留豆子") ? true : ScholarTools::CanSpendAetherflow()
:: void .ctor()                     -> HealerResolverBase::.ctor
```
Recovered: `IL_0000: ldstr "保留豆子"` … `IL_0012: ldc.i4.1`, `IL_0013: ret`. **[IL]**

### 4.2 `不屈不挠之策` — idx 13 — Indomitability

1. `StopRequested()` → **-999** (`IL_000e: ldc.i4 -999`)
2. `!GetQt("奶人") || !GetQt("群奶") || !GetQt("不屈")` → **-100** (`IL_0038: ldc.i4.s -100`, `ldstr` ×3 at `IL_0014/0020/002c`)
3. `HasSkillSilenceStatus()` → **-1** (`IL_004d: ldc.i4.m1`)
4. `!HealerResolverBase::CanUseOffGcd(2)` → **-4** (`IL_003b: ldc.i4.2`, `IL_0043: ldc.i4.s -4`)
5. `ScholarTools::CountLowEffectiveHpPartyMembersNearSelf(不屈阈值, 20) < Math.Clamp(群奶人数, 0, 8)` → **-2** (`IL_0059: ldc.i4.s 20`, `IL_006a: ldc.i4.0`, `IL_006b: ldc.i4.8`, `IL_0073: ldc.i4.s -2`)
6. `if (HasAetherflow() && CanSpendAetherflow())`: `!HealerActionHelper::IsReady(3583)` → **-200** (`IL_0084: ldc.i4 3583`, `IL_0091: ldc.i4 -200`); else `chosenActionId = 3583` (`IL_0098: ldc.i4 3583`), return **0** (`IL_00a2: ldc.i4.0`)
7. `if (Me.HasAura(1896) && IsReady(3583))`: `chosenActionId = 3583`, return **0** (`IL_00a9: ldc.i4 1896`)
8. `if (GetQt("秘策") && IsReady(16542))`: `chosenActionId = 16542` (`IL_00ea: ldc.i4 16542`), return **5** (`IL_00f4: ldc.i4.5`)
9. fallthrough → **-8** (`IL_00f6: ldc.i4.s -8`)

`Build`: if `chosenActionId == 16542` (`IL_0006`/`IL_000e: ldc.i4 16542`) add `Ability(16542).DontUseGcd()`; then always add `Ability(3583).DontUseGcd()` (`IL_0025: ldc.i4 3583`).

### 4.3 `仙光的低语` — idx 12 — Whispering Dawn (16537)

Stop -999 → QT(奶人,群奶,低语) -100 → silence **-1** → `CanUseOffGcd(2)` -4 → `Me.HasAura(315)` **-8** (`IL_004d: ldc.i4 315`, `IL_005a: ldc.i4.s -8`) → `CountLowHpAlliesNearFairy(低语阈值, 20.0f) < Clamp(群奶人数,0,8)` -2 (`IL_0067: ldc.r4 20`, `IL_007b: ldc.i4.0`, `IL_007c: ldc.i4.8`) → `Me.HasAura(791)` **-5** (`IL_008c: ldc.i4 791`) → `!HasFairy` **-3** → `SpellRecentlyUsed(16537, 2000)` **-4** (`IL_00a6: ldc.i4 16537`, `IL_00ab: ldc.i4 2000`) → `IsSeraphEndingSoon(3000)` **-5** (`IL_00ba: ldc.i4 3000`) → `!IsReady(16537)` **-200** → **0**.

### 4.4 `以太契约` — idx 17 — Aetherpact (7437) / Fey Union (7869)

Stop -999 → QT(奶人,以太契约) -100 → silence **-1** → `CanUseOffGcd(2)` -4 → linked-target block (`IL_0059: ldc.r4 0.95`): if `linked.CurrentHpPercent >= 0.95` then if `IsReady(7869)` (`IL_0060: ldc.i4 7869`) set `target = linked`, `shouldCancelLink = true`; return **-200**; else return **-2**. → `RecentlyUsed(16545, 23000)` **-3** (`IL_0086: ldc.i4 16545`, `IL_008b: ldc.i4 23000`) → `!HasFairy` **-3** → `target = AetherpactTarget(链子阈值, QT("单奶限制"))`; null → **-200** → `FairyGauge <= 0` **-2** (`IL_00d6: ldc.i4.0`, `IL_00d9: ldc.i4.s -2`) → `!IsReady(7437)` **-200** (`IL_00dc: ldc.i4 7437`) → **0**.
`Build`: if `shouldCancelLink` add `Ability(7869)`; if `target != null` add `Ability(7437, target)`.

### 4.5 `以太超流` — idx 23 — Aetherflow (166)

Stop -999 → QT(以太超流) -100 → silence **-1** → `CanUseOffGcd(2)` -4 → `SpellRecentlyUsed(3587, 1500)` **-8** (`IL_0030: ldc.i4 3587`, `IL_0035: ldc.i4 1500`) → `!IsReady(166)` -200 (`IL_0044: ldc.i4 166`) → `AetherflowStacks <= 0 && CurrBattleTimeInMs <= 15000` **-30** (`IL_006c: ldc.i4 15000`, `IL_0075: ldc.i4.0`, `IL_0078: ldc.i4.s -30`) → `GetQt("能量吸收")` **-30** → `if (Qt("转化") && IsReady(3587) && QuestManager::IsQuestComplete(67212) && !SpellRecentlyUsed(16545, 22000))` **-4** (`IL_00a7: ldc.i4 67212`, `IL_00b3/00b8`) → **0**.
`Build`: `Ability(166).DontUseGcd()`.

### 4.6 `埋伏之毒` — idx 26 — Baneful Impaction (37012)

Stop -999 → QT(埋伏之毒) -100 → `!IsReady(37012)` -200 → silence **-1** → target validity / `HasAttackBlock` / `IsDying` branches (`IL_0051: ldc.i4.m1`) → `CanUseOffGcd(1)` **-4** (`IL_0053: ldc.i4.1`) → `Me.HasAura(3882)` **-1** → `GCDHelper::CanUseOffGcd` **-8** → `!InCombat` **-1** → `!高难模式 && ShouldHoldBurstForDyingTrash()` **-10** → `Qt("攒爆发") && !Qt("倾泻资源")` **-30** → `Qt("倾泻资源")` **50**.
Smart-AOE: `if (智能AOE目标)` then `SelectCircularAoeTarget(25, cachedTarget)` (`IL_00de: ldc.i4.s 25`) and require `TargetHelper::GetNearbyEnemyCount(25) >= 20` (`IL_00f2: ldc.i4.s 25`, `IL_0104: ldc.i4.s 20`); then `!Me.HasMyAuraWithTimeleft(3882, 5000)` gates (`IL_010c: ldc.i4 3882`, `IL_0111: ldc.i4 5000`).
> **[gap]** The exact sense of the `CurrentTarget == null` branch at `IL_003f: brfalse.s IL_0053` cannot be trusted; the lossless dump shows the target of that branch is the `CanUseOffGcd(1)` continuation, which reads as "null target does *not* abort". Treat as **UNKNOWN**.

### 4.7 `异想的幻光` — idx 9 — Fey Illumination (16538)

Stop -999 → QT(奶人,幻光) -100 → silence **-1** → `CanUseOffGcd(2)` -4 → `!IsReady(16538)` -200 → `Me.HasAura(791)` **-3** → `!HasFairy` **-3** → `IsSeraphEndingSoon(3000)` **-5** → `CountLowEffectiveHpPartyMembersWithin20(Clamp(群奶人数,0,8)) < Clamp(应急战术阈值, 0, 100)` → **-2**, else **10**.
Constants recovered: `IL_0087: ldc.i4.0`, `IL_0088: ldc.i4.s 100` (Clamp bounds for 应急战术阈值), `IL_0099: ldc.i4.0`, `IL_009a: ldc.i4.8` (Clamp bounds for 群奶人数), `IL_00a9: ldc.i4.m1` (the `<` result path), `IL_00ab: ldc.i4.s 10`.
> **[gap]** The operand order at `IL_008a: call Math::Clamp` puts `群奶人数` as the *argument* to `CountLowEffectiveHpPartyMembersWithin20` and `Clamp(应急战术阈值,·,100)` as the left operand of the comparison. Whether `群奶人数` is semantically the HP-percent argument or an argument-exchange artifact of the decompiler is **UNKNOWN**; both fields are involved with the values shown.

### 4.8 `异想的祥光` — idx 11 — Fey Blessing (16543)

Stop -999 → QT(奶人,祥光) -100 → silence -1 → `CanUseOffGcd(2)` -4 → `Me.HasAura(791)` **-3** → `!HasFairy` **-3** → `CountLowHpAlliesNearFairy(祥光阈值, 20.0f) < Clamp(群奶人数,0,8)` -2 (`IL_0065: ldc.r4 20`, `IL_0079: ldc.i4.0`, `IL_007a: ldc.i4.8`) → `IsSeraphEndingSoon(3000)` **-3** (`IL_0085: ldc.i4 3000`) → `!IsReady(16543)` -200 → **0**.

### 4.9 `慰藉` — idx 10 — Consolation (16546) / Summon Seraph (16545)

Stop -999 → QT(奶人,慰藉,大天使) -100 → silence -1 → `CanUseOffGcd(2)` -4 → `Me.HasAura(791)` **-3** → `!Ability(16546).IsUnlock()` **-200** → `!Ability(16545).IsUnlock()` **-200** → `Charges(16546)`: if `IsSeraphEndingSoon(3000) && Charges > 1.0f` (`IL_009d: ldc.i4 3000`, `IL_00aa: ldc.r4 1`, `IL_00b2: ldc.i4 16546`) set `cachedActionId = 16546` → `CountLowHpAlliesNearFairy(慰藉阈值, 30.0f) < Clamp(群奶人数,0,8)` -2 (`IL_00c8: ldc.r4 30`, `IL_00dc: ldc.i4.0`, `IL_00dd: ldc.i4.8`) → `if (IsSeraphActive())`: if `Charges <= 0.0f` (`IL_00f2: ldc.r4 0`) → **-200**; set `cachedActionId = 16546` (`IL_0100`); `!IsReady(cachedActionId)` → **-12** (`IL_0118: ldc.i4.s -12`); else return **1** (`IL_011b: ldc.i4.1`). Else set `cachedActionId = 16545` (`IL_011e`); `!IsReady` → **-200**; else return **2** (`IL_013c: ldc.i4.2`).

### 4.10 `深谋远虑之策` — idx 16 — Excogitation (7434) / Recitation (16542)

Stop -999 → QT(奶人,单奶,绿帽) -100 → silence -1 → `CanUseOffGcd(2)` -4 → `RecentlyUsed(7434, 2500)` **-3** (`IL_0056: ldc.i4 7434`, `IL_005b: ldc.i4 2500`) → `target = ExcogitationTarget(绿帽阈值, QT("单奶限制"))`; null → **-200** → `if (HasAetherflow() && CanSpendAetherflow())`: `!IsReady(7434)` → -200; `chosenActionId = 7434`; return **20** (`IL_00c3: ldc.i4.s 20`) → `if (Me.HasAura(1896) && IsReady(7434))` (`IL_00cb: ldc.i4 1896`) `chosenActionId = 7434`; return **20** → `if (Qt("秘策") && IsReady(16542))` `chosenActionId = 16542`; return **5** (`IL_0117: ldc.i4.5`) → fallthrough **-2** (`IL_0119: ldc.i4.s -2`).
`Build`: if `target == null` (`IL_0008: brtrue.s IL_0009`) — note the decompiled guard; then if `chosenActionId == 16542` add `Ability(16542)`; add `Ability(7434, target)`.

### 4.11 `炽天附体` — idx 7 — Seraphism (37014)

Stop -999 → QT(奶人,变身) -100 → silence -1 → `CanUseOffGcd(2)` -4 → `Me.HasAura(791)` **-3** → `RecentlyUsed(16545, 22000)` **-5** (`IL_0051: ldc.i4 16545`, `IL_0056: ldc.i4 22000`) → `CountLowHpPartyMembers(Clamp(群奶人数,0,8)) < Clamp(变身阈值, 0, 100)` -2 (`IL_006f: ldc.i4.0`, `IL_0070: ldc.i4.s 100`, `IL_0081: ldc.i4.0`, `IL_0082: ldc.i4.8`) → `!HasFairy` **-3** → `!IsReady(37014)` -200 → **0**.

### 4.12 `生命回生法` — idx 19 — Protraction (25867)

Stop -999 → QT(奶人,单奶,回生法) -100 → silence -1 → `CanUseOffGcd(2)` -4 → `target = ProtractionTarget(回生法阈值, QT("单奶限制"))`; null → -200 → `!IsReady(25867)` -200 → **0**.

### 4.13 `生命活性法` — idx 18 — Lustrate (189)

Stop -999 → QT(奶人,单奶,活性法) -100 → silence -1 → `CanUseOffGcd(2)` -4 → `RecentlyUsed(189, 2500)` **-3** (`IL_004f: ldc.i4 189`, `IL_0054: ldc.i4 2500`) → `!IsReady(189)` -200 → `target = LustrateTarget(活性法阈值, QT("单奶限制"))`; null → -200 → `if (Qt("绿帽"))` (`IL_00a3: ldstr "绿帽"`): `if (HasAetherflow() || Me.HasAura(1896)) { if (IsReady(7434)) return -2 } else if (target.HasAura(1220)) return -2` (`IL_00bb: ldc.i4 1896`, `IL_00c8: ldc.i4 7434`, `IL_00db: ldc.i4 1220`) → `!HasAetherflow` **-2** → `!CanSpendAetherflow && !Me.HasAura(1896)` **-2** (`IL_0107: ldc.i4 1896`) → **0**.

### 4.14 `能量吸收` — idx 24 — Energy Drain (167)

Stop -999 → QT(能量吸收) -100 → silence **UNKNOWN** → `!IsReady(167)` -200 (`IL_0025: ldc.i4 167`) → `CanUseOffGcd(2)` -4 (`IL_0038: ldc.i4.2`) → `CurrBattleTimeInMs <= 3301` **-3** (`IL_0052: ldc.i4 3301`) → target null / `!IsValid` / `IsDying` **-4** (`IL_0076: ldc.i4.s -4`) → `AetherflowStacks <= 0` **-2** (`IL_0080: ldc.i4.0`) → cooldown gate: `NextAetherflowCooldown()` vs `GcdDurationMs()` with literal **4** (`IL_008c: ldc.i4.4`) and `double.MaxValue` (`IL_0099: ldc.r8 1.7976931348623157E+308`); a path returns **1** (`IL_00b2: ldc.i4.1`) → `GetQt("消耗豆子") && stacks <= Clamp(保留豆子数量, 0, 3)` **-2** (`IL_00c6: ldc.i4.0`, `IL_00c7: ldc.i4.3`) → cooldown == MaxValue (`IL_00d6`) **-2** → `!CanSpendAetherflow` **-5** (`IL_00eb: ldc.i4.s -5`) → `CurrentMp < 醒梦阈值` **-1** (`IL_0106: ldc.i4.m1`) → else **-2** (`IL_0108`).
`NextAetherflowCooldown()`: `if (!Qt("转化") || level < 60) → double.MaxValue` (`IL_0016: ldc.i4.s 60`, `IL_001a: ldc.r8 MaxValue`); else `Ability(3587).Cooldown.TotalMilliseconds` (`IL_0025: ldc.i4 3587`); then `min(that, Qt("以太超流") ? Ability(166).Cooldown.TotalMilliseconds : double.MaxValue)` (`IL_003c: ldstr "以太超流"`, `IL_0048: ldc.r8 MaxValue`, `IL_0053: ldc.i4 166`).
> **[gap]** The boolean composition of the `4` / `MaxValue` comparison (`IL_00a2: beq.s`, `IL_00a8: bgt.un.s`, `IL_00b0: bgt.un.s`) is not fully recoverable — the dump omits operand pushes. The literal **4** and `double.MaxValue` are proven; the exact predicate is not.

### 4.15 `自动减伤` — idx 4 — auto mitigation

`Check()`: clears `cachedSpells`; Stop -999 → QT(奶人,减伤) -100 → silence **-1** → `HasBossCastingAoeWithin(10000)` **-1** (`IL_003c: ldc.i4 10000`) → pending-mitigation block (`IL_0073: ldc.i4.2`, `IL_0087: ldc.i4.m1`) → `Environment.TickCount64 < mitigationLockUntil` → -1 → `CanUseOffGcd(2)`? (**UNKNOWN**, `IL_0089: ldc.i4.2`) → -4 (`IL_0091: ldc.i4.s -4`) → `CountAlivePartyMembersInRangePlusSelf(30) < 群减人数` → **-1** (`IL_0094: ldc.i4.s 30`) → `GetAoeMitigationSpells()`; empty → -1 (`IL_00c4: ldc.i4.0`).
`GetAoeMitigationSpells()` builds, in order: `BuildSacredSoil()` (188); `Ability(16538)`; `Ability(25868)`; `Ability(16546)`; `Ability(16545)`; gate `HasAetherflow() && CanSpendAetherflow()`; `Me.HasAura(1896)`; `SeraphTimeLeft`; `Charges(16546)`; `HasFairy()`; bubble = `IsUnlock(188) && Cooldown.TotalMilliseconds == 0` (`IL_006e: ldc.i4 188`, `IL_00a0: ldc.r8 0`); illumination = same for `16538` (`IL_00b0`, `IL_00de: ldc.r8 0`); expedient = `Qt("跑快快") && IsReady(25868) && !Me.HasMyAuraWithTimeleft(2711, 3000)` (`IL_00fa: ldc.i4 25868`, `IL_010c: ldc.i4 2711`, `IL_0111: ldc.i4 3000`); deployment = `DeploymentTarget() != null && IsReady(3585) && !HasScholarShield() && !RecentlyUsed(3585, 3000) && !RecentlyUsed(185, 3000) && TickCount64 >= deploymentLockUntil` (`IL_012e/0145: ldc.i4 3585`, `IL_014a: ldc.i4 3000`, `IL_0156: ldc.i4 185`, `IL_015b: ldc.i4 3000`); consolation = `Charges(16546) >= 1 && !RecentlyUsed(16546, 5000) && (seraph state ? IsReady(16545) : …)` (`IL_0182: ldc.i4 16546`, `IL_0187: ldc.i4 5000`, `IL_0198: ldc.i4 16545`); then `Succor` = `HasBossCastingAoeWithin(5000) && CountPartyMembersWithoutScholarShield(20) > 0 && CurrentMp > 1000 && IsUnlock(186)` (`IL_0416: ldc.i4 5000`, `IL_0422: ldc.i4.s 20`, `IL_0436: ldc.i4 1000`, `IL_043d: ldc.i4 186`).
`BuildSacredSoil()`: `target = CurrentTarget`; if `罩子优先目标位置 && target != null && target.IsValid && target.HitboxRadius < 15.0f` (`IL_0023: ldc.r4 15`) use it; else `HealerGroundTargetHelper::GroundCastPosition(罩子优先场中, 罩子开挂模式)`; `new Spell(188)` (`IL_004a: ldc.i4 188`).
`DeploymentTarget()`: first `PartyHelper::CastableTanks` with `CurrentHp > 0` (`IL_001b: ldc.i4.0`), `Me.Distance(tank) <= 30.0f` (`IL_002a: ldc.r4 30`), `CanReceiveHeal(tank)`; else `Me`.
`DeploymentSpells(target)`: if list empty and `Qt("秘策") && IsReady(16542)` add `Ability(16542)` (`IL_000f: ldstr "秘策"`, `IL_001b: ldc.i4 16542`); if still empty and `智能扩散盾_即刻咏唱 && IsReady(7561)` add `Ability(7561)` (`IL_004d: ldc.i4 7561`); if `IsUnlock(185) && CurrentMp > 1000` add `Gcd(185)` (`IL_006a: ldc.i4 185`, `IL_0086: ldc.i4 1000`); if `IsReady(3585)` add `Ability(3585)` (`IL_009e: ldc.i4 3585`).
`LockMitigation` sets `mitigationLockUntil = TickCount64 + 6000` (`IL_0005: ldc.i4 6000`). `LockDeployment` sets `deploymentLockUntil = TickCount64 + 3000` (`IL_0005: ldc.i4 3000`).
`IsSeraphConsolationPair(a,b)` = `(a==16545 && b==16546) || (a==16546 && b==16545)`.
`Build`: `limit = hasDeployment ? Min(count, count) : count`; if the list equals the Seraph+Consolation pair, add each non-188 spell; else add the first `limit` spells.

### 4.16 `转化` — idx 22 — Dissipation (3587)

Stop -999 → QT(转化) -100 → silence -1 → `CanUseOffGcd(2)` -4 → `AetherflowStacks <= 1` **-2** (`IL_0035: ldc.i4.1`, `IL_0038: ldc.i4.s -2`) → `RecentlyUsed(16545, 22000)` **-3** (`IL_003b: ldc.i4 16545`, `IL_0040: ldc.i4 22000`) → `!HasFairy` **-3** → `!IsReady(3587)` -200 → **0**.

### 4.17 `连环计` — idx 25 — Chain Stratagem (7436)

Stop -999 → QT(连环计) -100 → silence -1 → target null / `HasAttackBlock` / `IsDying` **-1** → `CanUseOffGcd(2)` -4 → `CurrBattleTimeInMs <= 5000` **-9** (`IL_0061: ldc.i4 5000`, `IL_0069: ldc.i4.s -9`) → `!CanAttack()` **-200** → target `HasAura(1221)` **-2** (`IL_0094: ldc.i4 1221`) → `!IsReady(7436)` -200 (`IL_00a4: ldc.i4 7436`) → `!高难模式 && ShouldHoldBurstForDyingTrash()` **-10** → `Qt("攒爆发") && !Qt("倾泻资源")` **-30** → `Qt("倾泻资源")` **50** → **0**.
`ShouldHoldForFourPlayerDuty()` = `连环计限制 && MemApiCondition::IsBoundByDuty() && !高难模式 && Party.Count == 4 && !IsInBossBattle() && CommonMapIds::IsDirectBossDungeon(GetCurrTerrId())`. Literals: `IL_0022: ldc.i4.1` (the negated 高难模式), `IL_002f: ldc.i4.4` (party count), `IL_0039/004a: ldc.i4.0`.

### 4.18 `醒梦` — idx 21 — Lucid Dreaming (7562)

Stop -999 → `Me.IsCasting` → **-1** (`IL_0019: ldc.i4.m1`) → `Me.Level < 14` **-3** (`IL_0025: ldc.i4.s 14`) → `CanUseOffGcd(1)` **-4** (`IL_002c: ldc.i4.1`) → `CurrentMp > 醒梦阈值` **-3** → silence **-1** (`IL_0059: ldc.i4.m1`) → `!IsReady(7562)` **-2** (`IL_005b: ldc.i4 7562`) → **0**.

### 4.19 `野战治疗阵` — idx 8 — Sacred Soil (188)

Stop -999 → QT(奶人) -100 → silence -1 → `CanUseOffGcd(2)` -4 → `!HasAetherflow` **-3** (`IL_0037: ldc.i4.s -3`) → `CountLowHpPartyMembersInRange(Clamp(群奶人数,0,8), 20) < Clamp(野战治疗阵阈值, 0, 100)` → **-2**, else **0**.
Constants: `IL_0044: ldc.i4.0`, `IL_0045: ldc.i4.s 100` (野战治疗阵阈值 Clamp bounds), `IL_0056: ldc.i4.2`, `IL_0058: ldc.i4.0`, `IL_0059: ldc.i4.8` (群奶人数 Clamp bounds — note an extra `ldc.i4.2` at `IL_0056`), `IL_0060: ldc.i4.s 20` (range), `IL_006a: ldc.i4.s -2`.
`Build` duplicates `BuildSacredSoil()` inline: `HitboxRadius < 15.0f` (`IL_0023: ldc.r4 15`), `new Spell(188)` (`IL_004b: ldc.i4 188`).

### 4.20 `DOT` — idx 28 — Biolysis (17864)

Stop -999 → QT(DOT) **-8** (`IL_0020: ldc.i4.s -8`) → silence **-1** (`IL_002a: ldc.i4.m1`) → target null / `!IsValid` / `HasAttackBlock` **-1** → `!IsReady(17864)` **-3** (`IL_0050: ldc.i4 17864`) → `DotBlacklistHelper::IsBlackList` **-10** (`IL_0068: ldc.i4.s -10`) → `ShouldSkipSingleTargetDot(target)` **-1** (`IL_0073: ldc.i4.m1`) → `IsOutOfAttackRangeOrDead(25.0f)` **-200** (`IL_0076: ldc.r4 25`) → `HasScholarDot(17864) == HasRecentlyApplied(17864, GetAdjustedActionId(17864))` (`IL_008f/0094` = `ldc.i4 17864` ×2, `IL_00a9: ldc.i4.0`) and `HasScholarDotRemaining(3000)` (`IL_00b1: ldc.i4 3000`) → **-1** (`IL_00bb: ldc.i4.0`, `IL_00c0: ldc.i4.0`).
Movement block: `IsMoving` (`IL_00ce: ldc.i4.1`) → `UpdateMovement`; `if (!DOT走位) → -1` (`IL_00fa: ldc.i4.0`); `Me.HasAura(167)` **-20** (`IL_00e5: ldc.i4 167`, `IL_00f2: ldc.i4.s -20`); `MoveStartTimeMs <= DOT走位延迟时间` **-21** (`IL_011a: ldc.i4.s -21`). Returns **45** (`IL_0120: ldc.i4.s 45`), **30** (`IL_0126`), **35** (`IL_0129`), **50** (`IL_0135: ldc.i4.s 50`), **-1** (`IL_013b: ldc.i4.m1`), **40** (`IL_013d: ldc.i4.s 40`).
`Build`: `Gcd(17864, cachedTarget)`; `HealerDotCastTracker::MarkPending(17864, cachedTarget)`.

### 4.21 `医术` — idx 15 — Physick (190)

Stop -999 → `Me.Level < 30` **-3** (`IL_001e: ldc.i4.s 30`) → QT(奶人,单奶) -100 → silence **-1** (`IL_0047: ldc.i4.m1`) → `IsMovementBlockingCast(190)` **-8** (`IL_0049: ldc.i4 190`) → `Me.HasAura(167) && HasDeadAllyWithoutRaise()` **-9** (`IL_005d: ldc.i4 167`) → `target = LowestHpHealTarget(QT("单奶限制"))`; null / `!CanReceiveHeal` **-6** (`IL_009e: ldc.i4.s -6`) → `Me.Distance(target) > 30.0f` **-6** (`IL_00b2: ldc.r4 30`) → hp threshold: if `target.IsTank` use `Clamp(GCD单奶阈值, 10, 100)` (`IL_00f7: ldc.i4.s 10`, `IL_00fb: ldc.r4 100`, `IL_0101: ldc.r4 0`, `IL_0106: ldc.r4 1`); else `Clamp(GCD单奶阈值, 100, 0, 1)` (`IL_00d6: ldc.r4 100`, `IL_00dc: ldc.r4 0`, `IL_00e1: ldc.r4 1`) — **note the boundary literals differ between the tank and non-tank branch**; then if `Me.Level < 30` clamp with `0.2f` (`IL_011b: ldc.i4.s 30`, `IL_0120: ldc.r4 0.2`) → `!NeedsLivingDeadHeal(target) && target.CurrentHpPercent >= threshold` **-6** (`IL_0151: ldc.i4.s -6`) → `IsReady(190, target)` false **-200** (`IL_0154: ldc.i4 190`) → **20** (`IL_016c: ldc.i4.s 20`).
`Build`: `Gcd(190, cachedTarget)`.

### 4.22 `即刻极炎法` — idx 29 — Swiftcast (7561) + filler

Stop -999 → QT(即刻极炎法) **-100** → `!Me.HasAura(49)` **-100** (`IL_0028: ldc.i4.s 49`) → `BuffTimeLessThan(49, 3000)` **-100** (`IL_0035`, `IL_0037: ldc.i4 3000`) → `HasDeadAllyWithoutRaise` **-1** (`IL_004d: ldc.i4.m1`) → `CurrentMp < 400` **-2** (`IL_0059: ldc.i4 400`) → silence **-1** (`IL_006a: ldc.i4.m1`) → target null / `HasAttackBlock` **-1** (`IL_007d`) → `Me.Distance > Min(25.0f, GeneralSettings.AttackRange + 2.5f)` **-2** (`IL_008b: ldc.r4 25`, `IL_009b: ldc.r4 2.5`) → `IsDying` **-2** → `!IsReady(7561)` **-9** (`IL_00b6: ldc.i4 7561`) → `filler = BroilFillerActionId()`; `!filler.IsReadyWithCanCast` **-200** → **15** (`IL_00ea: ldc.i4.s 15`).
`Build`: `Ability(7561).DontUseGcd()`; then `Gcd(fillerActionId).DontUseGcd()`.

### 4.23 `双DOT` — idx 27 — uses `HealerDoubleDotResolverBase`

```
StopRequested()      = GetQt("停手")        [IL_0000: ldstr "停手"]
DotEnabled()         = GetQt("DOT")         [IL_0000: ldstr "DOT"]
DoubleDotEnabled()   = GetQt("双DOT")       [IL_0000: ldstr "双DOT"]
CanDot(enemy)        = HealerDoubleDotResolverBase::CommonCanDot(enemy, Math.Clamp(不上Dot阈值, 0, 100))
                       [IL_000c: ldc.r4 100]
HasDot(enemy)        = ScholarTools::HasScholarDot(enemy)
HasDotRemaining(e,t) = ScholarTools::HasScholarDotRemaining(enemy, minTimeLeft)
.ctor                -> HealerDoubleDotResolverBase::.ctor
```
Base `Check()`: `StopRequested()` -999 → `!DotEnabled || !DoubleDotEnabled` -100 → silence → `CountTargets(now)`; `candidateCount < activeDotCount` -200 (`IL_004e`), `activeDotCount` gate, `SelectDotTarget(now)`, `IsReady(DotActionId, target)` → -3 else **35** (`IL_0085: ldc.i4.s 35`).
Base `Build`: `BeforeBuild(slot)`; `Gcd(DotActionId, target)`; `HealerDotCastTracker::MarkPending(DotActionId, target)`.
`CommonCanDot(enemy, minHpRatio)`: `enemy.IsValid && enemy.IsTargetable && Me.Distance(enemy) <= 25.0f + AttackRangeBonus() && !IsBlackList && !HasAttackBlock && !ShouldSkipDotByHp(enemy, minHpRatio, 12)`. Literals: `IL_001c: ldc.r4 25`, `IL_003b: ldc.i4.s 12`.
`HasDotPresence` uses `HasDotRemaining(enemy, 500)` (`IL_000c: ldc.i4 500`); `HasEnoughDotTime` uses `HasDotRemaining(enemy, 3000)` (`IL_000c: ldc.i4 3000`).

### 4.24 `康复` — idx 5 — Esuna (7568)

Stop -999 → QT(自动康复) -100 → silence **-1** (`IL_002a: ldc.i4.m1`) → `!IsReady()` **-200** (`IL_0033: ldc.i4 -200`) → `target = HealerEsunaTargetSelector::SelectGeneralTarget(H1)`; null **-7** (`IL_0056: ldc.i4.s -7`) → **10** (`IL_0059: ldc.i4.s 10`).
`IsReady()` = `Gcd(7568, true).IsReadyWithCanCast()` (`IL_0000: ldc.i4 7568`, `IL_0005: ldc.i4.1`). `Build`: `Gcd(7568, target)`.

### 4.25 `意气轩昂之策` — idx 6 — Succor (186 / 37016)

Stop -999 → QT(奶人,减伤,群盾) -100 → silence **-1** (`IL_0042: ldc.i4.m1`) → main = `Me.HasAura(3884) ? 37016 : 186` (`IL_0049: ldc.i4 3884`, `IL_0056: ldc.i4 186`, `IL_005d: ldc.i4 37016`); `IsMovementBlockingCast(main)` **-8** (`IL_0069: ldc.i4.s -8`) → `CurrentMp < 1000` **-9** (`IL_0076: ldc.i4 1000`) → `groupHealLimit = Clamp(群奶人数, 0, 8)` (`IL_008a: ldc.i4.0`, `IL_008b: ldc.i4.8`) → `emergency = CountLowEffectiveHpPartyMembersWithin20(Clamp(应急战术阈值, 10, 100))` (`IL_00ac: ldc.i4.s 10`, `IL_00b0: ldc.i4.s 100`) → `strict = CountLowEffectiveHpPartyMembersWithin20(应急战术阈值)` → `canQueueOffGcd = CanUseOffGcd(?)` (`IL_00bd: ldc.i4.2`) → `canUseEmergency = IsReady(3586, true)` (`IL_00c4: ldc.i4 3586`, `IL_00c9: ldc.i4.1`) → `!Me.HasAura(792)` (`IL_00d6: ldc.i4 792`) → `shouldGroupShield = …` combining `IL_00f1..00fd` = `ldc.i4.0, ldc.i4.1, ldc.i4.0, ldc.i4.1, ldc.i4.0`.
Then: `if (!shouldGroupShield)`: `CountExistingGroupShieldsWithin20() < 4` **-6** (`IL_0107: ldc.i4.4`) and `CountNeededGroupShieldsWithin20(群盾阈值) < 群盾阈值` **-6** (`IL_011f: ldc.i4.s -6`) → `!RecentlyUsed(3001)` gate (`IL_014d: ldc.i4 3001`) **-8** (`IL_0159: ldc.i4.s -8`) → `!main.IsReadyWithCanCast` **-200** (`IL_0165`) → `QueueIfReady(16542)` (`IL_0177: ldc.i4 16542`), `QueueIfReady(3586)` (`IL_0182: ldc.i4 3586`); else `QueueIfReady(3586)` (`IL_019a`).
`cachedSpellCount` recorded; `CountBleedingTargetsWithin20() < 10` (`IL_01c9: ldc.i4.s 10`) → returns **4** (`IL_01c6: ldc.i4.4`), **10** (`IL_01c9`), **0** (`IL_01d0`), **6** (`IL_01d2: ldc.i4.6`).
`QueueIfReady(actionId)`: if index < array length and `IsReady(actionId, true)` (`IL_0011: ldc.i4.1`) add `Ability(actionId, true)` (`IL_0029: ldc.i4.1`).
`.ctor`: array size **3** (`IL_0001: ldc.i4.3`).

### 4.26 `朝日召唤` — idx 20 — Summon Eos (17215)

Stop -999 → QT(自动召唤) -100 → silence **-1** → `HasFairy` **-7** (`IL_002c: ldc.i4.s -7`) → `Me.HasAura(791)` **-7** (`IL_0034: ldc.i4 791`) → `SpellRecentlyUsed(16545, 24000)` **-8** (`IL_0044: ldc.i4 16545`, `IL_0049: ldc.i4 24000`) → `SpellRecentlyUsed(3587, 32000)` **-8** (`IL_0058: ldc.i4 3587`, `IL_005d: ldc.i4 32000`) → `IsMovementBlockingCast(17215)` **-2** (`IL_006c: ldc.i4 17215`) → `!IsReady(17215, true)` **-200** (`IL_007b`, `IL_0080: ldc.i4.1`) → **1** (`IL_008e: ldc.i4.1`).
`Build`: `Gcd(17215, true)`.

### 4.27 `极炎法` — idx 33 — filler (`ScholarTools::BroilFillerActionId`)

Stop -999 → silence **-1** (`IL_001b: ldc.i4.m1`) → target null / `HasAttackBlock` **-1** (`IL_002e`) → `Distance > Min(25.0f, AttackRange+2.5f)` **-2** (`IL_003f: ldc.r4 25`, `IL_004f: ldc.r4 2.5`) → `IsDying` **-2** → `CurrentMp < 400` **-9** (`IL_0074: ldc.i4 400`) → level gate: `level >= 46` (`IL_0088: ldc.i4.s 46`) and `level >= 82` (`IL_0096: ldc.i4.s 82`) with enemy-count literals **2**, **3**, **5**, **5** (`IL_009a/009d/00a4/00a5`) → `< threshold` **-2** (`IL_00ae`) → `IsMovementBlockingCast(filler)` **-3** (`IL_00c9: ldc.i4.s -3`) → `!filler.IsReadyWithCanCast` **-200** (`IL_00df`) → **1** / **2** (`IL_00f1: ldc.i4.1`, `IL_00f3: ldc.i4.2`).
`Build`: `Gcd(fillerActionId).DontUseGcd()`.

### 4.28 `毁坏` — idx 31 — Ruin (17870)

Stop -999 → silence **-1** (`IL_0014: ldc.i4.m1`) → target null / `HasAttackBlock` **-1** (`IL_0027`) → `Distance > Min(25, AttackRange+2.5)` **-2** (`IL_0038: ldc.r4 25`, `IL_0048: ldc.r4 2.5`) → `IsDying` **-2** → `CurrentMp < 400` **-9** (`IL_006d: ldc.i4 400`) → `level < 38` **-3** (`IL_0083: ldc.i4.s 38`) → `MemApiMove::IsMoving` → `UpdateMovement`; moving ≥ **64** ms (`IL_009c: ldc.i4.s 64`) → if `!煤球走位` **-3** (`IL_00b4: ldc.i4.s -3`) else `CheckMovingRuin()`; `!煤球走位` **-100** (`IL_00c6: ldc.i4.s -100`).
Target proximity: `Distance > 5.0f` (`IL_00db: ldc.r4 5`) combined with nearby-enemy literals **7** (`IL_00d5`), **5**/**5** (`IL_00ea/00eb`), **2** (`IL_00f5`) → `!target` **-2** (`IL_00f8`), `!IsReady(17870)` **-200** (`IL_0030`/`IL_003d` in `CheckMovingRuin`), **-3** (`IL_00fb`).
`CheckMovingRuin()`: `煤球走位延迟时间 <= MoveStartTimeMs` (`IL_0010: ldc.i4.0`) → **-8** (`IL_0023: ldc.i4.s -8`); `CurrentTarget == null` **-2** (`IL_002d: ldc.i4.s -2`); `!IsReady(17870)` **-200** (`IL_0030: ldc.i4 17870`); else **1** (`IL_0043: ldc.i4.1`).
`Build`: `Gcd(17870)`.

### 4.29 `移动走位即刻极炎法` — idx 32

Stop -999 → QT(即刻走位) **-100** (`IL_0020: ldc.i4.s -100`) → `!MemApiMove::IsMoving` after `UpdateMovement` **-100** (`IL_0035`) → `HasDeadAllyWithoutRaise` **-1** (`IL_003f: ldc.i4.m1`) → `CurrentMp < 400` **-2** (`IL_004b: ldc.i4 400`) → silence **-1** (`IL_005c`) → target null / `HasAttackBlock` **-1** (`IL_006f`) → `Distance > Min(25, AttackRange+2.5)` **-2** (`IL_0080: ldc.r4 25`, `IL_0090: ldc.r4 2.5`) → `IsDying` **-2** → `!IsReady(7561)` **-3** (`IL_00ab: ldc.i4 7561`) → `BuffTimeLessThan(49, 3000)` **-7** (`IL_00bb: ldc.i4.s 49`, `IL_00bd: ldc.i4 3000`) → move-delay gate (`IL_00d8: ldc.i4.0`, `IL_00e0: ldc.i4.0`) → **-9** (`IL_00f3: ldc.i4.s -9`) → `!filler.IsReadyWithCanCast` **-200** (`IL_0114`) → **15** (`IL_011a: ldc.i4.s 15`).
`Build`: `Ability(7561).DontUseGcd()` + `Gcd(fillerActionId).DontUseGcd()`.

### 4.30 `绝亚康复` — idx 3 — Esuna, Alexander Ultimate only

`MemApiZoneInfo::GetCurrTerrId() != 887` → **-100** (`IL_0011: ldc.i4 887`) → QT(自动康复) **-100** (`IL_0027`) → `!IsReady()` **-200** (`IL_0031`) → `!HasAnyDispelTargetWithin30()` **-7** (`IL_003e: ldc.i4.s -7`) → `target = HealerEsunaTargetSelector::SelectTemporalStasisTarget(H1)`; null **-7** (`IL_005e`) → **1** (`IL_0061: ldc.i4.1`).
`IsReady()` = `Gcd(7568, true)` (`IL_0000: ldc.i4 7568`, `IL_0005: ldc.i4.1`).
`HasAnyDispelTargetWithin30()`: any of `PartyHelper::CastableAlliesWithin30` with `ACR.Tool.Data.Helper::HasDispelStatus` → `true` (`IL_001b: ldc.i4.1`), else `false` (`IL_0038: ldc.i4.0`).
`HealerEsunaTargetSelector::SelectTemporalStasisTarget` → `IsTemporalStasisTarget` = `IsValidEsunaTarget && (HasAura(938) || HasAura(700))` — literals `IL_0009: ldc.i4 938`, `IL_0017: ldc.i4 700`. `IsValidEsunaTarget` = `IsValid && IsTargetable && !HasAnyStatus(Status::不可选中合集) && Me.Distance <= 30.0f` (`IL_0029: ldc.r4 30`).

### 4.31 `裂阵法` — idx 30 — Art of War (16539)

Stop -999 → QT(AOE) -100 → silence **-1** (`IL_0023: ldc.i4.m1`) → target null / `HasAttackBlock` **-1** (`IL_0036`) → `Me.Level < 46` **-999** (`IL_0042: ldc.i4.s 46`, `IL_007f: ldc.i4 -999`) → territory ∈ {**293**, **296**, **1046**} **-999** (`IL_0058/0061/006a`, `IL_0071: ldc.i4.1`, `IL_0076: ldc.i4.0`) → `!IsReady(7562)` **-200** (`IL_0085: ldc.i4 7562`, `IL_008a: ldc.i4.1`) → `CurrentMp < 1000` **-999** (`IL_009c: ldc.i4 1000`) → `HasAura(43) || HasAura(44)` **-999** (`IL_00a8: ldc.i4.s 43`, `IL_00b7: ldc.i4.s 44`) → `!IsReady(16539)` **-200** (`IL_00c7: ldc.i4 16539`, `IL_00cc: ldc.i4.1`) → no nearby enemies **-200** (`IL_00df/00e0: ldc.i4.5`) → `Me.Level < 82` **-999** (`IL_00fa: ldc.i4.s 82`) → moving → **-1** (`IL_0113: ldc.i4.m1`) → **0** (`IL_0115`), **-1** (`IL_011b`), **1** (`IL_011d: ldc.i4.1`), with literals **2**/**3** (`IL_00fe/0101`).
`Build`: `Gcd(16539, true)`.

### 4.32 `鼓舞激励之策` — idx 14 — Adloquium (185 / 37015)

Stop -999 → QT(奶人,单盾) -100 → silence **-1** (`IL_003d: ldc.i4.m1`) → main = `Me.HasAura(3884) ? 37015 : 185` (`IL_0044: ldc.i4 3884`, `IL_0051: ldc.i4 185`, `IL_0058: ldc.i4 37015`); `IsMovementBlockingCast(main)` **-8** (`IL_0064`) → `CurrentMp < 1000` **-9** (`IL_0071: ldc.i4 1000`) → tankbuster branch: `HasBossCastingTankbusterWithin(10000)` (`IL_0086: ldc.i4 10000`) `&& target.IsTank && Me.Distance(tank) <= 30.0f` (`IL_00ab: ldc.r4 30`) `&& CanReceiveHeal(tank) && !HasScholarShield(tank)` → `CreateMainSpell` `IsReadyWithCanCast` false **-200** (`IL_00d8`) → `QueueEmergencyChain()`; return **10** (`IL_0100: ldc.i4.s 10`).
General branch: `cachedTarget = ScholarTools::ShieldTarget(单盾阈值, QT("单奶限制"))`; null **-6** (`IL_012a: ldc.i4.s -6`) → `HasScholarShield(target)` **-7** (`IL_013a`) → `CreateMainSpell(target).IsReadyWithCanCast` false **-200** (`IL_0151`) → `QueueEmergencyChain()`; return `target.IsTank ? 10 : 10` (`IL_016e: ldc.i4.1`, `IL_0186: ldc.i4.2`, `IL_0188: ldc.i4.s 10`).
`CreateMainSpell(target)`: `Gcd(Me.HasAura(3884) ? 37015 : 185, target)` (`IL_0005: ldc.i4 3884`, `IL_0012: ldc.i4 185`, `IL_0019: ldc.i4 37015`).
`QueueEmergencyChain()`: if `!CanUseOffGcd(2)` return (`IL_0000: ldc.i4.2`); `groupHealLimit = Clamp(群奶人数, 0, 8)` (`IL_0013: ldc.i4.0`, `IL_0014: ldc.i4.8`); `emergencyTargetCount = CountLowEffectiveHpPartyMembersNearSelf(应急战术阈值, 30)` (`IL_0025: ldc.i4.s 30`); `strict = CountLowEffectiveHpPartyMembersNearSelf(Clamp(应急战术阈值, 10, 100), 30)` (`IL_0037: ldc.i4.s 10`, `IL_003b: ldc.i4.s 100`, `IL_0042: ldc.i4.s 30`); if strict `>= groupHealLimit` → `QueueIfReady(16542)` + `QueueIfReady(3586)` (`IL_004d: ldc.i4 16542`, `IL_0058: ldc.i4 3586`); else if emergency `>= groupHealLimit` → `QueueIfReady(3586)` (`IL_0068`).
`QueueIfReady(actionId)`: `IsReady(actionId, true)` (`IL_0011: ldc.i4.1`) → `Ability(actionId, true)` (`IL_0029: ldc.i4.1`). `.ctor`: array size **3**.

### 4.33 `Strategy.复生` — idx 2 — raise

`.ctor`: constructs `ACR.Tool.Raise.HealerRaiseResolver(173, -999, <7 delegates>)`. Recovered literals: `IL_0116: ldc.i4 173` (raise action ID), `IL_011b: ldc.i4 -999` (stop code), `IL_0120: ldc.i4.0`. The constructor argument list from the signature is `(Func<bool> isStopped, Func<bool> isInstantRaiseEnabled, Func<bool> isCastRaiseEnabled, Func<bool> isPasserbyRaiseEnabled, Func<bool> hasForbiddenActionStatus, Func<IBattleChara> selectRaiseTarget, Func<bool> isRaiseMessageEnabled, Func<List<string>> raiseMessageMacros, Func<IReadOnlyList<string>> raiseMessageChannels, uint raiseActionId, int stopCode, uint castAssistActionId, Func<bool> canUseCastAssist)`. The delegate targets are `<>c::<.ctor>b__1_0 … b__1_6`, `HealerRuntimeTools::HasSkillSilenceStatus`, `ScholarTools::SelectRaiseTarget` — **lambda bodies are NOT in either dump**.
`Check()`/`Build()` just forward to `HealerRaiseResolver::Check/Build`.

### 4.34 `Strategy.过路圣人复活` — idx 1 — passer-by raise

`.ctor`: `HealerPasserbyRaiseResolver(28, 173, "学者复生", -999, <delegates>)`. Recovered: `IL_007f: ldc.i4.s 28` (classJobId — Scholar), `IL_0081: ldc.i4 173`, `IL_0086: ldstr "学者复生"`, `IL_008b: ldc.i4 -999`, `IL_0090: ldc.i4.0`. Delegate targets: `<>c::<.ctor>b__1_0/1/2/3` (**bodies absent**) plus `HealerRuntimeTools::HasSkillSilenceStatus`.
`HealerPasserbyRaiseResolver::Check()` **is** in the dump (`youshu.core.txt` 23700+). Constants proven there: minimum MP **2400** (`IL_0144: ldc.i4 2400`), `Swiftcast` **7561** (`IL_017d: ldc.i4 7561`), plus `Math::Max(raiseDelaySeconds)`, `classJobId` equality, `HasInstantCast()`, movement-blocking, and `castAssistActionId`.

### 4.35 `Strategy.学者奶满策略` — `ISlotSequence`, no resolver index

`StartCheck()`: `ScholarTools::FullHealTarget() != null && QT("奶人")` → `target` set, return **1** (`IL_001d: ldc.i4.1`); else **-1** (`IL_0015: ldc.i4.m1`).
`RunHealSequence(slot)`: requires `target != null && Me.Distance(target) <= 30.0f` (`IL_0017: ldc.r4 30`) `&& CanReceiveHeal(target)`; `groupLimit = Clamp(群奶人数, 0, 8)` (`IL_0035: ldc.i4.0`, `IL_0036: ldc.i4.8`); calls `QueueGroupFairyHeals`, `QueueGroupHeal`, `QueueSingleHeal`, `QueueFallbackGroupShield`.
`QueueGroupFairyHeals(slot, groupLimit)`:
- Illumination: `Qt("群奶") && Qt("幻光") && HasFairy() && !IsSeraphEndingSoon(3000)` (`IL_001f: ldc.i4 3000`) `&& CountLowEffectiveHpPartyMembersWithin20(应急战术阈值) >= groupLimit` → if `IsReady(16538, true)` add `Ability(16538).DontUseGcd()` (`IL_003d: ldc.i4 16538`, `IL_0042: ldc.i4.1`).
- Whispering Dawn: `Qt("群奶") && Qt("低语") && HasFairy() && !IsSeraphEndingSoon(3000)` && `!Me.HasAura(315)` (`IL_0090: ldc.i4 315`) `&& CountLowHpAlliesNearFairy(低语阈值, 20.0f) >= groupLimit` (`IL_00a7: ldc.r4 20`) → `IsReady(16537, true)` add (`IL_00b4: ldc.i4 16537`, `IL_00b9: ldc.i4.1`).
`QueueGroupHeal(slot, groupLimit)`:
- Indomitability: `Qt("群奶") && Qt("不屈") && CountLowEffectiveHpPartyMembersNearSelf(不屈阈值, 20) >= groupLimit` (`IL_0022: ldc.i4.s 20`) → `HasAetherflow() && CanSpendAetherflow() && IsReady(3583, true)` (`IL_003a: ldc.i4 3583`, `IL_003f: ldc.i4.1`) add `Ability(3583).DontUseGcd()`; else `QueueGroupShield(slot)`.
- Group shield: `Qt("群盾") && CountLowHpPartyMembersInRange(GCD群奶阈值, 20) >= groupLimit` (`IL_007a: ldc.i4.s 20`) → `QueueEmergencyActions(slot)` then `QueueGroupShield(slot)`.
`QueueSingleHeal(slot, target)`:
- Excogitation: `Qt("单奶") && Qt("绿帽") && HasAetherflow() && CanSpendAetherflow() && !target.HasAura(1220)` (`IL_002a: ldc.i4 1220`) `&& target.CurrentHpPercent + target.ShieldPercentage <= Clamp(绿帽阈值, 0, 1)` — literals `IL_0044: ldc.r4 100`, `IL_0056: ldc.r4 100`, `IL_005c: ldc.r4 0`, `IL_0061: ldc.r4 1` → `IsReady(7434)` (`IL_006d/007b: ldc.i4 7434`) add.
- Adloquium: `Qt("单盾") && !target.HasAura(297)` (`IL_00a1: ldc.i4 297`) `&& !target.HasAura(1918)` (`IL_00af: ldc.i4 1918`) `&& hp+shield <= Clamp(单盾阈值, 0, 1)` (`IL_00c9: ldc.r4 100`, `IL_00db: ldc.r4 100`, `IL_00e1: ldc.r4 0`, `IL_00e6: ldc.r4 1`) → main = `Me.HasAura(3884) ? 37015 : 185` (`IL_00f7: ldc.i4 3884`, `IL_0104: ldc.i4 185`, `IL_010b: ldc.i4 37015`) → `IsReady(main)` add `Gcd(main).DontUseGcd()`.
`QueueFallbackGroupShield(slot, groupLimit)`: `if (0.9f * CountLowHpPartyMembersWithin20(...) >= groupLimit)` (`IL_0000: ldc.r4 0.9`) set `fallbackCastCount`; then if `fallbackCastCount == 0 || Now - fallbackLastUseMs >= 1500` (`IL_0030: ldc.i4 1500`) → `QueueGroupShield(slot)`; increment.
`QueueEmergencyActions(slot)`: `if (AI.Instance.BattleData.HighPrioritySlots_OffGCD.Count >= 2)` (`IL_0014: ldc.i4.2`) return; if `Qt("秘策") && IsReady(16542)` add `Ability(16542)` (`IL_0024: ldc.i4 16542`, `IL_0029: ldc.i4.1`); if `IsReady(3586)` add `Ability(3586)` (`IL_0047: ldc.i4 3586`, `IL_004c: ldc.i4.1`).
`QueueGroupShield(slot)`: action = `Me.HasAura(3884) ? 37016 : 186` (`IL_0005: ldc.i4 3884`, `IL_0012: ldc.i4 186`, `IL_0019: ldc.i4 37016`) → `IsReady(action, true)` (`IL_0020: ldc.i4.1`) add `Gcd(action).DontUseGcd()`; then if `Me.HasAura(3884)` (`IL_0040`) and `IsReady(186, true)` (`IL_004d: ldc.i4 186`, `IL_0052: ldc.i4.1`) add `Gcd(186, true).DontUseGcd()` (`IL_005b: ldc.i4 186`, `IL_0060: ldc.i4.1`).

---

## 5. `ACR.Tool.Resolvers` — the 5 shared classes

Bodies **are present**: `youshu.core.txt` 23268–23675. All are `ACR.Tool.*`, so no `idx` in the Scholar list except `HealerPotionResolver` (idx 0).

| Class | idx | Body present? | Summary |
|---|---|---|---|
| `HealerDoubleDotResolverBase` | — (base of `双DOT`, idx 27) | **Yes**, but 6 `abstract`/`virtual` members have **no body** | See below |
| `HealerEsunaTargetSelector` | — (static helper) | **Yes** | `SelectGeneralTarget`, `SelectTemporalStasisTarget`, `SelectByPriority`, `IsGeneralDispelTarget`, `IsTemporalStasisTarget`, `IsValidEsunaTarget` |
| `HealerFullHealTargetSelector` | — (static helper) | **Yes** | `FindTarget`, `IsTargetInRange`, `FindTargetWithStatus`, `.cctor` |
| `HealerPotionResolver` | **0** | **Yes** | ctor + `Check` + `Build` |
| `HealerResolverBase` | — (base) | **Partially** | `Check`/`Build` **no body**; `CanUseOffGcd` **yes**; `.ctor` yes |

**`HealerResolverBase::CanUseOffGcd(int limit)` — proven, verbatim:**
```
IL_0000: ldsfld   AEAssist.CombatRoutine.Module.AI::Instance
IL_0005: callvirt AI::get_BattleData
IL_000a: ldfld     BattleData::HighPrioritySlots_OffGCD
IL_000f: callvirt Queue`1<Slot>::get_Count
IL_0015: clt
```
⇒ `return AI.Instance.BattleData.HighPrioritySlots_OffGCD.Count < limit;` (the `ldarg.0` push is dropped by the dump; semantics unambiguous). **`Check()` and `Build(slot)` are declared but have no body — they are abstract.**

**`HealerResolverBase::StopRequested` does not exist.** `StopRequested()` is `ScholarResolverBase::StopRequested()` ⇒ `ScholarQT::GetQt("停手")`.

**`HealerPotionResolver`** — `.ctor(Func<bool> isStopped, Func<bool> isEnabled)`; `Check()`: `isStopped()` → -999; `!isEnabled()` → -100; `Me.GetCurrTarget() == null || IsDying(...)` → skip; `!ItemHelper::CheckCurrJobPotion()` → **-2**. `Build`: `Spell::CreatePotion(10)` (`IL_0002: ldc.i4.s 10`) → `SlotAction`. The two `Func<bool>` passed at idx 0 are `<>c::<.cctor>b__1_0` / `b__1_1` — **bodies NOT in either dump**.

**`HealerDoubleDotResolverBase`** members **without bodies** (marked `[无方法体]` in the dump): `StopRequested`, `DotEnabled`, `DoubleDotEnabled`, `CanDot`, `HasDot`, `HasDotRemaining`. `BeforeBuild(slot)` is listed but has **no IL lines** — treat as empty/absent. Their Scholar overrides are all in `双DOT` (see 4.23).
Proven constants in the base: `Check()` → -999 (stop), -100 (QT), -200 (`candidateCount < activeDotCount`), -3 (`!IsReady(DotActionId, target)`), **35** (`IL_0085: ldc.i4.s 35`); `CountTargets` iterates `Svc.Objects` filtering `isinst IBattleChara && IsEnemy && CanDot && HasEnoughDotTime`; `HasDotPresence` uses `HasDotRemaining(enemy, 500)`; `HasEnoughDotTime` uses `HasDotRemaining(enemy, 3000)`; `IsBetterTarget` prefers missing-DOT → higher `MaxHp` → higher `CurrentHp` → closer `Distance`.

**`HealerFullHealTargetSelector::.cctor`** — `FullHealStatuses` is 12 `(territoryId, statusId)` pairs, all **[IL]**:
`(370,160) (210,188) (1769,826) (1769,973) (1769,1168) (1769,1169) (1769,1252) (1769,1346) (2303,922) (2303,923) (11,366) (11,1628)`.
`FindTarget()`: if `HealerGcdHealTracker::IsHpRefreshPending()` → null; else `IsFullHealMap(GetCurrTerrId())` or a matching status pair → `FindTargetWithStatus`. `IsTargetInRange`: `target != null && Me.Distance(target) <= 30.0f` (`IL_000f: ldc.r4 30`). `FindTargetWithStatus(id)`: first of `PartyHelper::CastableAlliesWithin30` with `HasAura(id)` and `CurrentHpPercent < 1.0f` (`IL_0025: ldc.r4 1`).

---

## 6. `ACR.Scholar.Timeline` — 33 classes (classification only)

### Conditions (5) — all category **(B) decision**, no settings written

| Class | Kind | Test, in IL order |
|---|---|---|
| `Conditions.QtCheck` | (B) | `ScholarQT::GetQt(key)` — pure pass-through |
| `Conditions.以太超流层数` | (B) | `Handle`: `Stacks == 0 ? AetherflowCharges == 0 : AetherflowCharges >= Stacks` — `IL_0008: call get_AetherflowCharges`, `IL_0013: clt`, `IL_0016: ceq`. `Draw` offers `"0层","1层","2层","3层"` |
| `Conditions.小仙女能量状态` | (B) | `Handle`: `Gauge == 0 ? FairyGauge == 0 : FairyGauge >= Gauge`. `Draw` (in `youshu.il.txt` 53163) builds an **11**-element array `"0","10",…,"100"` (`ldc.i4.s 11` at `IL_000b`) |
| `Conditions.慰藉层数` | (B) | `Handle`: `Stacks == 0 ? ConsolationCharges == 0 : ConsolationCharges >= Stacks`. `Draw`: `"0层","1层","2层"` |
| `Conditions.豆子层数` | (B) | `Handle`: `Blue == 0 ? AetherflowStacks == 0 : AetherflowStacks >= Blue`. `Draw`: `"0个","1个","2个","3个"` |

### Actions (28) — 25 write settings, 3 make decisions

| Class | Category | Writes / does | Literals |
|---|---|---|---|
| `Actions.DOT走位` | **(A) writes settings** | `ScholarSettingsData::DOT走位` via `BoolSettingTimelineAction("DOT走位", …)`, then `Save` | `ldstr "DOT走位"` |
| `Actions.GCD单奶` | **(A)** | `GCD单奶阈值` via `PercentSettingTimelineAction("GCD单奶阈值", …)` | `ldstr "GCD单奶阈值"` |
| `Actions.GCD群奶` | **(A)** | `GCD群奶阈值` via `PercentSettingTimelineAction` | `ldstr "GCD群奶阈值"` |
| `Actions.QtSetting` | **(A)** | Writes QT state: `ScholarQT::IsDefined`, `ScholarQT::SetQt`, `ScholarSettingsData::Save` (extends `HealerQtTimelineAction`) | — |
| `Actions.不上Dot阈值` | **(A)** | `不上Dot阈值` via `PercentSettingTimelineAction("不上dot阈值", …)` | `ldstr "不上dot阈值"` |
| `Actions.不屈阈值` | **(A)** | `不屈阈值` via `PercentSettingTimelineAction` | `ldstr "不屈阈值"` |
| `Actions.低语阈值` | **(A)** | `低语阈值` via `PercentSettingTimelineAction` | `ldstr "低语阈值"` |
| `Actions.保留豆子数量` | **(A)** | `保留豆子数量` via `IntSettingTimelineAction("保留/消耗豆子数量", ScholarSettings::get_保留豆子数量, …)` | `ldstr "保留/消耗豆子数量"` |
| `Actions.单盾阈值` | **(A)** | `单盾阈值` via `PercentSettingTimelineAction` | `ldstr "单盾阈值"` |
| `Actions.变身阈值` | **(A)** | `变身阈值` via `PercentSettingTimelineAction` | `ldstr "变身阈值"` |
| `Actions.回生法阈值` | **(A)** | `回生法阈值` via `PercentSettingTimelineAction` | `ldstr "回生法阈值"` |
| `Actions.小仙女移动到场中` | **(B) decision** | `Handle()`: `if (ScholarTools::HasFairy()) MemApiSpell::PetMove(TargetPos)`. `Draw`: `ImGui::InputFloat3("坐标", ref TargetPos)`. `.ctor` default `TargetPos = new Vector3(100, 0, 100)` — `IL_0001: ldc.r4 100`, `IL_0006: ldc.r4 0`, `IL_000b: ldc.r4 100` | 100, 0, 100 |
| `Actions.应急战术阈值` | **(A)** | `应急战术阈值` via `PercentSettingTimelineAction` | `ldstr "应急战术阈值"` |
| `Actions.康复顺序` | **(A)** | `Handle()`: `ScholarSettingsData::H1 = HealerEsunaOrderTimelineAction::H1`, then `Save`. `.ctor` seeds from `ScholarSettingsData::H1` | — |
| `Actions.慰藉阈值` | **(A)** | `慰藉阈值` via `PercentSettingTimelineAction` | `ldstr "慰藉阈值"` |
| `Actions.活性法阈值` | **(A)** | `活性法阈值` via `PercentSettingTimelineAction` | `ldstr "活性法阈值"` |
| `Actions.热键` | **(B) decision** | `RunHotkey(key)`: if `CustomHotkeys.TryGetValue(key, out customHotkey)` → `ScholarHotkeySystem::QueueCustomCombo(...)`; then `ScholarHotkeySystem::TryRunSystemHotkey(key)`. Extends `HealerHotkeyTimelineAction`. **Reads `ScholarSettingsData::CustomHotkeys`; writes nothing** | — |
| `Actions.煤球走位` | **(A)** | `煤球走位` via `BoolSettingTimelineAction("煤球走位", …)` | `ldstr "煤球走位"` |
| `Actions.祥光阈值` | **(A)** | `祥光阈值` via `PercentSettingTimelineAction` | `ldstr "祥光阈值"` |
| `Actions.绿帽阈值` | **(A)** | `绿帽阈值` via `PercentSettingTimelineAction` | `ldstr "绿帽阈值"` |
| `Actions.罩子阈值` | **(A)** | Writes **`野战治疗阵阈值`** (note: label is `"罩子阈值"`, field is `野战治疗阵阈值`), via `PercentSettingTimelineAction` | `ldstr "罩子阈值"` |
| `Actions.群减人数` | **(A)** | `群减人数` via `IntSettingTimelineAction("群减人数", …)` | `ldstr "群减人数"` |
| `Actions.群奶人数` | **(A)** | `群奶人数` via `IntSettingTimelineAction("群奶人数", …)` | `ldstr "群奶人数"` |
| `Actions.群盾阈值` | **(A)** | `群盾阈值` via `PercentSettingTimelineAction` | `ldstr "群盾阈值"` |
| `Actions.起手设置` | **(A)** | `Handle()`: `ScholarSettingsData::Opener = Math.Clamp(起手, 0, OpenerNames.Length)`, then `Save`. `.cctor`: `OpenerNames = ["空起手","扩散盾起手","幻光群盾起手"]` (**3** elements) | `ldc.i4.0`, 3 × `ldstr` |
| `Actions.醒梦阈值` | **(A)** | `醒梦阈值` via `IntSettingTimelineAction("阈值(MP)", 醒梦阈值, 10000, …)` | `ldc.i4 10000` |
| `Actions.链子阈值` | **(A)** | `链子阈值` via `PercentSettingTimelineAction` | `ldstr "链子阈值"` |
| `Actions.预读时间` | **(A)** | `预读时间` via `IntSettingTimelineAction("预读阈值", 预读时间, 3000, …)` | `ldc.i4 3000` |

Result: **25 of 33 are category (A)**, **8 are category (B)** (`QtCheck`, `以太超流层数`, `小仙女能量状态`, `慰藉层数`, `豆子层数`, `小仙女移动到场中`, `热键`), **0 pure data-only stubs**, **0 with missing bodies**.
> **[gap]** For `Actions.醒梦阈值` and `Actions.预读时间` the trailing literal (`10000`, `3000`) is the 3rd argument to `IntSettingTimelineAction::.ctor` after `(label, currentValue)`. `ACR.Tool.Timeline` is outside the requested namespaces and was not read, so whether it is `min` or `max` is **[inferred]** as `max` from the values (8000 ≤ 10000, 1500 ≤ 3000).

---

## 7. `ACR.Scholar.Openers` — 4 classes

| Class | StartCheck | StopCheck | InitCountDown (proven countdown offsets) |
|---|---|---|---|
| `学者起手辅助` | `DailyOpenerStartCheck()`: `GetQt("停手")` → **-1** (`IL_0018: ldc.i4.m1`); `Me.InCombat` → **-1**; `CastableParty.Count < 8` (`IL_002a: ldc.i4.8`) and target is not a dummy → **-100** (`IL_0038: ldc.i4.s -100`); else **0** (`IL_003b: ldc.i4.0`) | n/a | helper class, no `InitCountDown` |
| `幻光群盾起手` | `HighEndOpenerStartCheck(2)` (`IL_0000: ldc.i4.2`) | `GetQt("停手")` → **-1** (`IL_000c: ldc.i4.m1`) else **1** (`IL_000e: ldc.i4.1`) | off**15000** (`IL_0014`) and off**10000** (`IL_003f`), both `checkCombat = false` (`IL_0038: ldc.i4.0`, `IL_0063: ldc.i4.0`), + `AddCountdownSummonIfNeeded`, `AddCountdownPotionIfNeeded`, `AddCountdownBroil` |
| `扩散盾起手` | `HighEndOpenerStartCheck(1)` (`IL_0000: ldc.i4.1`) | same → -1 / 1 | off**10000** (`IL_0021`), off**8000** (`IL_004c`), off**5000** (`IL_0064`), all `checkCombat = false`; + summon/potion/broil |
| `空起手` | `DailyOpenerStartCheck()` | same → -1 / 1 | `AddCountdownSummonIfNeeded`, `AddCountdownPotionIfNeeded`, `AddCountdownBroil` only |

`学者起手辅助::HighEndOpenerStartCheck(int opener)`: `if (Me.InCombat() || GetQt("停手")) return -1` (`IL_0018: ldc.i4.m1`); `if (ScholarSettingsData::Opener != opener || !ScholarSettingsData::高难模式) return -1` (`IL_0033`); `if (CastableParty.Count > 4 && (CurrentTarget == null || CurrentTarget.IsBoss()))` → **0** (`IL_003f: ldc.i4.4`, `IL_004b: ldc.i4.0`); else **-100** (`IL_0055: ldc.i4.s -100`).
`AddCountdownSummonIfNeeded`: `if (!倒计时召唤 || HasFairy()) return;` else `AddCountdownAction(handler, 倒计时召唤延迟, <lambda>, checkCombat: false)` (`IL_003e: ldc.i4.0`; lambda **absent**).
`AddCountdownPotionIfNeeded`: `if (!GetQt("爆发药")) return;` else `handler.AddPotionAction(预读时间 - 100)` — `IL_0017: ldc.i4.s 100` with `IL_0019: sub`.
`AddCountdownBroil`: `AddCountdownAction(handler, 预读时间, <lambda>, checkCombat: true)` (`IL_002a: ldc.i4.1`).
`AddCountdownAction`: wraps `spellFactory` in a display class and calls `CountDownHandler::AddAction(timeLeft, Func<Spell>)`.
`SelectDeploymentShieldTarget()`: first `PartyHelper::CastableTanks` with `CanReceiveHeal && Me.Distance(tank) <= 30.0f` (`IL_002b: ldc.r4 30`); prefer one with `ACR.Tool.Data.Helper::HasTankStance`; else fallback tank; else `Me`.

> **[gap] — the opener sequences themselves are NOT verifiable.** The countdown *offsets* and *order* are proven, but the spells are supplied by compiler-generated lambdas (`<>c::<InitCountDown>b__5_0`, `<>c__DisplayClass5_0::<InitCountDown>b__1/b__2`, `<>c::<AddCountdownSummonIfNeeded>b__2_0`, `<>c::<AddCountdownBroil>b__4_0`). **No `<>c` or `<>c__DisplayClass*` class headings exist anywhere in either dump** (verified by grep for `^### .*<>c` — no matches). What each opener actually casts at 15000/10000/8000/5000 ms is therefore **UNKNOWN**.

---

## 8. Helper semantics that ARE verifiable (and were assumed missing)

`ACR.Scholar.ScholarTools` **is present** (`youshu.core.txt` 26135–26879). Proven members used by the resolvers:

| Helper | Proven semantics | IL evidence |
|---|---|---|
| `HasAetherflow()` | `AetherflowStacks > 0` | `IL_0005: ldc.i4.0`, `IL_0006: cgt` (youshu.il 48178) |
| `CanSpendAetherflow(int reserve)` | `AetherflowStacks > Math.Clamp(reserve, 0, 3)` | `IL_0006: ldc.i4.0`, `IL_0007: ldc.i4.3` (48200) |
| `CanSpendAetherflow()` | `CanSpendAetherflow(ScholarSettings::get_保留豆子数量())` | 48208 |
| `IsSeraphActive()` | `SeraphTimeLeft > 0` | `IL_0005: ldc.i4.0` (48183) |
| `IsSeraphEndingSoon(ms)` | `SeraphTimeLeft > 0 && SeraphTimeLeft <= ms` | `IL_0005: ldc.i4.0`, `IL_0006: ble.s`, `IL_0010: ldc.i4.0`, `IL_0011: ceq` (48188) |
| `HasFairy()` | `JobApi_Scholar != null && JobApi_Scholar.HasPet` | 26738 |
| `HasScholarDot(t)` / `HasScholarDotRemaining(t,ms)` | iterate private `DotStatuses` with `HasLocalPlayerAura` / `HasMyAuraWithTimeleft` | 26524/26533 |
| `ShouldSkipSingleTargetDot(t)` | `HealerEnemyTargetHelper::ShouldSkipDotByHp(t, Math.Clamp(不上Dot阈值, 0, 100), 12)` | `IL_000c: ldc.r4 100`, `IL_0012: ldc.i4.s 12` (26542) |
| `ShouldHoldBurstForDyingTrash()` | `HealerEnemyTargetHelper::ShouldHoldBurstForDyingTrash(0.3f, 15000, CurrBattleTimeInMs)` | `IL_0000: ldc.r4 0.3`, `IL_0005: ldc.i4 15000` (26548) |
| `HasScholarShield(t)` | `HasAura(297) \|\| HasAura(1918) \|\| HasAura(2607) \|\| HasAura(2608) \|\| HasAura(2609)` | 26405 |
| `CountExistingGroupShieldsWithin20()` | within 20.0f, `HasMyAuraWithTimeleft(297, 4000) \|\| HasMyAuraWithTimeleft(1918, 4000) \|\| HasAura(2609)` | `IL_002b: ldc.r4 20`, `IL_0038/004a: ldc.i4 4000` (26420) |
| `CountBleedingTargetsWithin20()` | within 20.0f, `CurrentHpPercent <= 0.8f`, `!HasDispelStatus`, `HasBleed` | `IL_0038: ldc.r4 0.8` (26475) |
| `CountAlivePartyMembersInRangePlusSelf(range)` | `CastableAlliesWithin30` with `CurrentHp > 0` and (`range >= 30` or `Me.Distance <= range`) | `IL_0021: ldc.i4.s 30` (26320) |
| `CountLowEffectiveHpPartyMembersNearSelf(hp,range)` | `CanReceiveHeal && Me.Distance <= range && CurrentHpPercent + ShieldPercentage < hp` | 26382 |
| `CountLowHpPartyMembersInRange(hp,range)` | `CanReceiveHeal && (range >= 30 \|\| Me.Distance <= range) && CurrentHpPercent <= hp` | `IL_003a: ldc.r4 100` (26342) |
| `CountLowHpAlliesNearFairy(hp,range)` | `FairyCenter() ?? Me`; `CurrentHpPercent <= Math.Clamp(hp, 0, 100)` | `IL_0002: ldc.r4 100`, `IL_0008: ldc.r4 0`, `IL_000d: ldc.r4 1` (26779) |
| `FairyCenter()` | `HasFairy() ? Svc.Objects.First(o => o.BaseId == 1008) : null` | `IL_0023: ldc.i4 1008` (26761) |
| `IsWithinRange(origin,target,range)` | squared XZ distance comparison | 26842 |
| `SwitchTargetIfNeeded(t)` | if `智能AOE目标 && 自动切换最优目标` and `CurrentTarget.EntityId != t.EntityId` → `LocalPlayerExtension::SetTarget(t)` | 26555 |
| `HasDeadAllyWithoutRaise()` | `HealerRaiseRuntime::HasDeadAllyWithoutRaise(173, 过路圣人模式)` | `IL_0000: ldc.i4 173` (26852) |
| `SelectRaiseTarget()` | `HealerRaiseRuntime::SelectRaiseTarget(RaiseDeathRecords, 复活延迟, 优先复活TN)` | 26857 |
| `UpdateMovement(bool)` / `get_MoveStartTimeMs` | delegate to `HealerMovementRuntimeState` | 26864 |
| `BroilFillerActionId()` | `level < 38 → 17869`; `38 ≤ level < 54 → 17869`; `54 ≤ level < 64 → 3584`; `level ≥ 64 → 7435`; fallback `17869` | `IL_000c: ldc.i4.s 38`, `IL_0017: ldc.i4.s 54`, `IL_001c: ldc.i4.s 64`, `IL_0027: ldc.i4.s 64`, IDs `17869`/`3584`/`7435` (26136) |
| `FullHealTarget()` | `if (!高难模式 \|\| HasSkillSilenceStatus()) return null; return HealerFullHealTargetSelector::FindTarget();` | 26152 |
| `ExcogitationTarget / AetherpactTarget / LustrateTarget / ShieldTarget` | all `Clamp(hpPercent, 0, 100)` then `Select*Tank ?? Select*Ally` | `IL_0002: ldc.r4 100`, `IL_0008: ldc.r4 0`, `IL_000d: ldc.r4 1` |
| `ProtractionTarget` | `Clamp(回生法阈值, 0, 100)`; prefers `MatchesSingleHealLimit` targets and `NeedsLivingDeadHeal`; `ShieldPercentage` compared against `100.0f` | `IL_0039: ldc.r4 100`, `IL_0051: ldc.r4 3.4028235E+38` |

---

## 9. 无法确证的部分 (everything that could NOT be verified)

Ordered by how likely it is to block a faithful reimplementation.

### A. Missing bodies — cannot be verified at all

1. **`<>c` and `<>c__DisplayClass*` compiler-generated classes are absent from both dumps.** Verified: `grep '^### .*<>c'` over `.il\` → **no matches**. Consequences:
   - **The 4 Opener spell sequences are unknowable.** Only the countdown offsets (15000/10000/8000/5000 ms) and the fact that a `Spell` is produced by a lambda survive. What 幻光群盾起手 casts at 15000 and 10000, and what 扩散盾起手 casts at 10000/8000/5000, is **UNKNOWN**.
   - `学者起手辅助::AddCountdownSummonIfNeeded` — the summon spell factory (`b__2_0`) is **UNKNOWN**.
   - `学者起手辅助::AddCountdownBroil` — the broil spell factory (`b__4_0`) is **UNKNOWN**.
   - `AddCountdownAction` — the `checkCombat` wrapper (`b__0`) is **UNKNOWN**.
   - The two `Func<bool>` passed to `HealerPotionResolver` at **idx 0** (`<>c::<.cctor>b__1_0`, `b__1_1`) are **UNKNOWN** — so the potion resolver's stop/enable conditions cannot be reproduced.
   - `Strategy.复生` (idx 2) — the 7 delegate bodies (`b__1_0 … b__1_6`) are **UNKNOWN**.
   - `Strategy.过路圣人复活` (idx 1) — the 4 delegate bodies (`b__1_0 … b__1_3`) are **UNKNOWN**.
   - All `Timeline.Actions.*` setting actions pass `<>c::<.ctor>b__0_0` as the value setter — the setters themselves are **UNKNOWN** (though the field they target is proven from the `ldfld`/`ldftn Save` pattern).

2. **`ScholarSettings::get_保留豆子数量` has no body in either dump.** It is only ever *called* (`youshu.core.txt` 26759, 29195, 30068, 31286; `youshu.il.txt` 48209, 52132, 53483, 55303). **[inferred]** it is a static accessor returning `Instance.保留豆子数量` (an `int`, ctor default **2**). Not proven.

3. **`ScholarSettings` (the wrapper class, `youshu.core.txt` 25881) has almost no bodies**, unlike `ScholarSettingsData`. Only `Build`, `Save`, `.cctor` are present in `youshu.il.txt`. Other accessors are **UNKNOWN**.

4. **`HealerResolverBase::Check()` and `::Build(Slot)` have no bodies** — declared abstract, so this is consistent, but it means the base contract ("what does `Check` return, and how is `Build` invoked") comes only from the 34 concrete overrides.

5. **`HealerDoubleDotResolverBase::BeforeBuild(Slot)`** is listed with **no IL lines** and no `[无方法体]` marker — ambiguous whether it is empty or the dump dropped it. Cannot be verified.

6. **The 6 abstract members of `HealerDoubleDotResolverBase`** (`StopRequested`, `DotEnabled`, `DoubleDotEnabled`, `CanDot`, `HasDot`, `HasDotRemaining`) are marked `[无方法体]` in the base — correct for abstract members; their Scholar implementations are proven in `双DOT`.

### B. Constants the decompiler dropped — proven absent, not guessed

7. **`能量吸收` silence guard (step 3).** `HasSkillSilenceStatus()` is called and `brfalse.s` branches past it, but the pushed return code is absent, so the silenced return value is **UNKNOWN**. (Every other resolver's silenced path is **-1**, but that is a pattern, not a proof.)

8. **`埋伏之毒` — `CanUseOffGcd` limit.** `IL_0053: ldc.i4.1` is present, but the dump's control flow makes `CurrentTarget == null` fall *through* to the `CanUseOffGcd` continuation instead of aborting, which contradicts the sibling resolvers. The exact sense of the `IL_003f: brfalse.s IL_0053` / `IL_0047: brtrue.s IL_0051` / `IL_004f: brfalse.s IL_0053` triple is **UNKNOWN**.

9. **`能量吸收` cooldown predicate.** The literal **4** (`IL_008c: ldc.i4.4`) and `double.MaxValue` (`IL_0099: ldc.r8`) are proven, and the branch instructions `IL_00a2: beq.s`, `IL_00a8: bgt.un.s`, `IL_00b0: bgt.un.s` are visible, but the operand pushes are missing, so the exact boolean composition (`NextAetherflowCooldown()` vs `GcdDurationMs() * 4`?) is **UNKNOWN**. `IL_00b2: ldc.i4.1` (return 1) and `IL_00b3: ret` are proven.

10. **`意气轩昂之策` — `shouldGroupShield` and `canQueueOffGcd` predicates.** The literal cluster `IL_00f1: 0`, `IL_00f6: 1`, `IL_00f9: 0`, `IL_00fc: 1`, `IL_00fd: 0` and `IL_016d: clt`, `IL_0170: ceq`, `IL_0190: clt`, `IL_0193: ceq` is present, but which literals are `Emergency Tactics` min/max clamps versus comparison operands cannot be determined without the dropped pushes. The three `Clamp` calls (`群奶人数`, `应急战术阈值`) have bounds `0/8` and `10/100` proven at `IL_008a/008b` and `IL_00ac/00b0`.

11. **`自动减伤` — several branch senses.** `Check()` contains `IL_0073: ldc.i4.2`, `IL_0087: ldc.i4.m1`, `IL_0089: ldc.i4.2`, `IL_00a7: ldc.i4.m1`, `IL_00c4: ldc.i4.0`, `IL_00c7: ldc.i4.m1`, `IL_00c9: ldc.i4.2`. Whether `CanUseOffGcd` takes `2` at `IL_0089` is **[inferred]** from the sibling resolvers. The `pendingMitigation` / `mitigationLockUntil` / `deploymentLockUntil` state machine's exact transitions are **partially UNKNOWN** because the `Build` method's constant cluster (`IL_0000: ldc.i4.2`, `IL_0002: ldc.i4.0`, `IL_0025: ldc.i4.1`, `IL_005b: ldc.i4.5`, `IL_005e: ldc.i4.4`, `IL_0061: ldc.i4.5`, `IL_0075: ldc.i4.3`, `IL_007e: ldc.i4.0`, `IL_008f: ldc.i4.1`, `IL_00a1: ldc.i4.3`, `IL_00a7: ldc.i4.4`, `IL_00b5: ldc.i4.5`, `IL_00d4: ldc.i4 188`, `IL_00e9: ldc.i4.1`, `IL_010b: ldc.i4.0`, `IL_012b: ldc.i4.1`) is interleaved with dropped operand pushes. **`GetAoeMitigationSpells`, `BuildSacredSoil`, `DeploymentTarget`, `DeploymentSpells`, `LockMitigation`, `LockDeployment`, `IsSeraphConsolationPair` are fully proven** (section 4.15).

12. **`DOT` movement return codes.** The literals **45**, **30**, **35**, **50**, **40**, **-1**, **-20**, **-21** are all proven (`IL_0120/0126/0129/0135/013d/013b/00f2/011a`), but which branch yields which is only partly reconstructible — the dump shows two adjacent `UpdateMovement` calls and several unlabelled `brtrue`s.

13. **`毁坏` / `极炎法` / `移动走位即刻极炎法` / `裂阵法` — enemy-count predicates.** The counts (**7**, **5**, **2**, **4**, **3**, **2**) and level thresholds (**38**, **46**, **64**, **82**) are proven; how they combine into the "AOE vs single-target" decision is **partially UNKNOWN** because operand pushes are dropped.

14. **`医术` HP-threshold branch.** The non-tank branch clamps `GCD单奶阈值` with `(100.0f, 0.0f, 1.0f)` and the tank branch with `(10, 100.0f, 0.0f, 1.0f)` — an extra `ldc.i4.s 10` in the tank path at `IL_00f7`. Both are proven literals, but whether the tank branch's clamp reads `Clamp(GCD单奶阈值/100f, 0f, 1f)` with a separate `10` used elsewhere is **UNKNOWN**.

15. **`伏`/`ShouldHoldForFourPlayerDuty` boundary.** `IL_0022: ldc.i4.1` sits where the source likely negates `高难模式`; whether it is a boolean constant or a comparison operand is **UNKNOWN**. `Party.Count == 4` (`IL_002f: ldc.i4.4`) is proven.

16. **`醒梦阈值` / `预读时间` timeline action 3rd argument.** `10000` and `3000` are proven; whether they are `min` or `max` is **[inferred]** (stated in section 6).

### C. Whole-body-absent framework helpers referenced by the resolvers

These are called but no body appears anywhere in either dump. **For each, only the arguments the caller passes are known; the semantics are unknown or name-inferred.**

| Called member | Call sites pass | Status |
|---|---|---|
| `ACR.Tool.Runtime.HealerRuntimeTools::HasSkillSilenceStatus` | (no args) | body **not in dump** — semantics **[inferred]** from the name. Used by nearly every resolver. |
| `ACR.Tool.Runtime.HealerRuntimeTools::BuffTimeLessThan` | `(49, 3000)` in 即刻极炎法; `(49, 3000)` in 移动走位即刻极炎法 | body **not in dump** |
| `ACR.Tool.Runtime.HealerRuntimeTools::IsHotkeyBlocked` | (no args) | body **not in dump** |
| `ACR.Tool.Runtime.HealerActionHelper::IsReady` | `(id)` or `(id, true)` | body **not in dump**. The extra `ldc.i4.1` overload flag is unverifiable. |
| `ACR.Tool.Runtime.HealerActionHelper::RecentlyUsed` | `(id, ms)` — e.g. `(7434, 2500)`, `(16545, 22000)` | body **not in dump** |
| `ACR.Tool.Runtime.HealerActionHelper::SpellRecentlyUsed` | `(id, ms)` — e.g. `(16537, 2000)` | body **not in dump** |
| `ACR.Tool.Runtime.HealerActionHelper::Charges` | `(16546)` | body **not in dump** |
| `ACR.Tool.Runtime.HealerActionHelper::IsMovementBlockingCast` | `(id)` | body **not in dump** |
| `ACR.Tool.Runtime.HealerActionHelper::GcdDurationMs` | (no args) | body **not in dump** |
| `ACR.Tool.Runtime.HealerActionHelper::GetAdjustedActionId` | `(17864)` | body **not in dump** |
| `ACR.Tool.Runtime.HealerActionHelper::Ability` / `::Gcd` | `(id)`, `(id, target)`, `(id, true)` | body **not in dump** — the meaning of the boolean overload is unverifiable |
| `ACR.Tool.Runtime.HealerDotCastTracker::HasRecentlyApplied` | `(17864, GetAdjustedActionId(17864))` | body **not in dump** |
| `ACR.Tool.Runtime.HealerDotCastTracker::MarkPending` | `(17864, target)` | body **not in dump** |
| `ACR.Tool.Runtime.HealerEnemyTargetHelper::HasAttackBlock` | (target) | body **not in dump** |
| `ACR.Tool.Runtime.HealerEnemyTargetHelper::IsDying` | (target) | body **not in dump** |
| `ACR.Tool.Runtime.HealerEnemyTargetHelper::HasBossCastingAoeWithin` | `(10000)` resp. `(5000)` | body **not in dump** |
| `ACR.Tool.Runtime.HealerEnemyTargetHelper::HasBossCastingTankbusterWithin` | `(10000)` | body **not in dump** |
| `ACR.Tool.Runtime.HealerEnemyTargetHelper::ShouldSkipDotByHp` | `(target, minHpRatio, 12)` | body **not in dump** |
| `ACR.Tool.Runtime.HealerEnemyTargetHelper::ShouldHoldBurstForDyingTrash` | `(0.3f, 15000, battleTimeMs)` | body **not in dump** |
| `ACR.Tool.Runtime.HealerEnemyTargetHelper::AttackRangeBonus` | (no args) | body **not in dump** |
| `ACR.Tool.Runtime.HealerEnemyTargetHelper::IsOutOfAttackRangeOrDead` | `(25.0f)` | body **not in dump** |
| `ACR.Tool.Runtime.HealerEnemyTargetHelper::SelectCircularAoeTarget` | `(25, cachedTarget)` | body **not in dump** |
| `ACR.Tool.Runtime.HealerEnemyTargetHelper::IsInBossBattle` | (no args) | body **not in dump** |
| `ACR.Tool.Runtime.HealerHealingHelper::CanReceiveHeal`, `::NeedsLivingDeadHeal`, `::LivingDeadTankForHeal`, `::MatchesSingleHealLimit`, `::IsBetterLivingDeadPriorityTarget`, `::HasBleed` | various | all bodies **not in dump** |
| `ACR.Tool.Runtime.HealerGcdHealTracker::IsHpRefreshPending` | (no args) | body **not in dump** |
| `ACR.Tool.Runtime.HealerGroundTargetHelper::GroundCastPosition` | `(罩子优先场中, 罩子开挂模式)` | body **not in dump** — the argument order is proven, the meaning of the two bools is **[inferred]** from their field names |
| `ACR.Tool.Raise.HealerRaiseRuntime::*` (`HasDeadAllyWithoutRaise`, `SelectRaiseTarget`, `CreateValidatedRaiseSpell`, `CreateValidatedSelfSpell`) | `(173, 过路圣人模式)`, `(RaiseDeathRecords, 复活延迟, 优先复活TN)`, … | bodies **not in dump** |
| `ACR.Tool.Data.CommonMapIds::IsFullHealMap`, `::IsDirectBossDungeon` | `(territoryId)` | bodies **not in dump** |
| `ACR.Tool.Data.Helper::HasDispelStatus`, `::HasAnyStatus`, `::HasTankStance` | `(target)` resp. `(target, Status::不可选中合集)` | bodies **not in dump** |
| `ACR.Tool.Data.Status::get_不可选中合集` | (no args) | body **not in dump** |
| `ACR.Scholar.ScholarQT::GetQt` / `::SetQt` / `::IsDefined` / `::ApplyDailyMode` / `::ReapplyCurrentMode` / `::EnsureStateDefaults` / `::EnsureOrderDefaults` | various | **not read** — `ScholarQT` is at `youshu.core.txt` 26880, outside the requested namespaces. `GetQt(string)` semantics (default when a key is undefined) is **UNKNOWN**, which matters because it decides every QT gate. |
| `ACR.Scholar.ScholarHotkeySystem::*` | `(key)`, `(settings, key, customHotkey)` | **not read** |
| `ECommons`, `Dalamud`, `AEAssist` framework calls (`GameObjectExtension::HasAura/HasMyAuraWithTimeleft/CurrentHpPercent/Distance/IsTank/IsEnemy/InCombat/CanAttack/IsBoss/IsDummy/GetCurrTargetsTarget/SetTarget`, `PartyHelper::*`, `TargetHelper::GetNearbyEnemyCount`, `SpellHistoryHelper::RecentlyUsed`, `SpellExtension::IsUnlock/IsReadyWithCanCast`, `SettingMgr::GetSetting<GeneralSettings>::AttackRange`, `MemApi*`, `DotBlacklistHelper::IsBlackList`, `GCDHelper::CanUseOffGcd`, `QuestManager::IsQuestComplete`, `ItemHelper::CheckCurrJobPotion`, `TimeHelper::Now`) | — | third-party; bodies **not in dump** and out of scope. The `GeneralSettings::AttackRange` value used in the `Min(25.0f, AttackRange + 2.5f)` distance checks is a **user setting outside `ScholarSettingsData`** and is **UNKNOWN** |

### D. Explicit statements of what could NOT be determined

- I could **not** determine the exact boolean expression of any `Math.Clamp` call whose 3 arguments are not all present as `ldc` opcodes in the lossless dump. Where all three are present (e.g. `Clamp(群奶人数, 0, 8)`, `Clamp(应急战术阈值, 10, 100)`, `Clamp(保留豆子数量, 0, 3)`, `Clamp(消耗豆子数量, 0, 3)`) they are stated as proven.
- I could **not** determine any Opener spell sequence (section 9.A.1).
- I could **not** determine what `ScholarQT::GetQt` returns for an undefined key, which affects the meaning of every `QT` gate.
- I could **not** determine the meaning of the second boolean argument to `HealerActionHelper::IsReady(id, true)` / `::Ability(id, true)` / `::Gcd(id, true)`.
- I did **not** read `ACR.Tool.Timeline`, `ACR.Tool.UI`, `ACR.Tool.Data`, `ACR.Scholar.ScholarQT`, or the `ACR.Tool.Raise` helper set — they are outside the five requested namespaces. Anything they decide is a gap.
- The `ClassJob` id for Scholar is **28** (`IL_007f: ldc.i4.s 28` in `过路圣人复活`) and the raise action is **173** (`IL_0081: ldc.i4 173`), both proven.
- A `-999` return appears to be the universal "stopped" sentinel and `-100` the universal "QT disabled" sentinel; `-200` always precedes an action that is not ready. This is a consistent **[inferred]** convention, not a proven contract.
