import pathlib, zipfile

根 = pathlib.Path(r"C:\Users\MECHREVO\Documents\deepseek-harness\default-workspace")
输出 = 根 / "源码审核包-0.6.4.2.zip"

排除目录 = {".git", "bin", "obj", "release", "build", ".scratch", ".snapshots",
            ".il", "backup", "localnuget", "ref", "cactbot_timelines"}

收录 = []
for p in 根.rglob("*"):
    if not p.is_file():
        continue
    rel = p.relative_to(根)
    if any(part in 排除目录 for part in rel.parts):
        continue
    if p.suffix.lower() in {".zip", ".7z", ".dll", ".pdb", ".exe", ".png", ".jpg", ".tsv"}:
        continue
    if p.name.startswith("Log-") or p.name.endswith(".log"):
        continue
    try:
        if p.stat().st_size > 2 * 1024 * 1024:
            continue
    except OSError:
        continue
    收录.append((p, rel))

with zipfile.ZipFile(输出, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p, rel in 收录:
        z.write(p, rel.as_posix())

print(f"已重新生成: {输出.name}  文件数 {len(收录)}  体积 {输出.stat().st_size/1048576:.2f} MB")
print("包含审计说明:", any(r.as_posix().endswith("本轮改动说明-给审计.md") for _, r in 收录))
print("包含倾向模块:", any(r.as_posix().endswith("HealerACR/Common/Ai倾向.cs") for _, r in 收录))
print("包含减伤排序:", any(r.as_posix().endswith("BlueWhale.AutoHealerACR/候选集.cs") for _, r in 收录))
