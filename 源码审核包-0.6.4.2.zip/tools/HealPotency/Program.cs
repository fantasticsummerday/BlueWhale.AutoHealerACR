using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using Lumina;
using Lumina.Data;

// 四奶「恢复力 / 威力」导出器。
//
// ⚠️ 为什么单独做这个工具：
//   CN 客户端的 ActionTransient 描述里，**伤害威力有数字，恢复力后面是空的** ——
//   例：id=120 治疗 → "恢复目标的体力　恢复力："（没有数字）
//   所以必须换个地方找治疗威力。本工具先 probe 出它在哪，再 dump。
//
// 用法: HealPotency.exe [game目录] [模式]
//   fields → 打印 Action / ActionTransient 的全部字段名
//   probe  → 对几个已知技能，并排打印 CN/EN/JP 描述（看数字在哪个语言里）
//   dump   → 导出四奶威力表（默认）

Console.OutputEncoding = Encoding.UTF8;

var root = args.Length > 0 ? args[0] : @"D:\FF14\最终幻想XIV\game";
var mode = args.Length > 1 ? args[1] : "dump";

var candidates = new List<string>();
foreach (var c in root.Split(';', StringSplitOptions.RemoveEmptyEntries))
{
    if (Directory.Exists(c)) candidates.Add(c);
    var sub = Path.Combine(c, "sqpack");
    if (Directory.Exists(sub)) candidates.Add(sub);
}

GameData data = null;
string 数据路径 = null;
foreach (var path in candidates)
{
    try { data = new GameData(path, new LuminaOptions { DefaultExcelLanguage = Language.ChineseSimplified }); 数据路径 = path; break; }
    catch (Exception e) { Console.WriteLine($"   {path}: {e.Message}"); }
}
if (data == null) return 2;

string 描述(Lumina.Excel.Sheets.ActionTransient t)
{
    try { return t.Description.ToString().Replace("\r", " ").Replace("\n", " ").Trim(); }
    catch { return ""; }
}

var cnT = data.Excel.GetSheet<Lumina.Excel.Sheets.ActionTransient>(Language.ChineseSimplified);
var enT = data.Excel.GetSheet<Lumina.Excel.Sheets.ActionTransient>(Language.English);

// ══════════════════════════════════════════════════════════════════
if (mode == "fields")
{
    foreach (var (名, 类型) in new (string, Type)[]
    {
        ("Action", typeof(Lumina.Excel.Sheets.Action)),
        ("ActionTransient", typeof(Lumina.Excel.Sheets.ActionTransient)),
    })
    {
        Console.WriteLine($"\n=== {名} 字段 ===");
        foreach (var p in 类型.GetProperties(BindingFlags.Public | BindingFlags.Instance))
            Console.WriteLine($"   {p.PropertyType.Name,-26} {p.Name}");
    }
    return 0;
}

// ══════════════════════════════════════════════════════════════════
if (mode == "raw")
{
    // 验证假设：CN 描述里「恢复力：」后面不是空的，
    // 而是 SeString 的 **payload（条件表达式）**，被 ToString() 丢掉了。
    // 可选：第三个参数传 id 列表，覆盖默认
    var rawIds = args.Length > 2
        ? args[2].Split(',', StringSplitOptions.RemoveEmptyEntries).Select(uint.Parse).ToArray()
        : new uint[] { 120, 185, 3594, 137, 24284 };
    foreach (var id in rawIds)
    {
        var s = cnT.GetRow(id).Description;
        Console.WriteLine($"\n=== id={id} payload数={s.PayloadCount} ===");
        Console.WriteLine($"  ToString()    : [{s.ToString().Replace("\n", " ").Replace("\r", "")}]");
        try { Console.WriteLine($"  ToMacroString(): [{s.ToMacroString().Replace("\n", " ").Replace("\r", "")}]"); }
        catch (Exception e) { Console.WriteLine($"  ToMacroString() 失败: {e.Message}"); }
    }
    return 0;
}

// ══════════════════════════════════════════════════════════════════
if (mode == "lang")
{
    // 用**新建 GameData**的方式切语言（比 GetSheet(lang) 可靠）
    foreach (var lang in new[] { Language.ChineseSimplified, Language.English, Language.Japanese, Language.German, Language.French })
    {
        try
        {
            var g = new GameData(数据路径, new LuminaOptions { DefaultExcelLanguage = lang });
            var a = g.Excel.GetSheet<Lumina.Excel.Sheets.Action>();
            var t = g.Excel.GetSheet<Lumina.Excel.Sheets.ActionTransient>();
            var 名 = a.GetRow(120).Name.ToString();
            var 描 = t.GetRow(120).Description.ToString().Replace("\r", " ").Replace("\n", " ");
            Console.WriteLine($"  {lang,-20} Name(120)={名,-8} Desc(120)={描}");
        }
        catch (Exception e) { Console.WriteLine($"  {lang,-20} 失败: {e.Message}"); }
    }
    return 0;
}

// ══════════════════════════════════════════════════════════════════
if (mode == "probe")
{
    // 120 治疗 / 135 救疗 / 124 医治 / 137 再生 / 16531 安慰之心 / 185 鼓舞激励之策 / 3570 神名 / 188 罩子
    // 规律：前 5 个「恢复力：」为空，后两个有数字。先看字符串原始形态。
    uint[] ids = { 120, 124, 135, 137, 16531, 185, 3570, 188 };

    Console.WriteLine("######## 描述原始形态（转义，暴露隐藏字符）########");
    foreach (var id in ids)
    {
        try
        {
            var t = cnT.GetRow(id);
            var s = t.Description.ToString();
            var sb = new StringBuilder();
            foreach (var ch in s)
                sb.Append(ch < 0x20 || ch == 0xFFFD ? $"<U+{(int)ch:X4}>" : ch.ToString());
            Console.WriteLine($"  [{id}] {sb}");
        }
        catch (Exception e) { Console.WriteLine($"  [{id}] {e.Message}"); }
    }

    // 语言到底有没有切成功？
    Console.WriteLine("\n######## 语言切换测试（同一 id=120）########");
    foreach (var lang in new[] { Language.ChineseSimplified, Language.English, Language.Japanese, Language.German })
    {
        try
        {
            var sh = data.Excel.GetSheet<Lumina.Excel.Sheets.ActionTransient>(lang);
            Console.WriteLine($"  {lang,-20} -> {sh.GetRow(120).Description.ToString()}");
        }
        catch (Exception e) { Console.WriteLine($"  {lang,-20} -> 失败: {e.Message}"); }
    }

    // Action 行的**全部**字段（含 0），比对 120 与 185 —— 看有没有藏着 500 的列
    var acts = data.Excel.GetSheet<Lumina.Excel.Sheets.Action>();
    var props = typeof(Lumina.Excel.Sheets.Action)
        .GetProperties(BindingFlags.Public | BindingFlags.Instance)
        .Where(p => p.Name is not ("ExcelPage" or "RowOffset"))
        .ToArray();

    Console.WriteLine("\n######## Action 全字段比对：120 治疗(恢复力缺失) vs 185 鼓舞(有300) ########");
    Console.WriteLine($"  {"字段",-24} {"120",-30} {"185",-30}");
    foreach (var p in props)
    {
        string v1, v2;
        try { v1 = p.GetValue(acts.GetRow(120))?.ToString() ?? "null"; } catch { v1 = "(x)"; }
        try { v2 = p.GetValue(acts.GetRow(185))?.ToString() ?? "null"; } catch { v2 = "(x)"; }
        if (v1 == v2) continue;                     // 只打两者不同的
        if (v1.Length > 28) v1 = v1[..28];
        if (v2.Length > 28) v2 = v2[..28];
        Console.WriteLine($"  {p.Name,-24} {v1,-30} {v2,-30}");
    }
    return 0;
}

// ══════════════════════════════════════════════════════════════════
//  dump：双语取数 —— 伤害威力用 CN，恢复力若 CN 为空就回落到 EN
// ══════════════════════════════════════════════════════════════════

var actions = data.Excel.GetSheet<Lumina.Excel.Sheets.Action>();

var jobName = new Dictionary<uint, string>
{
    [6] = "幻术", [26] = "秘术", [24] = "白魔", [28] = "学者", [33] = "占星", [40] = "贤者",
};

// ⚠️⚠️ 关键教训（本工具第一版在这里翻了车）⚠️⚠️
//   技能说明是 **SeString**，里面的条件和数值是 **payload**。
//   `ReadOnlySeString.ToString()` **只返回纯文本，payload 全部丢弃** ——
//   于是「恢复力：<if(职业==24,<if(等级>=85,500,450)>,450)>」被读成「恢复力：」，
//   我据此得出"CN 数据里威力为空"的结论，**那个结论是错的**（是工具缺陷）。
//   必须用 `ToMacroString()`，它会把 payload 渲染成 `<colortype(504)>` / `<if(...)>` 形式。
//   gnum68 = 玩家职业 ID，gnum72 = 玩家级别。
//
// ⚠️ 返回的是**分组**：每个「威力：」出现位置一组，组内是该处的**等级档位**（如 500/450）。
//    不能拍平成一个列表 —— 否则「天辉：直伤85/65 + DoT85/65」会被读成「初始85、每跳65」，
//    总伤直接算错。位置信息必须保留。
static List<List<string>> 取值组(string text, string 词)
{
    var groups = new List<List<string>>();
    var idx = 0;
    while (true)
    {
        var i = text.IndexOf(词 + "：", idx, StringComparison.Ordinal);
        if (i < 0) break;
        var p = i + 词.Length + 1;

        // 先跳过颜色/边框 payload（但**不能**跳过 <if( —— 那才是数值所在）
        while (p < text.Length && text[p] == '<' && !text.AsSpan(p).StartsWith("<if("))
        {
            var close = text.IndexOf('>', p);
            if (close < 0) break;
            p = close + 1;
        }

        string chunk;
        if (p < text.Length && text.AsSpan(p).StartsWith("<if("))
        {
            var depth = 0;
            var q = p + 3;
            for (; q < text.Length; q++)
            {
                if (text[q] == '(') depth++;
                else if (text[q] == ')') { depth--; if (depth == 0) break; }
            }
            chunk = text.Substring(p, Math.Min(q + 1, text.Length) - p);
        }
        else
        {
            var m = p < text.Length ? Regex.Match(text[p..], @"^\s*(\d+)") : Match.Empty;
            chunk = m.Success ? m.Groups[1].Value : "";
        }

        // 去掉条件 [gnum68==24] / [gnum72>=85]，只留数值分支
        chunk = Regex.Replace(chunk, @"\[gnum\d+[^\]]*\]", "");
        var tiers = new List<string>();
        foreach (Match m in Regex.Matches(chunk, @"\d+"))
            if (!tiers.Contains(m.Value)) tiers.Add(m.Value);
        if (tiers.Count > 0) groups.Add(tiers);

        idx = i + 词.Length + 1;
    }

    // 补充两种**无冒号**措辞（只认冒号的版本会漏）：
    //   ① 恢复力200＋积蓄…        （大宇宙 / 小宇宙）
    //   ② 抵消相当于500恢复力的…  （神祝祷：数字在词前面）
    if (groups.Count == 0)
    {
        var tiers = new List<string>();
        foreach (Match m in Regex.Matches(text, $@"{词}\s*?(\d+)"))
            if (!tiers.Contains(m.Groups[1].Value)) tiers.Add(m.Groups[1].Value);
        foreach (Match m in Regex.Matches(text, $@"(\d+)\s*{词}"))
            if (!tiers.Contains(m.Groups[1].Value)) tiers.Add(m.Groups[1].Value);
        if (tiers.Count > 0) groups.Add(tiers);
    }

    return groups;
}

// 分组 → "500/450|85/65"（组间用 | ，组内档位用 /）
static string 组串(List<List<string>> g) => string.Join("|", g.Select(x => string.Join("/", x)));

var 时长Re = new Regex(@"持续时间[：:]\s*(\d+)");

var rows = new List<string>
{
    "Job\tId\tLevel\tPvP\tMP\t消耗类型\t复唱s\t充能\t名称\t威力\t恢复力\t恢复力缺失\t持续\tCN描述"
};

foreach (var row in actions)
{
    uint job;
    try { job = row.ClassJob.RowId; } catch { continue; }
    if (!jobName.ContainsKey(job)) continue;

    var name = row.Name.ToString();
    if (string.IsNullOrWhiteSpace(name)) continue;

    uint level = 0, recast = 0, charges = 0, mp = 0, costType = 0;
    try { level = row.ClassJobLevel; } catch { }
    try { recast = row.Recast100ms; } catch { }
    try { charges = row.MaxCharges; } catch { }
    try { mp = row.PrimaryCostValue; } catch { }
    try { costType = row.PrimaryCostType; } catch { }

    string macro = "", cn = "";
    try { macro = cnT.GetRow(row.RowId).Description.ToMacroString(); } catch { }
    try { cn = 描述(cnT.GetRow(row.RowId)); } catch { }

    if (string.IsNullOrWhiteSpace(macro)) continue;
    // 只要提到威力/恢复力/完全恢复就保留 —— 数值缺失也保留，缺口才看得出来
    if (!macro.Contains("威力") && !macro.Contains("恢复力") && !macro.Contains("恢复量")
        && !macro.Contains("完全恢复")) continue;

    var 威力组 = 取值组(macro, "威力");
    var 恢复组 = 取值组(macro, "恢复力");
    if (恢复组.Count == 0) 恢复组 = 取值组(macro, "恢复量");

    // 描述里写了「恢复力/恢复量」但没能取到数字 → 才算真缺口
    bool 缺失 = (macro.Contains("恢复力") || macro.Contains("恢复量")) && 恢复组.Count == 0;

    // ⚠️ 时长用**纯文本**列取 —— 宏里 `持续时间：<edgecolortype(0)>18秒` 数字被 payload 隔开，正则会失配
    var 时长 = 时长Re.Match(cn);

    // ⚠️ PrimaryCostValue **要区分消耗类型**：
    //    type=3 是 MP，单位是 100（治疗=4 → 400 MP）
    //    灵橡清汁那种 "1" 消耗的是蛇胆，不是 1 MP —— 不能混进来
    string mp列 = costType == 3 && mp > 0 ? (mp * 100).ToString() : "";

    rows.Add(string.Join('\t',
        jobName[job], row.RowId, level, level == 0 ? "PvP" : "",
        mp列, costType.ToString(),
        $"{recast / 10.0:0.0}", charges >= 2 ? charges.ToString() : "",
        name,
        组串(威力组), 组串(恢复组),
        缺失 ? "★缺" : "",
        时长.Success ? 时长.Groups[1].Value : "",
        cn.Replace("\t", " ")));
}

File.WriteAllLines("dump_healpot.tsv", rows, Encoding.UTF8);
Console.WriteLine($"导出 {rows.Count - 1} 条 -> dump_healpot.tsv");

// ══════════════════════════════════════════════════════════════════
//  doc：生成整理好的 markdown
// ══════════════════════════════════════════════════════════════════
if (mode == "doc")
{
    var 全 = rows.Skip(1)
        .Select(l => l.Split('\t'))
        .Where(f => f[3] != "PvP")                       // 只要 PvE（Level=0 的是 PvP 行）
        .Select(f => new
        {
            // 幻术/秘术是基础职业，飞石/坚石/疾风/毁灭这些低等级档位挂在它们名下
            Raw = f[0],
            Job = f[0] == "幻术" ? "白魔" : f[0] == "秘术" ? "学者" : f[0],
            Id = f[1], Lv = f[2], MP = f[4], Recast = f[6], Charge = f[7],
            Name = f[8], Pow = f[9], Heal = f[10], Missing = f[11], Dur = f[12], Desc = f[13],
        })
        // 秘术里混着召唤兽技能和召唤师专属 buff，跟奶妈无关，剔掉
        // （25800 以太蓄能是 SMN 的增伤 buff，描述里「威力提高50」不是威力值）
        .Where(x => !(x.Name.Contains("召唤") || x.Name.Contains("宝石")
                      || x.Name.Contains("陆行鸟") || x.Name.Contains("迦楼罗")
                      || x.Name.Contains("泰坦") || x.Name.Contains("伊弗利特")
                      || x.Id == "25800"))
        .ToList();

    static bool 是AoE(string d) => d.Contains("周围的敌人") || d.Contains("范围魔法攻击");
    static bool 是DoT(string d) => d.Contains("持续伤害");
    static bool 是直伤型DoT(string d) => 是DoT(d) && d.Contains("对目标发动");
    // 基础职业的技能加后缀，避免与特职同名条目混淆（例：秘术的「毁灭」vs 学者的「毁灭」）
    static string 名(string n, string raw) => raw is "幻术" or "秘术" ? $"{n}（{raw}）" : n;

    var md = new List<string>();
    void W(string s = "") => md.Add(s);

    // 存储格式：组间用 | ，组内档位用 / —— 只用于落盘；展示时换成 "A + B"
    // 现在缺口已为 0，"—" 只表示"这个技能本来就没有该项数值"（如纯治疗技没有伤害威力）
    string 数(string v, string 缺 = "—") => v.Length > 0 ? v.Replace("|", " + ") : 缺;
    int 时长秒(string d) => d.Length > 0 && int.TryParse(d, out var n) ? n : 0;
    // 一档字符串（"500/450"）取最高档
    static int 高档(string s) => s.Split('/').Select(int.Parse).Max();

    W("# 四奶技能威力 · 数据表");
    W();
    W("> 全部数值来自游戏客户端的 `ActionTransient` 表（即**游戏内技能说明原文**），不是凭印象写的。");
    W("> 生成工具：`tools\\HealPotency`（`dotnet run --project tools\\HealPotency -- \"D:\\FF14\\最终幻想XIV\\game\" doc`）。");
    W();
    W("## 数据来源与两个已踩的坑（先看这段）");
    W();
    W("**坑 1：威力不在 `Action` 表里。** 比对 `Action` 行的全部字段（治疗 120 vs 鼓舞激励之策 185），只有");
    W("`RowId / Name / Icon / PrimaryCostValue / Cast100ms / ClassJobLevel` 六个不同 —— **没有任何威力列**。");
    W("`ActionTransient` 也只有 `Description` 一个字段。威力只存在于技能说明文本里。");
    W();
    W("**坑 2（更关键）：技能说明是 SeString，数值藏在 payload 里。**");
    W("`ReadOnlySeString.ToString()` **只返回纯文本、把 payload 全部丢掉**，于是");
    W("`恢复力：<if([gnum68==24],<if([gnum72>=85],500,450)>,450)>` 被读成 `恢复力：`。");
    W("必须用 **`ToMacroString()`** 才能拿到真实数值。");
    W("（第一版就是栽在这里，还据此写过\"CN 数据里威力为空\"的错误结论 —— 那是工具缺陷，不是数据缺陷。）");
    W();
    W("`gnum68` = 玩家职业 ID，`gnum72` = 玩家级别。所以**同一个技能在不同职业/等级下显示不同数值**。");
    W("本表把各档都列出来，写法 `500/450` 表示「高等级档 / 低等级档」（一般是 85 级或 94 级提升一档）。");
    W();
    W("几个解析要点：");
    W();
    W("| 要点 | 说明 |");
    W("|---|---|");
    W("| 必须用 `ToMacroString()` | `ToString()` 丢 payload，会把有数值的技能读成空的 |");
    W("| 数值要**按标签位置分组** | 天辉是「直伤 85/65 + DoT 85/65」，拍平会读成「初始85、每跳65」，总伤直接算错 |");
    W("| 无冒号措辞 `恢复力200＋…` | 大宇宙 / 小宇宙，只认 `恢复力：` 会漏 |");
    W("| 数字在词前 `相当于500恢复力` | 神祝祷，只认 `恢复力：` 会漏 |");
    W("| `PrimaryCostValue` **要 ×100** | 治疗=4 → **400 MP**；且必须先看 `PrimaryCostType` |");
    W("| `PrimaryCostType` 不是 MP 时不能当蓝耗 | 灵橡清汁的 \"1\" 消耗的是**蛇胆**，不是 1 点蓝 |");
    W();
    W("### 与 huijiwiki 的交叉核对");
    W();
    W("已用 [最终幻想XIV中文维基](https://ff14.huijiwiki.com/wiki/%E8%81%8C%E4%B8%9A) 的 `Data:Action/<id>.json`");
    W("（等价于游戏说明的宏展开形式）逐项核对白魔 / 学者 26 个技能：");
    W("**威力与恢复力全部一致**，且职业页的技能等级 / 魔力消耗也对得上");
    W("（治疗 2级/400、医治 10级/900、救疗 30级/1000、愈疗 40级/1500、医济 50级/1000、再生 35级/400）。");
    W();
    W("核对过的样例：飞石 140、神圣 140、豪圣 150、闪飒 640、闪灼 350/310、苦难之心 1400/1240、");
    W("天辉 85/65 + DoT 85/65、破阵法 165/150、蛊毒法 85/70、极炎法 320/295、");
    W("治疗 500/450、医治 400/300、救疗 800/700、愈疗 600/550、医济 250/200+HoT150/100、再生 250/200、");
    W("安慰之心 800/700、狂喜之心 400/300、医术 450/400、鼓舞 300、士气高扬 200、活性法 600、");
    W("不屈 400、深谋远虑 800、低语 80、祥光 320。");
    W();
    W("---");
    W();

    string[] jobs = { "白魔", "学者", "占星", "贤者" };

    // ---------------- 横向速查 ----------------
    W("## 一、横向速查");
    W();

    W("### 1.1 单体填充技（GCD 伤害，按等级档位，含基础职业档位）");
    W();
    W("| 职业 | 等级 | id | 技能 | 威力 | MP |");
    W("|---|---|---|---|---|---|");
    foreach (var j in jobs)
        foreach (var x in 全.Where(x => x.Job == j && x.Recast == "2.5" && !是AoE(x.Desc) && !是DoT(x.Desc)
                                        && (x.Desc.Contains("对目标发动") || x.Desc.Contains("对目标附加")))
                            .OrderBy(x => int.Parse(x.Lv)))
            W($"| {j} | {x.Lv} | {x.Id} | {名(x.Name, x.Raw)} | **{数(x.Pow)}** | {x.MP} |");
    W();

    W("### 1.2 群体伤害技（GCD）");
    W();
    W("| 职业 | 等级 | id | 技能 | 威力 | 递减 |");
    W("|---|---|---|---|---|---|");
    foreach (var j in jobs)
        foreach (var x in 全.Where(x => x.Job == j && x.Recast == "2.5" && 是AoE(x.Desc) && !是DoT(x.Desc))
                            .OrderBy(x => int.Parse(x.Lv)))
        {
            var m = System.Text.RegularExpressions.Regex.Match(x.Desc, @"对[^，。]*之外的敌人威力降低(\d+)%");
            W($"| {j} | {x.Lv} | {x.Id} | {名(x.Name, x.Raw)} | **{数(x.Pow)}** | {(m.Success ? m.Groups[1].Value + "%" : "—")} |");
        }
    W();

    W("### 1.3 DoT");
    W();
    W("两种形态，**不能混着算**：");
    W();
    W("- **有直伤型**（疾风/烈风/天辉）：`威力：N`（直伤）+ `追加效果：持续伤害 威力：M`（每跳）");
    W("- **纯持续型**（占星烧灼系、学者毒菌系）：`对目标附加持续伤害状态 威力：M` —— 这个数**就是每跳**，没有直伤");
    W();
    W("档位写法 `85/65` = 两档威力（低等级 / 高等级）。总伤按**最高档**算，跳跃间隔 3 秒。");
    W();
    W("| 职业 | 等级 | id | 技能 | 形态 | 直伤 | 每跳 | 持续 | 总伤(高档) |");
    W("|---|---|---|---|---|---|---|---|---|");
    foreach (var j in jobs)
        foreach (var x in 全.Where(x => x.Job == j && 是DoT(x.Desc)).OrderBy(x => int.Parse(x.Lv)))
        {
            var gs = x.Pow.Split('|', StringSplitOptions.RemoveEmptyEntries);
            var 直 = 是直伤型DoT(x.Desc);
            var s = 时长秒(x.Dur);
            string 直档, 跳档, tot;
            if (gs.Length == 0) { 直档 = "—"; 跳档 = "—"; tot = "—"; }
            else if (直 && gs.Length > 1)
            {
                直档 = gs[0]; 跳档 = gs[1];
                tot = s > 0 ? (高档(直档) + 高档(跳档) * (s / 3)).ToString() : "?";
            }
            else
            {
                直档 = "0"; 跳档 = gs[0];
                tot = s > 0 ? (高档(跳档) * (s / 3)).ToString() : "?";
            }
            W($"| {j} | {x.Lv} | {x.Id} | {名(x.Name, x.Raw)} | {(直 ? "有直伤" : "纯持续")} | {直档} | {跳档} | {s}s | **{tot}** |");
        }
    W();
    W("> 跳跃间隔按 3 秒算。白魔天辉 / 学者蛊毒法 / 占星焚灼 / 贤者均衡注药 的数值在 CN 数据里是空的，");
    W("> 所以它们的总伤算不出来（**不是 0**，别当成弱**）**。");
    W();

    W("### 1.4 治疗技能恢复力一览");
    W();
    W("| 职业 | 等级 | id | 技能 | 类型 | 恢复力 | MP | 复唱 | 充能 |");
    W("|---|---|---|---|---|---|---|---|---|");
    foreach (var j in jobs)
        foreach (var x in 全.Where(x => x.Job == j &&
                            (x.Heal.Length > 0 || x.Missing == "★缺" || x.Desc.Contains("防护罩") || x.Desc.Contains("完全恢复")))
                            .OrderBy(x => int.Parse(x.Lv)))
            W($"| {j} | {x.Lv} | {x.Id} | {名(x.Name, x.Raw)} | {(x.Recast == "2.5" ? "GCD" : "能力技")} | {(x.Heal.Length > 0 ? x.Heal.Replace("|", " + ") : "—")} | {x.MP} | {x.Recast}s | {x.Charge} |");
    W();
    W("---");
    W();

    // ---------------- 逐职业明细 ----------------
    W("## 二、逐职业明细");
    W();
    foreach (var j in jobs)
    {
        W($"### {j}");
        W();
        W("**输出 / 附带伤害**");
        W();
        W("| 等级 | id | 技能 | 类型 | 威力 | MP | 复唱 | 充能 |");
        W("|---|---|---|---|---|---|---|---|");
        foreach (var x in 全.Where(x => x.Job == j && (x.Desc.Contains("攻击") || x.Pow.Length > 0))
                            .OrderBy(x => int.Parse(x.Lv)))
        {
            var 类型 = x.Recast == "2.5" ? (是DoT(x.Desc) ? "DoT" : "GCD") : "能力技";
            W($"| {x.Lv} | {x.Id} | {名(x.Name, x.Raw)} | {类型} | {数(x.Pow)} | {x.MP} | {x.Recast}s | {x.Charge} |");
        }
        W();
        W("**治疗 / 护盾 / HoT**");
        W();
        W("| 等级 | id | 技能 | 类型 | 恢复力 | MP | 复唱 | 充能 |");
        W("|---|---|---|---|---|---|---|---|");
        foreach (var x in 全.Where(x => x.Job == j &&
                            (x.Heal.Length > 0 || x.Missing == "★缺" || x.Desc.Contains("防护罩") || x.Desc.Contains("完全恢复")))
                            .OrderBy(x => int.Parse(x.Lv)))
            W($"| {x.Lv} | {x.Id} | {名(x.Name, x.Raw)} | {(x.Recast == "2.5" ? "GCD" : "能力技")} | {(x.Heal.Length > 0 ? x.Heal.Replace("|", " + ") : "—")} | {x.MP} | {x.Recast}s | {x.Charge} |");
        W();
    }

    W("---");
    W();

    // ---------------- 缺口 ----------------
    W("## 三、仍取不到数值的（如果有）");
    W();
    var 缺 = 全.Where(x => (x.Pow.Length == 0 && x.Desc.Contains("威力")) || x.Missing == "★缺").ToList();
    if (缺.Count == 0)
    {
        W("**没有。** 全部 117 条 PvE 技能的威力 / 恢复力都已从游戏数据取到，并与 wiki 核对一致。");
        W();
        W("唯一不进表的是**天赐祝福（140）**这类：「令目标体力完全恢复」，本身就没有威力数值，");
        W("它在治疗逻辑里的意义是\"直接把 HP 设为 100%\"（见 `对照分析-治疗逻辑.md` 附录 A 的「必须奶满」机制）。");
    }
    else
    {
        W("| 职业 | 等级 | 技能 | 缺什么 |");
        W("|---|---|---|---|");
        foreach (var x in 缺.OrderBy(x => x.Job).ThenBy(x => int.Parse(x.Lv)))
        {
            var a = x.Pow.Length == 0 && x.Desc.Contains("威力");
            var b = x.Missing == "★缺";
            W($"| {x.Job} | {x.Lv} | {x.Name} | {(a ? "伤害威力" : "")}{(a && b ? " + " : "")}{(b ? "恢复力" : "")} |");
        }
    }
    W();
    W("> 说明：贤者伤害技（注药 / 发炎 / 失衡 / 箭毒系列）说明里的「恢复力」是**心关**给目标回的血，不是技能本身的治疗。");
    W();
    W("---");
    W();
    W("## 四、对 HealerACR 的意义");
    W();
    W("1. **不影响现有治疗逻辑** —— 我们的治疗决策全部基于血量阈值 / buff / 资源数量，没有一处依赖恢复力数值，");
    W("   所以上面的缺口**不阻塞**任何现有功能。");
    W("2. **对输出循环有用**：§1.1 / §1.2 可以核对 `SpellIds` + `取已解锁()` 的等级链有没有取错档位。");
    W("3. **DoT 总伤（§1.3）** 可以核对 `JobSpellTable.Dot技能` 的候选顺序 —— 若高等级档位总伤反而更低，就是顺序写反了。");
    W("4. MP 那一列（已按 `PrimaryCostType` 过滤、并 ×100）可以核对 `蓝量.停手阈值 = 2000` 这个红线：");
    W("   白魔医养 1000 MP / 愈疗 1500 MP，低蓝时连两发都放不出来 —— 阈值定在 2000 是合理的。");
    W("5. 缺口里的基础 GCD 治疗要补的话，**只从游戏内说明抄**，不要凭记忆写进注释 ——");
    W("   这与 `开发约定.md` ⑧「断章取义地引用文档」是同一类风险。");
    W();

    File.WriteAllLines("奶妈技能威力.md", md, Encoding.UTF8);
    Console.WriteLine($"\n生成 {md.Count} 行 -> 奶妈技能威力.md");
}

return 0;
