"""★ 全量崩溃防护审计 ★

═══ 为什么需要它（而不是逐点修）═══
  本项目连续 12+ 次崩溃，**每次都是同一个模式**：
      "读一个可能已被释放的游戏对象" ==> 原生访问违例 ==> 进程直接没。
  逐点修 = 每次堵一个洞，下次从别处漏（实测：修了 10 轮还在崩）。

  ==> 正确做法：**把"安全的必要条件"全部机检一遍**，一次列出所有缺口。

═══ 检什么（6 项，每项对应一类真实崩溃）═══
  ① 参数含游戏对象、读属性、但函数内无 `对象有效()`   —— 第 7~12 次崩溃
  ② `foreach` 遍历队伍列表后只判 null（不判有效性）   —— 第 7、8 次
  ③ `ClassJob.Value` / `StatusList` 读取前未判有效性  —— 第 6 次
  ④ 守卫返回值类型错（void 里 return null / 值类型 return null）—— 脚本事故
  ⑤ 形参列表 == 实参列表的自递归（栈溢出，症状同样是"进程直接没"）—— `调试窗.画()` 真踩过
  ⑥ `对象有效()` 实现唯一且三项判据齐全（哨兵 0x12345679 / 64KB 下限 / 内核区上限）

[!] 所有检查**只报真问题**：做过误报收敛（比如函数级而非行级判守卫），
   否则报告太长就没人看了。
"""
import pathlib
import re
import sys

R = pathlib.Path(__file__).resolve().parent.parent
文件s = [f for f in list((R / "HealerACR").rglob("*.cs")) + list((R / "BlueWhale.AutoHealerACR").rglob("*.cs"))
         if not ({"obj", "bin", ".scratch"} & set(f.parts))]

读属性 = re.compile(
    r"\.(CurrentHp|MaxHp|CurrentMp|MaxMp|Position|StatusList|IsDead|IsTargetable|Name|Level|"
    r"GameObjectId|HitboxRadius|ShieldPercentage|ClassJob)\b|"
    r"HasAura\s*\(|HasAnyAura\s*\(|血量比例\s*\(|有效血量比例\s*\("
)

失败 = []
打印 = print


def 段(s):
    return "\n".join(x.split("//")[0] for x in s if not x.strip().startswith("///"))


# ══ ① 参数含游戏对象 -> 必须自己判 ══
打印("=" * 100)
打印("  ① 参数含游戏对象、读属性、但函数内无 对象有效()")
打印("=" * 100)
n = 0
for f in 文件s:
    try:
        ls = f.read_text(encoding="utf-8", errors="replace").split("\n")
    except Exception:
        continue
    for k, l in enumerate(ls):
        m = re.match(r"\s*(?:public|private|internal|protected)\s+(?:static\s+)?[\w<>\[\],.\s?]+\s+(\w+)\s*\(([^)]*)\)\s*$", l)
        if not m or "IBattleChara" not in m.group(2):
            continue
        深 = 0
        起 = False
        止 = k
        for j in range(k + 1, min(len(ls), k + 300)):
            码 = ls[j].split("//")[0]
            深 += 码.count("{") - 码.count("}")
            if "{" in 码:
                起 = True
            if 起 and 深 == 0:
                止 = j
                break
        体 = 段(ls[k:止 + 1])
        if 读属性.search(体) and "对象有效" not in 体:
            n += 1
            打印("  [!!] {}:{}  {}({})".format(f.name, k + 1, m.group(1), m.group(2).strip()[:44]))
            失败.append("①")
打印("  -> {} 个函数".format(n))
打印()

# ══ ② 队伍列表遍历的守卫 ══
打印("=" * 100)
打印("  ② 遍历队伍列表后有 对象有效() 守卫")
打印("=" * 100)
n = 0
for f in 文件s:
    try:
        ls = f.read_text(encoding="utf-8", errors="replace").split("\n")
    except Exception:
        continue
    for k, l in enumerate(ls):
        if "PartyHelper." not in l.split("//")[0]:
            continue
        后 = 段(ls[k:min(len(ls), k + 60)])
        if "foreach" not in 后:
            continue
        if "对象有效" not in 后:
            n += 1
            打印("  [!!] {}:{}".format(f.name, k + 1))
            失败.append("②")
打印("  -> {} 处".format(n))
打印()

# ══ ③ ClassJob.Value / StatusList ══
打印("=" * 100)
打印("  ③ ClassJob.Value / StatusList 读取前判有效性")
打印("=" * 100)
n = 0
for f in 文件s:
    try:
        ls = f.read_text(encoding="utf-8", errors="replace").split("\n")
    except Exception:
        continue
    for k, l in enumerate(ls):
        码 = l.split("//")[0]
        if "ClassJob.Value" not in 码 and ".StatusList" not in 码:
            continue
        上 = 段(ls[max(0, k - 4):k + 1])
        if "对象有效" not in 上:
            n += 1
            打印("  [!!] {}:{}  {}".format(f.name, k + 1, 码.strip()[:76]))
            失败.append("③")
打印("  -> {} 处".format(n))
打印()

# ══ ④ 守卫返回值类型 ══
打印("=" * 100)
打印("  ④ 守卫返回值类型")
打印("=" * 100)
n = 0
for f in 文件s:
    try:
        ls = f.read_text(encoding="utf-8", errors="replace").split("\n")
    except Exception:
        continue
    for k, l in enumerate(ls):
        if "对象有效()" not in l or "if (" not in l:
            continue
        mret = re.search(r"return\s+([^;]+);", l)
        if not mret:
            continue
        给 = mret.group(1).strip()
        签名 = ""
        for j in range(k, max(-1, k - 14), -1):
            m2 = re.match(r"\s*(?:public|private|internal|protected)\s+(?:static\s+)?([\w<>\[\],.\s?]+?)\s+(\w+)\s*\(", ls[j])
            if m2:
                签名 = m2.group(1).strip()
                break
        if "void" in 签名 and 给 != "null":
            n += 1
            打印("  [!!] {}:{}  void 里 return {};".format(f.name, k + 1, 给))
            失败.append("④")
        if ("Vector3" in 签名 or "int" in 签名 or "uint" in 签名 or "float" in 签名) and 给 == "null":
            n += 1
            打印("  [!!] {}:{}  {} 里 return null;".format(f.name, k + 1, 签名))
            失败.append("④")
打印("  -> {} 处".format(n))
打印()

# ══ ⑤ 真自递归 ══
打印("=" * 100)
打印("  ⑤ 形参列表 == 实参列表 的自递归（栈溢出）")
打印("=" * 100)
n = 0
for f in 文件s:
    try:
        ls = f.read_text(encoding="utf-8", errors="replace").split("\n")
    except Exception:
        continue
    for k, l in enumerate(ls):
        m = re.match(r"\s*(?:public|private|internal|protected)\s+(?:static\s+)?[\w<>\[\],.\s?]+\s+(\w+)\s*\(([^)]*)\)\s*$", l)
        if not m:
            continue
        名, 参 = m.group(1), m.group(2).strip()
        # [!] **必须确认这条签名行真的是一个方法定义** ——
        #    否则参数里的类型名会被误当成函数名。
        #    实测误报：`按形状选最优(uint 技能Id, ...)` 里的 `uint 技能Id`
        #    被解析成"函数名 = 是直线技能"，于是 `是直线技能(uint 技能Id)`
        #    看起来就像在调用自己。
        #    精确判据：**这个方法名必须不是某个参数的类型名**。
        参数类型名s = {x.strip().split()[0] for x in 参.split(",") if len(x.strip().split()) >= 2}
        if 名 in 参数类型名s:
            continue
        # 而且参数列表不能以类型名开头（`uint 技能Id` 这种）
        if 参 and re.match(r"^(uint|int|float|bool|string|byte|long|double)\s", 参):
            continue
        形 = [x.strip().split()[-1] for x in 参.split(",") if x.strip()]
        if not 形:
            continue
        深 = 0
        起 = False
        止 = k
        for j in range(k + 1, min(len(ls), k + 300)):
            码 = ls[j].split("//")[0]
            深 += 码.count("{") - 码.count("}")
            if "{" in 码:
                起 = True
            if 起 and 深 == 0:
                止 = j
                break
        for j in range(k + 1, 止):
            码 = ls[j].split("//")[0]
            m2 = re.search(r"(?<![\w.])" + re.escape(名) + r"\s*\(([^)]*)\)", 码)
            if not m2 or "new " + 名 in 码:
                continue
            实 = [x.strip() for x in m2.group(1).split(",") if x.strip()]
            # [!] 形参名 == 实参名【还不能断定是自递归】——
            #    必须确认那一行的函数名**就是当前这个方法名**（不是同文件里
            #    另一个函数在调用它）。实测误报：`按形状选最优` 里调 `是直线技能`，
            #    被错判成"是直线技能 调用了自己"。
            if 实 == 形 and re.match(r"\s*(?:public|private|internal|protected)\s", ls[j]) is None:
                n += 1
                打印("  [!!] {}:{}  {}({}) 调用自己".format(f.name, j + 1, 名, 参[:40]))
                失败.append("⑤")
                break
打印("  -> {} 处".format(n))
打印()

# ══ ⑥ 对象有效() 实现 ══
打印("=" * 100)
打印("  ⑥ 对象有效() 实现唯一 + 三项判据")
打印("=" * 100)
实现 = [f for f in 文件s if "bool 对象有效(" in f.read_text(encoding="utf-8", errors="replace")]
if len(实现) != 1:
    n = 1
    打印("  [!!] 有 {} 份实现（应为 1）".format(len(实现)))
    失败.append("⑥")
else:
    t = 实现[0].read_text(encoding="utf-8", errors="replace")
    段文 = t.split("bool 对象有效(")[1][:3000]
    缺 = []
    if "0x12345679" not in 段文:
        缺.append("哨兵 0x12345679")
    if not re.search(r"0x10000|65536", 段文, re.I):
        缺.append("64KB 下限")
    if not re.search(r"0x7FFFFFFF", 段文, re.I):
        缺.append("内核区上限")
    n = len(缺)
    if 缺:
        打印("  [!!] 缺：{}".format("、".join(缺)))
        失败.append("⑥")
    else:
        打印("  [OK] {} 里三项判据齐全".format(实现[0].name))
打印()

# ══ ⑦ 把游戏对象交给【外部库】之前必须验有效性 ══
#
#   [!] 这是第 13 次崩溃才找到的一类 —— **最隐蔽的一类**：
#        我们自己的代码可以靠"读之前判"防住；
#        但一旦把对象**交给 AEAssist / Dalamud 的函数**，防线就断了 ——
#        它们不知道我们的哨兵约定（已释放对象 = 0x12345679，**不是 null**），
#        会直接读内存 ==> **原生访问违例发生在外部库的函数体里**
#        ==> 我们的 try/catch 和全局异常钩子**全都在它外面**，
#            所以连续 12 轮排查里钩子一次都没触发。
#
#   实测路径：采可选技能 -> 群攻命中数 -> 周围敌人数量
#             -> TargetHelper.GetNearbyEnemyCount(t, ...)  <- 崩在这里面
#
#   [!] 规则：调用点在传参之前判 `对象有效()`。
打印("=" * 100)
打印("  ⑦ 传给外部库(AEAssist/Dalamud)的游戏对象是否先验有效性")
打印("=" * 100)
外部API = re.compile(
    r"(TargetHelper\.GetNearbyEnemyCount|TargetHelper\.IsBoss|"
    r"MemApiSpell\.\w*LineOfSight|MemApiBuff\.\w+|"
    r"AI\.Instance\.BattleData\.\w+|ObjectTable\.\w+)"
)
n = 0
for f in 文件s:
    try:
        ls = f.read_text(encoding="utf-8", errors="replace").split("\n")
    except Exception:
        continue
    for k, l in enumerate(ls):
        码 = l.split("//")[0]
        m = 外部API.search(码)
        if not m:
            continue
        # 只看"把对象当参数传出去"的调用（参数以对象变量名开头）
        尾 = 码.split(m.group(0), 1)[1]
        if not re.search(r"\(\s*(t|目标|敌人|我|c|r|施法目标|优选敌人)\b", 尾):
            continue
        上 = 段(ls[max(0, k - 14):k + 1])
        if "对象有效" not in 上:
            n += 1
            打印("  [!!] {}:{}  {}".format(f.name, k + 1, 码.strip()[:82]))
            失败.append("⑦")
打印("  -> {} 处".format(n))
打印()

# ══ ⑧ 读游戏 API 的采集只能从主线程驱动 ══
#
#   [!] 这里修过两次，判据跟着结构走了两版：
#        v1: `采集()` 里必须判 `在主线程()`
#        v2（现在）: **`采集()` 已经不再采集了** —— 它只读缓存。
#                    真正采集的是 `主线程刷新缓存()`（由每帧回调驱动），
#                    所以判据改成查**那一个函数**里有没有主线程判定 + 互斥。
#
#   [!] 为什么这么改（日志证据）：
#        原结构下 AI 层和主线程**都在线程 2** 上跑采集，而且会**交错** ——
#        日志里 `3342` 打印在 `3347` 之后，而源码里 `3342` 在 `3346` 之前。
#        ==> 两个采集流程共享中间状态 ==> 在半初始化状态下互读 ==> 崩。
#        ==> 修法是"**采集只有一个驱动者**，其他人只读缓存"。
打印("=" * 100)
打印("  ⑧ 采集只有一个主线程驱动者（其他人只读缓存）")
打印("=" * 100)
n = 0
for f in 文件s:
    try:
        t2 = f.read_text(encoding="utf-8", errors="replace")
    except Exception:
        continue
    if "public static string 采集(" not in t2:
        continue

    # ① 采集() 必须【只读缓存】—— 不能再调 采集_主线程()
    #
    #  [!] **必须去掉注释再判**：说明性注释里会写到 `采集_主线程(快照)` 这个名字，
    #     直接搜字符串会误报（实测踩过一次）。
    段采集 = t2.split("public static string 采集(")[1].split("private static string 采集_主线程(")[0]
    段采集 = "\n".join(x.split("//")[0] for x in 段采集.split("\n"))
    if "采集_主线程(" in 段采集:
        n += 1
        打印("  [!!] {}: `采集()` 里直接调了 `采集_主线程()` —— 应该只读缓存".format(f.name))
        失败.append("⑧")

    # ② 必须存在 主线程刷新缓存()，且里面有 主线程判定
    if "public static void 主线程刷新缓存(" not in t2:
        n += 1
        打印("  [!!] {}: 缺少 `主线程刷新缓存()` —— 没有采集驱动者".format(f.name))
        失败.append("⑧")
    else:
        段刷新 = t2.split("public static void 主线程刷新缓存(")[1][:3000]
        if "在主线程()" not in 段刷新:
            n += 1
            打印("  [!!] {}: `主线程刷新缓存()` 没有主线程判定".format(f.name))
            失败.append("⑧")
        if "lock" not in 段刷新:
            n += 1
            打印("  [!!] {}: `主线程刷新缓存()` 没有互斥锁".format(f.name))
            失败.append("⑧")

    # ③ 缓存读取点必须在（否则拿不到局面）
    if "取主线程缓存" not in t2:
        n += 1
        打印("  [!!] {}: 没有 `取主线程缓存()` —— 采集结果没消费方".format(f.name))
        失败.append("⑧")

if n == 0:
    打印("  [OK] `采集()` 只读缓存；`主线程刷新缓存()` 有主线程判定 + 锁 —— 唯一驱动者")
    打印("       （AI 层永远不碰游戏 API，也不与任何人共享采集中间状态）")
打印()

# ══ ⑨ `Core.Me` 的读取必须有 null 判定 ══
#
#   [!] 这是**第 17 次崩溃的崩点**：
#        路标精确停在 `HealTargetHelper.可治疗队友()` 的
#            `var 我 = Core.Me.Position;`
#        ==> 队友都判了 `对象有效()`，**偏偏自己的 `Core.Me` 没判**。
#
#   [!] 为什么致命：`Core.Me` 在**换图 / 登录 / 过场**时可以是 null，
#        而它的属性（Position / CurrentHp / Level / ClassJob ...）是
#        **Dalamud 的原生 getter** —— null 上调用 = **原生访问违例**
#        ==> 崩在 Dalamud 内部 ==> 无转储 / 无托管异常 / 全局钩子不触发。
#
#   [!] 规则：所有 `Core.Me.X` 读取都要有 null 判定，
#        或走 `CharacterExt` 里的安全入口（我的位置 / 我的当前血量 / ...）。
打印("=" * 100)
打印("  ⑨ Core.Me 读取有 null 判定（或走安全入口）")
打印("=" * 100)
n = 0
for f in 文件s:
    try:
        ls = f.read_text(encoding="utf-8", errors="replace").split("\n")
    except Exception:
        continue
    for k, l in enumerate(ls):
        if l.strip().startswith("//") or l.strip().startswith("///"):
            continue
        码 = l.split("//")[0]
        if not re.search(r"Core\.Me\s*\.", 码):
            continue
        邻 = "\n".join(x.split("//")[0] for x in ls[max(0, k - 6):k + 1])
        if ("Core.Me == null" in 邻) or ("Core.Me != null" in 邻) or ("Core.Me?." in 邻):
            continue
        n += 1
        打印("  [!!] {}:{}  {}".format(f.name, k + 1, 码.strip()[:78]))
        失败.append("⑨")
if n == 0:
    打印("  [OK] 所有 Core.Me 读取都有 null 判定，或走 CharacterExt 的安全入口")
    打印("       （换图/登录时 Core.Me 可以是 null，而它的属性是原生 getter）")
打印()

# ══ ⑩ 所有 .ps1 必须带 UTF-8 BOM ══
#
#   [!] 实测踩过：用脚本改写 `tools\发布打包.ps1` 时把 BOM 弄丢了，
#       于是 PowerShell 按 GBK 读它 ==> 中文注释全变乱码 ==>
#       **整个脚本语法错误**，而报的错是"意外的标记 xxx"，和真实原因毫不相干。
#
#   [!] 规则：本仓库的 `.ps1` 一律带 UTF-8 BOM（`EF BB BF`）。
打印("=" * 100)
打印("  ⑩ .ps1 文件带 UTF-8 BOM（PowerShell 靠它识别 UTF-8）")
打印("=" * 100)
n = 0
for f in list((R / "tools").glob("*.ps1")) + list(R.glob("*.ps1")):
    try:
        头 = f.read_bytes()[:3]
    except Exception:
        continue
    if 头 != b"\xef\xbb\xbf":
        n += 1
        打印("  [!!] {} 缺 UTF-8 BOM —— PowerShell 会按 GBK 读，中文全乱".format(f.name))
        失败.append("⑩")
if n == 0:
    打印("  [OK] 全部 .ps1 都带 BOM")
打印()

# ══ H 开发约定 H：AI 层代码不许回调自己的钩子 ══
#
#   [!] 这是**连续 22 次崩溃的根因**：
#        `AiSituation.采集()` 读 `HealSettings.Instance.单体治疗阈值`。
#        那是**属性**，getter 里调 `阈值钩子.应用(...)`，
#        而阈值钩子是 **AI 层自己挂的**（`AiThresholdAdapter.挂载()`）。
#        ==> 采集流程回调进 AI 层自己的代码 = **重入**
#            ==> 半初始化状态下重入自己 ==> **原生崩溃**
#                （无转储 / 无托管异常 / 全局钩子一次都不触发）
#
#   [!] 实测证据：改读纯字段后，采集**连续跑通 644 次**
#        （`3314` 采集完成 644 次），而之前它**一次都没出现过**。
#
#   [!] 规则：**AI 层目录**里的代码读这些属性时，必须用 `_原始()`。
#        本地层（`HealerACR/`）**不受此限** ——
#        resolver 做决策就该走钩子，AI 的调整正是通过它生效的。
打印("=" * 100)
打印("  H  AI 层【非决策路径】不回调自己的钩子（开发约定 H）")
打印("=" * 100)
会走钩子的属性 = ["群体治疗阈值", "单体治疗阈值", "紧急单奶阈值",
                  "预铺血线", "妖精契约血线", "大招血线"]
n = 0
for f in 文件s:
    # 只看 AI 层
    if "BlueWhale.AutoHealerACR" not in str(f):
        continue
    # [!] **排除 resolver 路径** —— 它们本来就是"做决策的地方"，
    #    走钩子**正是设计意图**（AI 的调整通过钩子生效）。
    #    危险的是**非决策路径**（采集 / 绘制 / 事件回调）读它。
    if "Resolver" in f.name or "Resolver" in str(f):
        continue
    try:
        ls = f.read_text(encoding="utf-8", errors="replace").split("\n")
    except Exception:
        continue
    for k, l in enumerate(ls):
        if l.strip().startswith("//") or l.strip().startswith("///"):
            continue
        码 = l.split("//")[0]
        for a in 会走钩子的属性:
            if re.search(r"HealSettings\.Instance\." + a + r"\b(?!_基础)", 码):
                n += 1
                打印("  [!!] {}:{}  AI 层读了会走钩子的属性 `{}`".format(f.name, k + 1, a))
                打印("        ==> 改用 CharacterExt.{}_原始()".format(a))
                失败.append("H")
if n == 0:
    打印("  [OK] AI 层没有读「会走钩子」的属性 —— 不会回调自己")
    打印("       （本地 resolver 不受此限：它就该走钩子，AI 的调整通过它生效）")
打印()

# ══ 汇总 ══
打印("=" * 100)
if 失败:
    打印("  !! 还有 {} 处缺口：{}".format(len(失败), "、".join(sorted(set(失败)))))
    打印("=" * 100)
    sys.exit(1)
打印("  ★ 全部通过（11 项检查）★")
打印("=" * 100)
