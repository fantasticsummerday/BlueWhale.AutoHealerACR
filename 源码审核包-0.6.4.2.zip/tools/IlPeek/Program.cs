using System.Reflection.Metadata;
using System.Reflection.Metadata.Ecma335;
using System.Reflection.PortableExecutable;
using System.Text;

// IlPeek —— 线性 IL 反汇编（保留分支目标与比较运算符）。
// 比 DllPeek 强的地方：DllPeek 只给"常量集合 + 调用集合"（丢了控制流），
// IlPeek 给出**真实指令顺序 + 分支标签**，因此能看出 if/else 结构与比较方向。
//
// 用法: IlPeek.exe <dll> [类名关键词,逗号分隔] [--list]

var path = args.Length > 0 ? args[0] : "";
var filter = new List<string>();
bool listOnly = false;
for (int a = 1; a < args.Length; a++)
{
    if (args[a] == "--list") { listOnly = true; continue; }
    foreach (var f in args[a].Split(',', StringSplitOptions.RemoveEmptyEntries)) filter.Add(f);
}

if (!File.Exists(path)) { Console.WriteLine($"找不到 {path}"); return 2; }

using var fs = File.OpenRead(path);
using var pe = new PEReader(fs);
var md = pe.GetMetadataReader();
var sb = new StringBuilder();

string 类型全名(EntityHandle h)
{
    try
    {
        if (h.Kind == HandleKind.TypeDefinition)
        {
            var t = md.GetTypeDefinition((TypeDefinitionHandle)h);
            var ns = md.GetString(t.Namespace); var n = md.GetString(t.Name);
            return string.IsNullOrEmpty(ns) ? n : ns + "." + n;
        }
        if (h.Kind == HandleKind.TypeReference)
        {
            var t = md.GetTypeReference((TypeReferenceHandle)h);
            var ns = md.GetString(t.Namespace); var n = md.GetString(t.Name);
            return string.IsNullOrEmpty(ns) ? n : ns + "." + n;
        }
        if (h.Kind == HandleKind.TypeSpecification)
        {
            var ts = md.GetTypeSpecification((TypeSpecificationHandle)h);
            var b = md.GetBlobBytes(ts.Signature);
            return 解签名(b);
        }
    }
    catch { }
    return null;
}

// 极简签名解码：够用于打印参数类型名
string 解签名(byte[] b)
{
    try
    {
        int i = 0;
        var s = new StringBuilder();
        void T()
        {
            if (i >= b.Length) return;
            byte e = b[i++];
            switch (e)
            {
                case 0x01: s.Append("void"); break;
                case 0x02: s.Append("bool"); break;
                case 0x03: s.Append("char"); break;
                case 0x04: s.Append("sbyte"); break;
                case 0x05: s.Append("byte"); break;
                case 0x06: s.Append("short"); break;
                case 0x07: s.Append("ushort"); break;
                case 0x08: s.Append("int"); break;
                case 0x09: s.Append("uint"); break;
                case 0x0A: s.Append("long"); break;
                case 0x0B: s.Append("ulong"); break;
                case 0x0C: s.Append("float"); break;
                case 0x0D: s.Append("double"); break;
                case 0x0E: s.Append("string"); break;
                case 0x1C: s.Append("object"); break;
                case 0x1D:
                    {
                        // SZARRAY
                        T(); s.Append("[]"); break;
                    }
                case 0x0F:
                    {
                        T(); s.Append("*"); break;
                    }
                case 0x15:
                    {
                        var h = MetadataTokens.EntityHandle(解压缩(b, ref i));
                        s.Append(类型全名(h) ?? "?");
                        s.Append('<');
                        int n = 解压缩(b, ref i);
                        for (int k = 0; k < n; k++) { if (k > 0) s.Append(','); T(); }
                        s.Append('>');
                        break;
                    }
                case 0x11:
                case 0x12:
                    {
                        var h = MetadataTokens.EntityHandle(解压缩(b, ref i));
                        s.Append(类型全名(h) ?? "?");
                        break;
                    }
                case 0x13:
                    {
                        var n = 解压缩(b, ref i);
                        s.Append('!').Append(n);
                        break;
                    }
                case 0x1E:
                    {
                        var n = 解压缩(b, ref i);
                        s.Append('!').Append(n);
                        break;
                    }
                default: s.Append($"<e{e:x2}>"); break;
            }
        }
        T();
        return s.ToString();
    }
    catch { return "?"; }
}

// 压缩整数（ECMA-335 II.23.2）
int 解压缩(byte[] b, ref int i)
{
    byte f = b[i++];
    if ((f & 0x80) == 0) return f;
    if ((f & 0xC0) == 0x80) return ((f & 0x3F) << 8) | b[i++];
    if ((f & 0xE0) == 0xC0) { int v = ((f & 0x1F) << 24) | (b[i] << 16) | (b[i + 1] << 8) | b[i + 2]; i += 3; return v; }
    return ((f & 0x0F) << 28) | (b[i] << 24) | (b[i + 1] << 16) | (b[i + 2] << 8) | b[i + 3];
}

string 解析Token(int token, out bool isType)
{
    isType = false;
    try
    {
        var h = MetadataTokens.EntityHandle(token);
        if (h.IsNil) return null;
        switch (h.Kind)
        {
            case HandleKind.MethodDefinition:
                {
                    var m = md.GetMethodDefinition((MethodDefinitionHandle)h);
                    var t = md.GetTypeDefinition(m.GetDeclaringType());
                    return $"{md.GetString(t.Name)}.{md.GetString(m.Name)}";
                }
            case HandleKind.MemberReference:
                {
                    var mr = md.GetMemberReference((MemberReferenceHandle)h);
                    var 名 = md.GetString(mr.Name);
                    var 父 = 类型全名(mr.Parent) ?? "";
                    var 短 = 父.Contains('.') ? 父.Substring(父.LastIndexOf('.') + 1) : 父;
                    if (短.Contains('`')) 短 = 短.Substring(0, 短.IndexOf('`'));
                    return 短.Length > 0 ? $"{短}.{名}" : 名;
                }
            case HandleKind.MethodSpecification:
                {
                    var ms = md.GetMethodSpecification((MethodSpecificationHandle)h);
                    return 解析Token(MetadataTokens.GetToken(ms.Method), out _) + "<T>";
                }
            case HandleKind.FieldDefinition:
                {
                    var f = md.GetFieldDefinition((FieldDefinitionHandle)h);
                    var t = md.GetTypeDefinition(f.GetDeclaringType());
                    return $"{md.GetString(t.Name)}.{md.GetString(f.Name)}";
                }
            case HandleKind.TypeDefinition:
            case HandleKind.TypeReference:
            case HandleKind.TypeSpecification:
                isType = true;
                return 类型全名(h);
        }
    }
    catch { }
    return $"tok(0x{token:x8})";
}

var 单字节 = new Dictionary<byte, string>
{
    [0x00]="nop",[0x01]="break",[0x02]="ldarg.0",[0x03]="ldarg.1",[0x04]="ldarg.2",[0x05]="ldarg.3",
    [0x06]="ldloc.0",[0x07]="ldloc.1",[0x08]="ldloc.2",[0x09]="ldloc.3",
    [0x0A]="stloc.0",[0x0B]="stloc.1",[0x0C]="stloc.2",[0x0D]="stloc.3",
    [0x0E]="ldarg.s",[0x0F]="ldarga.s",[0x10]="starg.s",[0x11]="ldloc.s",[0x12]="ldloca.s",[0x13]="stloc.s",
    [0x14]="ldnull",[0x15]="ldc.i4.m1",[0x16]="ldc.i4.0",[0x17]="ldc.i4.1",[0x18]="ldc.i4.2",[0x19]="ldc.i4.3",
    [0x1A]="ldc.i4.4",[0x1B]="ldc.i4.5",[0x1C]="ldc.i4.6",[0x1D]="ldc.i4.7",[0x1E]="ldc.i4.8",
    [0x1F]="ldc.i4.s",[0x20]="ldc.i4",[0x21]="ldc.i8",[0x22]="ldc.r4",[0x23]="ldc.r8",
    [0x25]="dup",[0x26]="pop",[0x27]="jmp",[0x28]="call",[0x29]="calli",[0x2A]="ret",
    [0x2B]="br.s",[0x2C]="brfalse.s",[0x2D]="brtrue.s",[0x2E]="beq.s",[0x2F]="bge.s",[0x30]="bgt.s",
    [0x31]="ble.s",[0x32]="blt.s",[0x33]="bne.un.s",[0x34]="bge.un.s",[0x35]="bgt.un.s",[0x36]="ble.un.s",[0x37]="blt.un.s",
    [0x38]="br",[0x39]="brfalse",[0x3A]="brtrue",[0x3B]="beq",[0x3C]="bge",[0x3D]="bgt",
    [0x3E]="ble",[0x3F]="blt",[0x40]="bne.un",[0x41]="bge.un",[0x42]="bgt.un",[0x43]="ble.un",[0x44]="blt.un",
    [0x45]="switch",[0x46]="ldind.i1",[0x47]="ldind.u1",[0x48]="ldind.i2",[0x49]="ldind.u2",[0x4A]="ldind.i4",
    [0x4B]="ldind.u4",[0x4C]="ldind.i8",[0x4D]="ldind.i",[0x4E]="ldind.r4",[0x4F]="ldind.r8",[0x50]="ldind.ref",
    [0x51]="stind.ref",[0x52]="stind.i1",[0x53]="stind.i2",[0x54]="stind.i4",[0x55]="stind.i8",[0x56]="stind.r4",[0x57]="stind.r8",
    [0x58]="add",[0x59]="sub",[0x5A]="mul",[0x5B]="div",[0x5C]="div.un",[0x5D]="rem",[0x5E]="rem.un",
    [0x5F]="and",[0x60]="or",[0x61]="xor",[0x62]="shl",[0x63]="shr",[0x64]="shr.un",[0x65]="neg",[0x66]="not",
    [0x67]="conv.i1",[0x68]="conv.i2",[0x69]="conv.i4",[0x6A]="conv.i8",[0x6B]="conv.r4",[0x6C]="conv.r8",
    [0x6D]="conv.u4",[0x6E]="conv.u8",[0x6F]="callvirt",[0x70]="cpobj",[0x71]="ldobj",[0x72]="ldstr",
    [0x73]="newobj",[0x74]="castclass",[0x75]="isinst",[0x76]="conv.r.un",[0x79]="unbox",[0x7A]="throw",
    [0x7B]="ldfld",[0x7C]="ldflda",[0x7D]="stfld",[0x7E]="ldsfld",[0x7F]="ldsflda",[0x80]="stsfld",
    [0x81]="stobj",[0x8C]="box",[0x8D]="newarr",[0x8E]="ldlen",[0x8F]="ldelema",
    [0x90]="ldelem.i1",[0x91]="ldelem.u1",[0x92]="ldelem.i2",[0x93]="ldelem.u2",[0x94]="ldelem.i4",
    [0x95]="ldelem.u4",[0x96]="ldelem.i8",[0x97]="ldelem.i",[0x98]="ldelem.r4",[0x99]="ldelem.r8",[0x9A]="ldelem.ref",
    [0x9B]="stelem.i",[0x9C]="stelem.i1",[0x9D]="stelem.i2",[0x9E]="stelem.i4",[0x9F]="stelem.i8",
    [0xA0]="stelem.r4",[0xA1]="stelem.r8",[0xA2]="stelem.ref",[0xA3]="ldelem",[0xA4]="stelem",[0xA5]="unbox.any",
    [0xB3]="conv.ovf.i1",[0xB4]="conv.ovf.u1",[0xB5]="conv.ovf.i2",[0xB6]="conv.ovf.u2",[0xB7]="conv.ovf.i4",
    [0xB8]="conv.ovf.u4",[0xB9]="conv.ovf.i8",[0xBA]="conv.ovf.u8",[0xC2]="refanyval",[0xC3]="ckfinite",
    [0xC6]="mkrefany",[0xD0]="ldtoken",[0xD1]="conv.u2",[0xD2]="conv.u1",[0xD3]="conv.i",[0xD4]="conv.ovf.i",
    [0xD5]="conv.ovf.u",[0xD6]="add.ovf",[0xD7]="add.ovf.un",[0xD8]="mul.ovf",[0xD9]="mul.ovf.un",
    [0xDA]="sub.ovf",[0xDB]="sub.ovf.un",[0xDC]="endfinally",[0xDD]="leave",[0xDE]="leave.s",[0xDF]="stind.i",[0xE0]="conv.u",
};

var 双字节 = new Dictionary<byte, string>
{
    [0x00]="arglist",[0x01]="ceq",[0x02]="cgt",[0x03]="cgt.un",[0x04]="clt",[0x05]="clt.un",
    [0x06]="ldftn",[0x07]="ldvirtftn",[0x09]="ldarg",[0x0A]="ldarga",[0x0B]="starg",
    [0x0C]="ldloc",[0x0D]="ldloca",[0x0E]="stloc",[0x0F]="localloc",[0x11]="endfilter",
    [0x12]="unaligned.",[0x13]="volatile.",[0x14]="tail.",[0x15]="initobj",[0x16]="constrained.",
    [0x17]="cpblk",[0x18]="initblk",[0x19]="no.",[0x1A]="rethrow",[0x1C]="sizeof",[0x1D]="refanytype",[0x1E]="readonly.",
};

// 分支/比较运算符的可读化
var 比较名 = new Dictionary<string, string>
{
    ["ceq"]="==", ["cgt"]=">", ["cgt.un"]=">(un)", ["clt"]="<", ["clt.un"]="<(un)",
    ["beq"]="==", ["bne.un"]="!=", ["bge"]=">=", ["bgt"]=">", ["ble"]="<=", ["blt"]="<",
    ["bge.un"]=">=(un)", ["bgt.un"]=">(un)", ["ble.un"]="<=(un)", ["blt.un"]="<(un)",
    ["beq.s"]="==", ["bne.un.s"]="!=", ["bge.s"]=">=", ["bgt.s"]=">", ["ble.s"]="<=", ["blt.s"]="<",
    ["bge.un.s"]=">=(un)", ["bgt.un.s"]=">(un)", ["ble.un.s"]="<=(un)", ["blt.un.s"]="<(un)",
};

var 类清单 = new List<(string 全名, TypeDefinitionHandle 句柄)>();
foreach (var th in md.TypeDefinitions)
{
    var t = md.GetTypeDefinition(th);
    var tn = md.GetString(t.Name);
    if (tn.StartsWith("<")) continue;
    var ns = md.GetString(t.Namespace);
    var full = string.IsNullOrEmpty(ns) ? tn : $"{ns}.{tn}";
    if (filter.Count > 0 && !filter.Any(f => full.Contains(f, StringComparison.OrdinalIgnoreCase))) continue;
    类清单.Add((full, th));
}

if (listOnly)
{
    foreach (var (full, _) in 类清单) Console.WriteLine(full);
    return 0;
}

foreach (var (full, th) in 类清单)
{
    var t = md.GetTypeDefinition(th);
    var 方法块 = new List<string>();

    foreach (var mh in t.GetMethods())
    {
        var m = md.GetMethodDefinition(mh);
        if (m.RelativeVirtualAddress == 0) continue;
        var mn = md.GetString(m.Name);
        if (mn.StartsWith("get_") || mn.StartsWith("set_") || mn.StartsWith("<")) continue;

        byte[] il;
        try { il = pe.GetMethodBody(m.RelativeVirtualAddress).GetILBytes(); }
        catch { continue; }
        if (il == null || il.Length == 0) continue;

        var 行 = new List<string>();
        int i = 0;
        while (i < il.Length)
        {
            int 起始 = i;
            byte op = il[i++];
            string 名; int 操作数 = 0; string 文本 = null;
            try
            {

            if (op == 0xFE)
            {
                byte op2 = il[i++];
                名 = 双字节.TryGetValue(op2, out var n2) ? n2 : $"<fe{op2:x2}>";
                if (名 is "ldarg" or "ldarga" or "starg" or "ldloc" or "ldloca" or "stloc")
                {
                    操作数 = BitConverter.ToUInt16(il, i); i += 2;
                    文本 = 操作数.ToString();
                }
                else if (名 is "ldftn" or "ldvirtftn" or "initobj" or "constrained." or "sizeof")
                {
                    操作数 = BitConverter.ToInt32(il, i); i += 4;
                    文本 = 解析Token(操作数, out _);
                    if (名 == "constrained.") 文本 = "(" + 文本 + ")";
                }
                else if (名 is "unaligned." or "no.")
                {
                    文本 = il[i].ToString(); i += 1;
                }
            }
            else if (单字节.TryGetValue(op, out var n1))
            {
                名 = n1;
                switch (op)
                {
                    case 0x1F: 文本 = ((sbyte)il[i]).ToString(); i += 1; break;
                    case 0x20: 操作数 = BitConverter.ToInt32(il, i); 文本 = 操作数.ToString(); i += 4; break;
                    case 0x21: 文本 = BitConverter.ToInt64(il, i).ToString(); i += 8; break;
                    case 0x22: 文本 = BitConverter.ToSingle(il, i).ToString("0.###"); i += 4; break;
                    case 0x23: 文本 = BitConverter.ToDouble(il, i).ToString("0.###"); i += 8; break;
                    case 0x0E: case 0x0F: case 0x10: case 0x11: case 0x12: case 0x13:
                        文本 = il[i].ToString(); i += 1; break;
                    case 0x2B: case 0x2C: case 0x2D: case 0x2E: case 0x2F: case 0x30:
                    case 0x31: case 0x32: case 0x33: case 0x34: case 0x35: case 0x36: case 0x37:
                    case 0xDE:
                        {
                            var rel = (sbyte)il[i]; i += 1;
                            操作数 = i + rel;
                            文本 = $"L{操作数:x4}";
                            break;
                        }
                    case 0x38: case 0x39: case 0x3A: case 0x3B: case 0x3C: case 0x3D:
                    case 0x3E: case 0x3F: case 0x40: case 0x41: case 0x42: case 0x43: case 0x44:
                    case 0xDD:
                        {
                            var rel = BitConverter.ToInt32(il, i); i += 4;
                            操作数 = i + rel;
                            文本 = $"L{操作数:x4}";
                            break;
                        }
                    case 0x45:
                        {
                            int cnt = BitConverter.ToInt32(il, i); i += 4;
                            var tgt = new List<string>();
                            for (int k = 0; k < cnt; k++)
                            {
                                var rel = BitConverter.ToInt32(il, i); i += 4;
                                tgt.Add($"L{i + rel:x4}");
                            }
                            文本 = string.Join(",", tgt);
                            break;
                        }
                    case 0x28: case 0x6F: case 0x73: case 0x72: case 0x74: case 0x75:
                    case 0x7B: case 0x7C: case 0x7D: case 0x7E: case 0x7F: case 0x80:
                    case 0x81: case 0x8C: case 0x8D: case 0x8F: case 0xA5: case 0xD0: case 0x79:
                        {
                            操作数 = BitConverter.ToInt32(il, i); i += 4;
                            if (op == 0x72)
                            {
                                try
                                {
                                    var h2 = MetadataTokens.UserStringHandle(操作数 & 0x00FFFFFF);
                                    var s = md.GetUserString(h2);
                                    文本 = "\"" + (s.Length > 70 ? s.Substring(0, 70) + "…" : s) + "\"";
                                }
                                catch { 文本 = "?"; }
                            }
                            else if (op == 0x8C || op == 0x8D || op == 0x74 || op == 0x75)
                            {
                                文本 = 解析Token(操作数, out _);
                            }
                            else 文本 = 解析Token(操作数, out _);
                            break;
                        }
                    case 0x70: case 0x71: 操作数 = BitConverter.ToInt32(il, i); i += 4; 文本 = 解析Token(操作数, out _); break;
                    default: break;
                }
            }
            else { 名 = $"<{op:x2}>"; }
            }
            catch { break; }   // IL 尾部截断 / 操作数越界 → 放弃该方法剩余部分

            var 备注 = "";
            if (比较名.TryGetValue(名, out var cmp)) 备注 = $"   ; {cmp}";

            var 行文本 = $"    IL_{起始:x4}:  {名}{(文本 != null ? "  " + 文本 : "")}{备注}";
            行.Add(行文本);
        }

        if (行.Count == 0) continue;
        var head = $"  --- {mn} ({(m.Attributes)}) ---";
        方法块.Add(head);
        方法块.AddRange(行);
    }

    if (方法块.Count > 0)
    {
        sb.AppendLine($"\n### {full}");
        foreach (var l in 方法块) sb.AppendLine(l);
    }
}

File.WriteAllText(Path.ChangeExtension(path, null) + ".il.txt", sb.ToString(), new UTF8Encoding(false));
Console.WriteLine($"已写出: {Path.ChangeExtension(path, null)}.il.txt  ({sb.Length} chars)");
Console.WriteLine("提示: 类名过滤参数可缩小输出，例如  IlPeek.exe a.dll \"WhiteMage,Dot\"");
return 0;
