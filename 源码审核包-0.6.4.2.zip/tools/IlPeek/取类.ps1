param(
    [Parameter(Mandatory=$true)][string]$File,
    [Parameter(Mandatory=$true)][string]$Class,
    [int]$MaxLines = 400
)
# 从 IlPeek 输出里抽出某个类的完整 IL 块
$lines = Get-Content -LiteralPath $File -Encoding UTF8
$out = New-Object System.Collections.Generic.List[string]
$on = $false
foreach ($l in $lines) {
    if ($l -like '### *') {
        if ($on) { break }
        if ($l.Substring(4).Trim() -eq $Class) { $on = $true; $out.Add($l); continue }
    }
    elseif ($on) { $out.Add($l) }
}
if ($out.Count -eq 0) { "## 未找到类: $Class"; exit 1 }
if ($out.Count -gt $MaxLines) {
    $out[0..($MaxLines-1)]
    "## ...(截断，共 $($out.Count) 行；用 -MaxLines 调整)"
} else { $out }
