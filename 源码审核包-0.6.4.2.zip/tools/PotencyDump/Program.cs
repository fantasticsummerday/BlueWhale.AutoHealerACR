using System.Text;
using Lumina;
using Lumina.Data;

// 导出四奶 + 秘术/幻术的**伤害技威力**（按等级档位）。
//
// 为什么要它：判断"用哪个填充技"必须看**实际威力**，
// 不能凭印象。之前我就是凭印象说"破阵法 600 > 毁坏 500"，
// 结果从没验证过 —— 这个工具给出权威数据。
//
// 威力在 `ActionTransient` 表里（`Action` 表只有形状/射程，没有威力）。
//
// 用法: PotencyDump.exe "D:\FF14\最终幻想XIV\game" 输出前缀

Console.OutputEncoding = Encoding.UTF8;

var root = args.Length > 0 ? args[0] : @"D:\FF14\最终幻想XIV\game";
var prefix = args.Length > 1 ? args[1] : "pow";

var candidates = new List<string>();
foreach (var c in root.Split(';', StringSplitOptions.RemoveEmptyEntries))
{
    if (Directory.Exists(c)) candidates.Add(c);
    var sub = Path.Combine(c, "sqpack");
    if (Directory.Exists(sub)) candidates.Add(sub);
}

GameData data = null;
foreach (var path in candidates)
{
    try
    {
        data = new GameData(path, new LuminaOptions { DefaultExcelLanguage = Language.ChineseSimplified });
        Console.WriteLine($"OK {path}");
        break;
    }
    catch (Exception e)
    {
        Console.WriteLine($"   {path}: {e.Message}");
    }
}

if (data == null) return 2;

var actions = data.Excel.GetSheet<Lumina.Excel.Sheets.Action>();
var trans = data.Excel.GetSheet<Lumina.Excel.Sheets.ActionTransient>();

var jobName = new Dictionary<uint, string>
{
    [6] = "幻术", [26] = "秘术", [24] = "白魔", [28] = "学者", [33] = "占星", [40] = "贤者",
};

// ActionTransient 按 RowId 对齐 Action
var 威力表 = new Dictionary<uint, string>();
foreach (var t in trans)
{
    string s;
    try { s = t.Description.ToString(); } catch { continue; }
    if (string.IsNullOrWhiteSpace(s)) continue;
    威力表[t.RowId] = s;
}

var lines = new List<string> { "Id\tJob\tLevel\tCastType\tRecastSec\tName\t说明(含威力)" };
var 详细 = new List<string>();

foreach (var row in actions)
{
    uint job;
    try { job = row.ClassJob.RowId; } catch { continue; }
    if (!jobName.ContainsKey(job)) continue;

    var name = row.Name.ToString();
    if (string.IsNullOrWhiteSpace(name)) continue;

    uint level = 0, recast = 0;
    try { level = row.ClassJobLevel; } catch { }
    try { recast = row.Recast100ms; } catch { }

    var castType = 0;
    try { castType = (int)row.CastType; } catch { }

    var 说明 = 威力表.TryGetValue(row.RowId, out var d) ? d : "";

    lines.Add($"{row.RowId}\t{jobName[job]}\t{level}\t{castType}\t{recast / 10.0:0.0}\t{name}\t{说明.Replace('\n', ' ').Replace('\t', ' ')}");

    // 只要伤害技（说明里含"威力"）
    if (说明.Contains("威力"))
    {
        var 一行 = $"{说明.Replace('\n', ' ').Replace('\t', ' ')}";
        详细.Add($"[{jobName[job]}] Lv{level,-3} id={row.RowId,-6} {name,-14} {一行}");
    }
}

File.WriteAllLines($"{prefix}_potency.tsv", lines, Encoding.UTF8);
Console.WriteLine($"\n导出 {lines.Count - 1} 条 -> {prefix}_potency.tsv");
Console.WriteLine($"其中含威力的 {详细.Count} 条：\n");

foreach (var s in 详细.OrderBy(x => x)) Console.WriteLine("  " + s);

return 0;
