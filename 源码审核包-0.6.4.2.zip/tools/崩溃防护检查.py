"""崩溃防护回归检查 —— 核对本项目**已知的崩溃防护点**是否还在。

═══ 为什么必须机械检查 ═══
  本项目为同一类崩溃（`0xc0000005`）栽过三次，根因是**读已释放对象的内存**：
    · 第一、二次：以为加 `try` / 加 `对象有效()` 就行 —— **原理上无效**
      （访问违例会**穿透 C# 的 catch**；而当时的判据 `Address != IntPtr.Zero`
        被 Dalamud 的释放哨兵 `0x12345679` 放行了，因为哨兵**不是 0**）
    · 第三次：靠崩溃转储里的 `地址: 12345679` 才定位到
  ==> 这些防护点**一旦被谁"顺手重构掉"就会静默复发**，而且只在特定时机崩。
      所以每次发版前机械过一遍。

═══ 用法 ═══
  python tools/崩溃防护检查.py
  退出码 0 = 全部在；1 = 有防护点丢了
"""
import pathlib
import re
import sys

R = pathlib.Path(__file__).resolve().parent.parent


def 读(rel, 子=""):
    p = (R / 子 / rel) if 子 else (R / rel)
    try:
        return p.read_text(encoding="utf-8")
    except Exception:
        return ""


检查 = []

# ① `对象有效()` 的三条范围判据（挡哨兵 + 空指针区 + 内核区）
ce = 读("Common/CharacterExt.cs", "HealerACR")
检查.append(("对象有效()：挡 0x12345679 哨兵", "12345679" in ce, "Dalamud 释放对象的哨兵地址"))
检查.append(("对象有效()：挡 64KB 以下的地址", "0x10000" in ce or "65536" in ce, "空指针区"))
检查.append(("对象有效()：挡内核区地址", "0x7FFFFFFF" in ce or "0x7FFF" in ce, "Windows x64 用户态上界"))

# ② 读 `StatusList` 的地方必须有守卫（那是唯一真的遍历游戏内存的属性）
#    ==> 逐个文件查，而不是只看某一个
#
#  [!] `所有cs` 是**全工程 .cs 清单**，后面几项检查共用（别在每个检查里重扫一遍）
所有cs = [f for f in list((R / "HealerACR").rglob("*.cs")) + list((R / "BlueWhale.AutoHealerACR").rglob("*.cs"))
          if not ({"obj", "bin", ".scratch"} & set(f.parts))]

n_无守卫 = 0
for f in 所有cs:
    if {"obj", "bin", ".scratch"} & set(f.parts):
        continue
    try:
        ls = f.read_text(encoding="utf-8").split("\n")
    except Exception:
        continue
    for k, l in enumerate(ls):
        if "StatusList" not in l.split("//")[0]:
            continue
        # 找所在方法
        起 = 0
        for j in range(k, max(-1, k - 80), -1):
            if re.match(r"\s*(?:private|public|internal|protected)\s+[\w\[\]<>?,.\s]+\s+\w+\s*\([^)]*\)\s*$", ls[j]):
                起 = j
                break
        止 = len(ls)
        for j in range(起 + 1, min(len(ls), 起 + 120)):
            if re.match(r"\s*(?:private|public|internal|protected)\s+[\w\[\]<>?,.\s]+\s+\w+\s*\([^)]*\)\s*$", ls[j]):
                止 = j
                break
        体 = "\n".join(ls[起:止])
        if "对象有效()" not in 体 and "IsValid()" not in 体:
            n_无守卫 += 1
            print("  [!] {}:{}  读 StatusList 但没有对象有效性守卫".format(f.name, k + 1))
检查.append(("读 StatusList 的地方都有对象有效性守卫", n_无守卫 == 0,
             "无守卫 {} 处".format(n_无守卫)))

# ③ `可治疗队友()` 的**三层**加固
#
#   [!] 为什么要三层（每一层都是崩溃换来的）：
#     第 3 次崩溃时只加了"整体预检"（第二层），**没能挡住** ——
#     因为"判完有效"到"读 buff"之间那极窄的窗口依然存在。
#     实际崩溃栈（`dalamud_appcrash_*_154349`）：
#        地址 12345679 -> BattleChara.get_StatusList() -> MemApiBuff.HasAnyAura
#        -> HealerACR.<可治疗队友>b__0_1 -> 伤害预测.预计掉血人数 -> 调试窗.画预测
#     ==> 三层缺一不可：
#           第 0 层：场景可信吗（切图 / 地图 id 为 0）—— 整批不读
#           第 1 层：队伍整体可信吗 —— 有一个失效就整批放弃
#           第 2 层：`可以治()` 里**读之前再判一次** —— 把窗口压到最小
ht = 读("Common/HealTargetHelper.cs", "HealerACR")
ce2 = 读("Common/CharacterExt.cs", "HealerACR")
检查.append(("可治疗队友()：第 0 层【场景可信】判据",
             "IsBetweenAreas" in ht and "实时副本Id" in ht, "切图 / 不在场景 -> 整批不读"))
检查.append(("可治疗队友()：第 1 层【队伍整体预检】", "对象有效()" in ht, "有一个失效就整批放弃"))
# 第 2 层：`可以治()` 里在 `HasAnyAura` **之前**必须有 `对象有效()`
n_治 = 0
if "可以治" in ce2:
    段 = ce2.split("可以治")[1][:1400]
    if "HasAnyAura" in 段:
        前 = 段.split("HasAnyAura")[0]
        if "对象有效()" not in 前:
            n_治 = 1
检查.append(("可以治()：读 buff 之前再判一次有效性", n_治 == 0,
             "把「判完」到「读」的窗口压到最小" if n_治 == 0 else "缺少第二次判定"))

# ④ `ClassJob.Value` 的裸读 —— **这是崩了 6 次才定位到的元凶**
#
#   [!] 崩溃形态：原生访问违例（穿 catch、无转储、全局钩子不触发）
#   [!] 定位方式：两版路标。路标 32「单次尝试() 进入」有、
#       路标 33「局面采集 完成」没有 ==> 崩在 `AiSituation.采集()`；
#       而它 12 个子函数各自整段包了 try，只有 `采自己()` 那行 `ClassJob.Value` 是裸的。
#   [!] 触发时机：**换图后约 1.5 秒重建上下文**（对象还在重建的窗口）
#   [!] 规则：任何 `ClassJob.Value` 读取，**往上 3 行内必须有 `对象有效()`**
n_裸职业 = 0
for f in 所有cs:
    try:
        ls = f.read_text(encoding="utf-8").split("\n")
    except Exception:
        continue
    for k, l in enumerate(ls):
        码 = l.split("//")[0]
        if "ClassJob.Value" not in 码:
            continue
        上 = "\n".join(x.split("//")[0] for x in ls[max(0, k - 3):k + 1])
        if "对象有效" not in 上:
            n_裸职业 += 1
            print("  [!] {}:{}  裸读 ClassJob.Value（上方无 对象有效）".format(f.name, k + 1))
            检查.append(("ClassJob.Value 读取前判对象有效", False, "{}:{}".format(f.name, k + 1)))
if n_裸职业 == 0:
    检查.append(("ClassJob.Value 读取前判对象有效", True, "原生崩溃元凶，已全部加固"))

# ⑤ `foreach` 遍历队伍列表时，守卫必须是 `对象有效()`，不能只判 `null`
#
#   [!] 这是第 7、8 次崩溃的根因：
#        `PartyHelper.CastableAlliesWithin30` 里的成员在**换图/切区**时会被**释放**，
#        但它们**不是 null** —— Dalamud 把地址写成**哨兵 `0x12345679`**。
#        ==> 只判 `null` 就会继续读 `r.MaxHp` / `r.HasAura(...)`（走 StatusList）
#        ==> **原生访问违例**：穿 catch、无转储、全局钩子不触发。
#
#   [!] 规则：`foreach (var r in 队友...)` 之后的**第一个守卫**里必须有 `对象有效()`
n_队卫 = 0
for f in 所有cs:
    try:
        ls = f.read_text(encoding="utf-8").split("\n")
    except Exception:
        continue
    for k, l in enumerate(ls):
        码 = l.split("//")[0]
        if "PartyHelper.CastableAlliesWithin30" not in 码:
            continue
        # 往后 40 行内找 `foreach (... in ...)` 及其后 5 行的守卫
        段 = "\n".join(x.split("//")[0] for x in ls[k:min(len(ls), k + 40)])
        if "foreach" not in 段:
            continue
        后 = "\n".join(x.split("//")[0] for x in ls[k:min(len(ls), k + 60)])
        # 该文件里出现过 `对象有效()` 就算守住（这些列表的消费点只有几处）
        if "对象有效" not in 后:
            n_队卫 += 1
            print("  [!] {}:{}  遍历队伍列表后没有 对象有效() 守卫".format(f.name, k + 1))
if n_队卫 == 0:
    检查.append(("遍历队伍列表时有对象有效性守卫", True, "换图时成员会变哨兵地址，只判 null 挡不住"))
else:
    检查.append(("遍历队伍列表时有对象有效性守卫", False, "{} 处缺守卫".format(n_队卫)))

# ⑥ 候选集里读游戏对象的三个**统一入口**必须有 `对象有效()` 守卫
#
#   [!] 这是第 9 次崩溃的根因（`Log-5148620.log`）：
#        路标 3310「伤害预测 完成」有、3311「采可选技能 完成」**没有**
#        ==> 崩在 `采可选技能()` 里，它第一件事就是 `候选集.描述(快照)`
#        -> 快照为空时走 `生成()` -> 一路读队友/敌人的血量和名字。
#
#   [!] 那三个函数（`血比例` / `最大血` / `名`）原来**只有 try/catch** ——
#       而原生访问违例**穿透 catch**（本项目既定结论），等于没有防线。
#
#   [!] 规则：`候选集.cs` 里这三个函数体内必须有 `对象有效()`
cand = 读("候选集.cs", "BlueWhale.AutoHealerACR")
缺 = []
for 名 in ["血比例", "最大血", "名"]:
    if 名 not in cand:
        continue
    # 取该函数体（从签名到下一个 `private static` 或文件尾）
    try:
        段 = cand.split("static float " + 名 + "(")[1][:600] if 名 != "名" else cand.split("static string 名(")[1][:600]
    except IndexError:
        try:
            段 = cand.split("static string " + 名 + "(")[1][:600]
        except IndexError:
            缺.append(名)
            continue
    if "对象有效" not in 段:
        缺.append(名)
if 缺:
    检查.append(("候选集三个读取入口有对象有效() 守卫", False, "缺：{}".format("、".join(缺))))
else:
    检查.append(("候选集三个读取入口有对象有效() 守卫", True, "血比例 / 最大血 / 名 —— try 挡不住原生违例"))

# ⑦ 全工程：每个**含 `HasAura` 的函数**里必须有 `对象有效()` 守卫
#
#   [!] 为什么按**函数**而不是按**行**判：
#        `HasAura` 走 `StatusList`，但守卫通常是**函数级**的 ——
#        比如 `if (目标 == null || !目标.对象有效()) return false;` 在函数开头判一次，
#        后面整段就都安全了。
#        按行判会产生 38 个误报（全是这种"函数开头判过"的写法），那样检查就没人看了。
#
#   [!] 为什么仍然要查：本项目的崩溃**全部**是"读了没判的对象"，
#        而 `HasAura` 是最早那次转储（`地址: 12345679`）的现场。
#   [!] 只查**参数就是角色对象**的函数 —— 那类必须自卫：
#        它可能被任何地方调用，**不能假设调用方判过**。
#        （纯工具函数如 `AuraIds.有持续伤害(id)` 的调用方都判过，不在此列。）
n_光环 = 0
for f in 所有cs:
    try:
        ls = f.read_text(encoding="utf-8").split("\n")
    except Exception:
        continue
    当前段起 = 0
    for k in range(len(ls) + 1):
        结束 = (k == len(ls)) or bool(re.match(r"\s*(public|private|internal|protected)\s+", ls[k]))
        if not 结束:
            continue
        段文 = ls[当前段起:k]
        段 = "\n".join(x.split("//")[0] for x in 段文)
        # 该函数是否【参数含角色对象】且【调用了 HasAura】
        签名 = 段文[0] if 段文 else ""
        参数是角色 = ("IBattleChara" in 签名) or ("IBattleChara" in 段[:400])
        有光环 = ("HasAura(" in 段 or "HasAnyAura(" in 段) and "bool HasAura" not in 段 and "bool HasAnyAura" not in 段
        if 参数是角色 and 有光环 and "对象有效" not in 段:
            n_光环 += 1
            行 = 当前段起 + next((i for i, x in enumerate(段文) if "HasAura(" in x), 0) + 1
            print("  [!] {}:{}  参数含角色对象、有 HasAura、但整段无 对象有效()".format(f.name, 行))
        当前段起 = k
if n_光环 == 0:
    检查.append(("读 buff 的角色参数函数都自卫", True, "参数就是游戏对象 —— 不能假设调用方判过"))
else:
    检查.append(("读 buff 的角色参数函数都自卫", False, "{} 个函数缺守卫".format(n_光环)))





# ④ 调试窗的三条守卫（防绘制期崩溃）
#    ! 在 `BlueWhale.AutoHealerACR/调试窗.cs`（不在 HealerEntryBase）
调 = 读("调试窗.cs", "BlueWhale.AutoHealerACR")
检查.append(("调试窗：非 IsBetweenAreas", "IsBetweenAreas" in 调, "游戏自己说在切图"))
检查.append(("调试窗：实时副本Id != 0", "实时副本Id" in 调, "不在任何场景"))
检查.append(("调试窗：队伍成员逐个验有效性", "对象有效()" in 调, "队友对象正在重建的窗口"))

# ⑤ 反射调用都要在 try 里（AI 层是反射挂的）
he = 读("Common/HealerEntryBase.cs", "HealerACR")
检查.append(("反射调用包在 try 里", "catch" in he, ""))

# ⑥ 本地层不编译期依赖 AI 层
检查.append(("本地不编译期依赖 BlueWhale",
             "using BlueWhale" not in he, "AI 挂了本地要能独立跑"))

# ⑦ 后台续体会碰的静态集合有锁
bj = 读("候选集.cs", "BlueWhale.AutoHealerACR")
检查.append(("候选集静态集合有锁", "lock" in bj, "读点=后台线程"))

# ⑧ 主坦粘滞（防心关在两个 T 之间来回跳）
检查.append(("主坦有粘滞窗口", "粘滞" in ht, ""))

# ⑨ 版本号后两位一致（发布脚本会校验，这里提前发现）
m1 = re.search(r"<Version>([^<]+)</Version>", 读("HealerACR.csproj", "HealerACR"))
m2 = re.search(r"<Version>([^<]+)</Version>", 读("BlueWhale.AutoHealerACR.csproj", "BlueWhale.AutoHealerACR"))
一致 = bool(m1 and m2 and m1.group(1).split(".")[-1] == m2.group(1).split(".")[-1])
检查.append(("两个 csproj 的版本后两位一致", 一致,
             "{} / {}".format(m1.group(1) if m1 else "?", m2.group(1) if m2 else "?")))

print("=" * 92)
print("  崩溃防护回归检查")
print("=" * 92)
坏 = 0
for 名, ok, 备注 in 检查:
    print("  [{}] {:<40} {}".format("OK" if ok else "!!", 名, 备注))
    if not ok:
        坏 += 1
print()
print("  ==> {} / {} 通过".format(len(检查) - 坏, len(检查)))
if 坏:
    print("  ! 有防护点丢失 —— 那些是**用崩溃换来的**，别删。见各处的长注释。")
sys.exit(0 if 坏 == 0 else 1)
