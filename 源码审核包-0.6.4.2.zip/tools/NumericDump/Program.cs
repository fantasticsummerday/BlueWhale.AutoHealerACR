using System.Text;
using System.Text.RegularExpressions;
using Lumina;
using Lumina.Data;

// 全表导出**机制数值**：ActionId -> 名字 / 读条 / 威力 / 恢复力 / 是否 DoT。
//
// ══════════════════════════════════════════════════════════════════
//  为什么需要它（用户需求：把数值接进伤害预测）
// ══════════════════════════════════════════════════════════════════
//  现在的 `伤害预测.cs` **没有威力概念**：
//      · cactbot 时间轴只给"名字 + 时机"，没有量级
//      · 观察值要等打过一次，而且含当时的减伤
//      · wiki 只有散文（"伤害1k左右"）
//  => 所以开局必然空白，只能"记下来再反解"。
//
//  而官表**有真实威力** —— 在 `ActionTransient.Description` 里
//  （`Action` 表只有形状/射程/复唱，没有威力；这个坑之前踩过）。
//  ⇒ 有了这张表，"机制伤害"就能**开打前**算出来。
//
// ══════════════════════════════════════════════════════════════════
//  与 `tools/PotencyDump` 的区别
// ══════════════════════════════════════════════════════════════════
//  · PotencyDump  只导**四奶 + 秘术/幻术**，用来判断"用哪个填充技"
//  · 本工具导**全表**（Boss 技能也在里面）—— 因为要预测的是**挨打**
//    另外把中文说明**解析成数值列**，便于机器读取（散文没法直接算）
//
//  [!] `Cast100ms` / `Recast100ms` 的单位是**厘秒**（1/100 秒）——
//      换算成秒是 `/10.0`，不是 `/100.0`。
//      我第一次写成 /100，得到"读条 0.22 秒"，明显不对：
//      一个需要读条的 AOE 不可能 0.22 秒。
//      （0.22 秒那个数量级的是**复唱**，不是读条。）
//
//  用法: NumericDump.exe "D:\FF14\最终幻想XIV\game" 输出前缀
//
//  [!] 本版本 Lumina 里 `Action` **没有 DamageType 列**（实测 DLL 里
//      该符号出现 0 次）—— 所以伤害类型从说明文本判断，不硬依赖。
//  [!] 威力/恢复力是**档位值**，这里取第一组；完整说明也原样保留。

Console.OutputEncoding = Encoding.UTF8;

var root = args.Length > 0 ? args[0] : @"D:\FF14\最终幻想XIV\game";
var prefix = args.Length > 1 ? args[1] : "num";

var candidates = new List<string>();
foreach (var c in root.Split(';', StringSplitOptions.RemoveEmptyEntries))
{
    if (Directory.Exists(c)) candidates.Add(c);
    var sub = Path.Combine(c, "sqpack");
    if (Directory.Exists(sub)) candidates.Add(sub);
}

GameData data = null;
foreach (var path in candidates)
{
    try
    {
        data = new GameData(path, new LuminaOptions { DefaultExcelLanguage = Language.ChineseSimplified });
        Console.WriteLine($"OK {path}");
        break;
    }
    catch (Exception e)
    {
        Console.WriteLine($"   {path}: {e.Message}");
    }
}

if (data == null) return 2;

var actions = data.Excel.GetSheet<Lumina.Excel.Sheets.Action>();
var trans = data.Excel.GetSheet<Lumina.Excel.Sheets.ActionTransient>();

var 说明表 = new Dictionary<uint, string>();
foreach (var t in trans)
{
    string s;
    try { s = t.Description.ToString(); } catch { continue; }
    if (string.IsNullOrWhiteSpace(s)) continue;
    说明表[t.RowId] = s;
}

// ══════════════════════════════════════════════════════════════
//  从中文说明里抽数值
//
//  [!] 只认**明确标注**的写法，抽不到就留空 ——
//      宁可少一列，也不要给上层一个假数字（假数值会直接
//      变成错误的减伤决策，比"没有数据"更糟）。
//
//  写法样例：
//      「对目标发动土属性魔法攻击　威力：140」
//      「恢复目标的体力　恢复力：300」
//      「威力：50　追加效果：风属性持续伤害　威力：30　持续时间：30秒」
//      -> 第一组是直伤，第二组是 DoT；用是否出现"持续伤害"区分
// ══════════════════════════════════════════════════════════════
var 威力头 = new Regex(@"威力[：:]\s*(\d+)");
var 恢复头 = new Regex(@"恢复力[：:]\s*(\d+)");

// ══════════════════════════════════════════════════════════════
//  ★ 新增 MP 列（3.19.34）★
//
//  [!] 为什么（用户实测）：
//      "本地一直在打破阵法，ai建议毁灭 这是对的，因为毁灭少用100蓝"
//      而原来的输出**没有 MP 列** => 无法判定"谁的蓝耗更低"。
//
//  [!] 列名是**反射探出来的**，不是猜的：
//        PrimaryCostType   (Byte)    —— 消耗类型（1 = MP）
//        PrimaryCostValue  (UInt16)  —— 消耗量
//      （探法：`build/apicheck` 列出 Action 表全部 74 个属性。）
//
//  [!] 只认 `PrimaryCostType == 1` —— 其它消耗类型（技力等）
//      的值混进来会让"蓝耗"这一列变成**假数据**，
//      而假数据比没有数据更糟（会直接导致错误的技能取舍）。
// ══════════════════════════════════════════════════════════════
var lines = new List<string>
{
    "Id\tName\tCastType\tCastSec\tRecastSec\tRange\tEffectRange\tPotency\tHealPotency\tIsDot\tIsMagic\tMP\t说明"
};

int 有威力 = 0, 有恢复 = 0, 有读条 = 0, 有MP = 0, 总 = 0;

foreach (var row in actions)
{
    var name = "";
    try { name = row.Name.ToString(); } catch { continue; }
    if (string.IsNullOrWhiteSpace(name)) continue;

    var castType = 0; try { castType = (int)row.CastType; } catch { }
    var cast100 = 0u; try { cast100 = row.Cast100ms; } catch { }
    var recast100 = 0u; try { recast100 = row.Recast100ms; } catch { }
    var range = 0f; try { range = row.Range; } catch { }
    var effRange = 0f; try { effRange = row.EffectRange; } catch { }

    var 说明 = 说明表.TryGetValue(row.RowId, out var d) ? d : "";
    var 平 = 说明.Replace('\n', ' ').Replace('\r', ' ').Replace('\t', ' ');

    var 威力 = ""; var 恢复 = "";
    var mw = 威力头.Match(平);
    if (mw.Success) { 威力 = mw.Groups[1].Value; 有威力++; }
    var mh = 恢复头.Match(平);
    if (mh.Success) { 恢复 = mh.Groups[1].Value; 有恢复++; }

    var 是Dot = 平.Contains("持续伤害");
    var 是魔法 = 平.Contains("魔法攻击") || 平.Contains("魔法伤害");
    if (cast100 > 0) 有读条++;

    // ★ MP 消耗 —— 只认 PrimaryCostType == 1（MP）
    var mp = "";
    try
    {
        if (row.PrimaryCostType == 1 && row.PrimaryCostValue > 0)
        {
            mp = row.PrimaryCostValue.ToString();
            有MP++;
        }
    }
    catch { }

    总++;

    lines.Add(string.Join('\t',
        row.RowId, name, castType, (cast100 / 10.0).ToString("0.00"),
        (recast100 / 100.0).ToString("0.0"), range.ToString("0"), effRange.ToString("0"),
        威力, 恢复, 是Dot ? "1" : "0", 是魔法 ? "1" : "0", mp, 平));
}

File.WriteAllLines($"{prefix}_numeric.tsv", lines, Encoding.UTF8);

Console.WriteLine($"\n导出 {总} 条 -> {prefix}_numeric.tsv");
Console.WriteLine($"  含威力:   {有威力}");
Console.WriteLine($"  含恢复力: {有恢复}");
Console.WriteLine($"  有读条:   {有读条}");
Console.WriteLine($"  有 MP:    {有MP}");
return 0;
