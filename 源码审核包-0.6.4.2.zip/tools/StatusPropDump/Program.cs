using System;
using System.Linq;
using System.Text;
using Lumina;
using Lumina.Data;

// 导出**游戏自身的状态属性** —— 权威、全量，不需要任何外部数据。
//
// 为什么做这个（实测结论）：
//   从 wiki 抓的"可驱散"只有 50/13010 条（0.4%），基本没用。
//   而 `Lumina.Excel.Sheets.Status` **直接有 `CanDispel` 布尔字段** ——
//   游戏自己就知道哪些状态能驱散，而且是全量 5853 条。
//
// 顺带导出其它对本项目有用的标志：
//   CanDispel   可驱散        -> Res_Esuna 的判据（现在只靠通用 HasCanDispel）
//   IsGaze      视线机制      -> 该背对
//   LockMovement/LockActions 锁移动/锁行动 -> 治疗窗口判断
//   PartyListPriority        队伍列表优先级 -> 该优先照顾谁
//   MaxStacks                最大层数
//
// 用法: StatusPropDump.exe [游戏sqpack目录] [输出前缀]
Console.OutputEncoding = Encoding.UTF8;

var path = args.Length > 0 ? args[0] : @"D:\FF14\最终幻想XIV\game\sqpack";
var prefix = args.Length > 1 ? args[1] : "build/status_props";

GameData data;
try
{
    data = new GameData(path, new LuminaOptions { DefaultExcelLanguage = Language.ChineseSimplified });
}
catch (Exception e)
{
    Console.WriteLine("  打不开游戏数据: " + e.Message);
    return 2;
}

var sheet = data.Excel.GetSheet<Lumina.Excel.Sheets.Status>();

var 行 = new System.Collections.Generic.List<string>
{
    "Id\tName\tCanDispel\tIsGaze\tLockMovement\tLockActions\tMaxStacks\tPartyListPriority\tStatusCategory\tIsPermanent"
};

int 可驱散数 = 0, 视线数 = 0, 锁行动数 = 0, 有名字 = 0;
var 可驱散清单 = new System.Collections.Generic.List<string>();

foreach (var row in sheet)
{
    string 名;
    try { 名 = row.Name.ToString(); } catch { 名 = ""; }
    if (string.IsNullOrWhiteSpace(名)) continue;
    有名字++;

    bool 驱 = false, 视 = false, 锁移 = false, 锁行 = false, 永久 = false;
    byte 层 = 0, 优先 = 0, 类 = 0;
    try { 驱 = row.CanDispel; } catch { }
    try { 视 = row.IsGaze; } catch { }
    try { 锁移 = row.LockMovement; } catch { }
    try { 锁行 = row.LockActions; } catch { }
    try { 永久 = row.IsPermanent; } catch { }
    try { 层 = row.MaxStacks; } catch { }
    try { 优先 = row.PartyListPriority; } catch { }
    try { 类 = row.StatusCategory; } catch { }

    if (驱) { 可驱散数++; 可驱散清单.Add($"    id={row.RowId,-6} {名}"); }
    if (视) 视线数++;
    if (锁行) 锁行动数++;

    行.Add($"{row.RowId}\t{名}\t{驱}\t{视}\t{锁移}\t{锁行}\t{层}\t{优先}\t{类}\t{永久}");
}

System.IO.File.WriteAllLines($"{prefix}.tsv", 行, Encoding.UTF8);

Console.WriteLine($"  有名字的状态  {有名字}");
Console.WriteLine($"  可驱散        {可驱散数}");
Console.WriteLine($"  视线机制      {视线数}");
Console.WriteLine($"  锁行动        {锁行动数}");
Console.WriteLine($"  导出 -> {prefix}.tsv");
Console.WriteLine();
Console.WriteLine($"=== 全部可驱散状态（{可驱散数} 个）===");
foreach (var s in 可驱散清单) Console.WriteLine(s);

return 0;
