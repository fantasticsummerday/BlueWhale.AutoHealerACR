"""从 huijiwiki 抓四个治疗职业的**技能 MP 消耗**。

═══ 为什么需要它 ═══
  `选填充技()` 要按"输出优先、相同才比蓝"取舍（用户规则），
  而 **MP 数据在游戏 `Action` 表里查不到**：
      全表导出 45490 条，只有 11 行有消耗值，**而且全是 Boss 技能**。
  -> 只能从 wiki 取。

═══ 数据在哪（踩过的坑）═══
  · **wikitext 里没有** —— `{{记录项目|id=17869|毁灭}}` 只有 ID
  · **渲染后的 HTML 里有**：
        `技能:17869 毁灭 1级 魔力：300`
    所以必须用 `action=parse&prop=text` 取渲染后的 HTML。
    （我一开始只取 wikitext，白跑了两轮。）

═══ Cloudflare ═══
  站点在 Cloudflare 后面，标准客户端（urllib / curl / Invoke-WebRequest）
  **一律 403**。实测 `cloudscraper`（纯 Python，不需浏览器）可以过 ——
  和 `tools/DutyMechanics/抓机制.py` 用的是同一套。

  用法: python 抓技能MP.py
  输出: build/job_skill_mp.tsv   （职业 / Id / 技能名 / 等级 / MP）

  [!] 跑完之后要重新生成 `HealerACR/Common/技能MP表.cs`（见文件头的对照）。
      游戏大版本更新后重跑一次即可。
"""

import pathlib
import re
import sys
import time
import urllib.parse

try:
    import cloudscraper
except ImportError:
    print("[X] 缺 cloudscraper —— 先装：python -m pip install cloudscraper")
    sys.exit(1)

API = "https://ff14.huijiwiki.com/api.php"

# 仓库根目录（本文件在 tools/JobSkillMP/ 下）
根 = pathlib.Path(__file__).resolve().parents[2]
输出 = 根 / "build" / "job_skill_mp.tsv"

职业页 = {
    "学者": "学者/职业技能",
    "白魔法师": "白魔法师/职业技能",
    "占星术士": "占星术士/职业技能",
    "贤者": "贤者/职业技能",
    "秘术师": "秘术师/职业技能",
    "幻术师": "幻术师/职业技能",
}

# 渲染后文本形如：技能:<ID> <名> <等级>级 魔力：<MP>
样式 = re.compile(r"技能:(\d+)\s+([^\s<>]{2,12})\s+(\d+)级\s+魔力：(\d+)")

_会话 = [None]


def 取会话():
    if _会话[0] is None:
        _会话[0] = cloudscraper.create_scraper()
    return _会话[0]


def 请求(参数, 重试=5):
    url = API + "?" + urllib.parse.urlencode(参数)
    for i in range(重试):
        try:
            r = 取会话().get(url, timeout=45)
            if r.status_code == 200:
                return r.json()
            print("      HTTP {}（第 {} 次）".format(r.status_code, i + 1))
        except Exception as e:
            print("      异常 {}（第 {} 次）".format(e, i + 1))
        time.sleep(1.5 * (i + 1))
    return None


def main() -> int:
    行 = []
    for 职业, 标题 in 职业页.items():
        print()
        print("=" * 80)
        print("  [{}] {}".format(职业, 标题))
        print("=" * 80)

        d = 请求({"action": "parse", "page": 标题, "prop": "text",
                  "format": "json", "disablelimitreport": 1})
        if not d:
            print("  ★ 取不到")
            continue

        try:
            html = d["parse"]["text"]["*"]
        except Exception as e:
            print("  解析失败: {}".format(e))
            continue

        # 去标签，保留空白（正则依赖空格分隔）
        净 = re.sub(r"<[^>]+>", " ", html)
        净 = 净.replace("&#160;", " ").replace("&nbsp;", " ")
        净 = re.sub(r"\s+", " ", 净)

        找到 = 样式.findall(净)
        print("  抓到 {} 个技能".format(len(找到)))
        for cid, 名, 级, mp in 找到:
            行.append((职业, cid, 名, 级, mp))
            print("      {:<7} {:<14} {:>3}级  MP={}".format(cid, 名, 级, mp))

        time.sleep(0.5)

    # 去重（同一技能可能出现在多个职业页，如秘术师/学者都有毁灭）
    去重 = {}
    for 职业, cid, 名, 级, mp in 行:
        k = (cid, 名)
        # 同 ID 多处出现时取**较小的非零 MP**（更保守）
        if k not in 去重 or (int(mp) > 0 and int(mp) < int(去重[k][4])):
            去重[k] = (职业, cid, 名, 级, mp)

    输出.parent.mkdir(parents=True, exist_ok=True)
    with 输出.open("w", encoding="utf-8", newline="\n") as f:
        f.write("职业\tId\t技能名\t等级\tMP\n")
        for v in sorted(去重.values(), key=lambda x: (x[0], int(x[3]))):
            f.write("\t".join(v) + "\n")

    print()
    print("=" * 80)
    print("  共 {} 条（去重后）-> {}".format(len(去重), 输出))
    print("=" * 80)
    print()
    print("  下一步：用这份 TSV 重新生成 HealerACR/Common/技能MP表.cs")
    print("  （对照见该文件的类注释）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
