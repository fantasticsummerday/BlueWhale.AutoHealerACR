using System.Text;
using Lumina;
using Lumina.Data;

// 扫游戏的 Status / TerritoryType 表，回答两类问题：
//   ① 「哪些状态是"必须奶满"类机制」—— 靠**描述文本关键词**反查，不靠印象
//   ② 某个 TerritoryType id 到底是哪张图
//
// 用法: StatusScan.exe [game目录] [模式]
//   模式 = mech   → 扫"奶满/致死"类状态（默认）
//         terr   → 只翻译 YouShu FullHealStatuses 表里的地图 id
//         all    → 两个都做

Console.OutputEncoding = Encoding.UTF8;

var root = args.Length > 0 ? args[0] : @"D:\FF14\最终幻想XIV\game";
var mode = args.Length > 1 ? args[1] : "all";

var candidates = new List<string>();
foreach (var c in root.Split(';', StringSplitOptions.RemoveEmptyEntries))
{
    if (Directory.Exists(c)) candidates.Add(c);
    var sub = Path.Combine(c, "sqpack");
    if (Directory.Exists(sub)) candidates.Add(sub);
}

GameData data = null;
foreach (var path in candidates)
{
    try
    {
        data = new GameData(path, new LuminaOptions { DefaultExcelLanguage = Language.ChineseSimplified });
        Console.WriteLine($"OK 游戏数据: {path}\n");
        break;
    }
    catch (Exception e) { Console.WriteLine($"   {path}: {e.Message}"); }
}
if (data == null) return 2;

// ══════════════════════════════════════════════════════════════════
//  ① 扫 Status 表：找「效果时间结束时 / 未满 / 最大体力」这类描述
// ══════════════════════════════════════════════════════════════════

if (mode is "mech" or "all")
{
    var status = data.Excel.GetSheet<Lumina.Excel.Sheets.Status>();

    // 关键词：只保留**真的和"血量未满就死"有关**的候选，后面人工过一遍
    // 注意 CN 客户端的实际措辞是「陷入无法战斗状态」「恢复量」「倒计时为0」
    string[] 强关键 = { "无法战斗", "战斗不能" };
    string[] 弱关键 = { "未满", "最大体力", "恢复量", "倒计时" };

    var 命中 = new List<(uint Id, string Name, string Desc, string 依据)>();

    foreach (var st in status)
    {
        string 名, 描述;
        try { 名 = st.Name.ToString(); } catch { continue; }
        if (string.IsNullOrWhiteSpace(名)) continue;
        try { 描述 = st.Description.ToString(); } catch { continue; }
        if (string.IsNullOrWhiteSpace(描述)) continue;

        string 依据 = null;
        foreach (var k in 强关键) if (描述.Contains(k)) { 依据 = k; break; }
        if (依据 == null)
            foreach (var k in 弱关键) if (描述.Contains(k)) { 依据 = k; break; }
        if (依据 == null) continue;

        命中.Add((st.RowId, 名, 描述.Replace("\n", " ").Replace("\r", " "), 依据));
    }

    Console.WriteLine($"=== Status 表里含「血量阈值」描述的条目：{命中.Count} 条 ===");
    Console.WriteLine("（关键词命中 ≠ 一定是奶满机制，下面会按描述分两类）\n");

    // 分两类：A = 到期时血量不满足就死；B = 其它（治疗量/回复相关）
    bool 是致死型(string d) => d.Contains("无法战斗") || d.Contains("战斗不能");

    var A = 命中.Where(x => 是致死型(x.Desc)).OrderBy(x => x.Id).ToList();
    var B = 命中.Where(x => !是致死型(x.Desc)).OrderBy(x => x.Id).ToList();

    // ★ D 类 = A 类里「描述同时提到恢复/治疗」的 —— 这就是真正的"必须奶满"机制 ★
    bool 是奶满型(string d) =>
        是致死型(d) && (d.Contains("完全恢复") || d.Contains("恢复量") || d.Contains("体力恢复")
                        || d.Contains("治疗") || d.Contains("恢复至"));
    var D = A.Where(x => 是奶满型(x.Desc)).OrderBy(x => x.Id).ToList();

    Console.WriteLine($"════════ D 类：真正的「必须奶满 / 累计治疗量」机制（{D.Count} 条）════════");
    foreach (var x in D)
        Console.WriteLine($"[{x.Id}] {x.Name}\n      {x.Desc}\n");
    Console.WriteLine($"════════ D 类结束 ════════\n");

    // ★ E 类：不限是否 KO —— 只要描述里提到「恢复到最大 / 完全恢复 / 同等恢复量」就叫奶满型 ★
    //   必要性：塞壬的歌声写的是"变成僵尸"、渐渐石化压根没提 KO，D 类抓不到
    string[] 奶满措辞 = { "完全恢复", "恢复到最大", "恢复至最大", "恢复到最大值", "同等的恢复量", "体力没有恢复",
                          "全满", "体力全满", "体力最大", "满血", "未满", "体力不足", "治疗量达到" };
    var E = new List<(uint Id, string Name, string Desc)>();
    foreach (var st in status)
    {
        string 名, 描述;
        try { 名 = st.Name.ToString(); } catch { continue; }
        if (string.IsNullOrWhiteSpace(名)) continue;
        try { 描述 = st.Description.ToString(); } catch { continue; }
        if (string.IsNullOrWhiteSpace(描述)) continue;
        if (奶满措辞.Any(k => 描述.Contains(k)))
            E.Add((st.RowId, 名, 描述.Replace("\n", " ").Replace("\r", " ")));
    }

    Console.WriteLine($"════════ E 类：描述提到「恢复到最大 / 完全恢复 / 同等恢复量」的全部状态（{E.Count} 条）════════");
    foreach (var x in E.OrderBy(x => x.Id))
        Console.WriteLine($"[{x.Id}] {x.Name}\n      {x.Desc}\n");
    Console.WriteLine($"════════ E 类结束 ════════\n");

    Console.WriteLine($"──────── A 类：效果结束时血量不满足 → 无法战斗（{A.Count} 条）────────");
    foreach (var x in A)
        Console.WriteLine($"[{x.Id}] {x.Name}\n      描述: {x.Desc}\n      命中词: {x.依据}\n");

    // ★ 额外：把 YouShu 表里那 6 个状态 + 我们关心的几个的描述原文全打出来 ★
    Console.WriteLine("──────── C 类：YouShu FullHealStatuses 表用到的状态 —— 描述原文 ────────");
    foreach (var id in new uint[] { 370, 210, 1769, 2303, 11, 1628 })
    {
        try
        {
            var st = status.GetRow(id);
            var d = st.Description.ToString().Replace("\n", " ").Replace("\r", " ");
            Console.WriteLine($"[{id}] {st.Name}\n      描述: {d}\n");
        }
        catch { Console.WriteLine($"[{id}] (读取失败)\n"); }
    }

    Console.WriteLine($"──────── B 类：其它含血量描述的（{B.Count} 条，供排除用）────────");
    foreach (var x in B)
        Console.WriteLine($"[{x.Id}] {x.Name}  |  {x.Desc}   (命中:{x.依据})");

    var 输出 = new List<string> { "类别\tStatusId\tName\t命中词\t描述" };
    foreach (var x in A) 输出.Add($"A致死\t{x.Id}\t{x.Name}\t{x.依据}\t{x.Desc}");
    foreach (var x in B) 输出.Add($"B其它\t{x.Id}\t{x.Name}\t{x.依据}\t{x.Desc}");
    File.WriteAllLines("dump_fullheal.tsv", 输出, Encoding.UTF8);
    Console.WriteLine($"\n导出 -> dump_fullheal.tsv");
}

// ══════════════════════════════════════════════════════════════════
//  ② 翻译 YouShu FullHealStatuses 表里的地图 id
// ══════════════════════════════════════════════════════════════════

if (mode is "terr" or "all")
{
    Console.WriteLine($"\n=== YouShu FullHealStatuses 表里的地图 id ===");
    var terr = data.Excel.GetSheet<Lumina.Excel.Sheets.TerritoryType>();

    // 来自 HealerFullHealTargetSelector..cctor 的 (状态id, 地图id) 对
    var 表 = new (uint Status, uint Terr)[]
    {
        (370, 160), (210, 188),
        (1769, 826), (1769, 973), (1769, 1168), (1769, 1169),
        (1769, 1252), (1769, 1346),
        (2303, 922), (2303, 923),
        (11, 366), (1628, 0),
    };

    var status2 = data.Excel.GetSheet<Lumina.Excel.Sheets.Status>();

    string 状态名(uint id)
    {
        try { return status2.GetRow(id).Name.ToString(); } catch { return "?"; }
    }

    string 地图名(uint id)
    {
        if (id == 0) return "(不限地图)";
        try
        {
            var t = terr.GetRow(id);
            var 地名 = "";
            try { 地名 = t.PlaceName.Value.Name.ToString(); } catch { }
            var 内部 = "";
            try { 内部 = t.Name.ToString(); } catch { }
            return $"{地名}  [{内部}]";
        }
        catch { return "(查不到)"; }
    }

    foreach (var (s, t) in 表)
        Console.WriteLine($"  状态 {s,-6} {状态名(s),-12} 地图 {t,-6} {地图名(t)}");
}

return 0;
