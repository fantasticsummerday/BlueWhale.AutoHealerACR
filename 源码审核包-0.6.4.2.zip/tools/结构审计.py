"""结构审计 —— 一次跑完所有"静态可判定的 bug 模式"。

═══ 为什么要有这个 ═══
  本项目**反复栽在同一批模式上**，而那些模式**大多是静态可判定的**：
    - 算了不用的判据       -> `Res_SingleMitigation` 的盾线 / `Res_HealAmp` 的"要来"
    - 调了拦截没 return    -> （孪生于下面的裸块）
    - 裸块（守卫条件丢了）  -> `AiSuggestionResolver` 的 DoT 守卫（AI 瘫痪 27/30 秒）
    - 同名两套判据          -> `站定填充技` / `当前技能表` / `在移动` vs `移动中能放`
    - 登记了没人读          -> `妖精契约血线`（死设置）
    - 硬编码门槛 / 折扣      -> 群奶人数 `-1`
  这些**每次都是靠"碰巧想起来"才查到的** ==> 应该有一条命令一次全查。

═══ 用法 ═══
  python tools/结构审计.py
  退出码 0 = 全部通过；1 = 有需要人工确认的项（**不是**"一定是 bug"）
"""
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
源码 = []
for f in list((ROOT / "HealerACR").rglob("*.cs")) + \
         list((ROOT / "BlueWhale.AutoHealerACR").rglob("*.cs")):
    if {"obj", "bin", ".scratch"} & set(f.parts):
        continue
    源码.append(f)

def 读(f):
    try:
        return f.read_text(encoding="utf-8").split("\n")
    except Exception:
        return []

问题 = 0

# ══════════════════════════════════════════════════════════════════
#  ① 赋值后从未被读的局部变量（"算了不用"）
# ══════════════════════════════════════════════════════════════════
print("=" * 84)
print("  ① 赋值后从未被读的局部变量")
print("=" * 84)
n = 0
for f in 源码:
    ls = 读(f)
    for k, l in enumerate(ls):
        m = re.match(r"(\s*)(?:private|public|internal|protected)\s+[\w\[\]<>?,.\s]+\s+(\w+)\s*\([^)]*\)\s*$", l)
        if not m:
            continue
        # 收集方法体
        体 = []
        j, 深, 起 = k + 1, 0, False
        while j < len(ls):
            深 += ls[j].count("{") - ls[j].count("}")
            if "{" in ls[j]:
                起 = True
            体.append((j + 1, ls[j]))
            if 起 and 深 <= 0:
                break
            j += 1
        for 行, s in 体:
            mm = re.search(r"\bvar\s+(\w+)\s*=", s.split("//")[0])
            if not mm:
                continue
            变 = mm.group(1)
            之后 = "\n".join(x[1].split("//")[0] for x in 体 if x[0] > 行)
            if re.search(r"\b" + re.escape(变) + r"\b", 之后):
                continue
            print("  ! {}:{}  `{}`".format(f.name, 行, 变))
            n += 1
print("  -> {} 处{}".format(n, "" if n == 0 else "（需人工确认）"))
问题 += n
print()

# ══════════════════════════════════════════════════════════════════
#  ② `拦截(...)` 所在块内没有 return
# ══════════════════════════════════════════════════════════════════
print("=" * 84)
print("  ② `拦截(...)` 所在块内没有 return（守卫不生效）")
print("=" * 84)

def 找块(ls, 行):
    深, 起 = 0, None
    for k in range(行, -1, -1):
        for ch in reversed(ls[k].split("//")[0]):
            if ch == "}":
                深 += 1
            elif ch == "{":
                if 深 == 0:
                    起 = k
                    break
                深 -= 1
        if 起 is not None:
            break
    if 起 is None:
        return None
    深 = 0
    for k in range(起, len(ls)):
        for ch in ls[k].split("//")[0]:
            if ch == "{":
                深 += 1
            elif ch == "}":
                深 -= 1
                if 深 == 0:
                    return (起, k)
    return None

n = 0
for f in 源码:
    ls = 读(f)
    for k, l in enumerate(ls):
        s = l.split("//")[0]
        if not re.search(r"\b拦截\s*\(", s) or re.search(r"(void|private|public|internal)\s+拦截\s*\(", s):
            continue
        块 = 找块(ls, k)
        if 块 is None:
            continue
        段 = "\n".join(x.split("//")[0] for x in ls[块[0]:块[1] + 1])
        if "return" not in 段:
            print("  [X] {}:{}  （块 L{}~{}）".format(f.name, k + 1, 块[0] + 1, 块[1] + 1))
            n += 1
print("  -> {} 处{}".format(n, "（**这些守卫不会中断**）" if n else " [OK]"))
问题 += n
print()

# ══════════════════════════════════════════════════════════════════
#  ③ 裸块（`{` 前面不是控制结构）
# ══════════════════════════════════════════════════════════════════
print("=" * 84)
print("  ③ 裸块（等于无条件执行）")
print("=" * 84)
合法 = re.compile(
    r"(\bif\b|\belse\b|\bwhile\b|\bfor\b|\bforeach\b|\btry\b|\bcatch\b|\bfinally\b|"
    r"\block\b|\busing\b|\bswitch\b|\bdo\b|\bunsafe\b|\bfixed\b|\bchecked\b|\bunchecked\b|"
    r"\bget\b|\bset\b|\binit\b|=>|\bnew\b|\bclass\b|\bstruct\b|\bnamespace\b|"
    r"\binterface\b|\benum\b|\brecord\b|\)\s*$|:\s*\w+\s*$)")
# ★ 属性声明（`public static int X` / `public override 治疗候选集 治疗候选`）也会走到这里，
#   它们的特征：**行里没有 `=`、没有 `(`、以标识符结尾**，且下一行是 `{` 或 `get`。
#   ==> 用"这一行看起来像成员声明"来排除。
成员声明 = re.compile(
    r"^\s*(?:public|private|protected|internal|static|virtual|override|sealed|abstract|"
    r"readonly|partial|new|unsafe|extern|async|\s)+"
    r"[\w\[\]<>?,.\s]+?\s+\w+\s*$")
n = 0
for f in 源码:
    ls = 读(f)
    for k, l in enumerate(ls):
        s = l.split("//")[0].rstrip()
        if not s.strip().endswith("{"):
            continue
        if s.strip() == "{":
            前 = ""
            for j in range(k - 1, max(-1, k - 5), -1):
                t = ls[j].split("//")[0].strip()
                if t:
                    前 = t
                    break
        else:
            前 = s.strip()[:-1].strip()
        if not 前 or 合法.search(前):
            continue
        if 前.endswith(("=", ",", "(", "return", "=>")):
            continue
        # ★ 排除属性/成员声明（`public static int 以太` 这种）
        if 成员声明.match(前):
            # 再看下一行是不是 `get`（属性体）
            下 = ""
            for j in range(k + 1, min(len(ls), k + 3)):
                t = ls[j].split("//")[0].strip()
                if t:
                    下 = t
                    break
            if 下 in ("get", "get;", "get {", "set", "init"):
                continue
        print("  ! {}:{}  前一行: {}".format(f.name, k + 1, 前[:60]))
        n += 1
print("  -> {} 处{}".format(n, "" if n == 0 else "（需人工确认）"))
问题 += n
print()

# ══════════════════════════════════════════════════════════════════
#  ④ 群奶人数折扣（硬编码 `- 1`）
# ══════════════════════════════════════════════════════════════════
print("=" * 84)
print("  ④ 群奶人数折扣（`群奶最少人数 - 1`）")
print("=" * 84)
n = 0
for f in 源码:
    for k, l in enumerate(读(f)):
        if re.search(r"群奶最少人数\s*-\s*1", l.split("//")[0]):
            print("  [X] {}:{}  {}".format(f.name, k + 1, l.strip()[:70]))
            n += 1
print("  -> {} 处{}".format(n, " [OK]" if n == 0 else "（应走 `群疗能力技人数要求()`）"))
问题 += n
print()

# ══════════════════════════════════════════════════════════════════
#  ⑤ 注释说业务语义、代码判"拿不到数据"
# ══════════════════════════════════════════════════════════════════
#  [!] 这个形状的**真案例**（Round 28 修的）：
#        // 已经在场就别再铺（和本地 `Res_HealShield` 的跳过同源）
#        if (SpellUtil.Get(盾Id) == null) continue;
#      `Get()` 是 `id.GetSpell()`，对已解锁技能**恒不为 null**
#      ==> 守卫等于不存在，而注释让人相信它处理过了。
#      它躲过了 ①（不是赋值未读）和 ③（不是裸块），所以单独一条。
#
#  [!] **这个扫描器验证过**（不是"写完就信"）：
#      拿 `git show <修复前的提交>:...候选集.cs` 回放，
#      **修复前命中 1 处、修复后命中 0 处** ==> 判据确实有效。
#      （项目栽过"断言静默失败，看起来像检查过了" —— 所以留这条记录。）
#
#  [!] 判据：条件里出现 `某.Get(...) == null` / `!= null`（= 取**数据对象**），
#      而**前 4 行内的注释**出现业务语义词（在场/已经/重复/存在…）。
#      ==> 两者同时满足 = 高度可疑：注释在讲"状态"，代码在讲"能不能取到对象"。
print("=" * 84)
print("  ⑤ 注释说业务语义、代码判「拿不到数据」")
print("=" * 84)
业务词 = re.compile(r"(在场|已经|已在|还在|重复|别再加|已经有|存在|已上|已铺|挂上|没上|未上)")
取数据 = re.compile(r"(\w+(?:\.\w+)*\.\w*[Gg]et\w*\s*\([^)]*\))\s*(==|!=)\s*null")
n = 0
for f in 源码:
    ls = 读(f)
    for k, l in enumerate(ls):
        s = l.split("//")[0]
        m = 取数据.search(s)
        if not m:
            continue
        注 = ""
        for j in range(k - 1, max(-1, k - 5), -1):
            t = ls[j].strip()
            if t.startswith("//"):
                注 = t + " " + 注
            elif t == "":
                continue
            else:
                break
        if not 注 or not 业务词.search(注):
            continue
        print("  ! {}:{}".format(f.name, k + 1))
        print("        注释: {}".format(注.strip()[:78]))
        print("        代码: {}".format(s.strip()[:74]))
        n += 1
print("  -> {} 处{}".format(n, " [OK]" if n == 0 else "（注释与条件说的不是一件事？）"))
问题 += n
print()

# ══════════════════════════════════════════════════════════════════
#  ⑥ 治疗阈值表：登记了但没有任何 resolver 读的条目（死登记）
# ══════════════════════════════════════════════════════════════════
#  [!] 为什么查：`治疗阈值表` 的读点全都是**运行时才知道是谁**的（`技能` 属性 /
#      `_t.单体盾` 这类槽位），所以"登记了"不等于"读得到"。
#      真案例（本轮）：`庇护所`(3569) 和 `自生`(24288) 登记了、也归了类，
#      但 `Res_GroupHoT.Check` 用的是**硬编码的 `s.群体治疗阈值`**
#      ==> 两条死登记，AI 按"群疗类"调阔/收紧时**这两个技能纹丝不动**。
#
#  [!] 判据（保守，只报"明显没人读"的）：
#      把所有 `治疗阈值表.取(...)` 的**第一实参**收集起来，展开成"可能的技能集合"：
#        · `技能` / `瞬发` 这类属性 -> 收集全工程里同名属性的 `SpellIds.取("X")`
#          （不区分是哪个类 —— 宁可多算，避免误报）
#        · `_t.某槽位` -> 收集 `JobSpellTable` 里那个槽位的覆写值
#      一条登记的技能，如果**既不在上面任何一个集合里**，就报出来。
#
#  [!] **这个检查验证过**：修复前报 `庇护所` / `自生` 两条，修复后那两条消失。
#
#  [!] 但它**现在还会报出十几条**，而那些**不是误报** —— 是**已知的真实缺口**：
#      白魔 / 占星**没有任何 resolver 读 `治疗阈值表`**（学者有 `SCH_*` + `Res_Extra`
#      这一层，白魔/占星没有对应的 per-skill resolver），
#      所以给它们登记的值**只走槽位式读点**（`瞬发单奶能力技` / `群体治疗能力技` …），
#      具体 id 的登记值读不到。
#      ==> 本项现在还**不能当"零即通过"用**；要等白魔/占星补齐 per-skill 读点。
#      ==> 在那之前，报出来的条目请当成"待办清单"看，别当成回归。
print("=" * 84)
print("  ⑥ 治疗阈值表：登记了但没人读的条目")
print("=" * 84)
lt = (ROOT / "HealerACR" / "Common" / "治疗阈值表.cs")
lts = 读(lt)
登记 = []
for l in lts:
    # ! **必须跳过注释行** —— 文档里有 `设(SpellIds.取("xxx"), v)` 这种**示例**
    #    （说明"名字不在 SpellIds 里会怎样"），不跳过就会把它当成一条真登记
    #    并报出"技能 xxx 没人读"这种假警报。（本轮踩过。）
    码 = l.split("//")[0]
    m = re.search(r'设\(SpellIds\.取\("([^"]+)"\)', 码)
    if m:
        登记.append(m.group(1))

# 收集读点
读点属性 = set()      # `技能` / `瞬发` 这类属性名
读点槽位 = set()      # `_t.单体盾` 这类槽位名
for f in 源码:
    ls = 读(f)
    for k, l in enumerate(ls):
        s = l.split("//")[0]
        m = re.search(r"治疗阈值表\.取\(\s*([^,]+),", s)
        if not m:
            continue
        参 = m.group(1).strip()
        if 参.startswith("_t."):
            读点槽位.add(参[3:])
        else:
            读点属性.add(参)

# 展开属性 -> 技能名（全工程搜 `属名 => ... SpellIds.取("X")`，不区分类）
可达 = set()
for f in 源码:
    ls = 读(f)
    for k, l in enumerate(ls):
        for 属 in 读点属性:
            if re.search(r"\b" + re.escape(属) + r"\b\s*(?:=>|\{)", l):
                # 往后 20 行里的技能名都算可达（保守：宁可多算）
                for j in range(k, min(len(ls), k + 20)):
                    for mm in re.finditer(r'SpellIds\.取\("([^"]+)"\)', ls[j]):
                        可达.add(mm.group(1))
                    if ";" in ls[j] and "SpellIds" in ls[j]:
                        break

# 展开槽位 -> 技能名（JobSpellTable / 各职业表的覆写）
#  [!] **必须支持多行** —— 真实的槽位定义经常长这样：
#        `public override uint 紧急单奶 => SpellUtil.取已解锁(`
#        `    SpellIds.取("输血"), SpellIds.取("白牛清汁"), SpellIds.取("灵橡清汁"));`
#      只看单行会漏掉后面两行的技能名，把可达的技能误报成"没人读"。
#      （本轮踩过：`输血` / `白牛清汁` / `灵橡清汁` 被误报。）
for f in 源码:
    ls = 读(f)
    for k, l in enumerate(ls):
        for 槽 in 读点槽位:
            if not re.search(r"\b" + re.escape(槽) + r"\b\s*=>", l):
                continue
            # 从这一行往下拼到第一个 `;`（跨行定义）
            段 = ""
            for j in range(k, min(len(ls), k + 8)):
                段 += ls[j].split("//")[0]
                if ";" in ls[j]:
                    break
            for mm in re.finditer(r'SpellIds\.取\("([^"]+)"\)', 段):
                可达.add(mm.group(1))

# ══════════════════════════════════════════════════════════════════
#  ★ **"遍历治疗候选、按每个技能查表"也算可达**（本轮新增的读法）★
#    形态：`foreach (var c in ...治疗候选...) { ... 治疗阈值表.取(c.Id, ...) }`
#    ==> 凡是登记在职业治疗池里的技能，都能被取到。
#    [!] 加这条是因为本轮给 `Res_HealSingleGcd` 加的就是这种读法 ——
#        不加的话检查**看不见自己的改动**，会继续报那批假警报。
# ══════════════════════════════════════════════════════════════════
for f in 源码:
    ls = 读(f)
    for k, l in enumerate(ls):
        s = l.split("//")[0]
        if not re.search(r"治疗阈值表\.取\(\s*\w+\.Id\b", s):
            continue
        可达.add("__按候选遍历__")

# 如果存在"按候选遍历"的读点，就把各职业治疗池里的技能名也加进可达集
if "__按候选遍历__" in 可达:
    for f in 源码:
        ls = 读(f)
        for k, l in enumerate(ls):
            # `c.加(new 治疗技能 { Id = SpellIds.取("X"), ... })`
            if re.search(r"new\s+治疗技能\s*\{", l):
                for j in range(k, min(len(ls), k + 6)):
                    for mm in re.finditer(r'SpellIds\.取\("([^"]+)"\)', ls[j]):
                        可达.add(mm.group(1))
            # ★ `Res_BigAoEHeal.候选()` —— 也是个**硬编码技能数组**，
            #   而它的读点是 `治疗阈值表.取(id, ...)`（同一个循环变量）
            if re.search(r"private\s+uint\[\]\s+候选\s*\(\s*\)", l) or \
               re.search(r"Jobs\.\w+\s*=>\s*new\[\]", l):
                可达.add("__候选数组__")
    # 把"候选数组"里出现的技能名也算可达（只对**确实有循环读点**的那些）
    for f in 源码:
        ls = 读(f)
        for k, l in enumerate(ls):
            if re.search(r"Jobs\.\w+\s*=>\s*new\[\]", l) or re.search(r"^\s*SpellIds\.取\(\"", l):
                # 只在 Res_BigAoEHeal 那种"候选数组 + 循环读表"的类里算
                for j in range(max(0, k - 30), k):
                    if "治疗阈值表.取(技能" in ls[j] or "治疗阈值表.取(id" in ls[j]:
                        for mm in re.finditer(r'SpellIds\.取\("([^"]+)"\)', l):
                            可达.add(mm.group(1))
                        break



n = 0
for 名 in 登记:
    if 名 in 可达:
        continue
    print("  ! {}  —— 登记了，但没有任何读点能取到它".format(名))
    n += 1
print("  -> {} 条{}".format(n, " [OK]" if n == 0 else "（死登记：AI 调这个技能不生效）"))
问题 += n
print()

# ══════════════════════════════════════════════════════════════════
#  ⑦ 用 `冷却 > 0` 判"是不是能力技"（H13 那个坏谓词）
# ══════════════════════════════════════════════════════════════════
#  [!] 为什么查：本项目**两套打分**曾经对同一个问题用**两个谓词**：
#        `治疗决策` 的 `只要GCD` 用 `是能力技_实际`，
#        而 `候选集` 的 `能力技` 字段 / `本地分` 用 `冷却 > 0f`。
#      H13 的后果：**MP 0 + 冷却 0 的 GCD 技**（白魔 安慰之心 / 狂喜之心）
#      在本地被当能力技、在模型眼里是 GCD ==> 「模型对、本地错」。
#      ==> 现在统一走 `治疗技能.不占GCD`（唯一的转发点）。
#
#  [!] 允许出现的两处例外：
#        · `治疗技能.cs` 里 `是能力技_实际` 的**定义本身**（谓词就写在那里）
#        · `候选集.cs` 里渲染 `CD Ns` 的**显示**（`冷却 > 0.5f`，只是给模型看冷却，不判类型）
print("=" * 84)
print("  ⑦ 用 `冷却 > 0` 判「是不是能力技」")
print("=" * 84)
n = 0
for f in 源码:
    ls = 读(f)
    for k, l in enumerate(ls):
        s = l.split("//")[0]
        if "冷却 > 0" not in s and "冷却>0" not in s:
            continue
        # 例外一：谓词定义本身
        if "是能力技_实际" in s and "=>" in s:
            continue
        # 例外二：候选集渲染 "CD Ns"（显示用，不判类型）
        if "sb.Append" in s and "CD" in s:
            continue
        print("  ! {}:{}  {}".format(f.name, k + 1, s.strip()[:76]))
        n += 1
print("  -> {} 处{}".format(n, " [OK]" if n == 0 else "（应走 `技.不占GCD`）"))
问题 += n
print()

# ══════════════════════════════════════════════════════════════════
#  ⑧ 本地能用的治疗动作，AI 能不能看到（候选池 vs 槽位）
# ══════════════════════════════════════════════════════════════════
#  [!] 为什么查：真案例（Round 34）—— 贤者的 `瞬发单奶能力技` 槽位
#      是 `取已解锁(输血, 白牛清汁, 灵橡清汁)`，而**治疗候选池里没有 `输血`**
#      ==> AI 建议不了它，但本地会用它 ==>
#      **AI 和本地看到的动作集合不一致**（"AI 建议的东西本地不做"的一类成因）。
#
#  [!] **必须分对类**，否则全是假警报（我第一版就把减伤/复活也算进来了）：
#        [治疗池负责] 单体/群体 GCD、紧急单奶、预铺/瞬发单奶能力技、群体治疗能力技
#        [别的 resolver 负责，不在池里是**正确的**]
#            单体盾/群体盾 -> Res_HealShield / Res_GroupShield
#            团队/个人减伤 -> Res_TeamMitigation / Res_SingleMitigation
#            复活 / 驱散   -> 各自的 resolver
#            护盾前置      -> 由 Res_HealShield 自动配（不是独立动作）
#            HoT           -> Res_SingleHoT / Res_GroupHoT
#
#  [!] 已知的**预期**例外（不是缺口，别再报）：
#        `水流幕`(WHM) —— 双角色：盾（在池里，走 单体盾 槽位）+ 预铺单奶
#                          （`Res_InstantHealAbility` 的预铺分支）。不重复进池。
#        `神祝祷`(WHM) —— 双角色：个人减伤 + 单体盾，走减伤/盾那条路。
print("=" * 84)
print("  ⑧ 本地能用的治疗动作，AI 能不能看到")
print("=" * 84)
治疗池槽 = ["单体治疗GCD", "群体治疗GCD", "紧急单奶", "预铺单奶能力技",
            "瞬发单奶能力技", "群体治疗能力技"]
预期例外 = {"水流幕", "神祝祷"}
n = 0
for f in 源码:
    if not f.name.endswith("ACR.cs") or f.name == "ConjurerACR.cs":
        continue
    ls = 读(f)
    池 = set()
    for k, l in enumerate(ls):
        if "new 治疗技能" not in l.split("//")[0]:
            continue
        条 = ""
        for j in range(k, min(len(ls), k + 10)):
            条 += ls[j].split("//")[0]
            if "});" in ls[j]:
                break
        m = re.search(r'SpellIds\.取\("([^"]+)"\)', 条)
        if m:
            池.add(m.group(1))
    if not 池:
        continue
    for k, l in enumerate(ls):
        for 槽 in 治疗池槽:
            if not re.search(r"override\s+uint\s+" + re.escape(槽) + r"\b", l):
                continue
            段 = ""
            for j in range(k, min(len(ls), k + 8)):
                段 += ls[j].split("//")[0]
                if ";" in ls[j]:
                    break
            for 名 in re.findall(r'"([^"]+)"', 段):
                if not 名 or 名 in 池 or 名 in 预期例外:
                    continue
                print("  ! {} — {} 槽位指向它，但它不在治疗候选池里".format(名, 槽))
                n += 1
print("  -> {} 处{}".format(n, " [OK]" if n == 0 else "（AI 建议不了本地会用的动作）"))
问题 += n
print()

print("=" * 84)
print("  汇总：{} 项需要人工确认".format(问题))
print("=" * 84)
sys.exit(0 if 问题 == 0 else 1)
