r"""
从最终幻想XIV中文维基（灰机wiki）抓取**副本机制数据**。

═══ 为什么需要它 ═══
  我们有 cactbot 时间轴，但只覆盖 **286/638（45%）** 个副本 ——
  缺的 352 个几乎全是日随/练级本。

  cactbot 给的是「**什么时候**放」，而 wiki 机制页给的是：
    · 技能名 + **伤害类型**（物理/魔法/特殊/无）  -> 交哪种减伤
    · **有没有读条**                              -> 能不能提前反应
    · **形状**（全屏/扇形/圆形/直线）              -> 该躲哪、算不算范围
    · **附带状态 ID**（{{状态|名|id=N}}）          -> ★ 扩充 AuraIds
    · **是否可驱散**（正文写"可以驱散的X"）        -> ★ 驱散优先级
    · **阶段**（"血量下降至一定程度"、"第一次…"）   -> 战术分段

  => 两者互补：cactbot 管**时机**，wiki 管**内容**。wiki 没有时间轴，别指望它。

═══ 数据结构（已实测）═══
  机制正文在【子页面】：`副本名/1`、`副本名/2` … `副本名/B`（B = 最终 BOSS）
  入口在 `Module:Instance/Page`：expandTemplate({ title = ':' .. 副本名 .. '/' .. link })

  正文形如：
      {{xh|刺尾|物理}}读条结束后对一仇目标发动高伤害物理攻击。
      {{xh|白霜环绕|魔法}}读条结束后，造成全屏范围魔法伤害。
      *第一次：{{xh|低温俯冲|魔法}}对随机方向发动直线范围魔法伤害，
        附加可以驱散的{{状态|冻伤|id=268}}冻伤效果，有范围提示。

═══ [!] Cloudflare ═══
  站点在 Cloudflare 后面，标准客户端（urllib / curl / Invoke-WebRequest）**一律 403**
  并返回挑战页。实测 `cloudscraper`（纯 Python，不需浏览器）可以过。

═══ 用法 ═══
    python tools/DutyMechanics/抓机制.py            # 全量
    python tools/DutyMechanics/抓机制.py --试跑 12   # 只跑前 12 个，验证解析质量

  产出：
    build/wiki_duty_mechanics.tsv   —— 逐条机制
    build/wiki_aura_ids.tsv         —— 状态 ID 汇总（含"可驱散"标注）
    build/wiki_skip.tsv             —— 没有机制页的副本（说明覆盖缺口）
"""

import json
import pathlib
import re
import sys
import time
import urllib.parse

try:
    import cloudscraper
except ImportError:
    print("[X] 缺 cloudscraper —— 先装：python -m pip install cloudscraper")
    sys.exit(2)

ROOT = pathlib.Path(__file__).resolve().parent.parent.parent
API = "https://ff14.huijiwiki.com/api.php"
缓存目录 = ROOT / "build" / "wiki_cache"
缓存目录.mkdir(parents=True, exist_ok=True)

# ══════════════════════════════════════════════════════════════
#  ★ Cloudflare 处理（实测踩的坑）★
#
#  ── 现象 ──
#    原来每次请求都 `create_scraper()` **新建会话**，
#    结果工具前 3 次请求全 403，之后又通 —— 典型的
#    "**挑战还没过就发业务请求**"。
#
#  ── 为什么 probe 能过、工具不能 ──
#    probe 也是一次一建，但请求间隔长（3 秒），挑战来得及过。
#    工具是连续请求（1.2 秒间隔），挑战还没完成就被业务请求打断。
#
#  ── 修法 ──
#    ① **单一会话复用** —— 过一次挑战，Cookie 一直带着
#    ② **首次握手** —— 正式抓之前先打一个 siteinfo 把挑战过掉
#    ③ **403 专项退避** + 遇 403 重建会话（Cookie 可能已过期）
# ══════════════════════════════════════════════════════════════
请求间隔秒 = 1.5
_上次请求 = [0.0]
_会话 = [None]


def 取会话(重建: bool = False):
    if _会话[0] is None or 重建:
        if 重建:
            print("      （重建会话以重过挑战）")
        _会话[0] = cloudscraper.create_scraper()
    return _会话[0]


def 握手():
    """正式抓之前先过一次挑战，避免前几个业务请求吃 403。"""
    d = 请求({"action": "query", "meta": "siteinfo", "format": "json"}, 重试=4)
    if d:
        print("  握手成功：{}".format(d.get("query", {}).get("general", {}).get("sitename", "?")))
        return True
    print("  [X] 握手失败 —— 可能被 CF 拦了，稍后重试或换网络")
    return False


def 请求(参数: dict, 重试: int = 4):
    """打一次 API；带节流 + 退避重试。失败返回 None。"""
    url = API + "?" + urllib.parse.urlencode(参数)
    for 第次 in range(重试):
        等 = 请求间隔秒 - (time.time() - _上次请求[0])
        if 等 > 0:
            time.sleep(等)
        try:
            r = 取会话().get(url, timeout=40)
            _上次请求[0] = time.time()
            if r.status_code == 200:
                return json.loads(r.text)
            if r.status_code == 403:
                # ★ 403 = CF 挑战没过/过期 -> 重建会话并多等一会儿 ★
                print("      HTTP 403（CF 挑战）-> 重建会话后重试")
                取会话(重建=True)
                time.sleep(5.0 * (第次 + 1))
                continue
            print("      HTTP {}".format(r.status_code))
        except Exception as e:
            print("      {} {}".format(type(e).__name__, str(e)[:80]))
        time.sleep(2.5 * (第次 + 1))
    return None


# ══════════════════════════════════════════════════════════════
#  解析
# ══════════════════════════════════════════════════════════════

技能模板 = re.compile(r"\{\{xh\|([^|{}]+)\|([^|{}]*)\}\}")
状态模板 = re.compile(r"\{\{状态\|([^|{}]+)\|id=(\d+)\}\}")

# ══════════════════════════════════════════════════════════════
#  ★ 两种正文格式都要支持（实测发现）★
#
#  格式 A（模板式）—— 较新的页面：
#      {{xh|刺尾|物理}}读条结束后对一仇目标发动高伤害物理攻击。
#
#  格式 B（加粗冒号式）—— 老页面 / 编辑者手写：
#      *'''一万伏特：'''以奥尔特罗斯为圆心的读条圆形aoe，伤害1k左右。
#
#  [!] 只认 A 的话，格式 B 的副本会**整本抓出 0 条** ——
#     而且不报错，看起来像"这个副本没有机制"。
#     实测：邪教驻地无限城古堡 就是 B 式。
# ══════════════════════════════════════════════════════════════
加粗技能 = re.compile(r"'''([^：:'\n]{1,24})[：:]\s*'''")

# ── 噪声：只clean 正文，不碰模板本身 ──
#  [!] 顺序很重要：先抽模板，再清噪。
#     原来反过来做，`\{\{[^}]*\}\}` 把 `{{xh|...}}` 一起删了 -> 条数归零。
噪声 = [
    re.compile(r"\*?'''?如果您想浏览相关怪物词条[^\n]*"),
    re.compile(r"\[\[[^\]]*\|([^\]]*)\]\]"),          # [[A|B]] -> B
    re.compile(r"\[\[([^\]]*)\]\]"),                  # [[A]] -> A
    re.compile(r"\{\{[^}|]*(?:\|[^}|]*)*\}\}"),       # 残留模板（状态模板已在抽取阶段处理）
    re.compile(r"'''?"),                              # 加粗标记
]

形状表 = [
    ("全屏", ["全屏", "全体", "全场", "无范围提示"]),
    ("扇形", ["扇形", "90度", "120度", "180度"]),
    ("直线", ["直线"]),
    ("圆形", ["圆形", "脚下", "点名"]),
    ("自身周围", ["以Boss为中心", "以自身为中心", "自身周围"]),
    ("前方", ["对前方", "正面", "前方"]),
    ("背面", ["背面", "后方"]),
]

# ★ 关键修正：原来只认 `读条结束后`/`读条时`，漏了"读条技能/有读条"
读条有 = ["读条结束后", "读条时", "读条技能", "有读条", "需要读条", "咏唱", "读条"]
读条无 = ["无读条", "没有读条", "瞬发", "不需读条"]


def 清噪(文: str) -> str:
    for r in 噪声:
        文 = r.sub(lambda m: (m.group(1) if m.groups() else ""), 文)
    return 文


def 判形状(正文: str) -> str:
    for 名, 词 in 形状表:
        for w in 词:
            if w in 正文:
                return 名
    return ""


def 抽状态(段: str):
    """抽附带状态并去重（实测同一状态会被写 3 次）。"""
    出 = []
    for 名, i2 in 状态模板.findall(段):
        对 = (名.strip(), i2)
        if 对 not in 出:
            出.append(对)
    return 出


def 造条(副本名, 序号, 技能, 类型, 段):
    # ══════════════════════════════════════════════════════════════
    #  ★ 顺序：**先从原文抽模板，再清噪** ★
    #
    #  [!] 反过来写会静默丢数据（实测踩过）：
    #     `清噪` 的正则会删掉 `{{状态|X|id=N}}`，
    #     之后 `抽状态` 就什么都抽不到 -> `wiki_aura_ids.tsv` **归零**，
    #     而且不报错，看起来只是"这批副本没有状态"。
    # ══════════════════════════════════════════════════════════════
    状态 = 抽状态(段)          # ← 必须在清噪之前
    段 = 清噪(段)

    读条 = "?"
    if any(w in 段 for w in 读条无):
        读条 = "无"
    elif any(w in 段 for w in 读条有):
        读条 = "有"
    return {
        "副本": 副本名,
        "序号": 序号,
        "技能": 技能,
        "类型": 类型 or "无",
        "读条": 读条,
        "形状": 判形状(段),
        "可驱散": "是" if ("可以驱散" in 段 or "可驱散" in 段) else "",
        "状态": "；".join("{}={}".format(n, i2) for n, i2 in 状态),
        "原文": re.sub(r"\s+", " ", 段).strip()[:180],
    }


def 解析页(正文: str, 副本名: str, 序号: str):
    """把一个机制子页解析成若干条记录。两种格式都支持。"""
    条 = []

    # ══════════════════════════════════════════════════════════
    #  ★ 切段策略：把「A 式模板」和「B 式加粗」的**起点**合并排序，
    #     每个技能的上下文 = 从它的起点到下一个起点。
    #
    #  [!] 原来只按 A 式模板切，而且上下文写成 `前缀[-40:] + 段`，
    #     把上一个技能的尾巴带了进来 -> **跨技能串味**
    #     （"摆尾"带上了"猎食爪"的 572 号状态）。
    #     这种错很隐蔽：数据看着有，归属是错的。
    # ══════════════════════════════════════════════════════════
    起点 = []
    for m in 技能模板.finditer(正文):
        起点.append((m.start(), m.end(), m.group(1).strip(), m.group(2).strip()))
    for m in 加粗技能.finditer(正文):
        起点.append((m.start(), m.end(), m.group(1).strip(), ""))

    起点.sort(key=lambda x: x[0])

    for i, (起, 止, 技能, 类型) in enumerate(起点):
        下个起 = 起点[i + 1][0] if i + 1 < len(起点) else len(正文)
        段 = 正文[止:下个起]

        # ══════════════════════════════════════════════════════════
        #  ★ 剔除"Boss 名被当成技能"的误判 ★
        #
        #  [!] 症状：B 式页面里 `*'''奥尔特罗斯：'''` 这种 **Boss 小节标题**
        #     也被当成技能名，产出一条 `技能=奥尔特罗斯 原文=*` 的垃圾。
        #
        #  [!] 判据用「**后面有没有描述**」而不是"必须带 *"：
        #     Boss 名紧跟着换行（是标题），技能名后面紧跟描述。
        #     这个判据更本质 —— 有些技能也写成不带 `*` 的。
        #
        #  [!] 只在**空类型**（B 式没有类型标注）时才做这个检查：
        #     A 式模板 `{{xh|名|类型}}` 本身已经说明它是技能了。
        # ══════════════════════════════════════════════════════════
        if not 类型:
            描述 = 清噪(段).strip().strip("*").strip()
            if len(描述) < 4:
                continue

        条.append(造条(副本名, 序号, 技能, 类型, 段))

    return 条


# ══════════════════════════════════════════════════════════════
#  主流程
# ══════════════════════════════════════════════════════════════

def 读副本表():
    """从 常见副本表.cs 读 TerritoryType -> 副本名。"""
    p = ROOT / "HealerACR" / "Common" / "常见副本表.cs"
    t = p.read_text(encoding="utf-8")
    return [(int(i), n) for i, n in re.findall(r'\["(\d+)"\]\s*=\s*"([^"]+)"', t)]


def 找子页(副本名: str):
    d = 请求({"action": "query", "list": "allpages",
              "apprefix": 副本名, "aplimit": "50", "format": "json"})
    if not d:
        return []
    页 = d.get("query", {}).get("allpages", [])
    # 只要 `副本名/<数字或B>`，不要 `/剧情辅助器NPC台词` 之类
    出 = []
    for x in 页:
        t = x.get("title", "")
        if not t.startswith(副本名 + "/"):
            continue
        尾 = t[len(副本名) + 1:]
        if re.fullmatch(r"\d+|[A-Za-z]", 尾):
            出.append((尾, t))
    # 排序：数字按大小，字母排最后
    出.sort(key=lambda a: (0, int(a[0])) if a[0].isdigit() else (1, 0))
    return 出


_缓存文件 = 缓存目录 / "wikitext.json"
_缓存 = None


def 读缓存():
    global _缓存
    if _缓存 is None:
        if _缓存文件.exists():
            try:
                _缓存 = json.loads(_缓存文件.read_text(encoding="utf-8"))
            except Exception:
                _缓存 = {}
        else:
            _缓存 = {}
    return _缓存


def 存缓存():
    try:
        _缓存文件.write_text(json.dumps(_缓存, ensure_ascii=False),
                             encoding="utf-8")
    except Exception as e:
        print("      缓存写入失败: {}".format(e))


def 取wikitext(标题们):
    出 = {}
    缓 = 读缓存()
    待抓 = []
    for t in 标题们:
        if t in 缓:
            出[t] = 缓[t]
        else:
            待抓.append(t)

    if not 待抓:
        return 出

    标题们 = 待抓
    for i in range(0, len(标题们), 20):     # 每批 20 个标题
        批 = 标题们[i:i + 20]
        d = 请求({"action": "query", "prop": "revisions", "rvprop": "content",
                  "rvslots": "main", "titles": "|".join(批),
                  "format": "json", "formatversion": "2"})
        if not d:
            continue
        for pg in d.get("query", {}).get("pages", []):
            try:
                内容 = pg["revisions"][0]["slots"]["main"]["content"]
                出[pg["title"]] = 内容
                缓[pg["title"]] = 内容
            except Exception:
                pass

    存缓存()
    return 出


def main():
    试跑 = 0
    if "--试跑" in sys.argv:
        try:
            试跑 = int(sys.argv[sys.argv.index("--试跑") + 1])
        except Exception:
            试跑 = 12

    if not 握手():
        print("  中止：先解决 Cloudflare 访问问题")
        return

    副本 = 读副本表()
    if 试跑 > 0:
        副本 = 副本[:试跑]
    print("待抓副本 {} 个{}".format(len(副本), "（试跑）" if 试跑 else "（全量）"))

    全部条 = []
    跳过 = []
    状态汇总 = {}

    for idx, (tid, 名) in enumerate(副本, 1):
        子页 = 找子页(名)
        if not 子页:
            跳过.append((tid, 名, "无机制子页"))
            print("  [{:>3}/{}] {:<28} 跳过（无子页）".format(idx, len(副本), 名))
            continue

        文本s = 取wikitext([t for _, t in 子页])
        本副本条 = 0
        for 序号, 标题 in 子页:
            正文 = 文本s.get(标题)
            if not 正文:
                continue
            for r in 解析页(正文, 名, 序号):
                r["副本ID"] = tid
                全部条.append(r)
                本副本条 += 1
                # 汇总状态
                if r["状态"]:
                    for kv in r["状态"].split("；"):
                        if "=" in kv:
                            n, i2 = kv.split("=", 1)
                            状态汇总.setdefault(i2, {"名": n, "可驱散": "", "来源": set()})
                            状态汇总[i2]["来源"].add(名)
                            if r["可驱散"]:
                                状态汇总[i2]["可驱散"] = "是"

        print("  [{:>3}/{}] {:<28} {} 页 / {} 条".format(
            idx, len(副本), 名, len(子页), 本副本条))

    # ── 落盘 ──
    出目录 = ROOT / "build"
    出目录.mkdir(exist_ok=True)

    列 = ["副本ID", "副本", "序号", "技能", "类型", "读条", "形状", "可驱散", "状态", "原文"]
    p1 = 出目录 / "wiki_duty_mechanics.tsv"
    with p1.open("w", encoding="utf-8", newline="") as f:
        f.write("\t".join(列) + "\n")
        for r in 全部条:
            f.write("\t".join(str(r.get(c, "")) for c in 列) + "\n")

    p2 = 出目录 / "wiki_aura_ids.tsv"
    with p2.open("w", encoding="utf-8", newline="") as f:
        f.write("状态ID\t名称\t可驱散\t出现副本数\n")
        for i2, v in sorted(状态汇总.items(), key=lambda x: int(x[0])):
            f.write("{}\t{}\t{}\t{}\n".format(
                i2, v["名"], v["可驱散"], len(v["来源"])))

    p3 = 出目录 / "wiki_skip.tsv"
    with p3.open("w", encoding="utf-8", newline="") as f:
        f.write("副本ID\t副本名\t原因\n")
        for tid, 名, 原因 in 跳过:
            f.write("{}\t{}\t{}\n".format(tid, 名, 原因))

    print()
    print("=" * 62)
    print("  机制条数 {}  ->  {}".format(len(全部条), p1.name))
    print("  状态 ID  {}  ->  {}".format(len(状态汇总), p2.name))
    print("  无机制页 {}  ->  {}".format(len(跳过), p3.name))
    print("=" * 62)

    可驱散 = [v for v in 状态汇总.values() if v["可驱散"]]
    print("  ★ 标为「可驱散」的状态 {} 个".format(len(可驱散)))
    for i2, v in sorted(状态汇总.items(), key=lambda x: int(x[0])):
        if v["可驱散"]:
            print("      id={:<5} {}".format(i2, v["名"]))


if __name__ == "__main__":
    main()
