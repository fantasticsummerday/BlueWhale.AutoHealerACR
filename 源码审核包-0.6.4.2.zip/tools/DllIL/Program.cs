using System.Collections.Immutable;
using System.Reflection;
using System.Reflection.Emit;
using System.Reflection.Metadata;
using System.Reflection.Metadata.Ecma335;
using System.Reflection.PortableExecutable;

// DllIL —— 真·IL 反汇编器（只读元数据，不执行代码）
//
// 相比 DllPeek（只扒常量 + 被调方法名，丢失控制流），本工具输出**带分支目标的线性 IL**，
// 因此 if / else / 循环 / 比较运算符 / 短路逻辑 全部可见。
// 如果同目录存在同名 portable PDB，还会补上**局部变量名**和方法参数名，可读性大幅提升。
//
// 用法:
//   DllIL.exe <dll> [类型名关键词,逗号分隔] [--list] [--lines] [--no-locals]
//   不给关键词 = 全部类型；--list = 只列类型名

var path = args.Length > 0 ? args[0] : "";
var filterRaw = args.Length > 1 && !args[1].StartsWith("--") ? args[1] : "";
bool 只列类型 = args.Contains("--list");
bool 带行号 = args.Contains("--lines");
bool 带局部变量 = !args.Contains("--no-locals");

var filter = filterRaw.Split(',', StringSplitOptions.RemoveEmptyEntries);

if (!File.Exists(path)) { Console.WriteLine($"找不到 {path}"); return 2; }

using var fs = File.OpenRead(path);
using var pe = new PEReader(fs);
var md = pe.GetMetadataReader();

// ---------- 可选：portable PDB ----------
MetadataReader pdb = null;
MetadataReaderProvider pdbProv = null;
var pdbPath = Path.ChangeExtension(path, ".pdb");
if (带局部变量 && File.Exists(pdbPath))
{
    try
    {
        pdbProv = MetadataReaderProvider.FromPortablePdbStream(File.OpenRead(pdbPath));
        pdb = pdbProv.GetMetadataReader();
    }
    catch (Exception e) { Console.WriteLine($"// PDB 读取失败（忽略）: {e.Message}"); }
}

var tp = new TyProv();

// ---------- 名字解析 ----------
string 类型名(EntityHandle h)
{
    switch (h.Kind)
    {
        case HandleKind.TypeDefinition:
            {
                var t = md.GetTypeDefinition((TypeDefinitionHandle)h);
                var ns = md.GetString(t.Namespace); var n = md.GetString(t.Name);
                return string.IsNullOrEmpty(ns) ? n : ns + "." + n;
            }
        case HandleKind.TypeReference:
            {
                var t = md.GetTypeReference((TypeReferenceHandle)h);
                var ns = md.GetString(t.Namespace); var n = md.GetString(t.Name);
                return string.IsNullOrEmpty(ns) ? n : ns + "." + n;
            }
        case HandleKind.TypeSpecification:
            try { return md.GetTypeSpecification((TypeSpecificationHandle)h).DecodeSignature(tp, null); }
            catch { return "?"; }
        default: return null;
    }
}

string 成员名(EntityHandle h)
{
    try
    {
        switch (h.Kind)
        {
            case HandleKind.MethodDefinition:
                {
                    var m = md.GetMethodDefinition((MethodDefinitionHandle)h);
                    return $"{类型名(m.GetDeclaringType())}::{md.GetString(m.Name)}";
                }
            case HandleKind.FieldDefinition:
                {
                    var f = md.GetFieldDefinition((FieldDefinitionHandle)h);
                    return $"{类型名(f.GetDeclaringType())}::{md.GetString(f.Name)}";
                }
            case HandleKind.MemberReference:
                {
                    var mr = md.GetMemberReference((MemberReferenceHandle)h);
                    var n = md.GetString(mr.Name);
                    var p = 类型名(mr.Parent);
                    return p == null ? n : $"{p}::{n}";
                }
            case HandleKind.MethodSpecification:
                {
                    var ms = md.GetMethodSpecification((MethodSpecificationHandle)h);
                    var inner = 成员名(ms.Method);
                    try
                    {
                        var ga = ms.DecodeSignature(tp, null);
                        inner += "<" + string.Join(",", ga) + ">";
                    }
                    catch { }
                    return inner;
                }
            case HandleKind.StandaloneSignature:
                return "calli";
            default: return null;
        }
    }
    catch { return null; }
}

// ---------- 方法签名（含参数名） ----------
string 方法签名(MethodDefinition m)
{
    var name = md.GetString(m.Name);
    var 参数名 = new Dictionary<int, string>();
    foreach (var ph in m.GetParameters())
    {
        var p = md.GetParameter(ph);
        var pn = md.GetString(p.Name);
        参数名[p.SequenceNumber] = string.IsNullOrEmpty(pn) ? $"arg{p.SequenceNumber}" : pn;
    }

    string 返回 = "?";
    var 形参 = "";
    try
    {
        var sig = m.DecodeSignature(tp, null);
        返回 = sig.ReturnType;
        var ps = sig.ParameterTypes;
        for (int i = 0; i < ps.Length; i++)
        {
            var pn = 参数名.TryGetValue(i + 1, out var v) ? v : $"a{i}";
            形参 += (i > 0 ? ", " : "") + ps[i] + " " + pn;
        }
    }
    catch { 形参 = string.Join(", ", 参数名.OrderBy(k => k.Key).Select(k => k.Value)); }

    var 静态 = m.Attributes.HasFlag(MethodAttributes.Static) ? "static " : "";
    return $"{静态}{返回} {name}({形参})";
}

// ---------- 局部变量名 ----------
Dictionary<int, string> 局部变量(MethodDefinitionHandle mh)
{
    var d = new Dictionary<int, string>();
    if (pdb == null) return d;
    try
    {
        var h = MetadataTokens.MethodDebugInformationHandle(MetadataTokens.GetRowNumber(mh));
        var mdi = pdb.GetMethodDebugInformation(h);
        foreach (var sh in pdb.GetLocalScopes(mh))
        {
            foreach (var lvh in pdb.GetLocalScope(sh).GetLocalVariables())
            {
                var lv = pdb.GetLocalVariable(lvh);
                d[lv.Index] = pdb.GetString(lv.Name);
            }
        }
    }
    catch { }
    return d;
}

List<(int off, int line)> 序列点(MethodDefinitionHandle mh)
{
    var r = new List<(int, int)>();
    if (pdb == null) return r;
    try
    {
        var h = MetadataTokens.MethodDebugInformationHandle(MetadataTokens.GetRowNumber(mh));
        var mdi = pdb.GetMethodDebugInformation(h);
        foreach (var sp in mdi.GetSequencePoints())
            if (!sp.IsHidden) r.Add((sp.Offset, sp.StartLine));
    }
    catch { }
    return r;
}

// ---------- 主循环 ----------
int 输出方法数 = 0;
foreach (var th in md.TypeDefinitions)
{
    var t = md.GetTypeDefinition(th);
    var tn = md.GetString(t.Name);
    if (tn.StartsWith("<")) continue;

    var ns = md.GetString(t.Namespace);
    var full = string.IsNullOrEmpty(ns) ? tn : $"{ns}.{tn}";
    if (filter.Length > 0 && !filter.Any(f => full.Contains(f, StringComparison.OrdinalIgnoreCase))) continue;

    if (只列类型) { Console.WriteLine(full); continue; }

    var 块 = new List<string>();
    foreach (var mh in t.GetMethods())
    {
        var m = md.GetMethodDefinition(mh);
        var mn = md.GetString(m.Name);
        if (mn.StartsWith("get_") || mn.StartsWith("set_")) continue;

        var 签名行 = $"  :: {方法签名(m)}";
        if (m.RelativeVirtualAddress == 0) { 块.Add(签名行 + "   [无方法体]"); continue; }

        byte[] il;
        try { il = pe.GetMethodBody(m.RelativeVirtualAddress).GetILBytes(); }
        catch { 块.Add(签名行 + "   [IL 读取失败]"); continue; }

        var 局部 = 局部变量(mh);
        var 点 = 序列点(mh);

        var 行 = new List<string> { 签名行 };
        if (局部.Count > 0)
            行.Add("     // locals: " + string.Join(", ", 局部.OrderBy(k => k.Key).Select(k => $"V{k.Key}={k.Value}")));

        int i = 0, 上一行 = -1;
        while (i < il.Length)
        {
            int 本偏移 = i;
            int op = il[i];
            OpDef def;
            if (op == 0xFE)
            {
                if (i + 1 >= il.Length) break;
                def = OpTable.双字节.TryGetValue(il[i + 1], out var d2) ? d2 : new OpDef($"<fe{il[i + 1]:x2}>", OperandType.InlineNone);
                i += 2;
            }
            else
            {
                def = OpTable.单字节.TryGetValue((byte)op, out var d1) ? d1 : new OpDef($"<{op:x2}>", OperandType.InlineNone);
                i += 1;
            }

            // 序列点注释
            if (带行号)
            {
                var sp = 点.LastOrDefault(p => p.off == 本偏移);
                if (sp.line != 0 && sp.line != 上一行) { 行.Add($"     // ---- line {sp.line} ----"); 上一行 = sp.line; }
            }

            string 操作数文本 = "";
            switch (def.Op)
            {
                case OperandType.InlineNone: break;
                case OperandType.ShortInlineI:
                    if (def.Name == "unaligned." || def.Name == "no.") 操作数文本 = il[i].ToString();
                    else 操作数文本 = ((sbyte)il[i]).ToString();
                    i += 1; break;
                case OperandType.InlineI:
                    操作数文本 = BitConverter.ToInt32(il, i).ToString(); i += 4; break;
                case OperandType.InlineI8:
                    操作数文本 = BitConverter.ToInt64(il, i).ToString(); i += 8; break;
                case OperandType.ShortInlineR:
                    操作数文本 = BitConverter.ToSingle(il, i).ToString("R"); i += 4; break;
                case OperandType.InlineR:
                    操作数文本 = BitConverter.ToDouble(il, i).ToString("R"); i += 8; break;
                case OperandType.ShortInlineVar:
                    {
                        int idx = il[i]; i += 1;
                        操作数文本 = def.Name.StartsWith("ldloc") || def.Name.StartsWith("stloc")
                            ? $"V{idx}" + (局部.TryGetValue(idx, out var ln) ? $"({ln})" : "")
                            : $"a{idx}";
                        break;
                    }
                case OperandType.InlineVar:
                    {
                        int idx = BitConverter.ToUInt16(il, i); i += 2;
                        操作数文本 = def.Name.StartsWith("ldloc") || def.Name.StartsWith("stloc")
                            ? $"V{idx}" + (局部.TryGetValue(idx, out var ln) ? $"({ln})" : "")
                            : $"a{idx}";
                        break;
                    }
                case OperandType.ShortInlineBrTarget:
                    {
                        int d = (sbyte)il[i]; i += 1;
                        操作数文本 = $"IL_{i + d:x4}"; break;
                    }
                case OperandType.InlineBrTarget:
                    {
                        int d = BitConverter.ToInt32(il, i); i += 4;
                        操作数文本 = $"IL_{i + d:x4}"; break;
                    }
                case OperandType.InlineSwitch:
                    {
                        int n = BitConverter.ToInt32(il, i); i += 4;
                        var 表 = new List<string>();
                        int 基准 = i + 4 * n;
                        for (int k = 0; k < n; k++) { 表.Add($"IL_{基准 + BitConverter.ToInt32(il, i + 4 * k):x4}"); }
                        i = 基准;
                        操作数文本 = "[" + string.Join(", ", 表) + "]"; break;
                    }
                case OperandType.InlineString:
                    {
                        int tok = BitConverter.ToInt32(il, i); i += 4;
                        try
                        {
                            var s = md.GetUserString(MetadataTokens.UserStringHandle(tok & 0x00FFFFFF));
                            操作数文本 = "\"" + (s.Length > 80 ? s.Substring(0, 80) + "…" : s) + "\"";
                        }
                        catch { 操作数文本 = $"tok(0x{tok:x8})"; }
                        break;
                    }
                case OperandType.InlineMethod:
                case OperandType.InlineField:
                case OperandType.InlineType:
                case OperandType.InlineTok:
                    {
                        int tok = BitConverter.ToInt32(il, i); i += 4;
                        var h = MetadataTokens.EntityHandle(tok);
                        操作数文本 = 成员名(h) ?? 类型名(h) ?? $"tok(0x{tok:x8})";
                        break;
                    }
                case OperandType.InlineSig:
                    { i += 4; 操作数文本 = "sig"; break; }
                default:
                    i += 4; break;
            }

            var 原文 = op == 0xFE ? $"{def.Name}" : def.Name;
            if (操作数文本.Length > 0)
                操作数文本 = " " + 操作数文本;
            行.Add($"     IL_{本偏移:x4}: {原文}{操作数文本}");
        }

        块.AddRange(行);
        输出方法数++;
    }

    if (块.Count > 0)
    {
        Console.WriteLine($"\n### {full}");
        foreach (var l in 块) Console.WriteLine(l);
    }
}

if (!只列类型) Console.Error.WriteLine($"// 已输出 {输出方法数} 个方法");
return 0;

// ================= 类型签名打印 =================
sealed class TyProv : ISignatureTypeProvider<string, object>
{
    static readonly Dictionary<PrimitiveTypeCode, string> 别名 = new()
    {
        [PrimitiveTypeCode.Void] = "void", [PrimitiveTypeCode.Boolean] = "bool",
        [PrimitiveTypeCode.Char] = "char", [PrimitiveTypeCode.SByte] = "sbyte",
        [PrimitiveTypeCode.Byte] = "byte", [PrimitiveTypeCode.Int16] = "short",
        [PrimitiveTypeCode.UInt16] = "ushort", [PrimitiveTypeCode.Int32] = "int",
        [PrimitiveTypeCode.UInt32] = "uint", [PrimitiveTypeCode.Int64] = "long",
        [PrimitiveTypeCode.UInt64] = "ulong", [PrimitiveTypeCode.Single] = "float",
        [PrimitiveTypeCode.Double] = "double", [PrimitiveTypeCode.String] = "string",
        [PrimitiveTypeCode.Object] = "object", [PrimitiveTypeCode.IntPtr] = "nint",
        [PrimitiveTypeCode.UIntPtr] = "nuint", [PrimitiveTypeCode.TypedReference] = "TypedReference",
    };

    public string GetArrayType(string e, ArrayShape s) => e + "[]";
    public string GetByReferenceType(string e) => "ref " + e;
    public string GetFunctionPointerType(MethodSignature<string> s) => "fnptr";
    public string GetGenericInstantiation(string g, ImmutableArray<string> a) => g + "<" + string.Join(",", a) + ">";
    public string GetGenericMethodParameter(object c, int i) => "!!" + i;
    public string GetGenericTypeParameter(object c, int i) => "!" + i;
    public string GetModifiedType(string m, string u, bool r) => u;
    public string GetPinnedType(string e) => e;
    public string GetPointerType(string e) => e + "*";
    public string GetPrimitiveType(PrimitiveTypeCode c) => 别名.TryGetValue(c, out var s) ? s : c.ToString();
    public string GetSZArrayType(string e) => e + "[]";
    public string GetTypeFromDefinition(MetadataReader r, TypeDefinitionHandle h, byte k)
    {
        var t = r.GetTypeDefinition(h);
        var ns = r.GetString(t.Namespace); var n = r.GetString(t.Name);
        return string.IsNullOrEmpty(ns) ? n : ns + "." + n;
    }
    public string GetTypeFromReference(MetadataReader r, TypeReferenceHandle h, byte k)
    {
        var t = r.GetTypeReference(h);
        var ns = r.GetString(t.Namespace); var n = r.GetString(t.Name);
        return string.IsNullOrEmpty(ns) ? n : ns + "." + n;
    }
    public string GetTypeFromSpecification(MetadataReader r, object c, TypeSpecificationHandle h, byte k)
    {
        try { return r.GetTypeSpecification(h).DecodeSignature(this, c); } catch { return "?"; }
    }
}

// ================= 指令表 =================
readonly struct OpDef
{
    public readonly string Name;
    public readonly OperandType Op;
    public OpDef(string n, OperandType o) { Name = n; Op = o; }
}

static class OpTable
{
    public static readonly Dictionary<byte, OpDef> 单字节 = new();
    public static readonly Dictionary<byte, OpDef> 双字节 = new();

    static void A(byte c, string n, OperandType o = OperandType.InlineNone) => 单字节[c] = new OpDef(n, o);
    static void B(byte c, string n, OperandType o = OperandType.InlineNone) => 双字节[c] = new OpDef(n, o);

    static OpTable()
    {
        A(0x00, "nop"); A(0x01, "break");
        A(0x02, "ldarg.0"); A(0x03, "ldarg.1"); A(0x04, "ldarg.2"); A(0x05, "ldarg.3");
        A(0x06, "ldloc.0"); A(0x07, "ldloc.1"); A(0x08, "ldloc.2"); A(0x09, "ldloc.3");
        A(0x0A, "stloc.0"); A(0x0B, "stloc.1"); A(0x0C, "stloc.2"); A(0x0D, "stloc.3");
        A(0x0E, "ldarg.s", OperandType.ShortInlineVar); A(0x0F, "ldarga.s", OperandType.ShortInlineVar);
        A(0x10, "starg.s", OperandType.ShortInlineVar);
        A(0x11, "ldloc.s", OperandType.ShortInlineVar); A(0x12, "ldloca.s", OperandType.ShortInlineVar);
        A(0x13, "stloc.s", OperandType.ShortInlineVar);
        A(0x14, "ldnull");
        A(0x15, "ldc.i4.m1"); A(0x16, "ldc.i4.0"); A(0x17, "ldc.i4.1"); A(0x18, "ldc.i4.2"); A(0x19, "ldc.i4.3");
        A(0x1A, "ldc.i4.4"); A(0x1B, "ldc.i4.5"); A(0x1C, "ldc.i4.6"); A(0x1D, "ldc.i4.7"); A(0x1E, "ldc.i4.8");
        A(0x1F, "ldc.i4.s", OperandType.ShortInlineI); A(0x20, "ldc.i4", OperandType.InlineI);
        A(0x21, "ldc.i8", OperandType.InlineI8);
        A(0x22, "ldc.r4", OperandType.ShortInlineR); A(0x23, "ldc.r8", OperandType.InlineR);
        A(0x25, "dup"); A(0x26, "pop"); A(0x27, "jmp", OperandType.InlineMethod);
        A(0x28, "call", OperandType.InlineMethod); A(0x29, "calli", OperandType.InlineSig);
        A(0x2A, "ret");
        A(0x2B, "br.s", OperandType.ShortInlineBrTarget); A(0x2C, "brfalse.s", OperandType.ShortInlineBrTarget);
        A(0x2D, "brtrue.s", OperandType.ShortInlineBrTarget); A(0x2E, "beq.s", OperandType.ShortInlineBrTarget);
        A(0x2F, "bge.s", OperandType.ShortInlineBrTarget); A(0x30, "bgt.s", OperandType.ShortInlineBrTarget);
        A(0x31, "ble.s", OperandType.ShortInlineBrTarget); A(0x32, "blt.s", OperandType.ShortInlineBrTarget);
        A(0x33, "bne.un.s", OperandType.ShortInlineBrTarget); A(0x34, "bge.un.s", OperandType.ShortInlineBrTarget);
        A(0x35, "bgt.un.s", OperandType.ShortInlineBrTarget); A(0x36, "ble.un.s", OperandType.ShortInlineBrTarget);
        A(0x37, "blt.un.s", OperandType.ShortInlineBrTarget);
        A(0x38, "br", OperandType.InlineBrTarget); A(0x39, "brfalse", OperandType.InlineBrTarget);
        A(0x3A, "brtrue", OperandType.InlineBrTarget); A(0x3B, "beq", OperandType.InlineBrTarget);
        A(0x3C, "bge", OperandType.InlineBrTarget); A(0x3D, "bgt", OperandType.InlineBrTarget);
        A(0x3E, "ble", OperandType.InlineBrTarget); A(0x3F, "blt", OperandType.InlineBrTarget);
        A(0x40, "bne.un", OperandType.InlineBrTarget); A(0x41, "bge.un", OperandType.InlineBrTarget);
        A(0x42, "bgt.un", OperandType.InlineBrTarget); A(0x43, "ble.un", OperandType.InlineBrTarget);
        A(0x44, "blt.un", OperandType.InlineBrTarget);
        A(0x45, "switch", OperandType.InlineSwitch);
        A(0x46, "ldind.i1"); A(0x47, "ldind.u1"); A(0x48, "ldind.i2"); A(0x49, "ldind.u2");
        A(0x4A, "ldind.i4"); A(0x4B, "ldind.u4"); A(0x4C, "ldind.i8"); A(0x4D, "ldind.i");
        A(0x4E, "ldind.r4"); A(0x4F, "ldind.r8"); A(0x50, "ldind.ref");
        A(0x51, "stind.ref"); A(0x52, "stind.i1"); A(0x53, "stind.i2"); A(0x54, "stind.i4");
        A(0x55, "stind.i8"); A(0x56, "stind.r4"); A(0x57, "stind.r8");
        A(0x58, "add"); A(0x59, "sub"); A(0x5A, "mul"); A(0x5B, "div"); A(0x5C, "div.un");
        A(0x5D, "rem"); A(0x5E, "rem.un"); A(0x5F, "and"); A(0x60, "or"); A(0x61, "xor");
        A(0x62, "shl"); A(0x63, "shr"); A(0x64, "shr.un"); A(0x65, "neg"); A(0x66, "not");
        A(0x67, "conv.i1"); A(0x68, "conv.i2"); A(0x69, "conv.i4"); A(0x6A, "conv.i8");
        A(0x6B, "conv.r4"); A(0x6C, "conv.r8"); A(0x6D, "conv.u4"); A(0x6E, "conv.u8");
        A(0x6F, "callvirt", OperandType.InlineMethod);
        A(0x70, "cpobj", OperandType.InlineType); A(0x71, "ldobj", OperandType.InlineType);
        A(0x72, "ldstr", OperandType.InlineString);
        A(0x73, "newobj", OperandType.InlineMethod);
        A(0x74, "castclass", OperandType.InlineType); A(0x75, "isinst", OperandType.InlineType);
        A(0x76, "conv.r.un");
        A(0x79, "unbox", OperandType.InlineType); A(0x7A, "throw");
        A(0x7B, "ldfld", OperandType.InlineField); A(0x7C, "ldflda", OperandType.InlineField);
        A(0x7D, "stfld", OperandType.InlineField); A(0x7E, "ldsfld", OperandType.InlineField);
        A(0x7F, "ldsflda", OperandType.InlineField); A(0x80, "stsfld", OperandType.InlineField);
        A(0x81, "stobj", OperandType.InlineType);
        A(0x82, "conv.ovf.i1.un"); A(0x83, "conv.ovf.i2.un"); A(0x84, "conv.ovf.i4.un");
        A(0x85, "conv.ovf.i8.un"); A(0x86, "conv.ovf.u1.un"); A(0x87, "conv.ovf.u2.un");
        A(0x88, "conv.ovf.u4.un"); A(0x89, "conv.ovf.u8.un"); A(0x8A, "conv.ovf.i.un"); A(0x8B, "conv.ovf.u.un");
        A(0x8C, "box", OperandType.InlineType); A(0x8D, "newarr", OperandType.InlineType);
        A(0x8E, "ldlen"); A(0x8F, "ldelema", OperandType.InlineType);
        A(0x90, "ldelem.i1"); A(0x91, "ldelem.u1"); A(0x92, "ldelem.i2"); A(0x93, "ldelem.u2");
        A(0x94, "ldelem.i4"); A(0x95, "ldelem.u4"); A(0x96, "ldelem.i8"); A(0x97, "ldelem.i");
        A(0x98, "ldelem.r4"); A(0x99, "ldelem.r8"); A(0x9A, "ldelem.ref");
        A(0x9B, "stelem.i"); A(0x9C, "stelem.i1"); A(0x9D, "stelem.i2"); A(0x9E, "stelem.i4");
        A(0x9F, "stelem.i8"); A(0xA0, "stelem.r4"); A(0xA1, "stelem.r8"); A(0xA2, "stelem.ref");
        A(0xA3, "ldelem", OperandType.InlineType); A(0xA4, "stelem", OperandType.InlineType);
        A(0xA5, "unbox.any", OperandType.InlineType);
        A(0xB3, "conv.ovf.i1"); A(0xB4, "conv.ovf.u1"); A(0xB5, "conv.ovf.i2"); A(0xB6, "conv.ovf.u2");
        A(0xB7, "conv.ovf.i4"); A(0xB8, "conv.ovf.u4"); A(0xB9, "conv.ovf.i8"); A(0xBA, "conv.ovf.u8");
        A(0xC2, "refanyval", OperandType.InlineType); A(0xC3, "ckfinite");
        A(0xC6, "mkrefany", OperandType.InlineType);
        A(0xD0, "ldtoken", OperandType.InlineTok); A(0xD1, "conv.u2"); A(0xD2, "conv.u1"); A(0xD3, "conv.i");
        A(0xD4, "conv.ovf.i"); A(0xD5, "conv.ovf.u");
        A(0xD6, "add.ovf"); A(0xD7, "add.ovf.un"); A(0xD8, "mul.ovf"); A(0xD9, "mul.ovf.un");
        A(0xDA, "sub.ovf"); A(0xDB, "sub.ovf.un"); A(0xDC, "endfinally");
        A(0xDD, "leave", OperandType.InlineBrTarget); A(0xDE, "leave.s", OperandType.ShortInlineBrTarget);
        A(0xDF, "stind.i"); A(0xE0, "conv.u");

        B(0x00, "arglist");
        B(0x01, "ceq"); B(0x02, "cgt"); B(0x03, "cgt.un"); B(0x04, "clt"); B(0x05, "clt.un");
        B(0x06, "ldftn", OperandType.InlineMethod); B(0x07, "ldvirtftn", OperandType.InlineMethod);
        B(0x09, "ldarg", OperandType.InlineVar); B(0x0A, "ldarga", OperandType.InlineVar);
        B(0x0B, "starg", OperandType.InlineVar);
        B(0x0C, "ldloc", OperandType.InlineVar); B(0x0D, "ldloca", OperandType.InlineVar);
        B(0x0E, "stloc", OperandType.InlineVar);
        B(0x0F, "localloc"); B(0x11, "endfilter");
        B(0x12, "unaligned.", OperandType.ShortInlineI); B(0x13, "volatile."); B(0x14, "tail.");
        B(0x15, "initobj", OperandType.InlineType); B(0x16, "constrained.", OperandType.InlineType);
        B(0x17, "cpblk"); B(0x18, "initblk"); B(0x19, "no.", OperandType.ShortInlineI);
        B(0x1A, "rethrow"); B(0x1C, "sizeof", OperandType.InlineType);
        B(0x1D, "refanytype"); B(0x1E, "readonly.");
    }
}
