// ============================================================================
//  ContentFinderCondition 导出 —— 副本 ID → 名字
//
//  为什么要这个：
//    `Data.CurrentContentFinderConditionId` 给的是**副本 ID**，
//    而报告和 AI 提示词里要写"这是哪个副本"。
//    仓库里的 dump_territory.tsv 导的是 TerritoryType（只有区域名+地名，
//    没有副本名），**对不上这个 ID** —— 必须导 ContentFinderCondition。
//
//  用法：
//    dotnet run --project tools\DutyDump -- "D:\FF14\最终幻想XIV\game" [关键词]
//
//  输出：
//    dump_duty.tsv      （Id  名称  类型）—— 人工查阅
//    DutyNames.json     （id → 名称）—— ACR 运行时读
// ============================================================================

using System.Text;
using System.Text.Json;
using Lumina;
using Lumina.Data;

Console.OutputEncoding = Encoding.UTF8;

var root = args.Length > 0 ? args[0] : @"D:\FF14\最终幻想XIV\game";
var 关键词 = args.Length > 1 ? args[1] : "";

// 和 ZoneDump 一样：root 和 root\sqpack 都试（语言必须显式指定 CN）
var candidates = new List<string>();
foreach (var c in root.Split(';', StringSplitOptions.RemoveEmptyEntries))
{
    if (Directory.Exists(c)) candidates.Add(c);
    var sub = Path.Combine(c, "sqpack");
    if (Directory.Exists(sub)) candidates.Add(sub);
}

GameData data = null;
foreach (var path in candidates)
{
    try
    {
        data = new GameData(path, new LuminaOptions { DefaultExcelLanguage = Language.ChineseSimplified });
        Console.WriteLine($"OK {path}");
        break;
    }
    catch (Exception e)
    {
        Console.WriteLine($"   {path}: {e.Message}");
    }
}

if (data == null) return 2;

var sheet = data.Excel.GetSheet<Lumina.Excel.Sheets.ContentFinderCondition>();
Console.WriteLine($"ContentFinderCondition 共 {sheet.Count} 行");

var tsv = new StringBuilder("Id\t名称\t类型\n");
var 精简 = new Dictionary<string, string>();
var 命中 = 0;

foreach (var row in sheet)
{
    uint id = row.RowId;

    string 名 = "";
    try { 名 = row.Name.ToString(); } catch { }

    string 类型 = "";
    try { 类型 = row.ContentType.Value.Name.ToString(); } catch { }

    if (关键词.Length > 0 &&
        !(名.Contains(关键词, StringComparison.OrdinalIgnoreCase) ||
          类型.Contains(关键词, StringComparison.OrdinalIgnoreCase)))
        continue;

    tsv.AppendLine($"{id}\t{名}\t{类型}");

    if (!string.IsNullOrWhiteSpace(名))
        精简[id.ToString()] = 名;

    命中++;
}

Console.WriteLine($"命中 {命中} 行");

File.WriteAllText("dump_duty.tsv", tsv.ToString(), new UTF8Encoding(false));
Console.WriteLine("已写出 dump_duty.tsv");

File.WriteAllText("DutyNames.json",
    JsonSerializer.Serialize(精简, new JsonSerializerOptions { WriteIndented = false }),
    new UTF8Encoding(false));
Console.WriteLine($"已写出 DutyNames.json（{精简.Count} 条）");

return 0;
