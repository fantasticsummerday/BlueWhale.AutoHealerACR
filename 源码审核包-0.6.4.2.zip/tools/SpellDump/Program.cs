using System.Text;
using Lumina;
using Lumina.Data;

// 导出四奶 + 基础职业的技能（重点是充能数 / CastType），
// 以及**坦克减伤 buff**（给 AI 判断"减伤够不够"用）。
//
// 用法: SpellDump.exe "D:\FF14\最终幻想XIV\game" 输出前缀

Console.OutputEncoding = Encoding.UTF8;

var root = args.Length > 0 ? args[0] : @"D:\FF14\最终幻想XIV\game";
var prefix = args.Length > 1 ? args[1] : "dump";

var candidates = new List<string>();
foreach (var c in root.Split(';', StringSplitOptions.RemoveEmptyEntries))
{
    if (Directory.Exists(c)) candidates.Add(c);
    var sub = Path.Combine(c, "sqpack");
    if (Directory.Exists(sub)) candidates.Add(sub);
}

GameData data = null;
foreach (var path in candidates)
{
    try
    {
        data = new GameData(path, new LuminaOptions { DefaultExcelLanguage = Language.ChineseSimplified });
        Console.WriteLine($"OK {path}");
        break;
    }
    catch (Exception e)
    {
        Console.WriteLine($"   {path}: {e.Message}");
    }
}

if (data == null) return 2;

// ══════════════════════════════════════════════════════════════════
//  第一部分：四奶技能（原有功能）
// ══════════════════════════════════════════════════════════════════

var actions = data.Excel.GetSheet<Lumina.Excel.Sheets.Action>();
var jobName = new Dictionary<uint, string>
{
    [6] = "幻术", [26] = "秘术", [24] = "白魔", [28] = "学者", [33] = "占星", [40] = "贤者",
};

var lines = new List<string> { "Id\tJob\tLevel\tCharges\tRecastSec\tCastType\tRange\tEffectRange\tName" };
var 有充能 = new List<string>();

foreach (var row in actions)
{
    uint job;
    try { job = row.ClassJob.RowId; } catch { continue; }
    if (!jobName.ContainsKey(job)) continue;

    uint level = 0, charges = 0, recast = 0;
    try { level = row.ClassJobLevel; } catch { }
    try { charges = row.MaxCharges; } catch { }
    try { recast = row.Recast100ms; } catch { }

    var name = row.Name.ToString();

    // ★ CastType = 技能形状 ★
    //   1=单体 2=圆形(目标中心) 3=扇形/锥形 4=圆形(自身) 7=地面放置
    var castType = 0;
    try { castType = (int)row.CastType; } catch { }

    var range = 0;
    try { range = row.Range; } catch { }

    var effectRange = 0;
    try { effectRange = row.EffectRange; } catch { }

    lines.Add($"{row.RowId}\t{jobName[job]}\t{level}\t{charges}\t{recast / 10.0:0.0}\t{castType}\t{range}\t{effectRange}\t{name}");

    if (charges > 1) 有充能.Add($"{jobName[job]}  {name,-14} id={row.RowId,-6} 充能={charges}  复唱={recast / 10.0:0.0}s  等级={level}");
}

File.WriteAllLines($"{prefix}_actions.tsv", lines, Encoding.UTF8);
Console.WriteLine($"\n导出 {lines.Count - 1} 条 -> {prefix}_actions.tsv");

Console.WriteLine($"\n=== 四奶里**有充能**的技能（{有充能.Count} 个）===");
foreach (var s in 有充能.OrderBy(x => x)) Console.WriteLine("  " + s);

// ══════════════════════════════════════════════════════════════════
//  第二部分：坦克减伤 buff
//
//  ⚠️ **不靠关键词猜** —— 那种做法漏一个就静默出错。
//
//  做法：**从坦克职业的减伤技能反查它们给自己挂的 buff**。
//    ① 找出所有坦克职业（ClassJob 的 Role = 坦克）的技能
//    ② 对每个技能，看它的 Action 行里关联的 Status
//    ③ 汇总去重
//
//  这样拿到的 ID 是**游戏数据本身**，不是我凭印象写的。
// ══════════════════════════════════════════════════════════════════

Console.WriteLine("\n=== 坦克减伤 buff ===");

var 坦克职业 = new HashSet<uint> { 19, 20, 21, 32, 37 };   // 骑士/战士/暗骑/枪刃/斧术
var 坦克职业技能 = new List<(uint Id, string Name, uint Job, uint Level)>();

foreach (var row in actions)
{
    uint job;
    try { job = row.ClassJob.RowId; } catch { continue; }
    if (!坦克职业.Contains(job)) continue;

    var name = row.Name.ToString();
    if (string.IsNullOrWhiteSpace(name)) continue;

    uint level = 0;
    try { level = row.ClassJobLevel; } catch { }

    坦克职业技能.Add((row.RowId, name, job, level));
}

Console.WriteLine($"  坦克职业技能共 {坦克职业技能.Count} 个");

// 从 Status 表里找"名字能对上坦克技能"的 buff
// （FF14 里减伤 buff 名往往和技能名相同或相近）
var statusSheet = data.Excel.GetSheet<Lumina.Excel.Sheets.Status>();
var 技能名集合 = new HashSet<string>(坦克职业技能.Select(x => x.Name));

var 坦克Buff = new List<(uint Id, string Name, string 来源技能)>();

foreach (var st in statusSheet)
{
    string 名;
    try { 名 = st.Name.ToString(); } catch { continue; }
    if (string.IsNullOrWhiteSpace(名)) continue;

    // 名字完全匹配坦克技能 → 大概率就是它挂的 buff
    if (技能名集合.Contains(名))
    {
        var 来源 = 坦克职业技能.First(x => x.Name == 名);
        坦克Buff.Add((st.RowId, 名, $"{来源.Name}(技能{来源.Id} Lv{来源.Level})"));
    }
}

Console.WriteLine($"  名字能对上技能的 buff：{坦克Buff.Count} 个");

var buffLines = new List<string> { "StatusId\tName\t来源" };
foreach (var b in 坦克Buff.OrderBy(x => x.Id))
{
    buffLines.Add($"{b.Id}\t{b.Name}\t{b.来源技能}");
    Console.WriteLine($"  {b.Id,-8} {b.Name,-20} ← {b.来源技能}");
}

File.WriteAllLines($"{prefix}_tankbuffs.tsv", buffLines, Encoding.UTF8);
Console.WriteLine($"\n导出 -> {prefix}_tankbuffs.tsv");

// 顺带把坦克技能也导出来，方便人工核对
var 技能行 = new List<string> { "Id\tJob\tLevel\tName" };
foreach (var s in 坦克职业技能.OrderBy(x => x.Job).ThenBy(x => x.Level))
{
    技能行.Add($"{s.Id}\t{s.Job}\t{s.Level}\t{s.Name}");
}
File.WriteAllLines($"{prefix}_tankactions.tsv", 技能行, Encoding.UTF8);
Console.WriteLine($"导出 -> {prefix}_tankactions.tsv");

return 0;
