using System.Text;
using System.Text.Json;
using Lumina;
using Lumina.Data;

// 导出 **TerritoryType → 副本名** 映射。
//
// ══════════════════════════════════════════════════════════════════
//  ★ 为什么需要这个工具 ★
//
//  原来 `DutyNames.json` 的键是 **ContentFinderCondition 的行号**
//  （1 = 托托·拉克千狱、8 = 布雷福洛克斯…），
//  而游戏里 `MemApiZoneInfo.GetCurrTerrId()` 返回的是 **TerritoryType 的 RowId**。
//
//  两套编号**完全不同**：
//      布雷福洛克斯：CFC 行号 = 8，TerritoryType = 206
//      伊修加德房区：TerritoryType = 979，CFC 里根本没有
//
//  ⇒ 拿 TerritoryType 去查 CFC 表，**能不能命中全靠巧合**。
//     用户实测：进本显示 `副本#979`（那是雪都房区，本来就不是副本），
//     而布雷福洛克斯显示对了 —— 纯属 206 恰好没撞上别的名字。
//
//  正确做法：用 `ContentFinderCondition.TerritoryType` 这个**引用字段**
//  把两套编号连起来，导出一份**以 TerritoryType 为键**的新表。
// ══════════════════════════════════════════════════════════════════
//
// 用法: TerritoryDump.exe "D:\FF14\最终幻想XIV\game" [关键词]

Console.OutputEncoding = Encoding.UTF8;

var root = args.Length > 0 ? args[0] : @"D:\FF14\最终幻想XIV\game";
var 关键词 = args.Length > 1 ? args[1] : "";

var candidates = new List<string>();
foreach (var c in root.Split(';', StringSplitOptions.RemoveEmptyEntries))
{
    if (Directory.Exists(c)) candidates.Add(c);
    var sub = Path.Combine(c, "sqpack");
    if (Directory.Exists(sub)) candidates.Add(sub);
}

GameData data = null;
foreach (var path in candidates)
{
    try
    {
        data = new GameData(path, new LuminaOptions { DefaultExcelLanguage = Language.ChineseSimplified });
        Console.WriteLine($"OK {path}");
        break;
    }
    catch (Exception e)
    {
        Console.WriteLine($"   {path}: {e.Message}");
    }
}

if (data == null) return 2;

var cfc = data.Excel.GetSheet<Lumina.Excel.Sheets.ContentFinderCondition>();
Console.WriteLine($"ContentFinderCondition 共 {cfc.Count} 行");
Console.WriteLine();

// TerritoryType -> 副本名（一个 TerritoryType 可能被多条 CFC 引用，
// 比如普通/零式共用地图 —— 这里**保留第一个非空**，并记录被引用了几次）
var 映射 = new Dictionary<string, string>();
var 冲突 = new Dictionary<string, List<string>>();
var 命中 = 0;

foreach (var row in cfc)
{
    uint cfcId = row.RowId;
    if (cfcId == 0) continue;

    string 名 = "";
    try { 名 = row.Name.ToString(); } catch { }
    if (string.IsNullOrWhiteSpace(名)) continue;

    uint terr = 0;
    try { terr = row.TerritoryType.RowId; } catch { }
    if (terr == 0) continue;

    var key = terr.ToString();

    if (映射.TryGetValue(key, out var 已有))
    {
        // 冲突：同一个 TerritoryType 被多条 CFC 引用
        if (!冲突.TryGetValue(key, out var list)) { list = new List<string> { 已有 }; 冲突[key] = list; }
        if (!list.Contains(名)) list.Add(名);
        continue;
    }

    映射[key] = 名;

    if (!string.IsNullOrEmpty(关键词) && 名.Contains(关键词))
    {
        Console.WriteLine($"  ★ TerritoryType {terr}\tCFC {cfcId}\t{名}");
        命中++;
    }
}

Console.WriteLine();
Console.WriteLine($"已建立 {映射.Count} 条 TerritoryType → 副本名 映射");
if (冲突.Count > 0)
{
    Console.WriteLine($"⚠️ 有 {冲突.Count} 个 TerritoryType 被多条 CFC 引用（保留第一个）：");
    foreach (var kv in 冲突.Take(8))
        Console.WriteLine($"    {kv.Key} -> {string.Join(" / ", kv.Value)}");
}

// 顺带把 TerritoryType 本身的区域名也导出来 —— 房区 / 野外 这类
// **不是副本**的地方也要有个像样的名字（用户实测：雪都房区显示"副本#979"）
var terrSheet = data.Excel.GetSheet<Lumina.Excel.Sheets.TerritoryType>();
var 区域名 = new Dictionary<string, string>();
foreach (var row in terrSheet)
{
    uint id = row.RowId;
    if (id == 0) continue;

    string 区 = "";
    try { 区 = row.PlaceNameZone.Value.Name.ToString(); } catch { }
    string 地 = "";
    try { 地 = row.PlaceName.Value.Name.ToString(); } catch { }

    var 最终 = !string.IsNullOrWhiteSpace(地) ? 地 : 区;
    if (!string.IsNullOrWhiteSpace(最终)) 区域名[id.ToString()] = 最终;
}
Console.WriteLine($"已建立 {区域名.Count} 条 TerritoryType → 地点名 映射");

var 选项 = new JsonSerializerOptions { WriteIndented = false };
File.WriteAllText("TerritoryNames.json",
    JsonSerializer.Serialize(映射, 选项), new UTF8Encoding(false));
File.WriteAllText("TerritoryPlaces.json",
    JsonSerializer.Serialize(区域名, 选项), new UTF8Encoding(false));

Console.WriteLine();
Console.WriteLine("已写出 TerritoryNames.json（副本名）与 TerritoryPlaces.json（地点名）");
if (!string.IsNullOrEmpty(关键词)) Console.WriteLine($"关键词「{关键词}」命中 {命中} 条");
return 0;
