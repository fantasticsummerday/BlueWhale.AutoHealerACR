"""★★ 高频路径审计（永久工具 · 去误报版）★★

═══ 为什么需要它（用户原话）═══
  「不要猜测了 完整的检查一下代码 有无相同问题 有咩有bug
    我不想再反反复复开游戏-崩溃-重新开」

===> 本会话踩过的坑 —— 全是"高频路径里做了昂贵的事"：
    ① `调试窗.记诊断()` 每次绘制 `File.AppendAllText`
       => 每秒 1000+ 次写盘 => 开战卡顿 + 闪退 + 系统卡 + 鼠标延迟
    ② 路标节流对【循环路标】无效（号来回变 => "变了就打"永不生效）
       => 16 秒写 10 MB
    ③ 设置面板被画 550~8800 次/秒（ImGui 一帧最多 60 次）
    ④ `面板路标` 用全局节流 => 号互相挤掉 => 日志只剩 2 个号

===> 检查项（都做了去误报处理）
    A 高频函数里的文件 I/O
    B 高频函数里的日志（只看真代码，跳过注释/按钮回调/异常分支）
    C 绘制路径里的反射（必须有 null 缓存判断）
    D 节流器必须按号而不是全局
    E 绘制入口必须有每秒次数上限
    F 写盘的诊断函数必须按时间节流（不能只做内容去重）
    G 静态集合不能只加不减（内存泄漏）
"""
import pathlib
import re
import sys

R = pathlib.Path(__file__).resolve().parent.parent
失败 = []


def 打印(s=""):
    try:
        print(s)
    except Exception:
        print(s.encode("gbk", "replace").decode("gbk"))


文件s = {}
for f in list((R / "HealerACR").rglob("*.cs")) + list((R / "BlueWhale.AutoHealerACR").rglob("*.cs")):
    if {"obj", "bin", ".scratch", ".snapshots", ".il"} & set(f.parts):
        continue
    try:
        文件s[f] = f.read_text(encoding="utf-8", errors="replace").split("\n")
    except Exception:
        pass


def 去注释(ls):
    """去掉行注释与 XML 注释 —— 去误报的关键。"""
    出 = []
    for l in ls:
        s = l.strip()
        if s.startswith("//") or s.startswith("///") or s.startswith("*"):
            出.append("")
            continue
        出.append(l.split("//")[0])
    return 出


打印("=" * 110)
打印("  高频路径审计（{} 个文件）".format(len(文件s)))
打印("=" * 110)

函数s = []
for f, ls in 文件s.items():
    净 = 去注释(ls)
    for k, l in enumerate(净):
        m = re.match(r"\s*(public|private|protected|internal)\s+(?:static\s+)?(?:async\s+)?([\w<>\[\],\.\s\?]+?)\s+(\w+)\s*\(", l)
        if not m:
            continue
        名 = m.group(3)
        if 名 in ("if", "for", "while", "switch", "catch", "using", "lock", "return", "get", "set"):
            continue
        开 = None
        for j in range(k, min(len(净), k + 8)):
            if "{" in 净[j]:
                开 = j
                break
        if 开 is None:
            continue
        深 = 0
        起 = False
        止 = k
        for j in range(开, min(len(净), 开 + 600)):
            深 += 净[j].count("{") - 净[j].count("}")
            if "{" in 净[j]:
                起 = True
            if 起 and 深 == 0 and j > 开:
                止 = j
                break
        函数s.append((f, k + 1, 止 + 1, 名, "\n".join(净[开:止 + 1])))

# [!] 只认【框架每帧回调】的名字。
#     不要写 `Check$` / `Build$`：`StopCheck`、`HealSettings.Build` 之类
#     不是每帧调用，会把它们误报成高频（实测误报过 4 条）。
高频 = re.compile(r"(每帧更新|每帧检查|OnDrawSetting|OnBattleUpdate)")
文件IO = re.compile(r"(File\.(AppendAllText|WriteAllText|WriteAllLines|Open|Create|Delete|Copy|Move)|new\s+(StreamWriter|FileStream)\b)")

# ══ A ══
打印()
打印("  A  高频函数里的文件 I/O")
打印("-" * 110)
n = 0
for f, 起, 止, 名, 体 in 函数s:
    if not 高频.search(名) or not 文件IO.search(体):
        continue
    n += 1
    打印("  [!!] {}::{}() L{}-{}".format(f.name, 名, 起, 止))
    for m in 文件IO.finditer(体):
        打印("        L{:<5} {}".format(起 + 体[:m.start()].count("\n"), m.group(0)))
    失败.append("A")
if n == 0:
    打印("  [OK] 没有「高频 + 写文件」的组合")
打印()

# ══ B ══
打印("  B  高频函数里【每帧真会走到】的日志（跳注释/按钮/异常/后台）")
打印("-" * 110)
日志 = re.compile(r"(LogHelper\.(Info|Error|Warn|Debug)|写诊断\(|记诊断\()")
节流迹 = re.compile(r"(TimeHelper\.Now|_上次|毫秒|节流|只报一次|_已报|记录过|_诊断次数|次数 *>|无法|不存在|_变化|_本轮)")
n = 0
for f, 起, 止, 名, 体 in 函数s:
    if not 高频.search(名):
        continue
    for m in 日志.finditer(体):
        行 = 起 + 体[:m.start()].count("\n")
        前 = 体[max(0, m.start() - 700):m.start()]
        if re.search(r"if\s*\(\s*ImGui\.(Button|Checkbox|SmallButton|Selectable)", 前):
            continue
        if re.search(r"catch\s*\([^)]*\)\s*\{?\s*$", 前[-220:]):
            continue
        if re.search(r"Task\.Run|async\s*\(\)\s*=>", 前):
            continue
        上 = "\n".join(去注释(文件s[f])[max(0, 行 - 26):行])
        if 节流迹.search(上):
            continue
        # [!] **"状态变化才打"也算节流** —— 例如
        #       `if (地图 != _上次地图) { ... LogHelper.Info(...) }`
        #     它每帧被调用，但**只在变化时输出一行**。
        #     实测误报过（`进本识别.每帧检查`）。
        if re.search(r"if\s*\([^)]*!=\s*_?\w*(上次|旧|prev)", 上):
            continue
        # [!] **函数开头有"早退闸门"也算** —— 例如 `进本识别.每帧检查()`：
        #      方法开头有 `if (切图中) return;` / `if (没过稳定期) return;`
        #      / `if (本轮已通知) return;`，走到日志那行时**已经是换图事件**了。
        #      ==> 这类"被闸门保护"的日志每帧被调用、但**极少真的输出**。
        #      实测误报过这一条。
        开头 = 体[:600]
        if re.search(r"return\s*;", 开头) and "return;" in 开头:
            闸 = 开头.count("return;")
            if 闸 >= 2:
                continue
        n += 1
        打印("  [!!] {}::{}() L{:<5} {}".format(f.name, 名, 行, m.group(0)))
        失败.append("B")
if n == 0:
    打印("  [OK] 高频函数里没有「每帧必打且无节流」的日志")
打印()

# ══ C ══
打印("  C  绘制路径里的反射（必须有 null 缓存判断）")
打印("-" * 110)
反射 = re.compile(r"(GetAssemblies\(\)|Delegate\.CreateDelegate)")
n = 0
for f, 起, 止, 名, 体 in 函数s:
    if not re.search(r"(画|OnDraw)", 名):
        continue
    for m in 反射.finditer(体):
        行 = 起 + 体[:m.start()].count("\n")
        上 = "\n".join(去注释(文件s[f])[max(0, 行 - 30):行])
        if re.search(r"if\s*\(.*_\w+\s*==\s*null", 上):
            continue
        n += 1
        打印("  [!!] {}::{}() L{:<5} 反射没有 null 缓存判断".format(f.name, 名, 行))
        失败.append("C")
if n == 0:
    打印("  [OK] 绘制路径里的反射都有 null 缓存判断")
打印()

# ══ D ══
打印("  D  节流器必须【按号】而不是全局")
打印("-" * 110)
n = 0
for f, ls in 文件s.items():
    净 = 去注释(ls)
    for k, l in enumerate(净):
        if not re.search(r"static\s+void\s+(记|面板路标|记详)\s*\(", l):
            continue
        # 只认"路标/节流"语义的：函数体里必须有「输出一行」的动作
        if not re.search(r"(LogHelper\.|打印|Console\.)", "\n".join(净[k:k + 34])):
            continue
        体 = "\n".join(净[k:k + 34])
        if not re.search(r"(TimeHelper\.Now|< 1000|< 8)", 体):
            continue   # 不是节流器
        全文 = "\n".join(净)   # ★ 整个文件（类字段可能在函数外）
        if re.search(r"(Dictionary<int,\s*long>|_各号上次|_路标各号|_AI页各号|_各\w+上次)", 体 + 全文):
            打印("  [OK] {} L{} 按号节流".format(f.name, k + 1))
        else:
            n += 1
            打印("  [!!] {} L{} 全局节流（循环路标下会互相挤掉）".format(f.name, k + 1))
            失败.append("D")
if n == 0:
    打印("  (以上即全部节流器)")
打印()

# ══ E ══
打印("  E  绘制入口有每秒次数上限")
打印("-" * 110)
n = 0
for f, ls in 文件s.items():
    for k, l in enumerate(ls):
        if re.search(r"(public|protected)\s+virtual\s+void\s+OnDrawSetting", l):
            # [!] 窗口要**够大** —— `OnDrawSetting` 本体约 500 行（13 个设置段），
            #     而频率门可能在前面若干道身份门之后（实测在方法开头 +100 行处）。
            #     原来只取 90 行 => 门在窗口外 => **误报"没有频率门"**。
            体 = "\n".join(去注释(ls)[k:k + 260])
            if re.search(r"(_面板上次绘制|绘制节流\.该画面板)", 体):
                打印("  [OK] {}::OnDrawSetting 有频率门".format(f.name))
            else:
                n += 1
                打印("  [!!] {}::OnDrawSetting 【没有】频率门".format(f.name))
                失败.append("E")
if n == 0:
    打印("  (以上即全部绘制入口)")
打印()

# ══ F ══
打印("  F  写盘的诊断函数必须按【时间】节流（不能只做内容去重）")
打印("-" * 110)
n = 0
for f, ls in 文件s.items():
    净 = 去注释(ls)
    for k, l in enumerate(净):
        if not re.search(r"static\s+void\s+\w*(诊断|记)\w*\s*\(", l):
            continue
        体 = "\n".join(净[k:k + 45])
        if not 文件IO.search(体):
            continue
        if re.search(r"(TimeHelper\.Now|Environment\.TickCount64|DateTime\.Now\.Ticks|Stopwatch)", 体):
            打印("  [OK] {} L{} 有按时间节流".format(f.name, k + 1))
        else:
            n += 1
            打印("  [!!] {} L{} 写盘但没有按时间节流".format(f.name, k + 1))
            失败.append("F")
if n == 0:
    打印("  (以上即全部写盘诊断函数)")
打印()

# ══ G ══
打印("  G  静态集合不能只加不减（内存泄漏）")
打印("-" * 110)
全部 = {f: "\n".join(去注释(ls)) for f, ls in 文件s.items()}
集合模式 = re.compile(r"static\s+(?:readonly\s+)?(?:List|Dictionary|HashSet|Queue|Stack|ConcurrentQueue|ConcurrentDictionary)<")
n = 0
for f, t in 全部.items():
    for k, l in enumerate(t.split("\n")):
        if not 集合模式.search(l):
            continue
        m = re.search(r"(\w+)\s*=", l)
        if not m:
            continue
        名 = m.group(1)
        加 = 减 = 0
        for t2 in 全部.values():
            加 += len(re.findall(r"\b" + re.escape(名) + r"\s*\.\s*(Add|Enqueue|Push|TryAdd)\b", t2))
            减 += len(re.findall(r"\b" + re.escape(名) + r"\s*\.\s*(Clear|Remove|RemoveAll|Dequeue|Pop|TryDequeue)\b", t2))
        if 加 > 0 and 减 == 0:
            if re.search(r"(缓存|表$|已报|已诊断|见过|注册|登记|_各|设置|_已)", 名):
                continue
            n += 1
            打印("  [!!] {} L{} `{}` 只加不减（加={}）".format(f.name, k + 1, 名, 加))
            失败.append("G")
if n == 0:
    打印("  [OK] 没有可疑的「只加不减」静态集合")
打印()


# ══ H ══
打印("  H  ImGui Begin/End 必须配对（闪屏的根因）")
打印("-" * 110)
BeginPat = re.compile(r"ImGui\.(Begin|BeginChild|BeginTable|BeginTabBar|BeginCombo|BeginTooltip|BeginGroup)\s*\(")
配对名 = {"Begin": "End", "BeginChild": "EndChild", "BeginTable": "EndTable",
          "BeginTabBar": "EndTabBar", "BeginCombo": "EndCombo",
          "BeginTooltip": "EndTooltip", "BeginGroup": "EndGroup"}
n = 0
总 = 0
for f, ls in 文件s.items():
    净 = 去注释(ls)
    for k, l in enumerate(净):
        m = BeginPat.search(l)
        if not m:
            continue
        总 += 1
        名 = m.group(1)
        配 = 配对名.get(名, "End")
        段 = "\n".join(净[k:k + 240])
        第一配 = 段.find("ImGui." + 配 + "(")
        头部 = 段[:第一配] if 第一配 > 0 else 段[:1200]

        # [!] **有 `finally { End(); }` 时，`return` 是【正确】写法，不该告警。**
        #
        #     为什么（本项目实测踩过的最严重的一次）：
        #       早退分支里**又**自己调了一次 `End()`，而 `return` 会触发 `finally`
        #       => **一次 `Begin` 配了两次 `End`**
        #       => ImGui 的**进程级**窗口栈多弹一层
        #       => **所有窗口一起闪**（连 Dalamud 自己的窗口都被弹掉）
        #
        #     ==> 正确写法：**早退只管 `return`，配对交给 `finally`**。
        #     ==> 所以本检查只在【没有 finally 兜底】时才把 `return` 当问题。
        if re.search(r"finally\s*\{[^}]*ImGui\." + 配 + r"\(", 段):
            continue

        if re.search(r"\breturn\s*;", 头部):
            n += 1
            打印("  [!!] {} L{}  ImGui.{} 之后、ImGui.{} 之前有 return".format(
                f.name, k + 1, 名, 配))
            打印("        ==> 那条路上【没有 {}】==> ImGui 窗口栈失衡".format(配))
            打印("        ==> 现象：窗口反复重绘（闪屏），严重时绘制异常逃逸（闪退）")
            失败.append("H")
if n == 0:
    打印("  [OK] 全部 {} 个 ImGui Begin 之后、配对 End 之前都没有 return".format(总))
打印()

# ══ I ══
打印("  I  早退分支里不能自己 End（会与 finally 叠加成两次）")
打印("-" * 110)
n = 0
for f, ls in 文件s.items():
    净 = 去注释(ls)
    for k, l in enumerate(净):
        m = re.search(r"ImGui\.(Begin|BeginChild)\s*\(", l)
        if not m:
            continue
        配 = "End" if m.group(1) == "Begin" else "EndChild"
        段 = "\n".join(净[k:k + 240])
        第一配 = 段.find("ImGui." + 配 + "(")
        头部 = 段[:第一配] if 第一配 > 0 else 段[:1200]
        # 早退分支 = 含 return 的那一小段；它里面如果**又**有 End，就重复了
        for mm in re.finditer(r"if\s*\([^)]*\).{0,400}?\breturn\s*;", 头部, re.S):
            块 = mm.group(0)
            if re.search(r"ImGui\." + 配 + r"\(", 块):
                n += 1
                打印("  [!!] {} L{}  早退分支里自己调了 ImGui.{}".format(f.name, k + 1, 配))
                打印("        ==> `return` 还会触发 finally => 一次 Begin 配了两次 {} => 全局窗口栈错位".format(配))
                失败.append("I")
if n == 0:
    打印("  [OK] 没有「早退分支自己 End」的写法")
打印()

打印("=" * 110)
if 失败:
    打印("  !! 有 {} 项问题：{}".format(len(失败), "、".join(sorted(set(失败)))))
    打印("=" * 110)
    sys.exit(1)
打印("  ★ 高频路径审计全部通过（9 项）★")
打印("=" * 110)
