"""新环境自检 v2 —— 排除注释行，只扫真实代码。"""
import pathlib
import re

R = pathlib.Path(r"C:\Users\MECHREVO\Documents\deepseek-harness\default-workspace")
文件 = []
for 项目 in ["HealerACR", "BlueWhale.AutoHealerACR"]:
    for p in (R / 项目).rglob("*.cs"):
        if {"obj", "bin"} & set(p.parts):
            continue
        文件.append(p)

读调用 = re.compile(r"File\.(ReadAllText|ReadAllBytes|ReadAllLines|Exists|OpenRead|AppendAllText|AppendAllTextAsync|WriteAllText|WriteAllTextAsync)")


def 是代码行(l):
    """排除注释行（含 XML 文档注释）。"""
    s = l.strip()
    return not (s.startswith("//") or s.startswith("///") or s.startswith("*") or s.startswith("/*"))


print("=" * 78)
print("  运行时文件依赖自检")
print("=" * 78)

总 = 0
可疑 = []

for p in sorted(文件, key=lambda x: x.name):
    lines = p.read_text(encoding="utf-8").split("\n")

    for i, l in enumerate(lines):
        if not 是代码行(l):
            continue
        m = 读调用.search(l)
        if not m:
            continue

        操作 = m.group(1)
        是写 = 操作.startswith(("Write", "Append", "Open"))
        总 += 1

        上文 = "\n".join(x for x in lines[max(0, i - 30):i + 1])
        有Exists = "File.Exists" in 上文
        有建目录 = "CreateDirectory" in 上文
        有try = "try" in 上文

        if 是写 and not 有建目录:
            可疑.append((p.name, i + 1, "写文件，附近没有 CreateDirectory", l.strip()[:64]))
        if (not 是写) and (not 有Exists) and (not 有try):
            可疑.append((p.name, i + 1, "读文件，既没 Exists 守卫也没 try", l.strip()[:64]))

print()
print("  共扫描到 {} 处真实文件操作".format(总))
print()

if 可疑:
    print("  [!][!] 需要确认的 {} 处：".format(len(可疑)))
    for 名, 行, 原因, 代码 in 可疑:
        print("      {:<24} L{:<5} {}".format(名, 行, 原因))
        print("          {}".format(代码))
else:
    print("  [OK] 全部有守卫（Exists 或 try 或 CreateDirectory）")

# == 硬编码路径：看是不是"探测回退"而不是唯一依赖 ==
print()
print("=" * 78)
print("  硬编码路径检查（是不是'探测候选'而非唯一依赖）")
print("=" * 78)

for p in sorted(文件, key=lambda x: x.name):
    t = p.read_text(encoding="utf-8")
    lines = t.split("\n")
    for i, l in enumerate(lines):
        if not 是代码行(l):
            continue
        if not re.search(r'"[A-Za-z]:\\\\|"[A-Za-z]:\\', l):
            continue
        上文 = "\n".join(lines[max(0, i - 12):i + 1])
        有回退 = any(k in 上文 for k in ["Exists", "候选", "foreach", "try", "??", "GetFolderPath"])
        print("      {:<24} L{:<5} 有回退={}  {}".format(p.name, i + 1, 有回退, l.strip()[:56]))

# == 目录自动创建：列出所有写目标目录 ==
print()
print("=" * 78)
print("  首次运行会自动创建的目录")
print("=" * 78)

for p in sorted(文件, key=lambda x: x.name):
    t = p.read_text(encoding="utf-8")
    lines = t.split("\n")
    for i, l in enumerate(lines):
        if not 是代码行(l) or "CreateDirectory" not in l:
            continue
        # 往上找 6 行看注释里有没有说明这是什么目录
        上文 = [x.strip() for x in lines[max(0, i - 6):i] if x.strip().startswith("//")]
        说明 = 上文[-1][:52] if 上文 else ""
        print("      {:<24} L{:<5} {}".format(p.name, i + 1, l.strip()[:50]))
        if 说明:
            print("          {}".format(说明))
