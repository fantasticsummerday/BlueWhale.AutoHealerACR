using System.Text;
using Lumina;
using Lumina.Data;

// 导出副本（TerritoryType）对照表：ZoneId -> 副本名
// 用途：给「必须奶满」这类机制做地图限定 —— 需要知道机制的来源副本 ID
//
// 用法: ZoneDump.exe "D:\FF14\最终幻想XIV\game" [关键词]

Console.OutputEncoding = Encoding.UTF8;

var root = args.Length > 0 ? args[0] : @"D:\FF14\最终幻想XIV\game";
var 关键词 = args.Length > 1 ? args[1] : "";

var candidates = new List<string>();
foreach (var c in root.Split(';', StringSplitOptions.RemoveEmptyEntries))
{
    if (Directory.Exists(c)) candidates.Add(c);
    var sub = Path.Combine(c, "sqpack");
    if (Directory.Exists(sub)) candidates.Add(sub);
}

GameData data = null;
foreach (var path in candidates)
{
    try
    {
        data = new GameData(path, new LuminaOptions { DefaultExcelLanguage = Language.ChineseSimplified });
        Console.WriteLine($"OK {path}");
        break;
    }
    catch (Exception e)
    {
        Console.WriteLine($"   {path}: {e.Message}");
    }
}

if (data == null) return 2;

var sheet = data.Excel.GetSheet<Lumina.Excel.Sheets.TerritoryType>();
Console.WriteLine($"TerritoryType 共 {sheet.Count} 行");
Console.WriteLine();

var lines = new List<string> { "ZoneId\tZoneName\tPlaceName" };
var 命中 = 0;

foreach (var row in sheet)
{
    uint id = row.RowId;
    if (id == 0) continue;

    // 所有字段都可能是 null / 结构为空 —— 逐个 try
    string 区域名 = "";
    try { 区域名 = row.PlaceNameZone.Value.Name.ToString(); } catch { }

    string 地名 = "";
    try { 地名 = row.PlaceName.Value.Name.ToString(); } catch { }

    lines.Add($"{id}\t{区域名}\t{地名}");

    if (!string.IsNullOrEmpty(关键词) &&
        (区域名.Contains(关键词) || 地名.Contains(关键词)))
    {
        Console.WriteLine($"  ★ {id}\t{区域名}\t{地名}");
        命中++;
    }
}

File.WriteAllLines("dump_territory.tsv", lines, new UTF8Encoding(false));
Console.WriteLine();
Console.WriteLine($"已写出 dump_territory.tsv（{lines.Count - 1} 行）");
if (!string.IsNullOrEmpty(关键词)) Console.WriteLine($"关键词「{关键词}」命中 {命中} 行");
return 0;
