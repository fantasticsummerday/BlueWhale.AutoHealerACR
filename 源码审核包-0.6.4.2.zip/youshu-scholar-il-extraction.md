# Youshu (悠树/鍚岀被) Scholar — decision rules extracted from decompiled IL

Source: `.il/youshu.core.txt` (2,887 KB). Classes read: `ACR.Scholar.Resolvers.*`,
`ACR.Scholar.ScholarTools`, `ACR.Scholar.ScholarSettings(Data)`, `ACR.Scholar.ScholarQT`,
`ACR.Scholar.Timeline.Actions.*`, `ACR.Tool.Runtime.Healer*`, `ACR.Tool.Resolvers.Healer*`,
`ACR.Tool.Data.JobId`.

Mojibake note: `鍚岀被` is the corrupted namespace prefix; the readable part is `ACR.*`.

---

## 1. Single-target heal selection

**Deciding class:** `ACR.Scholar.ScholarTools` (selectors) called from
`ACR.Scholar.Resolvers.生命活性法` (Lustrate… see §"id caveat"), `深谋远虑之策`,
`生命回生法`, `医术`, and from `ACR.Scholar.Resolvers.Strategy.学者奶满策略`.

Selector shape (`ScholarTools.LowestHpHealTarget(bool)`, lines 26279-26319): min-by-`CurrentHpPercent`
loop, seeded `float.MaxValue`, no score, no weights:

```
IL_0002: ldc.r4 3.4028235E+38          ; targetHp = float.MaxValue
IL_0008: ldsfld PartyHelper::CastableAlliesWithin30
IL_001e: call ScholarTools::CanReceiveHeal
IL_0045: call HealerHealingHelper::MatchesSingleHealLimit   ; role gate
IL_004d: call GameObjectExtension::CurrentHpPercent
IL_0057: bge.s  IL_005e                 ; if (hp < targetHp) -> new best
```

Ability selectors (`ScholarTools.LustrateTarget/ExcogitationTarget/ShieldTarget/AetherpactTarget`,
lines 26185-26278) do **tank-first, then ally**:

```
IL_0002: ldc.r4 100 ; IL_0008: ldc.r4 0 ; IL_000d: ldc.r4 1
IL_0012: call System.Math::Clamp        ; threshold = Clamp(hpPercent,0,100)
IL_0019: call ScholarTools::SelectSingleHealTank
IL_0020: brfalse.s IL_0024              ; if tank found -> done
IL_0026: call ScholarTools::SelectSingleHealAlly
```

Threshold constants (ints = percent, `ScholarSettingsData::.ctor`, lines 26005-26045;
identical values in `ScholarSettingsUI::ApplyDefaultPreset`, lines 29721-29738):

| setting | default |
|---|---|
| 单盾阈值 Adloquium | 45 |
| 群盾阈值 Succor | 55 |
| 绿帽阈值 Excogitation | 60 |
| 链子阈值 Aetherpact | 55 |
| 活性法阈值 Lustrate | 45 |
| 回生法阈值 Protraction | 35 |
| 低语阈值 Whispering Dawn | 70 |
| 不屈阈值 Indomitability | 70 |
| 祥光阈值 Fey Blessing | 70 |
| 慰藉阈值 Consolation | 55 |
| 变身阈值 Seraphism | 40 |
| 野战治疗阵阈值 Sacred Soil | 35 |
| 应急战术阈值 Emergency Tactics | 35 |
| GCD群奶阈值 GCD group heal | 50 |
| GCD单奶阈值 GCD single heal | 45 |

**Rule:** lowest resolved-HP-percent party member within 30y wins; for *ability* heals a tank in
`CastableTanks` is selected first and allies are only considered if no tank qualifies; role
inclusion is gated by the 单奶限制坦克/奶妈/输出 toggles.

---

## 2. Tank prioritisation

Explicit. (a) Separate `CastableTanks` loop, lines 26628-26650:

```
:: static IBattleChara SelectSingleHealTank(float threshold)
IL_000a: ldsfld PartyHelper::CastableTanks
IL_0022: call ScholarTools::CanReceiveHeal
IL_002b: call GameObjectExtension::CurrentHpPercent
IL_0034: call ScholarTools::NeedsLivingDeadHeal   ; invuln tank wins outright
```

(b) Tank job set `ACR.Tool.Data.JobId::.cctor`, lines 24947-24957:
`19, 21, 32, 37` → `Tanks`; healers `24, 28, 33, 40`.

(c) Deployment-Tactics target prefers an actual tank stance, lines 33557-33571:
`CastableTanks` → `IsTank` + `Helper::HasTankStance` → else `Me`.

**Rule:** tanks (job 19/21/32/37, or Invincibility-status tanks) are a strictly higher-priority
bucket for single-target *ability* heals; cast-time heals ignore role.

---

## 3. Shield decisions

**Classes:** `ACR.Scholar.Resolvers.鼓舞激励之策` (Adloquium, lines 32819-32905),
`ScholarTools.HasScholarShield` (26405), `ScholarTools::SelectShieldTank/Ally` (26679/26708),
`ACR.Scholar.Resolvers.Strategy.学者奶满策略::QueueGroupShield` (33263).

Pre-checks on the target (lines 32865-32890 and 33194-33209):

```
IL_00bb: call ScholarTools::HasScholarShield
IL_00c0: brtrue.s IL_0103            ; already shielded -> abort
...
IL_012e: ldfld ...cachedTarget
IL_0133: call ScholarTools::HasScholarShield
IL_0138: brfalse.s IL_013d           ; second gate
IL_013a: ldc.i4.s -7                 ; "-7 no valid target"
```

`HasScholarShield` = plain presence check, no duration, on 297 (Galvanize) / 1918 (Catalyze) /
2607 / 2608 / 2609, lines 26405-26419. A **duration** constant appears only in the group-shield
counter `CountExistingGroupShieldsWithin20`, lines 26432-26441:

```
IL_0033: ldc.i4 297
IL_0038: ldc.i4 4000
IL_003d: call GameObjectExtension::HasMyAuraWithTimeleft   ; >= 4000 ms
```

Adloquium swaps to 37015 (Adloquium II) when 3884 (Seraphism) is up, line 32921-32923.
Scholar shield also gates the "effective HP" counters with the new `ShieldPercentage` API,
lines 26272-26275 and 26372-26375.

**Rule:** a target is shielded only if it has **no** Scholar shield aura at all (presence, not
remaining time); group-shield bookkeeping treats a shield as "present" only with ≥ 4000 ms left.
No HoT check exists in the shield path (Adloquium's on-hit heal is not modelled).

---

## 4. Group heal triggers

Injured count × threshold, all comparisons `count >= required`:

**Indomitability** — `ACR.Scholar.Resolvers.不屈不挠之策`, lines 30464-30484:

```
IL_0054: ldfld ScholarSettingsData::不屈阈值            ; 70
IL_0059: ldc.i4.s 20
IL_005b: call ScholarTools::CountLowEffectiveHpPartyMembersNearSelf
IL_0065: ldfld ScholarSettingsData::群奶人数
IL_006c: call System.Math::Clamp
IL_0071: bge.s IL_0076                                  ; count >= required
IL_0084: ldc.i4 3583
IL_008a: call HealerActionHelper::IsReady
```

(Indomitability is also forced when `Me` has aura **1896** = Recitation, lines 30560/30569.)

**Whispering Dawn (16537 / Eos)** — `仙光的低语`, lines 30543-30571:

```
IL_0062: ldfld ScholarSettingsData::低语阈值            ; 70
IL_0067: ldc.r4 20
IL_006c: call ScholarTools::CountLowHpAlliesNearFairy
IL_0076: ldfld ScholarSettingsData::群奶人数
IL_007d: call System.Math::Clamp
IL_0082: bge.s IL_0087
IL_00ba: ldc.i4 3000
IL_00bf: call ScholarTools::IsSeraphEndingSoon          ; don't waste Seraph
```

**Consolation** — `慰藉`, lines 30947-30955: `慰藉阈值`(55, but 70 in the daily preset) + `CountLowHpAlliesNearFairy(…, ldc.r4 30)`.
**Fey Blessing / "祥光" (16543)** — `异想的祥光`, lines 30876-30883: `祥光阈值`(70) + `ldc.r4 20`.
**Fey Illumination** — `异想的幻光`, lines 30833-30841: `应急战术阈值`(35) + `CountLowEffectiveHpPartyMembersWithin20`.
**Seraphism** — `炽天附体`, lines 31093-31100: `变身阈值`(40) + `CountLowHpPartyMembers`.
**Sacred Soil** — `野战治疗阵`, lines 31929-31937: `野战治疗阵阈值`(35) + `CountLowHpPartyMembersInRange(…, ldc.i4.s 20)`.
**Seraph's group heal path** — `学者奶满策略::QueueGroupShield` (33263) / `QueueFallbackGroupShield` (33222):
`ldc.r4 0.9` multiplies 群盾阈值, plus a 1500 ms re-cast guard.

**Rule:** fire a group heal when the number of heal-receivable allies whose HP ≤ the per-ability
percentage threshold reaches the configured `群奶人数` count, within 20y of self/the fairy (30y for
Seraph's count); the exception is the GCD group shield, which uses `0.9 × 群盾阈值`.

---

## 5. Ability vs cast-time preference

Static resolver order, `ACR.Scholar.Resolvers.Strategy.学者技能策略::.cctor`, lines 33291-33430
(34 slots, in order):

```
index  1 过路圣人复活     index 10 慰藉              index 19 生命回生法
index  2 复生             index 11 异想的祥光        index 20 朝日召唤
index  3 绝亚康复         index 12 仙光的低语        index 21 醒梦
index  4 自动减伤         index 13 不屈不挠之策      index 22 醒梦
index  5 康复             index 14 鼓舞激励之策  <-- Adloquium, FIRST GCD HEAL
index  6 意气轩昂之策     index 15 医术          <-- Physick
index  7 炽天附体         index 16 深谋远虑之策      index 23 转化
index  8 野战治疗阵       index 17 以太契约          index 24 以太超流
index  9 异想的幻光       index 18 生命活性法        index 25 能量吸收
index 26 连环计           index 27 埋伏之毒          index 28 双DOT
index 29 DOT              index 30 即刻极炎法        index 31 裂阵法
index 32 毁坏             index 33 移动走位即刻极炎法 index 34 极炎法
```

Ordering caveat: indices 14/15 (Adloquium, Physick) precede 16-19 (Excogitation, Aetherpact,
Lustrate, Protraction) — so the GCD shield outranks three off-GCD single-target heals, even though
every off-GCD group heal (7-13) outranks both GCD heals. Every off-GCD resolver additionally gates
on `HealerResolverBase::CanUseOffGcd`, lines 23667-23672
(`BattleData::HighPrioritySlots_OffGCD.Count < limit`) and emits `Spell::DontUseGcd()` in `Build`;
GCD heals use `HealerActionHelper::Gcd(...)` (`医术` line 32144, `鼓舞激励之策` 32924).
`生命活性法` also re-checks `IsReady(189)` at 31190 and refuses while an action was used in the
last 2500 ms (`HealerActionHelper::RecentlyUsed`, line 31184-31188).

**Rule:** priority is off-GCD group/ability heals first (curated order above), then shield, then
Physick; and usage-limit checks (`CanUseOffGcd`, `Charges`, `RecentlyUsed`) stop ability spam.

---

## 6. DoT maintenance

**Classes:** `ACR.Scholar.Resolvers.DOT` (31969, single target) and `ACR.Scholar.Resolvers.双DOT`
(32222) → `ACR.Tool.Resolvers.HealerDoubleDotResolverBase` (23268).

Single-target (`ScholarTools::ShouldSkipSingleTargetDot`, lines 26542-26547; `Resolvers.DOT` 31989-32011):

```
IL_0006: ldfld ScholarSettingsData::不上Dot阈值
IL_000c: ldc.r4 100
IL_0012: ldc.i4.s 12
IL_0015: call HealerEnemyTargetHelper::ShouldSkipDotByHp   ; minHpRatio, maxHpMultiplier=12
...
IL_0050: ldc.i4 17864                                       ; Biolysis
IL_0056: call HealerActionHelper::IsReady
IL_005d: ldc.i4.s -3
IL_006c: call ScholarTools::ShouldSkipSingleTargetDot
IL_0076: ldc.r4 25                                          ; range 25y
IL_0094: ldc.i4 17864
IL_00a0: call HealerDotCastTracker::HasRecentlyApplied
IL_00b1: ldc.i4 3000
IL_00b6: call ScholarTools::HasScholarDotRemaining          ; >= 3000 ms left -> skip
```

Multi-target (`HealerDoubleDotResolverBase`, lines 23408-23437):

```
HasDotPresence : ldc.i4 500  -> HasDotRemaining(500)
HasEnoughDotTime: ldc.i4 3000 -> HasDotRemaining(3000)
Check(): IL_0039 call CountTargets ; candidateCount / activeDotCount gate, ldc.i4.s 35 tail
```

**Rule:** apply/re-apply the DoT only if the target's HP ratio is above `不上Dot阈值` (and its max
HP isn't > 12× the player's), it isn't blacklisted/in a blocked state, no cast was tracked in the
last ~(tracker) window, and the remaining DoT time is **below 3000 ms** (presence test uses 500 ms);
target count gates are applied but their exact caps live in `CountTargets`, which the IL shows only
incrementally.

---

## 7. Incoming-damage prediction

There is **no** per-target predictive/expected-damage model. What exists is boss cast-bar and
engine-`DeathPrediction` polling, all in shared `ACR.Tool.Runtime.HealerEnemyTargetHelper`:

```
:: static bool HasBossCastingAoeWithin(int timeLeftMs)          ; line 21945
IL_0020: call TargetHelper::IsBoss
IL_0033: ldc.r4 30                                             ; only within 30y
IL_003c: call HealerEnemyTargetHelper::IsTargetCastingActionSoon
IL_0044: callvirt IBattleChara::get_CastActionId
IL_0049: call Helper::IsAoeAction

:: static bool HasBossCastingTankbusterWithin(int timeLeftMs)   ; line 21971
IL_0049: call Helper::IsTankDeathSentence

:: static bool IsTargetCastingActionSoon(IBattleChara t, int timeLeftMs)  ; line 22101
IL_0001: callvirt IBattleChara::get_IsCasting
IL_0009: callvirt IBattleChara::get_TotalCastTime
IL_000f: callvirt IBattleChara::get_CurrentCastTime
IL_0015: ldc.r4 1000                                           ; sub-second window
```

Callers:
- `ACR.Scholar.Resolvers.自动减伤` (31335) — `ldc.i4 10000` → `HasBossCastingAoeWithin`, then
  `CountAlivePartyMembersInRangePlusSelf(30) >= 群减人数`, plus a `mitigationLockUntil` tick lock.
- `ACR.Scholar.Resolvers.鼓舞激励之策` (32851-32866) — `GetCurrTargetsTarget()` +
  `ldc.i4 10000` → `HasBossCastingTankbusterWithin`, then `IsTank` && `Distance <= ldc.r4 30`
  && `CanReceiveHeal` && `!HasScholarShield` → pre-shield the tank 10 s before a tankbuster.
- `ACR.Tool.Runtime.HealerEnemyTargetHelper::ShouldHoldBurstForDyingTrash` (22008) reads
  `TargetStat::DeathPrediction` for *enemies* (trash), not for allies.

No auto-attack model, no `Timeline`-driven pre-shielding inside the Scholar resolvers (the
`ACR.Scholar.Timeline.Actions.*` classes only write settings/thresholds — e.g. `单盾阈值` at
line 30080 — and toggle QT flags; they do not compute damage).

**Rule:** the only "prediction" is reactive: read the boss's current cast id/time-remaining and
pre-shield or pre-mitigate if an AoE/tankbuster lands within 10 s (cast completion within 1 s for
the helper's own `timeLeftMs` argument) and the party/lock conditions hold.

---

## Could not determine from the IL

1. **`CountTargets` / `SelectDotTarget` exact caps** — `candidateCount`/`activeDotCount` are
   incremented in a loop whose comparison constants are consumed on other branches; the double-DoT
   cap is not readable as a literal.
2. **`ScholarTools::DotStatuses` contents** — initialised from a field RVA
   (`<PrivateImplementationDetails>::951DEB…`, line 26872 `InitializeArray`), so the status ids are
   in a binary blob, not in the IL.
3. **`ScholarQT::GetQt(string)` name table** — QT flag names are literals at call sites
   ("奶人","群奶","单奶","单盾","不屈","低语","绿帽","秘策","DontUse…"), but the *defaults* for each
   flag live in `EnsureStateDefaults`, which I did not fully disassemble.
4. **`ScholarSettingsData` bool defaults** — `群奶人数`, `群减人数`, `单奶限制坦克/奶妈/输出`,
   `H1` are stored with no preceding `ldc.i4` in the ctor, i.e. `default(bool/int) == false/0`
   unless a JSON config overrides them. So the *shipped* role-limit behaviour is "no limit", but I
   cannot prove the UI never flips them on first run.
5. **`MatchesSingleHealLimit` / `IsBetterLivingDeadPriorityTarget` internals** — both are one-screen
   branch chains with no float constants; the semantics (role gate, Invincibility-priority compare)
   are inferred from the field names they load, not read directly.
6. **`IsTargetCastingActionSoon`'s comparison direction** — the IL places `get_CastActionId` before
   `IsCasting`, so the `ldc.r4 1000` / `timeLeftMs` comparison compiles to a `TotalCastTime -
   CurrentCastTime < X` shape; which of the two operands is `1000` vs the argument is not provable
   from the stack trace alone (both are `<1000 ms` in practice at the two call sites).
7. **Skill-id ↔ Chinese-name mapping** is partly inferred: `185`=Adloquium and `186`=Succor are
   certain (they are swapped for `37015`/`37016` under aura `3884`), but `16543` is only *named*
   `祥光`/Fey Blessing by the resolver class `异想的祥光`; `16545`/`16546` are named by
   慰藉/自动减伤 (Consolation and its Seraph sibling). No name table is present in the IL.
8. **`预读时间` (1500) / `倒计时召唤延迟` (18000)** are configured but I did not find them consumed
   inside the Scholar resolvers — they are presumably used by the opener/countdown layer
   (`ACR.Scholar.Openers.*`, lines 33477-33690), which I did not fully read.
