# 占星术士（AST）两套 IL 实现逐技能对照表

**来源（全部为工作区文件，未做任何臆测替换）**

| 标记 | 文件 | 说明 |
|---|---|---|
| **Y** | `.il\youshu.il.txt`（92,419 行，含完整 IL） | 同类（YouShu）ACR，命名空间 `ACR.Astrologian.*`（Settings / Tools / Timeline / Resolvers / Resolvers.Strategy / Resolvers.GCD / Openers）+ 共享 `ACR.Tool.*` |
| **S** | `.il\shiyuvi.il.txt`（111,612 行） | Shiyuvi ACR，命名空间 `ACR.AST.*`（Overlay/Qt/EventHandler/Settings/Trigggers×3/Triggers×2/GCD×6/Ability×8）+ `ACR.Ast.*`（4 个 hotkey 目标类） |
| 辅助 | `.il\youshu.core.txt` / `.il\shiyuvi.core.txt` | 同一批类的**删减版**（丢掉了大量 `ldc.`/`dup`/`ldloc` 行，**不能用于取常量**）。本报告所有常量一律取自 `.il\*.il.txt` |

**读法约定**
- 所有数字后面括号里的 `IL_xxxx` 是该常量在对应方法里的 IL 偏移，可直接回到 dump 核对。
- `【IL】`＝直接由 IL 证明；`【推】`＝我根据 IL 上下文推断，未经 IL 直接证明；`【缺】`＝该方法/属性在 dump 中**没有方法体**，只能给出调用方传入的参数。
- `Check()` 的返回值语义（AEAssist）：负值 = 放弃（绝对值越小优先级越低），0/正值 = 可用并作为槽位优先级；`-999` 表示被"停手"类总开关否决。
- Y 的所有设置字段都在 `ACR.Astrologian.AstrologianSettingsData`，默认值取自其 `.ctor`（`.il\youshu.il.txt` 73301–73497）。

---

# 一、Y（同类）实现

## 1.1 设置默认值（`AstrologianSettingsData::.ctor`，全部【IL】）

| 字段 | 默认值 | 证据 |
|---|---|---|
| 群奶人数 | 2 | `ldc.i4.2` @73303 |
| 群减人数 | 2 | `ldc.i4.2` @73306 |
| 保留先天数量 | 1 | `ldc.i4.1` @73309 |
| 先天阈值 | 30 | `ldc.i4.s 30` @73312 |
| 擢升阈值 | 75 | `ldc.i4.s 75` @73315 |
| 天星交错阈值 | 70 | `ldc.i4.s 70` @73318 |
| 星位合图阈值 | 30 | `ldc.i4.s 30` @73321 |
| 吉星相位阈值 | 75 | `ldc.i4.s 75` @73324 |
| 贵妇卡阈值 | 70 | `ldc.i4.s 70` @73327 |
| 地星阈值 | 30 | `ldc.i4.s 30` @73330 |
| 星体爆轰阈值 | 60 | `ldc.i4.s 60` @73333 |
| 天宫图阈值 | 75 | `ldc.i4.s 75` @73336 |
| 天星冲日阈值 | 80 | `ldc.i4.s 80` @73339 |
| 中间学派阈值 | 65 | `ldc.i4.s 65` @73342 |
| GCD群奶阈值 | 55 | `ldc.i4.s 55` @73345 |
| GCD单奶阈值 | 40 | `ldc.i4.s 40` @73348 |
| 预读时间 | 1500 | `ldc.i4 1500` @73351 |
| 不上Dot阈值 | 3 | `ldc.i4.3` @73354 |
| 醒梦阈值 | 8000 | `ldc.i4 8000` @73357 |
| 复活延迟 | 1 | `ldc.i4.1` @73360 |
| 地星起手倒数时间 | 10000 | `ldc.i4 10000` @73363 |
| 发卡模式 | 1 | `ldc.i4.1` @73366 |
| DOT走位 | 1 | `ldc.i4.1` @73369 |
| H1 | 1 | `ldc.i4.1` @73372 |
| 优先复活TN | 1 | `ldc.i4.1` @73375 |
| 自动切换最优目标 | 1 | `ldc.i4.1` @73378 |
| 单奶限制坦克 | 1 | `ldc.i4.1` @73381 |
| 地星起手 | 1 | `ldc.i4.1` @73384 |
| 地星优先场中 | 1 | `ldc.i4.1` @73387 |
| 地星优先自己 | 1 | `ldc.i4.1` @73390 |
| 卡1排除黑头玩家 | 1 | `ldc.i4.1` @73393 |
| 放浪神对齐 | 1 | `ldc.i4.1` @73396 |
| ShowDevTest / ShowQt / ShowHotkey / 切换模式自动隐藏QT | 1 | @73399–73409 |
| 太阳神指定目标名称 | `ldstr "优先级目标"` | @73411 |
| 战争神指定目标名称 | `ldstr "优先级目标"` | @73414 |
| 复活提醒频道列表 | `ldstr "/p "` | @73441 |

**未在 `.ctor` 中赋值**（因此为 CLR 默认 0/false，除非 UI 另设）：`高难模式`(=0)、`单奶限制奶妈`、`单奶限制输出`、`智能AOE目标`、`地星开挂模式`、`地星优先目标位置`、`发卡调试`、`过路圣人模式`、`接入MacroRedirection`、`ResetQtOnBattleEnd`、`移动中DOT延迟时间`(=0)、`光速走位`、`光速走位延迟时间`(=0)、`即刻咏唱延迟时间`(=0)、`Opener`(=0=空起手)。【IL：`.ctor` 中无对应 `stfld`】

## 1.2 解析器发布顺序（`Resolvers.Strategy.占星技能策略::.cctor`，`SlotResolvers`，共 38 项）

`ldc.i4.s 38`(IL_0000) → `CollectionsMarshal.SetCount`。索引 → 类 → `SlotResolverData` 的槽位类别：

| # | 类 | 槽位参数 | 证据 |
|---|---|---|---|
| 0 | `ACR.Tool.Resolvers.HealerPotionResolver`（爆发药，构造参数为两个 lambda） | 2 | IL_003f–0045 |
| 1 | `Strategy.过路圣人复活` | 1 | IL_0057–0059 |
| 2 | `Strategy.生辰`（复活） | 1 | IL_0064–006d |
| 3 | `GCD.绝亚康复` | 1 | IL_007b–0081 |
| 4 | `GCD.康复` | 1 | IL_008f–0095 |
| 5 | `命运之轮` | 2 | IL_00a3–00a9 |
| 6 | `擢升` | 2 | IL_00b7–00bd |
| 7 | `中间学派` | 2 | IL_00cb–00d1 |
| 8 | `太阳星座` | 2 | IL_00df–00e5 |
| 9 | `GCD.大宇宙` | 1 | IL_00f4–00fa |
| 10 | `GCD.阳星合相` | 1 | IL_0109–010f |
| 11 | `GCD.阳星` | 1 | IL_011e–0124 |
| 12 | `地星` | 2 | IL_0133–0139 |
| 13 | `星体爆轰` | 2 | IL_0148–014e |
| 14 | `神谕` | 2 | IL_015d–0163 |
| 15 | `天星冲日` | 2 | IL_0172–0178 |
| 16 | `天宫图` | 2 | IL_0187–018d |
| 17 | `GCD.吉星相位` | 1 | IL_019c–01a2 |
| 18 | `GCD.吉星` | 1 | IL_01b1–01b7 |
| 19 | `先天禀赋` | 2 | IL_01c6–01cc |
| 20 | `天星交错` | 2 | IL_01db–01e1 |
| 21 | `星位合图` | 2 | IL_01f0–01f6 |
| 22 | `光速` | 2 | IL_0205–020b |
| 23 | `占卜` | 2 | IL_021a–0220 |
| 24 | `出卡1`（构造参数 `ldc.i4.0` = ignoreQt=false） | 2 | IL_022f–0235 |
| 25 | `小奥秘卡` | 2 | IL_0245–024b |
| 26 | `抽卡` | 2 | IL_025a–0260 |
| 27 | `出卡2` | 2 | IL_026f–0275 |
| 28 | `出卡3` | 2 | IL_0284–028a |
| 29 | `醒梦` | 2 | IL_0299–029f |
| 30 | `光速走位` | 1 | IL_02ae–02b4 |
| 31 | `GCD.双DOT` | 1 | IL_02c3–02c9 |
| 32 | `GCD.DOT` | 1 | IL_02de–02e3 |
| 33 | `GCD.即刻落陷凶星` | 1 | IL_02ed–02f3 |
| 34 | `GCD.移动走位即刻重力` | 1 | IL_0302–0308 |
| 35 | `GCD.移动走位即刻落陷凶星` | 1 | IL_0317–031d |
| 36 | `GCD.中重力` | 1 | IL_032c–0332 |
| 37 | `GCD.落陷凶星` | 1 | IL_0337–0347 |

另外 `ASTACR::Build()`（72672–72896）注册：`TargetJob = ldc.i4.s 33`(占星)、`AcrType=0`、`MinLevel=0`、`MaxLevel=100`；加 1 个 SlotSequence `占星奶满策略`；加 29 个 Timeline Action、11 个 Timeline Condition；`GetOpener(level)`：`level < ldc.i4.s 50` → `空起手`，否则按 `Opener` 字段 `0→空起手 / 1→占星3GCD前半起手 / 其它→null`。

## 1.3 技能 ID 总表（Y，全部【IL】）

| 技能（中文/客户端名） | ID | 出现位置 |
|---|---|---|
| 星极抽卡 Astral Draw | 37017 | `ActiveDrawSpell` @73570+；`抽卡::DrawRecentlyUsed` |
| 灵极抽卡 Umbral Draw | 37018 | 同上（`JobApi_Astrologian.ActiveDraw != 0` 时） |
| 出卡I/II/III（基础） | 37019 / 37020 / 37021 | `AstrologianTools::DrawnCard`、出卡1/2/3 |
| 出卡（按卡面调整后） | 37023=太阳神之衡 / 37024=放浪神之箭 / 37025=建筑神之塔 / 37026=战争神之枪 / 37027=世界树之干 / 37028=河流神之瓶 | `DrawnCard` 的 switch（37023+0..5） |
| 小奥秘卡 | 37022 | `小奥秘卡::Check` |
| 王冠之领主 Lord | 7444 | `小奥秘卡::CheckLord/Build` |
| 王冠之贵妇 Lady | 7445 | `小奥秘卡::CheckLady/Build` |
| 占卜 Divination | 16552 | 占卜 / 小奥秘卡 / 出卡1 / 大宇宙 |
| 命运之轮 | 3613 | 命运之轮 / 太阳星座 / 大宇宙 |
| 地星 | 7439 | 地星::Check/Build、占星奶满策略 |
| 星体爆轰 | 8324 | `星体爆轰::Check/Build`（`RecentlyUsed(8324,2500)`） |
| 天宫图 | 16557 | 天宫图::Build |
| 天宫图二段（Horoscope Helios） | 16558 | 天宫图::Check/Build |
| 天星交错 | 16556 | 天星交错::Check/Build |
| 天星冲日 | 16553 | 天星冲日::Build |
| 太阳星座 | 37031 | 太阳星座::Build |
| 擢升 | 25873 | 擢升::Check/Build |
| 星位合图 | 3612 | 星位合图::Check/Build |
| 神谕 Oracle | 37029 | 神谕::Check/Build |
| 醒梦 | 7562 | 醒梦::Check/Build |
| 中间学派 | 16559 | 中间学派::Check/Build |
| 阳星合相（经 3601 调整） | 37030 | 中间学派::Build（直接 37030）、阳星::Check（`RecentlyUsed(37030,8000)`） |
| 光速 | 3606 | 光速 / 光速走位 / 生辰辅助 / 即刻落陷凶星（预留） |
| 先天禀赋 | 3614 | 先天禀赋 / 占星奶满策略 |
| 即刻咏唱 | 7561 | 即刻落陷凶星 / 移动走位即刻* / 合相/落陷凶星移动分支 |
| 生辰（复活） | 3603 | `HasDeadAllyWithoutRaise`、`HealerRaiseResolver` 构造 |
| 康复 | 7568 | GCD.康复 / GCD.绝亚康复 |
| 阳星 | 3600 | GCD.阳星 Build |
| 阳星相位（升级为阳星合相） | 3601 | GCD.阳星合相 Build、占星奶满策略 |
| 吉星 | 3594 | GCD.吉星（回退分支）、占星奶满策略 |
| 福星 | 3610 | GCD.吉星（首选分支）、占星奶满策略 |
| 吉星相位 | 3595 | GCD.吉星相位 Build、占星奶满策略 |
| 凶星 | 3596 / 3594 无关；GCD.DOT 用 3599（烧灼） | — |
| 烧灼（DoT） | 3599 | GCD.DOT、GCD.双DOT |
| 落陷凶星 | 25871 | GCD.落陷凶星 / 即刻落陷凶星 / 移动走位 |
| 重力（升级为中重力） | 3615 | GCD.中重力 / 移动走位即刻重力 / 起手 |
| 大宇宙 | 25874 | GCD.大宇宙 Build |
| 强击（防击退，hotkey） | 7559 | S 侧 rotation entry（Y 侧未见） |

## 1.4 逐技能条件表（Y）

### 1.4.1 抽卡（`Resolvers.抽卡`，youshu 83921–84152）

`Check()` 顺序【IL】：

| # | 条件 | 字面量/字段 | 分支 |
|---|---|---|---|
| 1 | `AstrologianResolverBase::StopRequested()`（= QT `"停手"`） | `ldstr "停手"` | true → `-999` |
| 2 | QT `"抽卡"` | `ldstr "抽卡"` | false → `-50` |
| 3 | QT `"攒爆发"` 且 非 QT `"倾泻资源"` | 两个 ldstr | → `-50` |
| 4 | `HasSkillSilenceStatus()` | — | true → `-1` |
| 5 | `HealerResolverBase::CanUseOffGcd(2)` | `ldc.i4.2` | false → `-4` |
| 6 | `RecentlyUsed(16552, 3000)` 且 `HasHeldDamageCard()` | `ldc.i4 16552`,`ldc.i4 3000` | true → `-6` |
| 7 | `DrawRecentlyUsed()` | 见下 | true → `-1` |
| 8 | `Level >= 70` 且 `DrawnCrownCard == 7`（手持领主打牌未出） | `ldc.i4.s 70`,`ldc.i4.7` | true → `-4` |
| 9 | `ShouldAlignDivination()` 为 false | 见下 | → `RegularDrawWeight()` |
| 10 | `16552` 冷却 = `Ability(16552).Cooldown.TotalMilliseconds` | — | `< 55000`（`ldc.r8 55000`）→ 清两个静态锁，返回 `-5` |
| 11 | | | `> 67000`（`ldc.r8 67000`）→ `highEndLockedInWindow=false; highEndAllowDrawIn55Window=true` → `RegularDrawWeight()` |
| 12 | `!highEndLockedInWindow && cd <= 56000` | `ldc.r8 56000` | 锁入窗口：`highEndAllowDrawIn55Window = BaseDrawReady()`；`highEndLockedInWindow = true` |
| 13 | `!highEndLockedInWindow || !highEndAllowDrawIn55Window` | — | → `-5` |
| 14 | 兜底 | — | `RegularDrawWeight()` |

`RegularDrawWeight()`：`DrawnCard(0) != 0`（0 号卡槽已有卡）→ `-7`；`!DrawQueueReady() || !BaseDrawReady()` → `-4`；QT`"倾泻资源"` → `50`，否则 `40`。
`DrawQueueReady()`：`TickCount64 - lastDrawQueuedTime >= 1200`（`ldc.i4 1200`）。
`BaseDrawReady()`：`!DrawRecentlyUsed() && SpellExtension::IsReadyWithCanCall(ActiveDrawSpell())`（`call AEAssist.Helper.SpellExtension::IsReadyWithCanCast`）。
`DrawRecentlyUsed()`：`RecentlyUsed(37017,55000) || RecentlyUsed(37018,55000)`（两个 `ldc.i4 55000`）。
`HasHeldDamageCard()`：`DrawnCard(0) == 1 || == 4`。
`ShouldAlignDivination()`：`高难模式 == 1` → true；`高难模式 == 2` → QT`"对齐占卜"`；否则 false。
`构建自用抽卡()`：写 `lastDrawQueuedTime = Environment.TickCount64`，返回 `AstrologianTools::SelfActiveDrawSpell()` → `ActiveDrawSpell()` → `JobApi_Astrologian.ActiveDraw ? 37018 : 37017`。
`副本内强制抽卡判定()`（给 EventHandler 用）：需 `!QT停手` && `QT抽卡` && (非攒爆发 或 QT倾泻资源) && `MemApiCondition::IsBoundByDuty` && `!HasSkillSilenceStatus` && `DrawnCard(0)==0` && (`Level < 70` 或 `DrawnCrownCard != 7`) && `!DrawRecentlyUsed` && `DrawQueueReady`；最后返回 `BaseDrawReady()`。
`AstrologianEventHandler::TryDutyDraw()`：满足上述则每 `1500`（`ldc.i4 1500`）ms 一次；非战斗中且 `!MemApiSpell.HasActionQueue` → 直接 `SpellHelper::Cast(构建自用抽卡())`；战斗中若 `BattleData.HighPrioritySlots_OffGCD.Count >= 2`(`ldc.i4.2`) 则放弃，否则入队 `new Slot(600)`（`ldc.i4 600`）。

**持有卡上限**：IL 只体现"0 号卡槽非空就不再抽"（`RegularDrawWeight` 的 `-7`）与按索引 `DrawnCard(0/1/2)` 读卡；**没有**任何 `DrawnCards.Length` 常量或上限常量出现在 IL 中。

### 1.4.2 出卡1（`Resolvers.出卡1`，1=太阳神之衡 / 4=战争神之枪）

| # | 条件 | 字面量 | 分支 |
|---|---|---|---|
| 1 | （若 `ignoreQt==false`）`StopRequested()` | `"停手"` | `-999` |
| 2 | （若 `ignoreQt==false`）QT `"出卡1"` | `"出卡1"` | false → `-8` |
| 3 | `card = DrawnCard(0)`；actionId = `1→37023`、`4→37026`、其它 `→37019` | `ldc.i4 37023/37026/37019` | 写入 `cachedActionId` |
| 4 | 若 `ignoreQt==true`（热键路径）→ `CheckHotkeyCard(card)` | — | 见下 |
| 5 | `CanUseOffGcd(2)` | `ldc.i4.2` | false → `-4` |
| 6 | `HasSkillSilenceStatus()` | — | `-1` |
| 7 | 当前目标存在且（`HasAttackBlock()` 或 `IsDying()`） | — | `-1` |
| 8 | `card == 0`（无卡） | — | `-10` |
| 9 | `CurrBattleTimeInMs < 5000` | `ldc.i4 5000` | `-200` |
| 10 | 目标角色 = `(card==1或4) ? 发卡设置::获取发卡目标角色(card) : null` | — | — |
| 11 | `!ShouldAlignDivination()` 时：`BurstHoldControl::ShouldHoldForDyingTrash()` | — | `-10` |
| 12 | | | 否则 `TryCardTarget(目标, 20)`（`ldc.i4.s 20`） |
| 13 | `ShouldAlignDivination()` 时：QT`"攒爆发"` 且 非 QT`"倾泻资源"` | 两个 ldstr | `-50` |
| 14 | QT `"倾泻资源"` | | `TryCardTarget(目标, 50)` |
| 15 | `Me` 有 aura `1878`（占卜已开） | `ldc.i4 1878` | `TryCardTarget(目标, 40)` |
| 16 | `Level >= 50` 且 `Ability(16552).Cooldown.TotalMilliseconds <= 67000` | `ldc.i4.s 50`,`ldc.r8 67000` | `-10` |
| 17 | 兜底 | | `TryCardTarget(目标, 30)` |

`TryCardTarget(target, success)`：目标为空 → `-1`；`ShouldWaitSelfCardFallback(target)` → `-1`；`发卡模式 != 2` 且 目标已有同卡 buff（37023→aura `3887`，37026→aura `3889`）→ `-5`；`IsReady(cachedActionId, target)` 失败 → `-1`；否则返回传入的 `success`。
`ShouldWaitSelfCardFallback(target)`：目标不是自己 → 清零 `selfCardStart` 返回 false；是自己 → 首次记录 `selfCardStart=CurrBattleTimeInMs` 并返回 true；否则返回 `CurrBattleTimeInMs - selfCardStart < 3000`（`ldc.i4 3000`）。
`CheckHotkeyCard`：静默 → `-1`；`card==0` → `-10`；`card` 为 1/4 时取 `发卡设置::获取发卡目标角色`，否则 null；目标空或 `!IsReady(cachedActionId,target)` → `-1`；否则 `1`。
`Build`：`slot.Add(HealerActionHelper::Ability(cachedActionId, cachedTarget).DontUseGcd())`，再 `SendDebugMessage()`（`发卡调试` 开启时 `/e …`）。

### 1.4.3 出卡2（`Resolvers.出卡2`，2=世界树之干 / 3=放浪神之箭）

| # | 条件 | 字面量 | 分支 |
|---|---|---|---|
| 1 | 清缓存、`alignRecitation=false` | `ldc.i4.0` | — |
| 2 | `StopRequested()` | `"停手"` | `-999` |
| 3 | `enabled = QT("出卡2")` | `"出卡2"` | — |
| 4 | `高难模式 != 1` 时需 `QT奶人 && QT能力技奶` | 两个 ldstr | 否则 `-8` |
| 5 | `card = DrawnCard(1)`；`2→37027`、`3→37024`、其它 `→37020` | `ldc.i4 37027/37024/37020` | 写 `cachedActionId` |
| 6 | `applySingleHealLimit = QT("单奶限制")` | `"单奶限制"` | — |
| 7 | `!enabled` 且（`!放浪神对齐` 或 `card != 3`） | `ldc.i4.3` | `-8` |
| 8 | `CanUseOffGcd(1)` | `ldc.i4.1` | false → `-4` |
| 9 | `HasSkillSilenceStatus()` | — | `-1` |
| 10 | `card == 0` | — | `-10` |
| 11 | `!MemApiDuty.InBossBattle` 且 `CurrBattleTimeInMs < 15000` | `ldc.i4 15000` | `-9` |
| 12 | `card == 3`（放浪神）→ `SelectArrowTarget()`；目标空或 `!IsReady` → `-1`；`alignRecitation` 为真 → `50`，否则 `1` | `ldc.i4.s 50` | — |
| 13 | `card == 2`（世界树）→ `SelectBoleTarget()`；目标空或 `!IsReady` → `-1`；`HasBossCastingTankbusterWithin(10000)` → `10`，否则 `2` | `ldc.i4 10000`,`ldc.i4.s 10` | — |
| 14 | 其它卡 | | `-1` |

`SelectArrowTarget()`：`alignRecitation=false`；若 `放浪神对齐`：遍历 `PartyHelper::CastableAlliesWithin30`，找 `ClassJob.RowId == 28`（学者）且 有 aura `1896`（连环计）者 → `alignRecitation=true` 并返回之；找不到返回 null。否则返回 `SelectLowestHpTarget(先天阈值/100f, tankFirst=false)`（`ldc.r4 100` 除、`ldc.i4.0`）。
`SelectBoleTarget()`：`HasBossCastingTankbusterWithin(10000)` 成立则 `SelectLowestTank(pred)`（pred = 编译生成的 `<>c::<SelectBoleTarget>b__7_0`，**方法体不在 dump**），非空即返回；否则 `SelectLowestHpTarget(0.9f, tankFirst=true)`（`ldc.r4 0.9`,`ldc.i4.1`）。
`SelectLowestHpTarget(hpThreshold, tankFirst)`：遍历 `CastableAlliesWithin30`，需 `CanReceiveHeal`、`CurrentHpPercent < hpThreshold`、无 aura `1945`、通过 `CanSingleHeal`；`rank = IsTank ? hp - 1f : hp`（`ldc.r4 1`），取最小。
`CanSingleHeal(target)`：未启用单奶限制则 true；否则 `AstrologianTools::CanSingleHealTarget`。

### 1.4.4 出卡3（`Resolvers.出卡3`，6=建筑神之塔 / 5=河流神之瓶）

| # | 条件 | 字面量 | 分支 |
|---|---|---|---|
| 1 | 清 `cachedTarget`；`StopRequested()` | `"停手"` | `-999` |
| 2 | QT `"出卡3"` | | false → `-8` |
| 3 | `高难模式 != 1` 时需 QT奶人+能力技奶 | | 否则 `-8` |
| 4 | `card = DrawnCard(2)`；`5→37028`、`6→37025`、其它 `→37021` | `ldc.i4 37028/37025/37021` | — |
| 5 | `applySingleHealLimit = QT("单奶限制")` | | — |
| 6 | `CanUseOffGcd(1)` | `ldc.i4.1` | `-4` |
| 7 | `HasSkillSilenceStatus()` | | `-1` |
| 8 | `card == 0` | | `-10` |
| 9 | `card == 6` → `SelectSpireTarget()`；空或 `!IsReady` → `-1`；否则 `1` | | — |
| 10 | `card == 5` → `SelectEwerTarget()`；空或 `!IsReady` → `-1`；否则 `2` | | — |
| 11 | 其它 | | `-1` |

`SelectSpireTarget()`：`HasBossCastingTankbusterWithin(10000)`（`ldc.i4 10000`）时先 `SelectLowestTank(pred=<>c::b__5_1)`（**体缺**）→ 非空返回；再 `SelectLowestTank(pred=<>c::b__5_0)`（**体缺**）→ 非空且 `!HasShieldBuff(t)`（aura `2608`）则返回，否则 null；都失败时：`Me.CurrentHpPercent < 0.5f`（`ldc.r4 0.5`）且 `!HasShieldBuff(Me)` → 返回自己，否则 null。
`SelectEwerTarget()`：遍历 `CastableAlliesWithin30`，需 `CanReceiveHeal`、`hp < 先天阈值/100f`（`ldc.r4 100`）、`CanSingleHeal`；分别记录最低血的治疗（healer 分支）与非治疗，优先返回治疗。
`CountSpireMitigations`：aura `2717` + `3890` + `1889` 计数（未被调用）。`HasShieldBuff`：aura `2608`。

### 1.4.5 小奥秘卡（`Resolvers.小奥秘卡`，youshu 83584–83921）

`Check()`：

| # | 条件 | 字面量 | 分支 |
|---|---|---|---|
| 1 | `StopRequested()` | `"停手"` | `-999` |
| 2 | `HasSkillSilenceStatus()` | | `-1` |
| 3 | `CurrBattleTimeInMs < 5000` | `ldc.i4 5000` | `-200` |
| 4 | `CanUseOffGcd(2)` | `ldc.i4.2` | `-4` |
| 5 | `RecentlyUsed(37022,5000) \|\| RecentlyUsed(7444,5000) \|\| RecentlyUsed(7445,5000)` | 三个 id + `ldc.i4 5000` | `-6` |
| 6 | `cachedCrown = DrawnCrownCard`；`7 → CheckLord()`、`8 → CheckLady()`、其它 `→ -1` | `ldc.i4.7 / ldc.i4.8` | — |

`CheckLord()`：`!IsReady(7444)` → `-200`；`!QT("AOE")` → `-3`；当前目标 `IsDying()` → `-1`；`ShouldAlignDivination()`（`高难模式==1` 或 `高难模式==2 && QT("对齐占卜")`）为真 → 走 1 分支，为假 → 2 分支：
- **对齐分支**：`ShouldHoldForDyingTrash()` → `-10`；目标 `HasAttackBlock` → `-1`；`enemyCount = TargetHelper::GetNearbyEnemyCount(20)`（`ldc.i4.s 20`）；`==0 → -2`；`==3 → -200`；`ShouldWaitDivination(2000)`（`ldc.i4 2000`）→ `-13`；否则 `15`。
- **非对齐分支**：QT攒爆发且非倾泻 → `-50`；QT倾泻资源 → `50`；`enemyCount = GetNearbyEnemyCount(20)`；`0 → -2`；`>=6`（`ldc.i4.6`）时：`ShouldWaitDivination(2000)` → `-200`；否则 QT`"剑卡"` → `22`，否则 `5`；`<6` 时：`Level < 50`（`ldc.i4.s 50`）→ `2`；`Me` 有 aura `1878` → `1`；`16552` 冷却 `> 67000`（`ldc.r8 67000`）或 `enemyCount >= 3` → `2`；否则 `-10`。
`CheckLady()`：`!IsReady(7445)` → `-200`；需 `QT奶人 && QT能力技奶`，否则 `-100`；`Me` 有 aura `1224` 或 `1248` → `-8`（**这是唯一的"学派"分支**）；`threshold = Clamp(贵妇卡阈值/100f, 0, 1)`（`ldc.r4 100/0/1`）；`CountAlliesHpBelow(threshold, 20)` > 0 → `3`；`GetNearbyEnemyCount(20) < 3` → `-5`；`HasCriticalTank(threshold)`（治疗距离 `ldc.r4 20`）为假 → `-5`；否则 `4`。
`ShouldWaitDivination(ms)`：`Level < 50` → false；否则 `16552` 冷却 `<= ms` 且 `Me` 无 aura `1878` → true（`ldc.i4 1878`）。
`Build`：`7 → slot.Add(Ability(7444).DontUseGcd())`；`8 → slot.Add(Ability(7445).DontUseGcd())`。

### 1.4.6 发卡目标选择（`Resolvers.Strategy.发卡设置`，youshu 85488–87180）

- `规范化发卡模式(mode)`：`mode == 2 → 2`，否则 `→ 1`（IL_0000–0007）。
- `获取发卡目标(actionId)`：若 `规范化发卡模式 == 2`：`37023 → 太阳神指定目标名称`、`37026 → 战争神指定目标名称`，其它 `""`；用 `获取指定目标ID(name)` 在 `Party` 里按 `GameObject.Name.ToString()` 逐个 `String.Equals(name, Ordinal)` 匹配（跳过自己，且要求 `目标有效`）；命中即返回其 `EntityId`。未命中则 `刷新候选者如需()`，再 `37023 → 获取候选者ID_太阳神`、`37026 → 获取候选者ID_战争神`、其它 → 自己的 `EntityId`。
- `获取发卡目标角色(card)`：`card==1→37023`、`card==4→37026`、其它 → 返回 `Me`；随后按上表取 id，id == 自己 → `Me`，否则在 `Party` 中找 `EntityId` 相同者，找不到 → `Me`。
- `获取指定目标ID(name)`：`name` 为空或 `Party.Count < 2`（`ldc.i4.2`）→ 0。
- `目标有效(t)`：非空、`IsTargetable`、非 `IsDead`、`CurrentHp > 0`、`Distance(me) <= 30f + AttackRangeBonus()`（`ldc.r4 30`）。
- `目标有黑头Debuff(t)`：遍历状态，`StatusId != 0` 且 `Helper::IsDamageDown(StatusId)` 且（`StatusId != 1793`（`ldc.i4 1793`）或 `RemainingTime <= 600f`（`ldc.r4 600`））→ true。
- `刷新候选者如需()`：`Party.Count <= 1`（`ldc.i4.1`）时清空两个候选表与缓存并返回；否则当 `需要重新排序` 或 `队伍成员已变化` 时 `排序候选者` + `缓存队伍成员` + 清标志。
- `更新战斗阶段()`：脱离战斗 → 阶段 0；进入战斗 → 阶段 1 并记 `战斗开始时间`；`CurrBattleTimeInMs <= 30000` → 阶段 2；`>= 120000` → 阶段 3；否则保持。阶段变化时置 `需要重新排序`。
- `获取当前阶段键()`：阶段 `== 2 → "起手"`，否则 `"2分钟+"`（`ldstr`）。
- `排序候选者(party)`：取 `获取职业优先级(自定义近战发卡顺序, 默认职业优先级.近战, phase)` 与远程版；`添加职业优先级候选者(party, meleeOrder, isMelee=true)`（`ldc.i4.1`）与 `(…, false)`（`ldc.i4.0`）；再 `添加后备候选者`；两张表各自 `Sort(<>c::<排序候选者>b__34_0 / b__34_1)`（**比较器体缺**）。
- `添加职业优先级候选者`：跳过自己；`IsDamageCardCandidate(member,isMelee)`；`计算职业优先级(jobId, order)`。
- `IsDamageCardCandidate(member,isMelee)`：`isMelee==false` → `JobId.RangedDps.Contains(job) || JobId.CasterDps.Contains(job)`；`isMelee==true` → `JobId.MeleeDps.Contains(job) || job == 32`（`ldc.i4.s 32`＝黑骑，作为近战发卡候选）。
- `计算职业优先级(jobId, order)`：返回 `order.Length - i`（命中下标 i），未命中返回 `0.5`（`ldc.r8 0.5`）。
- `TryMapJobName(name, ref id)`：按名字长度 switch，匹配 `"Ninja"→30`、`"Samurai"→34`、`"Reaper"→39`、`"Dragoon"→22`、`"Monk"→20`、`"Viper"→41`、`"Dark Knight"→32`、`"Machinist"→31`、`"Bard"→23`、`"Dancer"→38`、`"Black Mage"→25`、`"Summoner"→27`、`"Red Mage"→35`、`"Pictomancer"→42`（全部 `ldc.i4.s`；表格见 §1.4.6 末尾）。
- `添加单类型后备候选者`：候选表为空时，把第一个满足条件者以权重 `1`（`ldc.r8 1`）加入。
- `获取候选者ID_太阳神()`：先近战表三次尝试（`<>c::<获取候选者ID_太阳神>b__45_0/1/2`，**过滤器体缺**）→ 命中返回 `EntityId`；否则远程表三次（b__45_3/4/5）→ 命中返回；否则 `获取兜底目标ID()`。
- `获取候选者ID_战争神()`：远程表三次（b__46_0/1/2）→ 近战表三次（b__46_3/4/5）→ 兜底。
- `从候选表取第一个_按黑头策略(candidates, filter)`：若 `卡1排除黑头玩家` 为真，先用 `filter && !目标有黑头Debuff`（`<>c__DisplayClass28_0::<从候选表取第一个_按黑头策略>b__0`，**体缺**）取第一个；失败再退回原 `filter`。
- `存在有效候选者(candidates, actionId)`：任一候选者 `目标有效` 且 `!有指定卡1Buff(target, actionId)`。
- `有指定卡1Buff`：`37023→aura 3887`、`37026→aura 3889`、其它 false；`有任意卡1Buff` = `HasAura(3887) || HasAura(3889)`。
- **默认职业优先级（`.cctor`，全部 `ldstr`，IL 142344–145007）**
  - `默认近战起手` = `["Samurai","Ninja","Dragoon","Dark Knight","Monk","Reaper","Viper"]`
  - `默认近战二分钟` = `["Samurai","Ninja","Viper","Dragoon","Monk","Dark Knight","Reaper"]`
  - `默认远程起手` = `["Pictomancer","Summoner","Machinist","Dancer","Red Mage","Black Mage","Bard"]`
  - `默认远程二分钟` = `["Pictomancer","Summoner","Machinist","Bard","Red Mage","Dancer","Black Mage"]`
  - 配置键：`"起手"`、`"2分钟+"`；来源标记 `"自定义配置"` / `"默认配置"` / `"未知"`。

### 1.4.7 地星（`Resolvers.地星`，youshu 82677–82860）

`Check()` 顺序【IL】：

| # | 条件 | 字面量 | 分支 |
|---|---|---|---|
| 1 | `StopRequested()` | `"停手"` | `-999` |
| 2 | QT `"地星"` | | false → `-100` |
| 3 | `高难模式 != 1` 时需 `QT倾泻资源` 或 (`QT奶人 && QT能力技奶`) | 三个 ldstr | 否则 `-100` |
| 4 | `HasSkillSilenceStatus()` | | `-1` |
| 5 | `Me` 有 aura `1224` 或 `1248` | `ldc.i4 1224 / 1248` | `-1`（**学派分支**） |
| 6 | `IsReady(7439)` | | false → `-200` |
| 7 | `CanUseOffGcd(2)` | | `-4` |
| 8 | `CurrBattleTimeInMs >= 1000` 或 QT倾泻资源 | `ldc.i4 1000` | 否则 `-50` |
| 9 | 目标为空 或 `!目标.IsBoss` → 再判 `CurrBattleTimeInMs >= 15000`（`ldc.i4 15000`）或 QT倾泻资源，否则 `-4` | | |
| 10 | `AstrologianTools::CountEnemiesInRange(25f)`（`ldc.r4 25`）非 0 或 QT倾泻资源 | | 否则 `-5` |
| 11 | `AEAssist.Helper.GCDHelper::CanUseOffGcd()` | | false → `-8` |
| 12 | `Me.InCombat` | | false → `-1` |
| 13 | `HasBossCastingAoeWithin(10000)`（`ldc.i4 10000`）且 非 QT倾泻资源：`CountAlliesHpBelow(0.8f,20f)`（`ldc.r4 0.8`,`ldc.r4 20`）`>= 2`（`ldc.i4.2`）→ `35`，否则 `25` | | |
| 14 | `非 QT倾泻资源` 且 `CountAlliesHpBelow(地星阈值/100f, 20f) >= 1`（`ldc.i4.1`） | `ldc.r4 100`,`ldc.r4 20` | `60` |
| 15 | QT攒爆发 且 非倾泻资源 | | `-50` |
| 16 | 非 QT倾泻资源 | | `30` |
| 17 | QT倾泻资源 | | `50` |

`Build(slot)`【IL】：
- `currentTarget = AstrologianTools::CurrentTarget`
- `targetPosValid = 地星优先目标位置 && currentTarget != null && currentTarget.IsValid && currentTarget.HitboxRadius < 15f`（`ldc.r4 15`）
- `pos = HealerGroundTargetHelper::GroundCastPosition(地星优先场中, 地星开挂模式, targetPosValid, currentTarget)`
- `slot.Add(new Spell(7439, pos).DontUseGcd())`

**关于"10 秒延迟"**：地星类里没有 10000 的延迟判断；`10000` 只出现在 `HasBossCastingAoeWithin(10000)` 与设置默认值 `地星起手倒数时间=10000`。真正的引爆阈值在下面的星体爆轰里。`ACR.Astrologian.出卡1` 还有一个 `new Slot(600)`（热键包装）与 `MenuHighPriorityOffGcd` 入队。

### 1.4.8 星体爆轰（`Resolvers.星体爆轰`，youshu 84580–84792）

| # | 条件 | 字面量 | 分支 |
|---|---|---|---|
| 1 | `StopRequested()` | `"停手"` | `-999` |
| 2 | 需 `QT奶人 && QT能力技奶 && QT地星` | 三个 ldstr | `-100` |
| 3 | `HasSkillSilenceStatus()` | | `-1` |
| 4 | `IsReady(8324)` | | `-3` |
| 5 | `CanUseOffGcd(2)` | | `-4` |
| 6 | `RecentlyUsed(8324, 2500)` | `ldc.i4 2500` | `-1` |
| 7 | `Me` 有 aura `1224` 或 `1248` | | `-1`（学派分支） |
| 8 | `GCDHelper::CanUseOffGcd()` | | `-8` |
| 9 | `Me.InCombat` | | `-1` |
| 10 | QT `"倾泻资源"` | | `22` |
| 11 | QT `"日随模式"` 时：`HasLowHpBoss()` → `3`；否则 `HasDyingTrash()` → `4` | | |
| 12 | `Me` 有 aura `1248`（黑夜学派）且 `CountAlliesHpBelow(天宫图阈值/100f, 30f) >= 群奶人数` | `ldc.r4 100`,`ldc.r4 30` | `2` |
| 13 | `Me` 有 aura `1248` 且 `CountAlliesHpBelow(星体爆轰阈值/100f, 30f) >= 1` | `ldc.i4.1` | `1` |
| 14 | 兜底 | | `-200` |

- `HasLowHpBoss()`：遍历 `TargetMgr.Enemys`，`TargetHelper::IsBoss(e)` 且 `e.CurrentHpPercent < 0.05f`（`ldc.r4 0.05`）。
- `HasDyingTrash()`：统计非 Boss、`CurrentHp > 0`、`Distance(me) <= 25f`（`ldc.r4 25`）的敌人数量与血量百分比之和；`count > 0 && (hpSum / count) < 0.2f`（`ldc.r4 0.2`）。
- `Build`：`slot.Add(Ability(8324).DontUseGcd())`。
- **注意**：`星体爆轰阈值` 默认 60（对应你问的"阈值"），且只在**黑夜学派 aura 1248** 存在时才参与判定；另外两条 `日随模式` 分支用的是 boss 血量 <5% 与杂兵平均血量 <20%。

### 1.4.9 其余 off-GCD 技能（Y）

**中间学派（16559 / 阳星合相 37030）**：清 `shouldUseAspectedHelios=false`；`StopRequested`→`-999`；QT`奶人`+QT`减伤`+QT`中间学派`→否则 `-1`；静默→`-1`；`CanUseOffGcd(2)`→`-4`；非战斗→`-5`；`Me` 有 aura `2718` 或 `RecentlyUsed(25874,5000)`（`ldc.i4 25874`,`ldc.i4 5000`）→`-2`；`!IsReady(16559)`→`-3`；`HasBossCastingAoeWithin(5000)` 时：有 aura `849` 或 `!IsReady(3613)` 或 有 aura `3895` 或 有 aura `3896` →`-4`；否则 `PartyHelper::CastableAlliesWithin20.Count >= 2`（`ldc.i4.2`）→`50`；否则 `CountAlliesHpBelow(中间学派阈值/100f,15f) >= 群奶人数` → `30`；否则若 `Me` 有 aura `1892`（中间学派）：`remaining = MemApiBuff::GetAuraTimeleft(Me,1892,true)`；`remaining <= 3000`(`ldc.i4 3000`) 且 `> 0` 且 `requiredCount = Party.Count > 4 ? 4 : 2`（`ldc.i4.4/2`）且 `CountAlliesWithoutNeutralSectShield() >= requiredCount` 且 `IsReady(37030)` → 置 `shouldUseAspectedHelios=true`，返回 `10`；否则 `-1`。
`Build`：`shouldUseAspectedHelios` → `slot.Add(HealerActionHelper::Gcd(37030, (SpellTargetType)0).DontUseGcd())`；否则 `Ability(16559).DontUseGcd()` 并 `MarkNeutralSectShieldPending()`。

**先天禀赋（3614）**：`StopRequested`→`-999`；`高难模式==1` 时只认 QT`自动先天`，否则需 `QT奶人+QT能力技奶+QT自动先天`，不满足 `-1`；静默→`-1`；`spell=Ability(3614)`，`!IsReadyWithCanCast`→`-2`；`CanUseOffGcd(2)`→`-4`；QT`"保留先天"` 时 `spell.Charges <= Clamp(保留先天数量,0,3)`（`ldc.i4.3`）→`-5`；`hpThreshold = 先天阈值/100f`，若 `Charges > 2`（`ldc.r4 2`）则 `+ 0.1f`（`ldc.r4 0.1`）；`SelectTarget(hpThreshold)` 为空或非 `IsValid` →`-3`；`Now - LastTargetTime(target) >= 1000`（`ldc.i4 1000`）→ `2`，否则 `-200`（同一目标 1 秒内不重复）。`Build` 后 `RecordTargetTime`；键名 `"先天禀赋_" + GameObjectId`。
`SelectTarget`：优先 `NeedsLivingDeadHeal` 的最低血坦克；否则在 `CastableAlliesWithin30` 中筛 `CanReceiveHeal && CanSingleHealTarget && hp <= threshold`，坦克与非坦克各取最低，坦克优先。

**光速（3606）**：`StopRequested`→`-999`；QT`光速`→否则 `-50`；`RecentlyUsed(3606,15000)`（`ldc.i4 15000`）→`-3`；静默→`-1`；`CanUseOffGcd(2)`→`-4`；非战斗→`-6`；`GCDHelper::CanUseOffGcd` 失败→`-8`；有 aura `167`（即刻）→`-4`；有 aura `841`（光速）→`-5`；`!IsReadyWithCanCast`→`-2`；`CurrBattleTimeInMs < 3500`（`ldc.i4 3500`）→`-200`；非高难且 `ShouldHoldForDyingTrash`→`-10`；`divinationSoon = Level >= 50 && QT占卜 && Ability(16552).Cooldown.TotalMilliseconds < 1500`（`ldc.r8 1500`）；QT倾泻资源 → `50`；QT攒爆发 → `Charges > 1`（`ldc.r4 1`）则 `50` 否则 `-50`；`!divinationSoon` → `-9`；否则 `50`。

**光速走位（3606）**：`StopRequested`→`-999`；QT光速→`-50`；`!IsReadyWithCanCast`→`-2`；`RecentlyUsed(3606,15000)`→`-3`；静默→`-1`；`CanUseOffGcd(2)`→`-4`；`Charges < 2`（`ldc.r4 2`）→`-7`；非战斗→`-6`；aura `167`→`-4`；aura `841`→`-5`；未移动→`-10`；`!光速走位`→`-13`；`delay = 光速走位延迟时间`；`delay <= 0` → `40`；`MoveStartTimeMs <= 0` → `-200`；`Now - MoveStartTimeMs < delay` → `-200`；`CountEnemiesInRange(25f) <= 0` → `-13`；否则 `40`。

**占卜（16552）**：`StopRequested`→`-999`；QT占卜→`-100`；`!IsReady(16552)`→`-2`；静默→`-1`；目标 `HasAttackBlock||IsDying`→`-1`；`CanUseOffGcd(2)`→`-4`；非战斗→`-1`；非高难且 `ShouldHoldForDyingTrash`→`-10`；QT攒爆发且非倾泻→`-50`；QT倾泻资源且 `!HasLocalPlayerAura(1878)` → `50`；`CurrBattleTimeInMs <= 5000`（`ldc.i4 5000`）→`-9`；否则 `40`。

**命运之轮（3613）**：`StopRequested`→`-999`；需 `QT减伤 && QT奶人 && QT能力技奶`，否则 `-1`；`!IsReady(3613)`→`-2`；静默→`-1`；`CanUseOffGcd(2)`→`-4`；非战斗→`-5`；`HasBossCastingAoeWithin(6000)` 为假→`-2`；否则 `50`。

**天宫图（16557 / 16558）**：`StopRequested`→`-999`；需 `QT奶人 && QT能力技奶 && QT天宫图`，否则 `-1`；静默→`-1`；`CanUseOffGcd(2)`→`-4`；若 `Me` 有 aura `1890`（天宫图 buff）：`!IsReady(16558)`→`-9`；`CountAlliesHpBelow(Clamp((天宫图阈值-35)/100f,0,1), 30f) >= GroupHealTriggerCount()` → 置 `checkResult=9` 返回 `9`，否则 `-9`；若 `Me` 有 aura `1891`：`!IsReady(16558)`→`-8`；`CountAlliesHpBelow(天宫图阈值/100f,30f) >= GroupHealTriggerCount()` → `checkResult=8` 返回 `8`，否则 `-8`；否则 `!IsReady(16557)`→`-2`；`CountAlliesHpBelow(天宫图阈值/100f,30f) >= GroupHealTriggerCount()` → `checkResult=7` 返回 `7`，否则 `-1`。
`Build`：`checkResult` 为 8 或 9 → `Ability(16558).DontUseGcd()`；为 7 → `Ability(16557).DontUseGcd()`。
（`GroupHealTriggerCount()` = `群奶人数` clamp 到 [0,8]；`CountAlliesHpBelow(hp,range)` 遍历 `CastableAlliesWithin30`，要求 `Distance(me,7) <= range`、`CanReceiveHeal`、`CurrentHpPercent <= hp`。）

**天星交错（16556）**：`StopRequested`→`-999`；需 `QT奶人 && QT能力技奶`，否则 `-1`；静默→`-1`；`!IsReady(16556)`→`-200`；`CanUseOffGcd(2)`→`-2`；非战斗→`-2`；`threshold=Clamp(天星交错阈值/100f,0,1)`；若 `CastableAlliesWithin30.Count <= 2` 且有 `SelectBleedTarget()` → `60`；若 `Me.CurrentHpPercent < threshold` 且 `CanCastCelestialIntersection(Me)` → 目标=自己，`50`；`HasBossCastingTankbusterWithin(10000)` 且有 `SelectTankbusterTarget()` → `40`；`SelectRegularTank(threshold)` → `30`；`SelectRegularNonTank(threshold)` → `20`；否则 `-1`。
- `SelectBleedTarget()`：`CanReceiveHeal && CanSingleHealTarget && hp < 0.85f && HealerHealingHelper::HasBleed && !Helper::HasDispelStatus && CountAspectedBeneficBleedShields(t) < 2 && CanCastCelestialIntersection`。
- `SelectTankbusterTarget()`：坦克、`CanReceiveHeal`、`CanSingleHealTarget`、`CountMitigations(t) < 2`、`CanCastCelestialIntersection`，取最低血。
- `CanCastCelestialIntersection`：`CanReceiveHeal && IsInHealRange(t,30f) && !HasAura(1889) && !HasAura(2717)`。
- `CountMitigations`：aura `2717`+`3890`+`3892` 计数。
- `Build`：目标非空 → `Ability(16556, target).DontUseGcd()`；否则无目标版 `Ability(16556).DontUseGcd()`。

**天星冲日（16553）**：`StopRequested`→`-999`；需 `QT奶人 && QT能力技奶`，否则 `-100`；静默→`-1`；`CanUseOffGcd(2)`→`-2`；`!IsReady(16553)`→`-1`；非战斗→`-2`；`BleedTargetWithin20()` 存在时：`CastableAlliesWithin20.Count <= 2` → `-1`；`CountAspectedBeneficBleedShields(t) < 2` → `10`，否则 `-1`；否则若 `CountEnemiesInRange(20f) >= 5`（`ldc.i4.5`）且 `CountTanksHpBelow(天星冲日阈值/100f, 20f) > 0` → `2`；否则 `CountAlliesHpBelow(天星冲日阈值/100f, 20f) >= 群奶人数` → `1`，否则 `-1`。
`BleedTargetWithin20()`：`CanReceiveHeal && hp < 0.85f && HasBleed && !HasDispelStatus`。

**太阳星座（37031）**：`StopRequested`→`-999`；需 `QT减伤 && QT中间学派`，否则 `-100`；静默→`-1`；`CanUseOffGcd(2)`→`-4`；`Me` 无 aura `3895` → `-3`；非战斗→`-4`；非高难模式下 `MemApiBuff::GetAuraTimeleft(Me,3895,true) <= 3000`（`ldc.i4 3000`）→ `50`；`HasBossCastingAoeWithin(10000)` 为假 → `-5`；`Me` 有 aura `849` → `-6`；`IsReady(3613)` → `-7`；`Party.Count < 2` → `-5`；否则 `47`。

**擢升（25873）**：`StopRequested`→`-999`；需 `QT减伤 && QT能力技奶`，否则 `-100`；静默→`-1`；`!IsReady(25873)`→`-3`；`CanUseOffGcd(2)`→`-4`；`HasBossCastingTankbusterWithin(5000)`（`ldc.i4 5000`）且有 `SelectTankbusterTarget()` → `10`；`tankThreshold = Clamp((擢升阈值-10)/100f,0,1)`（`ldc.i4.s 10`）；`nonTankThreshold = Clamp(擢升阈值/100f,0,1)`；`SelectLowHpTarget(tankThreshold,nonTankThreshold)` 命中 → `1`；否则若 `Me.CurrentHpPercent <= tankThreshold` → `useSelf=true`，返回 `2`；否则 `-2`。
- `SelectTankbusterTarget()`：`CastableTanks`、`IsInHealRange(t,30f)`、`CanReceiveHeal`、`!HasLocalPlayerAura(2717)`、`CountTankbusterMitigations(t) < 2`（aura `3890`+`3892`+`1889`）、取最低血。
- `SelectLowHpTarget`：`CanReceiveHeal && CanSingleHealTarget && !HasLocalPlayerAura(2717)`；坦克 `hp <= tankThreshold`，非坦克 `hp <= nonTankThreshold`。

**星位合图（3612）**：`StopRequested`→`-999`；需 `QT奶人 && QT能力技奶`，否则 `-1`；静默→`-1`；`CanUseOffGcd(2)`→`-4`；`SelectTarget()` 为空→`-2`；`!IsReady(3612,target)`→`-2`；否则 `1`。
`SelectTarget()`：`tankThreshold = Clamp((星位合图阈值-5)/100f,0,1)`（`ldc.i4.5`）、`nonTankThreshold = 星位合图阈值/100f`；遍历 `CastableAlliesWithin30`，要求 `CanReceiveHeal`、`!HasLocalPlayerAura(845)`、`CanSingleHealTarget`，坦克/非坦克各自阈值内取最低血，坦克优先。

**神谕（37029）**：`StopRequested`→`-999`；QT 组合：`QT倾泻资源` 时需 `QT神谕`；否则 `QT AOE` 时需 `QT神谕`；都不满足 → `-100`；`!IsReady(37029)`→`-2`；静默→`-1`；目标无效或 `HasAttackBlock` → `-1`；`CanUseOffGcd(1)`→`-4`；`Me` 无 aura `3893` → `-1`；非战斗→`-1`；`cachedSpell = Ability(37029, target?)`；`MemApiBuff::GetAuraTimeleft(Me,1878,true) > 3000`（`ldc.i4 3000`）→ `100`；非高难且 `ShouldHoldForDyingTrash`→`-10`；QT攒爆发且非倾泻→`-50`；QT倾泻资源→`50`；`CountEnemiesInRange(25f)` 为 0→`-5`；若 `智能AOE目标` 且有目标：`SelectCircularAoeTarget(2, 25, 5, target, true)`（`ldc.i4.2`,`ldc.i4.s 25`,`ldc.i4.5`,`ldc.i4.1`）命中且 `GetNearbyEnemyCount(25,5) >= 2` → 切目标、`cachedSpell = Ability(37029, best)`、返回 `0`；否则 `0`。

**醒梦（7562）**：`StopRequested`→`-999`；`Me.IsCasting` → `-1`；`Level < 14`（`ldc.i4.s 14`）→`-3`；`CanUseOffGcd(1)`→`-4`；`CurrentMp > 醒梦阈值`（`conv.u8` 与 `conv.i8` 比较）→`-3`；静默→`-1`；`!IsReady(7562,(SpellTargetType)1)`→`-2`；否则 `0`（注意：醒梦返回 0，不是正优先级）。`Build`：`slot.Add(Ability(7562,(SpellTargetType)1).DontUseGcd())`。

### 1.4.10 GCD 解析器（Y）

| 类 | 主要条件（顺序） | 技能 id | 成功优先级 |
|---|---|---|---|
| `GCD.DOT` | `StopRequested`→-999；QT`DOT`→-8；静默→-1；目标空或 `HasAttackBlock`→-1；`!IsReady(3599,target)`→-3；`ShouldSkipDotByHp(target, 不上Dot阈值/100f, 12)`（`ldc.i4.s 12`）→-1；`IsOutOfAttackRangeOrDead(target,25f)`→-200；`hasVisibleDot=HasMyDot(target,1000)`（`ldc.i4 1000`）；`hasDot = HealerDotCastTracker::HasRecentlyApplied(GetAdjustedActionId(3599),target,hasVisibleDot) \|\| hasVisibleDot`；`dotExpiring = !hasDot && !HasMyDot(target,3000)`（`ldc.i4 3000`）；移动分支：若 `IsMoving && DOT走位`：有 aura `841` 或 `167` → -20；否则 `MoveStartTimeMs > 0` 且 `Now - MoveStartTimeMs < 移动中DOT延迟时间` → -21；随后 `!hasDot → 45`；`!dotExpiring → 30`；否则 `35`。非移动：`!hasDot → 50`；`!dotExpiring → -1`；否则 `40` | 3599 | 45/50/35/40 |
| `GCD.中重力` | `StopRequested`→-999；QT`AOE`→-100；静默→-1；目标空/`HasAttackBlock`→-1；`IsMovementBlockingCast(3615)`→-200；`IsOutOfAttackRangeOrDead(25f)`→-200；`!IsReady(3615,(SpellTargetType)0)`→-200；`threshold = Level >= 82 ? 3 : 2`（`ldc.i4.s 82`,`ldc.i4.3/2`）；`智能AOE目标` 且 `SelectCircularAoeTarget(threshold,25,8,target,true)`（`ldc.i4.s 25`,`ldc.i4.8`）命中且 `GetNearbyEnemyCount(25,8) >= threshold` → 20；否则 `GetNearbyEnemyCount(currentTarget,25,8) >= threshold` → 0；否则 -1 | 3615 | 20/0 |
| `GCD.即刻落陷凶星` | `StopRequested`→-999；QT`即刻凶星`→-100；`HasDeadAllyWithoutRaise()`→-200；静默→-1；目标空/`HasAttackBlock`→-1；`IsOutOfAttackRangeOrDead(25f)`→-2；`CurrentMp < 800`（`ldc.i4 800`）→-9；`!IsReady(7561)`→-3；无 aura `49`（即刻咏唱）→-100；`!BuffTimeLessThan(49,3000)`（`ldc.i4.s 49`,`ldc.i4 3000`）→-100；有 aura `841`→-7；否则 15。Build：先 `Ability(7561)` 再 `Gcd(25871,(SpellTargetType)0)` | 7561 + 25871 | 15 |
| `GCD.双DOT` | 继承 `HealerDoubleDotResolverBase::Check`：`StopRequested`→-999；`!DotEnabled \|\| !DoubleDotEnabled`→-100；静默→-1；`CountTargets(now)` 后 `candidateCount < 2`→-200；`activeDotCount >= 2`→-1；`SelectDotTarget` 空→-1；`!IsReady(DotActionId,target)`→-3；否则 35。`CommonCanDot(enemy,不上Dot阈值/100f)`：`IsValid && IsTargetable && Distance(me) <= 25f + AttackRangeBonus && !DotBlacklistHelper::IsBlackList && !HasAttackBlock && !ShouldSkipDotByHp(enemy,ratio,12)`（`ldc.r4 25`,`ldc.i4.s 12`） | `DotActionId`（**属性体缺**，`get_DotActionId` 在 dump 中无体） | 35 |【缺】 |
| `GCD.吉星` | `StopRequested`→-999；需 `QT奶人 && QT GCD奶`；静默→-1；有 aura `167` 且 `HasDeadAllyWithoutRaise`→-16；`IsMovementBlockingCast(3594)`→-8；`CountAlliesHpBelow(GCD群奶阈值/100f,20f) >= 群奶人数`→-6；`cachedTarget = LowestHpMember(QT单奶限制)`，空→-4；`!CanReceiveHeal`→-7；`!IsInHealRange(t,30f)`→-7；`threshold = IsTank ? Clamp((GCD单奶阈值-10)/100f,0,1)（`ldc.i4.s 10`） : Clamp((GCD单奶阈值-5)/100f,0,1)（`ldc.i4.5`）`；`Level < 30`（`ldc.i4.s 30`）时 `threshold = Clamp(threshold + 0.2f,0,1)`（`ldc.r4 0.2`）；若 `!NeedsLivingDeadHeal(target) && target.hp >= threshold` → -6；`cachedActionId = (Level >= 26 && CurrentMp >= 700 && IsReady(3610,target)) ? 3610 : 3594`（`ldc.i4.s 26`,`ldc.i4 700`）；`!IsReady(cachedActionId,target)`→-6；`cachedActionId == 3610 → 40`，否则 `20` | 3610 / 3594 | 40/20 |
| `GCD.吉星相位` | `StopRequested`→-999；需 `QT奶人 && QT GCD奶`；静默→-1；`CurrentMp < 400`（`ldc.i4 400`）→-1；`CountAspectedBeneficNeedByBeneficThreshold() >= 3`（`ldc.i4.3`）→-6；`CountAspectedBeneficNeed() >= GroupHealTriggerCount()`→-6；`GetBleedTarget()` 命中且 `CanCastOn` → 60；`GetNeutralSectTarget()` 命中且 `CanCastAspectedBeneficOn` 且 `CanCastOn` → 50（并置 `shouldClearNeutralSect`）；`GetHealTarget()` 命中且 `CanCastAspectedBeneficOn` 且 `CanCastOn` → 30；否则 -1。Build 用 3595 | 3595 | 60/50/30 |
| `GCD.康复` | `StopRequested`→-999；QT`自动康复`→-100；静默→-1；`!IsReady()`(7568 Gcd) →-200；`HealerEsunaTargetSelector::SelectGeneralTarget(H1)` 空→-7；否则 10。Build 用 7568 | 7568 | 10 |
| `GCD.绝亚康复` | 仅 `MemApiZoneInfo::GetCurrTerrId() == 887`（`ldc.i4 887`）时有效；QT`自动康复`→-100；`!IsReady`→-200；`!HasAnyDispelTargetWithin30()`→-7；`SelectTemporalStasisTarget(H1)` 空→-7；否则 1。Build 用 7568 | 7568 | 1 |
| `GCD.移动走位即刻落陷凶星` | `StopRequested`→-999；QT`即刻走位`→-100；`MemApiMove::IsMoving` 假→-100；静默→-1；目标空/`HasAttackBlock`→-1；`IsOutOfAttackRangeOrDead(25f)`→-2；`CurrentMp < 800`→-9；`!IsReady(7561)`→-3；有 aura `841`→-7；`ShouldWaitMovingDelay()`（`即刻咏唱延迟时间 > 0 && MoveStartTimeMs > 0 && Now - MoveStartTimeMs < delay`）→-200；QT`AOE` 且 `Level >= 45`（`ldc.i4.s 45`）且 `CountEnemiesInRange(25f) >= RequiredTargetCount()` → -200；否则 15。Build：`Ability(7561)` + `Gcd(25871,(SpellTargetType)0)` | 7561 + 25871 | 15 |
| `GCD.移动走位即刻重力` | 需 `QT即刻走位 && QT AOE`，否则 -100；`!IsReady(7561) \|\| Level < 45`→-3；静默→-1；目标空/`HasAttackBlock`→-1；`CurrentMp < 1000`（`ldc.i4 1000`）→-9；有 aura `841`→-7；`!IsMoving`→-100；`ShouldWaitMovingDelay`→-200；`RequiredTargetCount() > CountEnemiesInRange(25f)`→-2；`SelectCircularAoeTarget(25,5,true)` 空或无效或 `IsOutOfAttackRangeOrDead(25f)`→-2；否则 14。Build：`Ability(7561)` + `Gcd(3615,target)` | 7561 + 3615 | 14 |
| `GCD.落陷凶星` | `StopRequested`→-999；静默→-1；目标空/`HasAttackBlock`→-1；`IsOutOfAttackRangeOrDead(25f)`→-200；`CurrentMp < 400`→-2；`IsMovementBlockingCast(25871)` → `CheckMoving()`（有 aura `841`→2；有 aura `167`→(`!HasDeadAllyWithoutRaise` ? 2 : -200)；需 `QT即刻走位 && IsReady(7561)` 否则 -1；`HasDeadAllyWithoutRaise`→-200；`即刻咏唱延迟时间 > 0` 且移动未达延迟 → -5；否则 0）；否则 `!IsReady(25871,(SpellTargetType)0)`→-9999；否则 1 | 25871 | 1 |
| `GCD.阳星` | `StopRequested`→-999；需 `QT奶人 && QT GCD奶`；`IsMovementBlockingCast(3600)`→-200；若 `QT能力技奶 && QT天宫图` 且 `new 天宫图().Check() >= 0` → -200；静默→-1；`RecentlyUsed(Gcd(37030,0), 8000)`（`ldc.i4 8000`）→-3；`CurrentMp < 700`→-2；`RecentlyUsed(Gcd(3600,0), 3500)`（`ldc.i4 3500`）→-9；有 aura `1248` → `-222`；`!IsReady(3600)`→-999；`CountHeliosNeed() < GroupHealTriggerCount()`→-1；否则 1 | 3600 | 1 |
| `GCD.阳星合相` | `StopRequested`→-999；需 `QT奶人 && QT GCD奶`；静默→-1；`IsMovementBlockingCast(3601)`→-200；`(!InCombat \|\| !HasAura(1892))` → `shouldClearNeutralSect=false`；若 `!IsReady(3601) \|\| CurrentMp < 800 \|\| RecentlyUsed(Gcd(3601,0),3500)`（`ldc.i4 800`,`ldc.i4 3500`）→-1；若 `NeutralSectShieldPending && InCombat && HasBossCastingAoeWithin(5000)`（`ldc.i4 5000`）→ 置 `shouldClearNeutralSect`，`90`；`HasAstrodyneShield()`(aura `1879`)→-90；若 `NeutralSectShieldPending && InCombat && CountNeutralSectMissingShields() >= 2`（`ldc.i4.2`）→ `85`；若 `BleedTargetWithin20()` 且 `CastableAlliesWithin20.Count > 2` 且 `CountAspectedBeneficBleedShields() < 2` → `70`；若 `高难模式==0 && InCombat && HasAura(1892) && !HasMyAuraWithTimeleft(1892,5000) && !dailyRefreshDone && CountCanReceiveHealWithoutNeutralSectShield() > 4`（`ldc.i4 5000`,`ldc.i4.4`）→ `50`；若 `CountAspectedBeneficNeed() >= GroupHealTriggerCount()` 且 (`!QT能力技奶 || !QT天宫图 || 天宫图::Check() < 0`) → 走后续；有 aura `1248`→`-222`；`!ShouldCastHelios()`；`CountAspectedBeneficNeedByBeneficThreshold() >= 3` → `80`；`!HasAura(1921)` → `1`；否则 `-1` | 3601（被 37030 调整） | 90/85/70/50/80/1 |
| `GCD.大宇宙` | `StopRequested`→-999；QT 组合（`QT倾泻资源 && QT大宇宙`，或 `QT AOE && QT大宇宙`）否则 -100；静默→-1；`!IsReady(25874)`→-1；`CurrentMp < 600`（`ldc.i4 600`）→-2；QT攒爆发且非倾泻→-50；QT倾泻资源→50；非高难且 `ShouldHoldForDyingTrash`→-10；有 aura `1892` 或 `RecentlyUsed(16559,5000)`→-2；`cannotReceiveHeal = CannotReceiveHealSelf()`；`enemyCount = GetNearbyEnemyCount(20)`；`>= 6`（`ldc.i4.6`）时 `ShouldWaitDivination()`→-8，否则 60；若 `高难模式 != 1` 且 (`!QT奶人 \|\| cannotReceiveHeal`)：`enemyCount >= 3`（`ldc.i4.3`）时 `ShouldWaitDivination()`→-8，否则 30；`enemyCount < 3` → -1；`HasBossCastingAoeWithin(10000)`：有 aura `849`→-5；`IsReady(3613)`→-6；(`IsReady(16559) \|\| (IsReady(37031) && HasAura(3895))`)→-7；否则 44；非 AOE 窗口 → -1。`ShouldWaitDivination()`：`Gcd(16552,0).Cooldown.TotalMilliseconds <= 2000`（`ldc.r8 2000`）且 `!HasAura(1878)` | 25874 | 60/30/44 |

### 1.4.11 起手（Y，`Openers.*`）

- **空起手**：`StartCheck`：`QT停手` 或 `InCombat` → -1；`PartyHelper::CastableParty.Count < 8`（`ldc.i4.8`）且目标非木桩 → -100；否则 0。
  `InitCountDown`：`QT停手` 或 `高难模式==1` → 直接返回；`地星起手` 为真 → `AddEarthlyStarCountdown(handler, 地星起手倒数时间, checkCombat=false)`；`QT爆发药` → `AddPotionAction(地星起手 ? 50 : 预读时间-100)`（`ldc.i4.s 100`,`ldc.i4.s 50`）；`AddCountdownAction(预读时间, PrecastDailySpell, false)`。
  `PrecastDailySpell`：`AstrologianOpenerHelper::SelectGravityTarget()` 命中 → `Gcd(3615)`；否则若 `CurrentTarget != null` 且 `IsReadyWithCanCast(Gcd(25871,(SpellTargetType)0))` → 返回它（`ldc.i4 25871`）。
- **占星3GCD前半起手**：`StartCheck`：`InCombat` 或 `QT停手` → -1；需 `Opener == 1`（`ldc.i4.1`）且 `高难模式 != 0`；`CastableParty.Count <= 4`（`ldc.i4.4`）且目标非 Boss → -100；否则 0。
  `InitCountDown`：发 `/aestop off`、`/aeTargetSelector on` 两条聊天命令；`地星起手` → `AddEarthlyStarCountdown(handler, 地星起手倒数时间, true)`；`QT爆发药` → `AddPotionAction(地星起手 ? 50 : 1400)`（`ldc.i4 1400`,`ldc.i4.s 50`）；`AddCountdownAction(1500, …)`（`ldc.i4 1500`）；`AddAction(100, …)`（`ldc.i4.s 100`）。
  五步：`Step0` = 目标有效且 `!HasAstrologianDot` → `Gcd(3599)`；否则 → `Gcd(25871)`；`Step1` = `Ability(3606)`（光速）+ `Gcd(25871,(SpellTargetType)0)` + `Ability(16552)`（占卜）；`Step2` = `AddCard1IfNeeded` + `Gcd(25871)` + 若 `DrawnCrownCard == 7`（`ldc.i4.7`）则 `Ability(7444)`；`Step3` = `Ability(37018)`（灵极抽卡）+ `Gcd(25871)`；`Step4` = `AddCard1IfNeeded` + `Gcd(25871)` + `Level >= 92`（`ldc.i4.s 92`）时 `Ability(37029)`（神谕）。
  `AddCard1IfNeeded`：`DrawnCard(0)` → `Card1ActionId(card)`；若该 id `== 37019`（无卡）或 `RecentlyUsed(1000)`（`ldc.i4 1000`，此处 `actionId` 实参由栈顶给出但过滤视图丢失；按上下文为上一张出卡）则返回；否则 `发卡设置::获取发卡目标角色(card)`，非空时对其 `Ability(...)`，`IsReadyWithCanCast` 通过则入槽。
  `Card1ActionId(card)`：`card==1 → 37023`，`card==4 → 37026`，其它 `→ 37019`。
  `AddEarthlyStarCountdown` 与 `AddCountdownAction` 都用 `<>c::<>9__N_x` 工厂（**lambda 体缺**），最终 `CountDownHandler::AddAction(timeLeft, factory)`。
- `AstrologianOpenerHelper::EarthlyStarPosition()`：与 `地星.Build` 同构（`地星优先目标位置`、`HitboxRadius < 15f`、`地星优先场中`、`地星开挂模式` → `GroundCastPosition`）。
- `AstrologianOpenerHelper::SelectGravityTarget()`：`Level < 45` → null；目标空或 `HasAttackBlock` → null；`threshold = Level >= 82 ? 3 : 2`（`ldc.i4.s 82`）；`SelectCircularAoeTarget(threshold,25,8,true)` 命中且 `GetNearbyEnemyCount(25,8) >= threshold` 才返回。

### 1.4.12 Timeline 条件/动作（Y，79684–80692）

**条件**（`Handle` 返回"条件成立"）：
| 条件类 | 判定 | 字面量 |
|---|---|---|
| `QtCheck` | `AstrologianQT::GetQt(key)` | — |
| `先天充能层数` | `EssentialDignityCharges >= Stacks`（Stacks=0 时改判 `== 0`） | 选项 `0/1/2/3 层`（`ldc.i4.4` 个选项） |
| `光速充能层数` | `LightSpeedCharges >= Stacks` | 选项 `0/1/2`（`ldc.i4.3`） |
| `天星交错充能层数` | `CelestialIntersectionCharges >= Stacks` | 选项 `0/1/2`（`ldc.i4.3`） |
| `卡1类型` | `DrawnCard(0)`（`ldc.i4.0`）与 选项 0→`==1`、1→`==4`、2→`==0` 比较 | 文案 `ldstr "太阳神之衡"/"战争神之枪"/"无卡"` |
| `卡2类型` | `DrawnCard(1)`（`ldc.i4.1`）与 0→`==3`、1→`==2`、2→`==0` | `"放浪神之箭"/"世界树之干"/"无卡"` |
| `卡3类型` | `DrawnCard(2)`（`ldc.i4.2`）与 0→`==6`、1→`==5`、2→`==0` | `"建筑神之塔"/"河流神之瓶"/"无卡"` |
| `小奥秘卡类型` | `DrawnCrownCard` 与 0→`==7`、1→`==8`、2→`==0` | `"王冠之领主"/"王冠之贵妇"/"无卡"` |
| `抽卡类型` | `ActiveDrawSpell().Id` 的 `GetAdjustedActionId` 与 0→`37017`、1→`37018` 比较 | `"星极抽卡"/"灵极抽卡"` |

**动作**（写设置字段，构造时用 `ldstr` 标题 + 字段引用 + `Action` 委托）：
`不上Dot阈值`（PercentSettingTimelineAction）、`中间学派阈值`、`先天阈值`、`吉星相位阈值`、`地星阈值`、`天宫图阈值`、`天星交错阈值`、`天星冲日阈值`、`擢升阈值`、`星位合图阈值`、`星体爆轰阈值`、`贵妇卡阈值`、`GCD单奶`、`GCD群奶`（`ldstr "GCD单奶阈值"/"GCD群奶阈值"`）、`DOT走位`、`光速走位`（BoolSettingTimelineAction）、`保留先天数量`（IntSettingTimelineAction，范围 `0..2`，`ldc.i4.2`）、`群减人数`/`群奶人数`（`0..8`，`ldc.i4.8`）、`醒梦阈值`（`0..10000`，`ldc.i4 10000`，标题 `ldstr "阈值(MP)"`）、`预读时间`（`0..3000`，`ldc.i4 3000`，标题 `ldstr "预读阈值"`）、`康复顺序`（`HealerEsunaOrderTimelineAction`，绑定 `H1`）、`起手设置`（下拉 `"空起手"` / `"3GCD前半起手"`，写 `Opener`）、`热键`（先查 `CustomHotkeys` → `QueueCustomCombo`，否则 `TryRunSystemHotkey`）、`QtSetting`（`SetQt(name,value,false)` + Save）。

## 1.5 Y 用到的共享 `ACR.Tool.*`（含方法体，属"已证明"）

| 方法 | 行为 | 证据 |
|---|---|---|
| `HealerResolverBase::CanUseOffGcd(int limit)` | `AI.Instance.BattleData.HighPrioritySlots_OffGCD.Count < limit` | y_tool 3430–3437 |
| `HealerActionHelper::RecentlyUsed(actionId, ms)` | 直接转调 `AEAssist.Helper.SpellExtension::RecentlyUsed(actionId, ms)`（**内部未在 dump**） | y_tool 302–306 |
| `HealerActionHelper::IsReady(actionId)` | `Ability(actionId).IsReadyWithCanCast()` | y_tool 285–289 |
| `HealerActionHelper::Ability(actionId,target/targetType)` | `new Spell(GetAdjustedActionId(actionId), target)` | y_tool 172–191 |
| `HealerActionHelper::GetAdjustedActionId(id)` | `id != 0 ? MemApiSpell::CheckActionChange(id) : 0` | y_tool 192–200 |
| `HealerActionHelper::IsMovementBlockingCast(id)` | 若 `IsMoving \|\| IsJumpingOrFalling()`：有 aura `167`/`1249`/`841`/`3884` 之一则不阻断；否则查 Action 表的 `Cast100ms > 0` 判阻断；无数据视为阻断 | y_tool 201–246 |
| `HealerRuntimeTools::HasSkillSilenceStatus()` | `Me == null` → true；否则遍历 `StatusList`，`StatusId != 0 && Helper::IsActionProhibitedStatus(StatusId)` | y_tool 2034–2055 |
| `HealerRuntimeTools::BuffTimeLessThan(statusId,ms)` | `MemApiBuff::GetAuraTimeleft(Me,statusId,true) > 0 && < ms` | y_tool 2020–2033 |
| `HealerRuntimeTools::IsHotkeyBlocked(pred)` | `IsAcrPausedOrStopped()`（`Share.CombatRun==0` 或右键停手）或 未登录/无 Me/死亡/条件 `4,10,64,71` 任一为真/`IsGameObjectStateUnstable()`/`pred()` | y_tool 1961–1996 |
| `HealerEnemyTargetHelper::HasBossCastingAoeWithin(ms)` | 遍历 `TargetMgr.Enemys`：`TargetHelper::IsBoss(e)` 且 `Distance(me) <= 30f`（`ldc.r4 30`）且 `IsTargetCastingActionSoon(e,ms)` 且 `Helper::IsAoeAction(e.CastActionId)` | y_tool 1184–1210 |
| `HasBossCastingTankbusterWithin(ms)` | 同上，末条改 `Helper::IsTankDeathSentence(CastActionId)` | y_tool 1211–1237 |
| `IsTargetCastingActionSoon(t,ms)` | `t.IsCasting && (TotalCastTime - CurrentCastTime) * 1000f < ms`（`ldc.r4 1000`） | y_tool 1381–1396 |
| `IsDying(t)` | `CurrentHp <= 0 \|\| CurrentHpPercent <= 0.001f`（`ldc.r4 0.001`） | y_tool 1117–1130 |
| `IsOutOfAttackRangeOrDead(t,range)` | `Distance(me,t) > range + AttackRangeBonus()` → true，否则 `IsDying(t)` | y_tool 1103–1116 |
| `AttackRangeBonus()` | `Min(GeneralSettings.AttackRange, 2.5f)`（`ldc.r4 2.5`） | y_tool 1335–1340 |
| `ShouldSkipDotByHp(t,ratio,maxHpMult)` | `Me==null \|\| IsDying \|\| ratio > t.hp% \|\| t.MaxHp > Me.MaxHp * maxHpMult` | y_tool 1131–1152 |
| `SelectCircularAoeTarget(minCount,castRange,damageRange,current,includeAttackRange)` | 遍历 `TargetMgr.Enemys`，`CanAttackTargetInRange` 且 `CountCircularAoeHits >= minCount`，计数相同则取当前血更少者 | y_tool 1153–1183 |
| `HealerGroundTargetHelper::GroundCastPosition(preferCenter,cheatMode,preferTargetPosition,currentTarget)` | 见 §1.7 说明（已完整读出） | youshu 39557–39611 |
| `HealerHealingHelper::CanReceiveHeal(t)` | 非空/`IsValid`/非死/`CurrentHp>0`/非敌/`!HasAnyStatusRemaining(无法接受治疗合集,3f)`（`ldc.r4 3`）/`!HasAnyStatusRemaining(假无敌Buff合集,3f)`/无 aura `810`/（无 aura `811` 或 `NeedsLivingDeadHeal`） | y_tool 1654–1696 |
| `NeedsLivingDeadHeal(t)` | 坦克 且 `hp < 0.8f`（`ldc.r4 0.8`）且 有状态 `811` 且 `0 < RemainingTime < 5f`（`ldc.r4 5`） | y_tool 1816–1852 |
| `MatchesSingleHealLimit(t,enabled,tank,healer,dps)` | 未启用 → true；否则按 `enabled` 组合判断 `IsTank/IsHealer/IsDps` | y_tool 1697–1726 |
| `HealerEsunaTargetSelector::SelectGeneralTarget(isH1)` | `IsValidEsunaTarget && Helper::HasDispelStatus`，按队伍顺序从 H1 侧起找 | y_tool 3178–3234 |
| `IsValidEsunaTarget` | `IsValid && IsTargetable && !HasAnyStatus(不可选中合集) && Distance(me) <= 30f` | y_tool 3253–3274 |
| `HealerFullHealTargetSelector::FindTarget()` | `HealerGcdHealTracker::IsHpRefreshPending()`(1.5s，`ldc.i4 1500`) 为真 → null；否则按 `CommonMapIds::IsFullHealMap(terrId)` 与 `FullHealStatuses` 表（12 项：`(370,160)`,`(210,188)`,`(1769,826)`,`(1769,973)`,`(1769,1168)`,`(1769,1169)`,`(1769,1252)`,`(1769,1346)`,`(2303,922)`,`(2303,923)`,`(11,366)`,`(1628,0)`）匹配状态+地图 | y_tool 3276–3381 |
| `HealerDotCastTracker::MarkPending/HasRecentlyApplied` | 见 y_tool 892–1066（Y 的 DOT/双DOT 用它防重复上 DOT） | — |

`ACR.Tool.Data.JobId`（全部【IL】，`ldc.i4.s`）：`Tanks={19,21,32,37}`、`Healers={24,28,33,40}`、`MeleeDps={20,22,30,34,39,41}`、`RangedDps={23,31,38}`、`CasterDps={25,27,35,42}`。

`ACR.Tool.Data.Status::.cctor` 关键集合（全部【IL】）：
`伤害降低类BUFF`（=黑头/伤害降低判定，`Helper::IsDamageDown` 用它）= 27 项：`43,44,62,215,215,647,696,1016,1090,1334,1715,1793,2092,2373,2404,2483,2485,2522,2533,2911,3166,3304,3964,4370,4371,4372,4514`；
`假无敌Buff = {3255,409}`；`真无敌Buff = {1836,1302}`；`无敌Buff = {811,810,3255,409,1836,1302}`；
`无法接受治疗 = {1495}`；`不可选中 = {292}`；`驱散Buff补充 = {17,200}`；`盾姿Buff = {91,79,743,1833}`；
`无法造成伤害自建库 = {2208,2209}`；`敌人魔法攻击无效自建库 = {942,3621,2166}`；`AoE技能补充 = {31136,31137}`；
`ActionProhibitedStatusIgnoreList = {17}`；`流血BUFF` = **295 项，用 `RuntimeHelpers::InitializeArray` 从 RVA 数据块加载，具体 id 无法从 IL 读取**（【缺】）；
`AoeActionSet` = `AEAssist.CombatRoutine.Data::AoeActions` + `AoE技能补充` + `上位锁刃龙AOE_ID` + `艳翼蛇鸟歼殛战AOE_ID`；
`TankDeathSentenceSet` = `Data::TankDeathSentence`；`EnemyAttackBlockedStatusSet` = `Data::InvincibleStatus` + `Data::MagicReflectStatus` + 自建两个库。
`Helper::IsActionProhibitedStatus` 依赖的 `禁止发动技能状态合集` **既不在 `.cctor` 中构建，也没有属性 getter 体**（【缺】）——因此"静默/禁技"判定的完整 id 集合无法确证，只确证忽略表 `{17}`。

---

# 二、S（Shiyuvi）实现 `ACR.AST.*`

## 2.1 入口与顺序（`ACR.<mojibake>ACRASTRotationEntry`，`.il\cls_shiyuvi\ACR.鍚岀被 ACRASTRotationEntry.txt`）

- `Build`：`TargetJob = ldstr?`→ 实际 `ldc.i4.s 33`（占星）、`AcrType = ldc.i4.2`、`MinLevel = ldc.i4.s 70`、`MaxLevel = ldc.i4.s 100`（**注意：最低等级 70，与 Y 的 0 不同**）；`AddSlotSequences(Array.Empty())`（**没有 SlotSequence**）；注册 TriggerAction：`Trigggers.Play_I`、`Trigggers.Lady_of_Crowns`、`ForcedTimelineAction`、`Triggers.AST_QT`、`Triggers.NewQt`、`ACR3._0.Triggers.MPBelowUseItem23168`；TriggerCondition：`Trigggers.AST_UsePotionCheck`；RotationEventHandler = `ASTRotationEventHandler`。
- **技能调度**：`SlotResolvers` 字段由 `ACR.SharedJobView`/AEAssist 的 JobView 机制装载（该字段的初始化不在 dump 的 `Build` 中，本类也未在 dump 中出现逐项 `newobj` 列表）→ **S 侧的有序解析器清单无法从 IL 确证**（【缺】）。可确证的是：Ability/GCD 类都实现了 `int Check()` + `void Build(Slot)`，`Check` 返回值即优先级；`Ability.GetCard`/`Horoscope`/`Ast_LucidDreaming` 的 `Check` 返回 `0`（最低可用），`Burst` 返回 `1`，`Divination` 返回 `0`。
- `ASTRotationEventHandler`：`AfterSpell` 里用 `GCDHelper::GetGCDDuration(); ldc.i4.s 100; sub; SpellExtension::RecentlyUsed(...)` 判断"刚打过即刻(GCD 时长-100ms 内)" 或 `RecentlyUsed(3606,15000)`（`ldc.i4 15000`）→ 设 `BattleData.CurrGcdAbilityCount = 2`（`ldc.i4.2`）；否则按技能 id 分派 `CurrGcdAbilityCount`：`3594..3615` 区间的 switch 表（`ldc.i4 3594` 起点）里 `3594/3596/3599/3600/3601/3613/3614/…` 归为 1 类，`3598/3603(?)` 等归 2 类，`16554/16555/…` 见 IL_00e2 等；`25874/37030` → 2；其余 → 0。（**switch 表跳转目标与分类对应关系已读出，但部分分支被过滤视图省略**，此处只给可确证常量）。
- `AutoLucidDream(slot)`：`IsReadyWithCanCast(7562)` 且 `CurrentMp < 8000`（`ldc.i4 8000`）→ 入槽 `new Spell(7562, Me)`。

## 2.2 设置默认值（`ACR.AST.ASTSettings::.ctor`，全部【IL】，`.il\shiyuvi.il.txt` 97301–97417）

| 字段 | 默认值 | 证据 |
|---|---|---|
| DeploymentTacticsTarget | `ldstr "PM1"` | IL_0194 |
| AutoReset | 1 | `ldc.i4.1` IL_019f |
| Time | 100 | `ldc.i4.s 100` IL_01e0 |
| GCD群奶排除T目标 | 1（true） | `ldc.i4.1` IL_01e8 |
| GCD群奶治疗阈值 | 0.5 | `ldc.r4 0.5` IL_01ef |
| GCD群奶治疗人数 | 2 | `ldc.i4.2` IL_01fa |
| 天宫图治疗阈值 | 0.5 | `ldc.r4 0.5` IL_0201 |
| 天宫图排除T目标 | 1（true） | `ldc.i4.1` IL_020c |
| 天宫图提前群奶治疗人数 | 2 | `ldc.i4.2` IL_0213 |
| EssentialDignity（先天阈值） | 0.2 | `ldc.r4 0.2` IL_021a |
| JobViewSave.MainColor | `(0.65882355, 0.078431375, 0.078431375, 0.8)` | IL_01ac–01c5 |
| UserCustomQtDefaultValues | `new Dictionary<string,bool>(2)`（容量 `ldc.i4.2`） | IL_0001/0008 |
| SolarPriorityJobs（默认表） | `{22,41,20,30,34,39,36,42,25,35,31,27,23,38,32,19,37,21,24,40,33,28}`（Jobs 枚举，22=龙骑…见 §2.5） | `.ctor` IL_0024–018e |
| WandererPriorityJobs（默认表） | `{36,42,25,35,31,27,23,38,22,41,20,30,34,39,32,19,37,21,24,40,33,28}` | `.ctor` IL_00df–0189 |
| 未赋值字段（→0/false） | `UsePotion`、`EssentialDignityTank`、`EssentialDignityNotTank`、`UserCustomQtUnVisibleList`(列表) | `.ctor` 中无 `stfld` |

`ASTSettings::.cctor`：静态 `IDs`（"黑头/减益"表）= `{62,215,628,692,696,1016,1090,2092,2404,2522,2911,3166,3304,3964,43,44}`（全部 `ldc.i4`/`ldc.i4.s`，共 16 项）。

## 2.3 逐技能条件表（S）

### 2.3.1 `Ability.GetCard`（抽卡）

| # | 条件 | 字面量 | 分支 |
|---|---|---|---|
| 1 | QT `"自动抽卡"` | `ldstr` | false → `-99` |
| 2 | `Level >= 30` | `ldc.i4.s 30` | false → `-1` |
| 3 | `IsReadyWithCanCast(spellid)` | `this.spellid`（**属性体缺**） | false → `-10` |
| 4 | `DrawnCrownCard == 7`（领主） | `ldc.i4.7` | `-2` |
| 5 | `DrawnCrownCard == 8`（贵妇） | `ldc.i4.8` | `-3` |
| 6 | `DrawnCards` 含 `CardType 1`（太阳神之衡） | `ldc.i4.1` | `-4` |
| 7 | `DrawnCards` 含 `CardType 4`（战争神之枪） | `ldc.i4.4` | `-4` |
| 8 | 通过 | — | `0` |

`Build`：`slot.Add(new Spell(spellid, Me))`。**没有** 任何冷却/时间窗口判断，也**没有** `RecentlyUsed`；重复抽卡只靠"手持同卡"拦截。`spellid` 的取值（37017/37018）不在 dump 中。

### 2.3.2 `Ability.Burst`（120 爆发：抽卡/出卡/小奥秘卡一体）

| # | 条件 | 字面量 | 分支 |
|---|---|---|---|
| 1 | QT `"120爆发"` | `ldstr` | false → `-99` |
| 2 | `IsReadyWithCanCast(16552)` | `ldc.i4 16552` | true → `1` |
| 3 | `HasAura(Me,1878)`（占卜已开） 或 `RecentlyUsed(16552, 1000)` | `ldc.i4 1878`,`ldc.i4 1000` | 若都假 → `-1` |
| 4 | `DrawnCards` 含 1 | | 若含 → `1` |
| 5 | `DrawnCards` 含 4 | | 若含 → `1` |
| 6 | `DrawnCrownCard == 7` | `ldc.i4.7` | 若真 → `1` |
| 7 | `IsReadyWithCanCast(GetAdjustedActionId(37017))` | `ldc.i4 37017` | 真 → `1`，否则 `-1` |

`spell()`（按顺序返回第一个可用）：
1. 若 `IsReadyWithCanCast(16552)` → `Spell(16552)`
2. 否则若 `DrawnCards` 含 1 → `Spell(37023, ASTSettings::GetFirstValidTarget(true, 37023))`
3. 否则若含 4 → `Spell(37026, GetFirstValidTarget(false, 37026))`
4. 否则若 `DrawnCrownCard == 7` → `Spell(7444, Me)`
5. 否则若 `IsReadyWithCanCast(37017)` → `Spell(37017, Me)`
6. 否则 → `Spell(37018, Me)`
`Build`：`slot.Add(spell())`。

### 2.3.3 `Ability.Divination`（占卜）

| # | 条件 | 字面量 | 分支 |
|---|---|---|---|
| 1 | QT `"停输出"` | `ldstr` | `-1` |
| 2 | QT `"占卜"` | `ldstr` | false → `-10` |
| 3 | `BattleData.CurrBattleTimeInMs > 3300` | `ldc.i4 3300` | false → `-2` |
| 4 | `GCDHelper::GetGCDDuration() - GCDHelper::GetElapsedGCD() >= 600` | `ldc.i4 600` | false → `-3` |
| 5 | `IsReadyWithCanCast(Spell(16552, Me))` | `ldc.i4 16552` | false → `-1` |
| 6 | 通过 | | `0` |

（**没有任何** 战斗时间 5s 判断、没有 `HasAttackBlock`、没有 QT 攒爆发/倾泻资源。）

### 2.3.4 `Ability.Horoscope`（天宫图二段）

| # | 条件 | 字面量 | 分支 |
|---|---|---|---|
| 1 | QT `"天宫图二段"` | `ldstr` | false → `-10` |
| 2 | `天宫图buff`（**属性体缺**，布尔） | — | false → `-1` |
| 3 | 计数 `FrameCache::CastableAlliesWithin15` 中 `CurrentHp > 0 && CurrentHpPercent <= 天宫图治疗阈值`（`ldc.i4.0` 比较、`ldc.r4` 阈值）且（`天宫图排除T目标` 为真时跳过坦克） | `ldc.i4.0` | — |
| 4 | `计数 >= 天宫图提前群奶治疗人数` | | false → `-4`，true → `0` |

`Build`：`slot.Add(天宫图)`（**属性体缺**）。

### 2.3.5 `Ability.LightSpeed`（光速）

| # | 条件 | 字面量 | 分支 |
|---|---|---|---|
| 1 | QT `"120爆发"` | `ldstr` | false → `-10` |
| 2 | `GetSpell(3606).Charges >= 1` | `ldc.i4 3606`,`ldc.r4 1` | false → `-99` |
| 3 | 读 `divCD = MemApiSpell::GetCooldown(16552).TotalMilliseconds` 与 `lightspeedTime = MemApiBuff::GetAuraTimeleft(Me,841,true)` | `ldc.i4 16552`,`ldc.i4 841` | — |
| 4 | `divCD < 3000 && lightspeedTime < 5000` | `ldc.r8 3000`,`ldc.r8 5000` | 两者都满足 → `0`，否则 `-1` |

`Build`：`slot.Add(new Spell(3606, Me))`。（没有 15s `RecentlyUsed`、没有 GCD 检查、没有 debuff 检查。）

### 2.3.6 `Ability.Oracle`（神谕）

`QT停输出`→`-1`；`RecentlyUsed(GetSpell(16552), 1000)`（`ldc.i4 1000`）→`-20`；`IsTargetVisibleOrInRange(37029, GetCurrTarget())` 假→`-99`；`HasAura(Me,3893)` 真→`0`；否则 `-1`。`Build`：`slot.Add(GetSpell(37029))`。

### 2.3.7 `Ability.Ast_LucidDreaming`（醒梦）

`!IsReadyWithCanCast(7562)`→`-1`；`GCDHelper::GetGCDCooldown() < 600`（`ldc.i4 600`）→`-7`；`CurrentMp > 8000`（`ldc.i4 8000`）→`-2`；否则 `0`。`Build` 入槽 7562。构造参数 `ldc.i4.2`。

### 2.3.8 `Ability.AST_Resurrect`

仅有 `Target()`：`ACRTargetHelper::FindResurrectTargetForward()`（**框架体缺**）。该类无 `Check`/`Build`（由 JobView/复活机制驱动）。

### 2.3.9 `GCD.AutoGCDHeal`（自动 GCD 群奶）

| # | 条件 | 字面量 | 分支 |
|---|---|---|---|
| 1 | `Level >= 10` | `ldc.i4.s 10` | false → `-99` |
| 2 | QT `"自动GCD群奶"` | `ldstr` | false → `-3` |
| 3 | 若 `MemApiMove::IsMoving` 且无 aura `167` 且无 aura `841` | `ldc.i4 167/841` | `-20` |
| 4 | `符合阈值人数 = FrameCache::CastableAlliesWithin15` 中 `CurrentHp > 0 && CurrentHpPercent <= GCD群奶治疗阈值`，且 `GCD群奶排除T目标` 为真时跳过坦克 | `ldc.i4.0` | — |
| 5 | `符合阈值人数 >= GCD群奶治疗人数` | | false → `-4`，true → `0` |

`Build`：若 `QuestManager::IsQuestComplete(67551)`（`ldc.i4 67551`）且（有 aura `836` 或 aura `3894`）且 `!RecentlyUsed(阳星相位, 3000)`（`ldc.i4 3000`）→ 入槽 `阳星相位`；否则入槽 `阳星`（两个属性体均**缺**；按 §2.5 的 id 表推断为 3601/3600）。

### 2.3.10 `GCD.Combust` / `GCD.ExtraCombust` / `GCD.Gravity` / `GCD.Malefic` / `GCD.Esuna`

| 类 | 条件（顺序） | id |
|---|---|---|
| `Combust` | `QT停输出`→-1；`QT DOT` 假→-2；目标有 aura `838`(剩余>4000) 或 `1881`(剩余>4000) → -3；`IsTargetVisibleOrInRange(3599, 当前目标)` 假→-99；否则 0。Build：`slot.Add(GetSpell(CheckActionChange(3599)))` | 3599 |
| `ExtraCombust`（双目标 DOT） | `QT停输出`→-1；`!QT双目标DOT`→-1；`!QT DOT`→-2；要求"血量 ≥ `Me.MaxHp * 15`（`ldc.i4.s 15`）的合格敌人"数量 `>= 3`（`ldc.i4.3`）→ 否则 -2；目标无效→-7、不可选中→-10；有 aura `838`/`1881`(>4000)→-3；有 aura `680`→-12；`HSS.utils.HSSBuff::敌人无敌BUFF`→-13；aura `942`→-14；aura `3621`→-15；`IsTargetVisibleOrInRange(3599)` 假→-99；否则 0 | 3599 |
| `Gravity` | `IsMoving && !aura167 && !aura841`→-20；`!QT AOE`→-1；`GetCurrTarget()==null`→-2；`!QT智能AOE` 且 `GetNearbyEnemiesCount(目标, 8f, true) >= 2` → `1`；`QT智能AOE` 且 `SmartTargetCircleAOE(2, 目标, 25f, 8f, 25872, true)` 后 `GetNearbyEnemiesCount(...,8f,true) >= 2` → `2`；否则 -99 | 25872（`ldc.i4 25872`） |
| `Malefic` | 移动且无 167/841→-20；`QT停输出`→-1；`IsTargetVisibleOrInRange(3599, 当前目标)` 假→-99；否则 0 | 3596（`CheckActionChange(3596)`） |
| `Esuna` | `FindDispelTargetForward()` 空→-2；`IsTargetVisibleOrInRange` 假→-3；遍历 `FrameCache::CastableAlliesWithin30` 找 `HasCanDispel`，有则 `QT康复` 真→`1`，否则 `-1` | 7568 |

### 2.3.11 触发器

| 类 | 行为 | 字面量 |
|---|---|---|
| `Trigggers.AST_UsePotionCheck` | `Handle` 返回 `ASTSettings.UsePotion`（默认 false） | — |
| `Trigggers.Play_I` | 设 `NextSlot = new Slot(600)`（`ldc.i4 600`）；若 `DrawnCards` 含 1 → `Slot::Add(new Spell(37023, GetFirstValidTarget(true,37023)))` 并 Toast（`ldc.i4.6`,`ldc.i4.1`,`ldc.i4.2`,`ldc.i4 3000`）；否则若含 4 → `Spell(37026, GetFirstValidTarget(false,37026))`；始终返回 1 | 37023/37026/600/3000 |
| `Trigggers.Lady_of_Crowns` | `BattleData.NextSlot = new Slot(600)`；若 `DrawnCrownCard == 8` → `AddSpell2NextSlot(new Spell(7445, Me))` 返回 1；否则若 `SwiftCast` 勾选且 `IsReadyWithCanCast(7561)` → `AddSpell2NextSlot(new Spell(7561, Me))`；再 `AddSpell2NextSlot(new Spell(CheckActionChange(3600), Me))`（阳星） | 600/7445/7561/3600 |
| `Triggers.AST_QT` | `JobViewWindow.SetQt(ValueName, Value)`；返回 1 | — |
| `Triggers.NewQt` | 批量 `SetQt`（用户自选 QT 列表） | — |

### 2.3.12 目标选择（S 的"发卡目标"）

- `ASTSettings::GetFirstValidTarget(bool isSolar, uint actionid)`：先算 `allMembersHaveAura`（遍历 `FrameCache::Party`，`HasAnyAura(IDs, 0)`，`ldc.i4.0`）；再按 `isSolar ? SolarPriorityJobs : WandererPriorityJobs` 顺序，用 `GetPartyMemberByJob(job)` 取人；要求非空、`IsValid`、`IsTargetable`、非 `IsDead`、`ACR3._0.ACRTargetHelper::IsTargetVisibleOrInRange(actionid, member)`；并且 **`allMembersHaveAura` 为真 或 该成员不携带 `IDs` 中的减益** → 命中返回。**【推】"全体都有减益时放弃黑头过滤"这一量词由过滤视图推得（`brtrue` 结构），原始栈序被删减。**
- `GetPartyMemberByJob(job)`：`FrameCache::Party` 中 `IsValid && IsTargetable && !IsDead && CurrentJob == job` 的第一个。
- `JobTranslations`（`ldstr` + `ldc.i4.s`）：`33=占星,34=武士,27=召唤,23=诗人,38=舞者,22=龙骑,37=枪刃,31=机工,20=武僧,30=忍者,19=骑士,39=镰刀,40=贤者,28=学者,21=战士,25=黑魔,32=黑骑,35=赤魔,24=白魔,36=青魔,41=蝰蛇,42=画家`。
- `ACR.Ast.*` 四个 hotkey/包装类：`Aspected_Benefic.spellid = 3595`；`Celestial_Intersection.spellid = 16556`；`Essential_Dignity.spellid = 3614`；`Helios_Conjunction.spellid = MemApiSpell::CheckActionChange(37030)`；四者的 `Target()` 都是遍历 `FrameCache::CastableAlliesWithin30` 取 `CurrentHp > 0 && IsTargetable && IsValid && CurrentHpPercent < bestHpPercent`（初始 `ldc.r4 3.4028235E+38`）的最低血；`Aspected_Benefic.Target` 额外要求 `!HasAura(835)`；找不到时返回 `Me`。

---

# 三、两套参考实现的差异

1. **最低等级/入口**：Y `MinLevel=0`、有 1 个 SlotSequence（`占星奶满策略`）、38 个已发布的有序解析器；S `MinLevel=70`、`AddSlotSequences(Array.Empty())`、**有序解析器清单不在 dump 中**（不可确证）。
2. **抽卡**：Y 有完整的 55s/56s/67s 冷却窗口状态机、`RecentlyUsed(37017/37018,55000)`、入队节流 1200ms、副本内强制抽卡（1500ms）、`Level>=70 && 领主在手` 时不抽；S 只有 `Level>=30`、`IsReadyWithCanCast(spellid)`、领主/贵妇/太阳神/战争神在手时否决，**完全没有冷却窗口与时间节流**。
3. **出卡/发卡目标**：Y 有 `发卡模式`（1=优先级顺序 / 2=指定名字）、自定义近战/远程顺序表、`卡1排除黑头玩家`、`存在更好的发卡目标`、黑头检测（aura `1793` 需剩余 ≤600s 才算）；S 只有 `SolarPriorityJobs` / `WandererPriorityJobs` 两张 Jobs 列表 + `IDs` 减益过滤，**没有"指定玩家名"模式，也没有近战/远程两套顺序**。
4. **世界树/放浪神**：Y 的 `出卡2` 用 `放浪神对齐` 找**学者(ClassJob RowId 28) 且带 aura 1896（连环计）** 者，并把优先级从 1 抬到 50；S 完全没有该概念（`Play_I` 只看 `DrawnCards` 是否含 1/4）。
5. **小奥秘卡**：Y 有 `小奥秘卡` 解析器（领主/贵妇分别判定，含 `RecentlyUsed(37022/7444/7445,5000)`、日随模式分支、`ShouldWaitDivination(2000)`、`HasCriticalTank(贵妇卡阈值)`）；S 只有 `Lady_of_Crowns` 触发器：`DrawnCrownCard==8` 就打贵妇，否则（勾选"即刻"且即刻可用时先即刻）打**阳星**。
6. **地星**：Y 有完整条件网（QT、学派 aura 1224/1248、`GCDHelper::CanUseOffGcd`、`HasBossCastingAoeWithin(10000)`、`地星阈值`、`地星优先场中/开挂模式/优先目标位置` 的地面位置解算、优先级 25/30/35/50/60）；S **完全没有地星代码**（`ACR.AST` 内无该类）。
7. **星体爆轰**：Y 用 id **8324**、`RecentlyUsed(8324,2500)`、阈值 `星体爆轰阈值`（默认 60）+ `天宫图阈值`（默认 75）、仅黑夜学派 aura 1248 生效、`日随模式` 特殊分支（boss<5%、杂兵均血<20%）；S 无。
8. **中间学派/阳星合相**：Y 有 `中间学派` 解析器（`中间学派阈值`、aura 2718/1892/3895/3896/849、`RecentlyUsed(25874,5000)`、`CountAlliesWithoutNeutralSectShield`、pending 标志）与独立的 `阳星合相` GCD 解析器（70/80/85/90/50 多档）；S **只用 `阳星/阳星相位`（`AutoGCDHeal` 与 `Lady_of_Crowns`），没有中间学派/阳星合相/护盾 pending 逻辑**。
9. **天宫图**：Y 三档（aura 1890/1891/16557 本体）+ `GroupHealTriggerCount()` + `(天宫图阈值-35)/100` 的提前段；S 只有"二段引爆"（`天宫图二段` QT + `天宫图治疗阈值` + `天宫图提前群奶治疗人数`，默认 0.5 / 2），是否出第一段由其他机制（`Lady_of_Crowns` 打阳星等）驱动。
10. **GCD 群奶阈值**：Y 用整数百分数（`GCD群奶阈值=55`、`GCD单奶阈值=40`、`群奶人数=2`）；S 用浮点比例（`GCD群奶治疗阈值=0.5`、`GCD群奶治疗人数=2`），并且 S 默认 **排除坦克**（`GCD群奶排除T目标=1`、`天宫图排除T目标=1`），Y 的对应字段默认 0/无该字段。
11. **减益（黑头）判定**：Y 用 `Helper::IsDamageDown`（`伤害降低类Buff合集`，27 个 id，含 `1793` 的 600s 例外）+ `卡1排除黑头玩家`；S 用自己静态 `IDs`（16 个 id：`62,215,628,692,696,1016,1090,2092,2404,2522,2911,3166,3304,3964,43,44`），且只在 `GetFirstValidTarget` 里用，**没有 1793 的剩余时间例外**。
12. **学派（白昼/黑夜）**：两套都只在少数处引用 aura `1224`/`1248`（Y：地星、星体爆轰、阳星/阳星合相 的 `-222`/`-1` 守卫；S：完全不引用）。两套都**没有**根据学派切换技能的逻辑（没有 3595/3601 之外的学派分支）。
13. **康复**：Y 有 `GCD.康复`（`H1` 决定扫描方向）+ `GCD.绝亚康复`（仅 `GetCurrTerrId()==887`，用 `IsTemporalStasisTarget` = aura `938` 或 `700`）；S 只有通用 `GCD.Esuna`（`FindDispelTargetForward` + `HasCanDispel` + `QT康复`）。
14. **醒梦**：Y 用 `醒梦阈值`（默认 8000、可被时间轴改、`Check` 返回 0）；S 硬编码 `8000` + `GCDHelper::GetGCDCooldown() >= 600`。
15. **大宇宙/宏观宇宙**：Y 有独立 GCD 解析器（6/3 敌人分档、`ShouldWaitDivination()` 2000ms、aura 849/1892/3895 与 `RecentlyUsed(16559,5000)` 守卫、优先级 30/44/60）；S **无大宇宙**。
16. **复活**：Y 用共享 `HealerRaiseResolver`（id 3603、`CanUseLightspeedForRaise`：`Level >= 6`(`ldc.i4.6`)、`IsReady(3606)`、无 aura `167`、无 aura `841`）与 `HealerPasserbyRaiseResolver`（job 33、id 3603、消息 `"占星生辰"`、-999、3606）；S 只有 `AST_Resurrect.Target()` → `FindResurrectTargetForward()`。

---

# 四、无法确证的部分（dump 中没有方法体 / 只能给出调用方传参）

**A. 属性 getter 系统性缺失**（调用点存在，`get_*` 方法体在 `.il.txt` 与 `.core.txt`、以及 `.il\cls_*\` 单类文件中都不存在）：

| 属性（Y） | 用在何处 | 影响 |
|---|---|---|
| `AstrologianTools::CurrentTarget` | 几乎所有解析器 | 实际取目标策略未知（疑为 `Me.GetCurrTarget()`）【推】 |
| `AstrologianTools::DrawnCrownCard` | 抽卡/出卡/时间轴 | 返回 7/8 的判定对象未知（疑为 `JobApi_Astrologian.DrawnCrownCard`）【推】 |
| `AstrologianTools::MoveStartTimeMs` | DOT/光速走位/即刻走位 | 由 `Movement`(HealerMovementRuntimeState) 维护，`Update` 体在 dump 中但具体时间戳语义未能直接读出 |
| `EssentialDignityCharges` / `LightSpeedCharges` / `CelestialIntersectionCharges` | 时间轴条件 | 疑为 `ActionCharges(3614/3606/16556)`【推】 |
| `NeutralSectShieldPending` | 吉星相位/阳星合相 | 与 `neutralSectShieldPending` 静态字段对应【推】 |
| `AspectedBeneficBleedShieldStatuses` | `CountAspectedBeneficBleedShields` | **数组用 `RuntimeHelpers::InitializeArray` 初始化，3 个流血盾 id 无法从 IL 读取**【缺】 |
| `Resolvers.GCD.双DOT::get_DotActionId`（继承自 `HealerDoubleDotResolverBase`） | 双DOT Build | 实际施放的 DOT id 未知【缺】（其余逻辑证明会用 `HealerDotCastTracker::MarkPending`） |

**B. S 侧缺失**：`Ability.GetCard::get_spellid`、`GCD.AutoGCDHeal::get_阳星`、`get_阳星相位`、`Ability.Horoscope::get_天宫图`、`get_天宫图buff`、`HealerDoubleDotResolverBase::get_DotActionId` 等——**属性体全部不在 dump**。因此 S 的抽卡实际 id（37017/37018？）、阳星/阳星相位 id（3600/3601？）、天宫图 id（16557/16558？）**只能按工作区 `dump_actions.tsv` 的技能 id 表推断，不能算作 IL 证据**。

**C. 过滤/委托体缺失（Y）**：`<>c::<获取候选者ID_太阳神>b__45_0..5`、`<获取候选者ID_战争神>b__46_0..5`、`<排序候选者>b__34_0/1`、`<SelectBoleTarget>b__7_0`、`<SelectSpireTarget>b__5_0/5_1`、`<GetDamageDownStatuses>b__13_0..4`、`<>c__DisplayClass28_0::<从候选表取第一个_按黑头策略>b__0`、`空起手/占星3GCD前半起手` 的倒计时 spell 工厂、`HSS` 相关委托 —— 这些 lambda/委托的**过滤谓词与工厂返回值不在 dump**，因此"太阳神/战争神候选者的三级过滤条件"与"两处 `SelectLowestTank` 的谓词"无法逐条复现。

**D. 框架内部未在 dump**（调用方参数已给出，内部实现未知）：
- `AEAssist.Helper.SpellExtension::RecentlyUsed` / `IsReadyWithCanCast`（`HealerActionHelper::RecentlyUsed` 只是转调）
- `AEAssist.Helper.SpellHistoryHelper::RecentlyUsed`
- `AEAssist.Helper.GCDHelper::{CanUseOffGcd, GetGCDDuration, GetElapsedGCD, GetGCDCooldown}`
- `AEAssist.Helper.TargetHelper::{IsBoss, GetNearbyEnemyCount}`
- `AEAssist.CombatRoutine.Module.Target.TargetMgr::{Enemys, EnemysIn25, TargetStats/*DeathPrediction*/}`
- `Avarice`/`HSS.utils.HSSBuff`（S 侧 `敌人无敌BUFF` 的 id 表）
- Y 侧 `FrameCache::*`、`TargetSelector`、`目标CastingIsBossAOE` 之类的名字**在 Y 的 IL 中并未出现**（Y 用 `ACR.Tool.Runtime.HealerEnemyTargetHelper` 自己的实现，已完整读出）；S 侧才用 `FrameCache::get_CastableAlliesWithin15/20/30`、`Avarice.Data.ActionWatching` 等外部实现（`FrameCache` 类头在 `shiyuvi.il.txt` 第 773 行有，但内容未展开）。
- `ACR3._0.ACRTargetHelper::{IsTargetVisibleOrInRange, GetNearbyEnemiesCount, SmartTargetCircleAOE, FindDispelTargetForward, FindResurrectTargetForward, FindDispelTarget}`：S 大量使用，**方法体不在 dump**，只知传入的 id/距离/范围参数。

**E. 逻辑层面无法确证的点**：
1. `ACR.Tool.Data.Status::禁止发动技能状态合集` 既不 `.cctor` 构建也无 getter 体 ⇒ `HasSkillSilenceStatus()`（两套的"禁技/沉默"守卫核心）**完整 id 集合未知**；只确证忽略表 `{17}`。
2. `流血BUFF`（295 项）与 `AspectedBeneficBleedShieldStatuses`（3 项）通过 RVA 数据块加载，**id 无法从 IL 读出** ⇒ 所有"流血"判定（`HasBleed`、`BleedTargetWithin20`、`天星交错`/`天星冲日` 的流血分支、`吉星相位` 的流血盾分支）的**具体触发状态未知**。
3. Y `出卡1::AddCard1IfNeeded` 中 `RecentlyUsed(1000)` 的 actionId 实参由栈传递，在过滤视图里丢失；原文（`占星3GCD前半起手::AddCard1IfNeeded`）需再看未过滤 IL 才能确定是"上一张出卡 id"还是 `Card1ActionId` 的结果。
4. Y `GCD.双DOT` 的 `DotActionId`、`CountTargets` 的候选判定（`CanDot` 已由 `CommonCanDot` 证明）→ 除 id 外均可复现。
5. S 的 `ASTRotationEventHandler::AfterSpell` 里那张 `switch` 跳转表对 `CurrGcdAbilityCount` 的分类（0/1/2）我按跳转目标读出，但过滤视图删掉了若干 `dup/branch`，**若需 100% 精确需回未过滤 IL 逐行核对**。
6. Y `未在 .ctor 赋值` 的字段（`高难模式`、`光速走位`、`移动中DOT延迟时间`、`即刻咏唱延迟时间`、`地星开挂模式`、`地星优先目标位置`、`Opener` 等）默认值我按 CLR 默认 0/false 报告——**它们的"实际默认"可能由设置 UI 或 `EnsureDefaults` 另行写入**，dump 中未见。

---

# 五、给复刻实现的要点清单（由上面 IL 直接可落地）

1. `Check()` 返回负值 = 放弃，正值 = 优先级；Y 的"总开关"是 QT `停手`（`AstrologianResolverBase::StopRequested`）。
2. 卡面 ↔ 出卡 id ↔ buff：`37023→CardType1/Balance/aura3887`、`37026→CardType4/Spear/aura3889`、`37024→3/Arrow`、`37027→2/Bole`、`37025→6/Spire`、`37028→5/Ewer`、`37019/37020/37021` = 出卡 I/II/III 基础 id。
3. 大奥秘卡按 `DrawnCard(0/1/2)` 三槽读；**"不能再抽"只在 0 号槽非空时成立**（`-7`）。
4. 领主/贵妇：`DrawnCrownCard 7=领主(7444)`、`8=贵妇(7445)`；`小奥秘卡` 主卡 37022。
5. 地星：`GroundCastPosition(地星优先场中, 地星开挂模式, targetHitbox<15f && 地星优先目标位置, currentTarget)`；`MapCenter` 仅当中心与玩家距离²<900（`ldc.r4 900`）时可用。
6. 星体爆轰 = **8324**，且只在 aura `1248` 下由血量阈值触发（`星体爆轰阈值=60`、`天宫图阈值=75`）。
7. 两套的"已用/冷却"守卫大多转调 `SpellExtension::RecentlyUsed`（内部未知）与 `GCDHelper::*`（内部未知）：复刻时必须自行定义等价语义。
